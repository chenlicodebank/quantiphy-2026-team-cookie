import av, numpy as np, cv2
c=av.open('simulation_0053.mp4')
for fr in c.decode(video=0):
    img=fr.to_ndarray(format='bgr24'); break
g=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY).astype(float)
def fitcircle(pts):
    x,y=pts[:,0],pts[:,1]
    A=np.c_[2*x,2*y,np.ones(len(x))]; b=x**2+y**2
    s=np.linalg.lstsq(A,b,rcond=None)[0]
    return s[0],s[1],np.sqrt(s[2]+s[0]**2+s[1]**2)
out=img.copy()
for name,(x0,y0,x1,y1),thr in [('mid',(330,1020,540,1130),70),('bot',(380,1860,540,2048),70)]:
    sub=g[y0:y1,x0:x1]
    m=(sub<thr).astype(np.uint8)
    m=cv2.morphologyEx(m,cv2.MORPH_OPEN,np.ones((3,3),np.uint8))
    n,lab,st,cen=cv2.connectedComponentsWithStats(m)
    print(name,[ (st[i].tolist(),cen[i].round(1).tolist()) for i in range(1,n) if st[i,4]>200])
    cnts,_=cv2.findContours(m,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_NONE)
    cnt=max(cnts,key=cv2.contourArea)[:,0,:].astype(float)+[x0,y0]
    # pick contour points on the right side (disk edge, away from pole/head)
    if name=='mid':
        sel=cnt[cnt[:,0]>470]
    else:
        sel=cnt[(cnt[:,1]<1945)&((cnt[:,0]>480)|(cnt[:,1]<1900))]
    cx,cy,r=fitcircle(sel)
    res=np.hypot(sel[:,0]-cx,sel[:,1]-cy)-r
    print(name,'circle',round(cx,1),round(cy,1),'r',round(r,1),'rms',res.std().round(2),len(sel))
    cv2.circle(out,(int(round(cx)),int(round(cy))),int(round(r)),(0,0,255),1)
    cv2.circle(out,(int(round(cx)),int(round(cy))),2,(0,255,0),-1)
    for p in sel.astype(int): out[p[1],p[0]]=(0,255,255)
cv2.imwrite('frames/lamp_mid_fit.png',cv2.resize(out[1000:1150,320:560],None,fx=4,fy=4,interpolation=cv2.INTER_NEAREST))
cv2.imwrite('frames/lamp_bot_fit.png',cv2.resize(out[1850:2048,360:560],None,fx=4,fy=4,interpolation=cv2.INTER_NEAREST))
