import pandas as pd, numpy as np
d=pd.read_csv('scene/tracks/orange_car.csv'); d=d[d.ref_reliable==1]
f=d.frame.values; x=d.ref_x.values; y=d.ref_y.values
for lo,hi in [(17,90),(17,50),(50,90),(30,70)]:
    m=(f>=lo)&(f<=hi)
    py=np.polyfit(f[m],y[m],2); px=np.polyfit(f[m],x[m],2)
    res=y[m]-np.polyval(py,f[m])
    print(lo,hi,'ay px/fr2',2*py[0],'ax',2*px[0],'rms',res.std(), 'a px/s2',2*py[0]*900)
s=np.hypot(np.diff(x),np.diff(y)); fs=f[1:]
print(np.round(s,2))
print('speed slope px/s2', np.polyfit(fs,s,1)[0]*900)
