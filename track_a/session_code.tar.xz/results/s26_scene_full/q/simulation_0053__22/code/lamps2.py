import av, numpy as np, cv2
c=av.open('simulation_0053.mp4')
for fr in c.decode(video=0):
    img=fr.to_ndarray(format='bgr24'); break
g=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY).astype(float)
def fitcircle(pts):
    x,y=pts[:,0],pts[:,1]
    A=np.c_[2*x,2*y,np.ones(len(x))]; b=x**2+y**2
    s=np.linalg.lstsq(A,b,rcond=None)[0]
    return s[0],s[1],np.sqrt(s[2]+s[0]**2+s[1]**2)
# radial edge search from a seed centre: find where gray crosses threshold
def radial(seed,angles,thr,rmax=40):
    pts=[]
    for a in angles:
        for r in np.arange(5,rmax,0.25):
            x=seed[0]+r*np.cos(a); y=seed[1]+r*np.sin(a)
            v=cv2.getRectSubPix(g.astype(np.float32),(1,1),(x,y))[0,0]
            if v>thr: pts.append((x,y)); break
    return np.array(pts)
for name,seed,angs in [('mid',(495,1064),np.deg2rad(np.arange(-120,121,5))),
                       ('bot',(497,1910),np.deg2rad(np.arange(-150,61,5)))]:
    for thr in (50,60,75):
        p=radial(seed,angs,thr)
        cx,cy,r=fitcircle(p); res=np.hypot(p[:,0]-cx,p[:,1]-cy)-r
        print(name,thr,round(cx,1),round(cy,1),'r',round(r,1),'rms',res.std().round(2))
print('bg levels mid', np.median(g[1040:1090,530:545]), 'bot', np.median(g[1880:1940,525:540]))
