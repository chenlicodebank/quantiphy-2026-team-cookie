import numpy as np, av, csv
V = '/private/tmp/qp_blind/scene_full_b/simulation_0073/q_53/simulation_0073.mp4'

def frames(idx):
    out = {}
    c = av.open(V)
    for i, f in enumerate(c.decode(video=0)):
        if i in idx:
            out[i] = f.to_ndarray(format='rgb24').astype(float)
        if i > max(idx): break
    c.close()
    return out

# --- cyclist speed from track (linear fit) ---
rows = list(csv.DictReader(open('scene/tracks/cyclist.csv')))
fr = np.array([int(r['frame']) for r in rows]); cy = np.array([float(r['cy_px']) for r in rows])
cx = np.array([float(r['cx_px']) for r in rows])
m = fr >= 1
p = np.polyfit(fr[m], cy[m], 1); print('centroid fit slope px/frame', p[0])
# bbox top / bottom slopes
for k in ['y0', 'y1']:
    key = [c for c in rows[0].keys() if c.endswith(k) or c == k]
    print(rows[0].keys()); break

F = frames({0, 10, 20, 30, 40, 50, 60, 71})
# --- template matching of the cyclist between frames for a second route ---
import cv2
g = {i: cv2.cvtColor(F[i].astype(np.uint8), cv2.COLOR_RGB2GRAY) for i in F}
# template around cyclist at frame 10
def cyc_pos(i):
    j = np.argmin(abs(fr - i)); return cx[j], cy[j]
x10, y10 = cyc_pos(10)
T = g[10][int(y10) - 40:int(y10) + 40, int(x10) - 20:int(x10) + 20]
ys = []
for i in [10, 20, 30, 40, 50, 60, 71]:
    xi, yi = cyc_pos(i)
    y0 = int(yi) - 80; x0 = int(xi) - 50
    S = g[i][y0:y0 + 160, x0:x0 + 100]
    R = cv2.matchTemplate(S, T, cv2.TM_CCOEFF_NORMED)
    _, mv, _, ml = cv2.minMaxLoc(R)
    # subpixel in y
    yy, xx = ml[1], ml[0]
    if 0 < yy < R.shape[0] - 1:
        a, b, c = R[yy - 1, xx], R[yy, xx], R[yy + 1, xx]
        off = 0.5 * (a - c) / (a - 2 * b + c)
    else: off = 0
    ys.append((i, y0 + yy + off, mv))
ys = np.array(ys); print(ys)
q = np.polyfit(ys[:, 0], ys[:, 1], 1); print('template slope px/frame', q[0])

# --- brown squares: profile of colour difference from sidewalk ---
img = F[0]
def edges(cx0, cy0, half=60):
    sub = img[int(cy0) - half:int(cy0) + half, int(cx0) - half:int(cx0) + half]
    side = np.median(np.concatenate([sub[:5].reshape(-1, 3), sub[-5:].reshape(-1, 3)]), axis=0)
    d = np.linalg.norm(sub - side, axis=2)
    colp = d[half - 25:half + 25].mean(axis=0)  # x profile
    rowp = d[:, half - 25:half + 25].mean(axis=1)  # y profile
    res = []
    for prof in (colp, rowp):
        thr = 0.5 * (prof.max() + np.median(prof[:8]))
        idx = np.where(prof > thr)[0]
        # subpixel crossings
        a = idx[0]; b = idx[-1]
        l = a - 1 + (thr - prof[a - 1]) / (prof[a] - prof[a - 1])
        r = b + (prof[b] - thr) / (prof[b] - prof[b + 1])
        res.append(r - l)
    return res, d
for name, (x, y) in {'TL': (411, 222.5), 'BL': (411, 849), 'BR': (1217, 845.5)}.items():
    (wx, wy), d = edges(x, y, 60 if name != 'dark' else 60)
    print(name, 'width x %.1f  height y %.1f' % (wx, wy))
    cv2.imwrite(f'frames/d_{name}.png', np.clip(d * 3, 0, 255).astype(np.uint8))
