import numpy as np, av
V = 'simulation_0073.mp4'
c = av.open(V)
for i, f in enumerate(c.decode(video=0)):
    if i == 0:
        img = f.to_ndarray(format='rgb24').astype(float); break
c.close()
lum = img.mean(axis=2)

def subpix(prof, k):
    if 0 < k < len(prof) - 1:
        a, b, cc = prof[k - 1], prof[k], prof[k + 1]
        den = a - 2 * b + cc
        return k + (0.5 * (a - cc) / den if den != 0 else 0)
    return k

def measure(cx0, cy0, half=70):
    x0, y0 = int(cx0) - half, int(cy0) - half
    sub = lum[y0:y0 + 2 * half, x0:x0 + 2 * half]
    out = {}
    for name, prof in (('x', sub[half - 25:half + 25].mean(axis=0)), ('y', sub[:, half - 25:half + 25].mean(axis=1))):
        g = np.gradient(prof)
        L = subpix(-g, int(np.argmax(-g[:half])))          # bright sidewalk -> dark patch
        R = subpix(g, int(np.argmax(g[half:])) + half)       # dark patch -> bright sidewalk
        # half-level crossing
        side = np.median(np.r_[prof[:10], prof[-10:]]); inside = np.median(prof[half - 20:half + 20])
        thr = 0.5 * (side + inside)
        idx = np.where(prof < thr)[0]
        a, b = idx[0], idx[-1]
        l = a - 1 + (prof[a - 1] - thr) / (prof[a - 1] - prof[a])
        r = b + (thr - prof[b]) / (prof[b + 1] - prof[b])
        out[name] = (R - L, r - l, x0 + l if name == 'x' else y0 + l)
    return out

for name, (x, y) in {'TL': (411, 222.5), 'BL': (411, 849), 'BR': (1217, 845.5)}.items():
    o = measure(x, y)
    print(name, {k: ('grad %.1f  half %.1f' % v[:2]) for k, v in o.items()})
