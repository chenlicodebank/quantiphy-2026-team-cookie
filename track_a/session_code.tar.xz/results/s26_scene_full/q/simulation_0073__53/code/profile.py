import numpy as np, av
c = av.open('simulation_0073.mp4')
for i, f in enumerate(c.decode(video=0)):
    img = f.to_ndarray(format='rgb24').astype(int); break
c.close()
# BL square, horizontal profile through middle rows, and vertical profile
rows = img[829:869, 355:470].mean(axis=0)
for k, v in enumerate(rows):
    if k < 25 or k > 85: print('x', 355 + k, np.round(v).astype(int))
cols = img[795:905, 391:431].mean(axis=1)
for k, v in enumerate(cols):
    if k < 25 or k > 80: print('y', 795 + k, np.round(v).astype(int))
