import av, numpy as np, cv2, csv
# track several boat points (different heights / image rows) -> straight trajectories -> vanishing point of the motion
V='simulation_0041.mp4'
rows={int(r['frame']):r for r in csv.DictReader(open('scene/tracks/boat.csv'))}
cx0,cy0=float(rows[30]['ref_x']),float(rows[30]['ref_y'])
P={'masttip':(323,797),'roof':(300,872),'bowtip':(192,882),'hatch':(250,903),'window':(318,935),
   'green':(410,955),'stern':(500,985),'hull_wl':(420,1018),'hull_wl2':(330,1003),'rail_far':(470,935)}
half=10; srch=6
fr30=None; tracks={k:[] for k in P}
frames=list(range(2,63))
with av.open(V) as c:
    for i,f in enumerate(c.decode(video=0)):
        if i==30: fr30=cv2.cvtColor(f.to_ndarray(format='rgb24'),cv2.COLOR_RGB2GRAY).astype(np.float32)
        if i>30: break
T={k:fr30[y-half:y+half+1,x-half:x+half+1] for k,(x,y) in P.items()}
with av.open(V) as c:
    for i,f in enumerate(c.decode(video=0)):
        if i not in frames: continue
        g=cv2.cvtColor(f.to_ndarray(format='rgb24'),cv2.COLOR_RGB2GRAY).astype(np.float32)
        dx=float(rows[i]['ref_x'])-cx0; dy=float(rows[i]['ref_y'])-cy0
        for k,(x,y) in P.items():
            px=int(round(x+dx)); py=int(round(y+dy))
            if px-half-srch<0 or px+half+srch+1>1080 or py+half+srch+1>1080: continue
            S=g[py-half-srch:py+half+srch+1,px-half-srch:px+half+srch+1]
            m=cv2.matchTemplate(S,T[k],cv2.TM_CCOEFF_NORMED)
            _,mv,_,ml=cv2.minMaxLoc(m)
            j,ii=ml
            def sub(a,b,c_):
                den=a-2*b+c_; return 0.5*(a-c_)/den if den!=0 else 0
            ox=sub(m[ii,j-1],m[ii,j],m[ii,j+1]) if 0<j<m.shape[1]-1 else 0
            oy=sub(m[ii-1,j],m[ii,j],m[ii+1,j]) if 0<ii<m.shape[0]-1 else 0
            tracks[k].append((i,px-srch+j+ox,py-srch+ii+oy,mv))
lines=[]
for k,tr in tracks.items():
    a=np.array(tr)
    ok=a[:,3]>0.8
    xy=a[ok,1:3]; m=xy.mean(0)
    U,S,Vt=np.linalg.svd(xy-m); d=Vt[0]; nrm=Vt[1]
    r=(xy-m)@nrm
    ang=np.degrees(np.arctan2(d[1],d[0])); ang=ang if ang<90 else ang-180
    ang=ang if ang>-90 else ang+180
    print('%-9s y=%.0f  n=%d angle=%.3f deg  resid=%.3f px  minNCC=%.2f'%(k,m[1],ok.sum(),ang,r.std(),a[:,3].min()))
    lines.append((k,m,d,nrm,r.std(),ok.sum()))
np.save('vp_lines.npy',np.array([(m[0],m[1],d[0],d[1],nrm[0],nrm[1],s,n) for k,m,d,nrm,s,n in lines]))
# least-squares intersection: minimise sum ((p-m).n)^2 weighted
A=np.zeros((2,2)); b=np.zeros(2)
for k,m,d,nrm,s,n in lines:
    w=n/max(s,0.05)**2
    A+=w*np.outer(nrm,nrm); b+=w*np.outer(nrm,nrm)@m
vp=np.linalg.solve(A,b)
print('VP of motion: x=%.0f y=%.0f'%tuple(vp))
# angle vs y regression: tan(angle) ~ linear in y?  for lines through VP: dy/dx = (y - yv)/(x - xv)
ys=np.array([m[1] for k,m,d,nrm,s,n in lines]); sl=np.array([d[1]/d[0] for k,m,d,nrm,s,n in lines]); xs=np.array([m[0] for k,m,d,nrm,s,n in lines])
print(np.c_[xs.round(0),ys.round(0),np.degrees(np.arctan(sl)).round(3)])
