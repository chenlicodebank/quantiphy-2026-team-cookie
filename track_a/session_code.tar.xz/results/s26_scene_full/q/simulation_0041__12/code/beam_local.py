import numpy as np, sys
import beam
from pinhole import cam
# max beam with the centre line interpolated locally between the last bow chord and the first aft chord
beam.ZD=0.8; beam.DMIN=0.17
def run(th,zd=0.8,dmin=0.17,verbose=False):
    beam.ZD=zd; beam.DMIN=dmin
    th_r=np.radians(th); f=4523/np.tan(th_r)
    r=beam.solve(th); h=r['h']
    proj,back=cam(th_r,f,h)
    N=np.array([back(x,y,zd)[:2] for x,y in beam.near])
    F1=np.array([back(x,y,zd)[:2] for x,y in beam.farbow]); F2=np.array([back(x,y,zd)[:2] for x,y in beam.farmid])
    phi=np.radians(r['phi'])
    ax=np.array([np.cos(phi),-np.sin(phi)]); bm=np.array([np.sin(phi),np.cos(phi)])
    sN,lN=N@ax,N@bm; sb=sN.min()
    pieces=[]
    for F in (F1,F2):
        sF,lF=F@ax,F@bm; o=np.argsort(sF); res=[]
        for s_,l_ in zip(sN,lN):
            if sF.min()<=s_<=sF.max():
                lf=np.interp(s_,sF[o],lF[o]); res.append((s_,lf-l_,(lf+l_)/2))
        pieces.append(np.array(res))
    b,a=pieces
    # local linear fits of the midpoint on each side (last 1 m of bow piece, first 1 m of aft piece)
    bb=b[b[:,0]>b[:,0].max()-1.0]; aa=a[a[:,0]<a[:,0].min()+1.0]
    pb=np.polyfit(bb[:,0],bb[:,2],1); pa=np.polyfit(aa[:,0],aa[:,2],1)
    s1,s2=b[:,0].max(),a[:,0].min()
    m1,m2=np.polyval(pb,s1),np.polyval(pa,s2)
    sel=(sN>s1)&(sN<s2)
    cl=m1+(sN[sel]-s1)*(m2-m1)/(s2-s1)
    w=2*(cl-lN[sel])
    o=np.argsort(sN[sel]); ws=np.convolve(w[o],np.ones(7)/7,mode='valid')
    if verbose:
        ss=sN[sel][o]
        for j in range(0,len(o),6): print('   station %.2f width %.3f'%(ss[j]-sb,w[o][j]))
    return r,max(b[:,1].max(),a[:,1].max()),w.max(),ws.max()
if __name__=='__main__':
    for th in (32,33,34,34.5,35,36):
        r,ch,wm,ws=run(th)
        print('theta=%.1f s_boat=%.2f  max visible chord %.3f  hidden-midship max %.3f (smoothed %.3f)'%(th,r['s_b'],ch,wm,ws))
    run(34.5,verbose=True)
    for zd in (0.5,1.2):
        for dm in (0.10,0.25):
            r,ch,wm,ws=run(34.5,zd,dm)
            print('theta=34.5 zd=%.1f dmin=%.2f -> s_person=%.2f chord %.3f mid-max %.3f (sm %.3f)'%(zd,dm,r['s_p'],ch,wm,ws))
