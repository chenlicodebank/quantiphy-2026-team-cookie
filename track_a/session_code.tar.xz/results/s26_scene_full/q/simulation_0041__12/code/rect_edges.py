import av, numpy as np, cv2, sys
# sub-pixel line fits of rectangle edges (hatch top face, cabin roof eaves) -> camera tilt (c = cos(theta))
V='simulation_0041.mp4'
FR=int(sys.argv[1]) if len(sys.argv)>1 else 30
DX=float(sys.argv[2]) if len(sys.argv)>2 else 0.0
DY=float(sys.argv[3]) if len(sys.argv)>3 else 0.0
with av.open(V) as c:
    for i,f in enumerate(c.decode(video=0)):
        if i==FR: img=f.to_ndarray(format='rgb24').astype(np.float32); break
g=cv2.GaussianBlur(img.mean(axis=2),(0,0),0.7)
def fit_edge(p0,p1,trim=0.2,half=3.0):
    p0=np.array(p0,float)+[DX,DY]; p1=np.array(p1,float)+[DX,DY]
    d=p1-p0; L=np.linalg.norm(d); u=d/L; n=np.array([-u[1],u[0]])
    pts=[]
    for t in np.arange(trim*L,(1-trim)*L,0.5):
        c0=p0+u*t
        offs=np.arange(-half,half+0.01,0.25)
        xs=(c0[0]+offs*n[0]).astype(np.float32); ys=(c0[1]+offs*n[1]).astype(np.float32)
        prof=cv2.remap(g,xs[None,:],ys[None,:],cv2.INTER_CUBIC)[0]
        gr=np.abs(np.gradient(prof))
        k=int(np.argmax(gr))
        if 0<k<len(gr)-1:
            a,b,cc=gr[k-1],gr[k],gr[k+1]; dd=0.5*(a-cc)/(a-2*b+cc) if (a-2*b+cc)!=0 else 0
            pts.append(c0+n*(offs[k]+dd*0.25))
    pts=np.array(pts)
    m=pts.mean(0); U,S,Vt=np.linalg.svd(pts-m); dirv=Vt[0]
    if dirv[0]<0: dirv=-dirv
    r=(pts-m)@Vt[1]
    ang=np.degrees(np.arctan2(dirv[1],dirv[0]))
    return ang,r.std(),len(pts)
E={
 'hatch_top':((247,885),(270,891.5)),'hatch_bot':((234,916),(257,923)),
 'hatch_left':((234,916),(247,885)),'hatch_right':((257,923),(270,891.5)),
 'roof_near':((281.2,903.8),(340,920)),'roof_far':((298.8,860),(350,873.8)),
 'roof_front':((281,904),(299,860)),'roof_aft':((340,920),(357,879)),
}
A={}
for k,(p0,p1) in E.items():
    ang,rs,n=fit_edge(p0,p1)
    A[k]=ang
    print('%-12s angle %.2f deg  resid %.2f px  n=%d'%(k,ang,rs,n))
def c_of(a_ax,a_bm):
    v=-np.tan(np.radians(a_ax))*np.tan(np.radians(a_bm))
    return np.sqrt(v) if v>0 else np.nan
for name,ax,bm in (('hatch',('hatch_top','hatch_bot'),('hatch_left','hatch_right')),('roof',('roof_near','roof_far'),('roof_front','roof_aft'))):
    a=np.mean([A[k] for k in ax]); b=np.mean([A[k] for k in bm])
    # angles of 'beam' edges are around -67 deg (or 113): use direction going up-right
    if b>0: b=b-180
    c=c_of(a,b)
    print(name,'axis %.2f beam %.2f -> c=%.3f theta=%.1f deg'%(a,b,c,np.degrees(np.arccos(c))))
