import av, numpy as np, cv2
# near gunwale (top of red hull band) and far silhouette edge of the boat at frame 30
V='simulation_0041.mp4'
with av.open(V) as c:
    for i,f in enumerate(c.decode(video=0)):
        if i==30: img=f.to_ndarray(format='rgb24').astype(np.float32); break
R,G,B=img[...,0],img[...,1],img[...,2]
red=(R>120)&(R-G>60)&(R-B>60)
white=(R>150)&(G>150)&(B>150)&(np.abs(R-B)<45)
near=[]
for x in range(186,512):
    col=red[:,x]
    ys=np.where(col[880:1045])[0]+880
    if len(ys)==0: continue
    yb=ys.max()                     # waterline end of the hull band
    y=yb
    while y>860 and (red[y,x] or red[y-1,x] or red[y-2,x]): y-=1
    # y is now first non-red row above the band; refine with vertical gradient of (R-G)
    prof=(R-G)[y-3:y+5,x]
    d=np.diff(prof); k=int(np.argmax(d))
    near.append((x,y-3+k+0.5,yb))
near=np.array(near)
np.save('near_edge.npy',near)
for x,y,yb in near[::10]: print('near x=%d y_gunwale=%.1f y_waterline=%d band=%.1f'%(x,y,yb,yb-y))
# far silhouette edge for the bow (water above, white deck below)
far=[]
for x in range(186,290):
    col=white[860:900,x]
    ys=np.where(col)[0]
    if len(ys)==0: continue
    y0=ys.min()+860
    prof=img[y0-4:y0+3,x].mean(axis=1)
    d=np.diff(prof); k=int(np.argmax(d))
    far.append((x,y0-4+k+0.5))
far=np.array(far); np.save('far_bow.npy',far)
for x,y in far[::8]: print('far x=%d y=%.1f'%(x,y))
