import av, numpy as np, cv2, csv
V='simulation_0041.mp4'
want={2,30,58}
fr={}
with av.open(V) as c:
    for i,f in enumerate(c.decode(video=0)):
        if i in want: fr[i]=cv2.cvtColor(f.to_ndarray(format='rgb24'),cv2.COLOR_RGB2GRAY).astype(np.float32)
        if i>max(want): break
rows={int(r['frame']):r for r in csv.DictReader(open('scene/tracks/boat.csv'))}
def crop(i,pad=0):
    r=rows[i]; cx,cy=float(r['ref_x']),float(r['ref_y'])
    return cx,cy
# template: frame 30 boat region (hull only, below mast) bbox
r=rows[30]
x0,y0,x1,y1=int(r['bb_x0']),int(r['bb_y0']),int(r['bb_x1']),int(r['bb_y1'])
print('bb30',x0,y0,x1,y1)
T=fr[30][860:1035,180:520]
tc=np.array([(180+520)/2,(860+1035)/2])
for i in (2,58):
    cx,cy=float(rows[i]['ref_x'])-float(rows[30]['ref_x']),float(rows[i]['ref_y'])-float(rows[30]['ref_y'])
    best=None
    for s in np.arange(0.95,1.051,0.005):
        Ts=cv2.resize(T,None,fx=s,fy=s,interpolation=cv2.INTER_LINEAR)
        h,w=Ts.shape
        ccx,ccy=tc[0]+cx,tc[1]+cy
        X0=int(ccx-w/2-15);Y0=int(ccy-h/2-15)
        X0=max(X0,0);Y0=max(Y0,0)
        S=fr[i][Y0:min(Y0+h+30,1080),X0:min(X0+w+30,1080)]
        if S.shape[0]<h or S.shape[1]<w: continue
        m=cv2.matchTemplate(S,Ts,cv2.TM_CCOEFF_NORMED)
        v=m.max()
        if best is None or v>best[0]: best=(v,s)
        print(i,round(s,3),round(float(v),4))
    print('best',i,best)
