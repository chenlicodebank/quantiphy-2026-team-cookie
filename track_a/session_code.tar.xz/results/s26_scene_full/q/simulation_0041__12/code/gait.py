import numpy as np, csv
r=[x for x in csv.DictReader(open('scene/tracks/person.csv'))]
h=np.array([float(x['bb_h']) for x in r]); fy=np.array([float(x['feet_y']) for x in r]); ht=np.array([float(x['head_top_y']) for x in r])
w=np.array([float(x['bb_w']) for x in r]); cy=np.array([float(x['ref_y']) for x in r])
print(' '.join('%d'%v for v in h))
print('head_top', ' '.join('%d'%v for v in ht))
print('width', ' '.join('%d'%v for v in w))
# spectrum of detrended height (frames 1..71)
x=h[1:]-h[1:].mean(); n=len(x)
F=np.abs(np.fft.rfft(x*np.hanning(n),n=1024)); fr=np.fft.rfftfreq(1024)
k=np.argmax(F[5:])+5
print('dominant period %.2f frames'%(1/fr[k]))
# head-top y detrended (bobbing, 2 per stride)
p=np.polyfit(np.arange(72),ht,1); hd=ht-np.polyval(p,np.arange(72))
F2=np.abs(np.fft.rfft(hd[1:]*np.hanning(71),n=1024)); k2=np.argmax(F2[5:])+5
print('head bob period %.2f frames'%(1/fr[k2]))
pc=np.polyfit(np.arange(2,72),cy[2:],1); print('centroid vy %.3f px/frame'%pc[0])
