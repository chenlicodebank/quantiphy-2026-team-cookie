import numpy as np
L=np.load('vp_lines.npy')  # mx,my,dx,dy,nx,ny,resid,n
names=['masttip','roof','bowtip','hatch','window','green','stern','hull_wl','hull_wl2','rail_far']
use=[i for i,n in enumerate(names) if n!='masttip']
x=L[use,0]; y=L[use,1]; ang=np.arctan2(L[use,3],L[use,2]); ang=np.where(ang>np.pi/2,ang-np.pi,ang); ang=np.where(ang<-np.pi/2,ang+np.pi,ang)
w=1/np.maximum(L[use,6],0.06)**2
for yh in (-2000,-3200,-5000,-8000,-10400,-15000,-30000,-1e6):
    best=None
    for xv in np.linspace(-200000,-2000,20000):
        pred=np.arctan((y-yh)/(x-xv))
        e=((pred-ang)**2*w).sum()
        if best is None or e<best[0]: best=(e,xv)
    e,xv=best
    pred=np.arctan((y-yh)/(x-xv))
    print('y_h=%8.0f  xv=%8.0f  chi=%.3e  resid(deg)=%s'%(yh,xv,e,np.round(np.degrees(ang-pred),3)))
