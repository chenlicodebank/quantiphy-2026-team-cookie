import numpy as np, csv
# image speed of the boat (constant world speed) vs image row -> perspective rate dln(s)/dy
r=[x for x in csv.DictReader(open('scene/tracks/boat.csv'))]
f=np.array([int(x['frame']) for x in r]); X=np.array([float(x['ref_x']) for x in r]); Y=np.array([float(x['ref_y']) for x in r])
for lo,hi in ((2,62),(2,71),(5,58)):
    m=(f>=lo)&(f<=hi)
    t=f[m]-f[m].mean()
    px=np.polyfit(t,X[m],2); py=np.polyfit(t,Y[m],2)
    v0=np.hypot(px[1],py[1]);
    # d|v|/dt = (vx*ax+vy*ay)/|v|, a = 2*p[0]
    dv=(px[1]*2*px[0]+py[1]*2*py[0])/v0
    dlnv_dt=dv/v0; dy_dt=py[1]
    k=dlnv_dt/dy_dt
    res=np.hypot(X[m]-np.polyval(px,t),Y[m]-np.polyval(py,t)).std()
    print(lo,hi,'speed %.3f px/f, dy/dt %.3f, dln v/dy = %.3e -> 1/k = %.0f px (y_mid %.1f) resid %.2f'%(v0,dy_dt,k,1/k,np.polyval(py,0),res))
