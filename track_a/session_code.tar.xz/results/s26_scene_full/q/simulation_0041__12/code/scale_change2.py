import av, numpy as np, cv2, csv
# Affine ECC registration of the frame-30 boat (hull+cabin) into other frames -> scale vs image row
V='simulation_0041.mp4'
want=list(range(2,61,2))+[30]
fr={}
with av.open(V) as c:
    for i,f in enumerate(c.decode(video=0)):
        if i in want: fr[i]=cv2.GaussianBlur(cv2.cvtColor(f.to_ndarray(format='rgb24'),cv2.COLOR_RGB2GRAY).astype(np.float32),(3,3),0.8)
        if i>max(want): break
rows={int(r['frame']):r for r in csv.DictReader(open('scene/tracks/boat.csv'))}
X0,Y0,X1,Y1=180,860,520,1035
cx0,cy0=float(rows[30]['ref_x']),float(rows[30]['ref_y'])
T=np.zeros_like(fr[30]); M=np.zeros(fr[30].shape,np.uint8)
T=fr[30]; M[Y0:Y1,X0:X1]=255
out=[]
for i in sorted(fr):
    if i==30: continue
    tx=float(rows[i]['ref_x'])-cx0; ty=float(rows[i]['ref_y'])-cy0
    W=np.array([[1,0,tx],[0,1,ty]],np.float32)
    crit=(cv2.TERM_CRITERIA_EPS|cv2.TERM_CRITERIA_COUNT,500,1e-7)
    try:
        cc,W=cv2.findTransformECC(T,fr[i],W,cv2.MOTION_AFFINE,crit,M,5)
    except cv2.error as e:
        print(i,'fail');continue
    A=W[:,:2]
    sx=np.hypot(A[0,0],A[1,0]); sy=np.hypot(A[0,1],A[1,1])
    # image row of template centre in frame i
    ycen=W[1,0]*cx0+W[1,1]*cy0+W[1,2]
    out.append((i,ycen,sx,sy,np.sqrt(abs(np.linalg.det(A))),cc))
    print(i,'y=%.1f sx=%.4f sy=%.4f sqrtdet=%.4f a01=%.4f a10=%.4f cc=%.4f'%(ycen,sx,sy,out[-1][4],A[0,1],A[1,0],cc))
o=np.array(out)
for k,name in ((2,'sx'),(3,'sy'),(4,'iso')):
    p=np.polyfit(o[:,1],np.log(o[:,k]),1)
    res=np.log(o[:,k])-np.polyval(p,o[:,1])
    print(name,'dln s/dy=%.3e +- %.1e -> 1/that=%.0f px'%(p[0],res.std()/np.sqrt(((o[:,1]-o[:,1].mean())**2).sum()),1/p[0]))
