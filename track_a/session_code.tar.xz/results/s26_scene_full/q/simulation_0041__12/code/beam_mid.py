import numpy as np, sys
import beam
from pinhole import cam, img_angle
# chord midpoints vs station: checks the heading (axis) used for the beam chords
th=float(sys.argv[1]) if len(sys.argv)>1 else 34.5
beam.ZD=0.8; beam.DMIN=0.17
th_r=np.radians(th); f=4523/np.tan(th_r)
r=beam.solve(th); h=r['h']
proj,back=cam(th_r,f,h)
ZD=beam.ZD
N=np.array([back(x,y,ZD)[:2] for x,y in beam.near])
F1=np.array([back(x,y,ZD)[:2] for x,y in beam.farbow]); F2=np.array([back(x,y,ZD)[:2] for x,y in beam.farmid])
for dphi in (-4,-2,0,2,4):
    phi=np.radians(r['phi']+dphi)
    ax=np.array([np.cos(phi),-np.sin(phi)]); bm=np.array([np.sin(phi),np.cos(phi)])
    sN,lN=N@ax,N@bm
    res=[]
    for F in (F1,F2):
        sF,lF=F@ax,F@bm; o=np.argsort(sF)
        for s_,l_ in zip(sN,lN):
            if sF.min()<=s_<=sF.max():
                lf=np.interp(s_,sF[o],lF[o]); res.append((s_,lf-l_,(lf+l_)/2))
    res=np.array(res); sb=sN.min()
    p=np.polyfit(res[:,0],res[:,2],1)
    print('phi=%.1f  max chord %.3f  midpoint slope %.3f m/m  mid sd %.3f'%(np.degrees(phi),res[:,1].max(),p[0],np.std(res[:,2]-np.polyval(p,res[:,0]))))
    if dphi==0:
        for a,b,c in res[::5]: print('   station %.2f width %.3f mid %.3f'%(a-sb,b,c))
