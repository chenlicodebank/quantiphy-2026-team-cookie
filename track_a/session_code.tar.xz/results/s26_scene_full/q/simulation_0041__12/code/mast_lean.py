import av, numpy as np, cv2, csv
# lean of the vertical mast vs its image x over the clip -> nadir (vertical vanishing point)
V='simulation_0041.mp4'
rows={int(r['frame']):r for r in csv.DictReader(open('scene/tracks/boat.csv'))}
cx0,cy0=float(rows[30]['ref_x']),float(rows[30]['ref_y'])
want=set(range(0,64,3))
res=[]
with av.open(V) as c:
    for i,f in enumerate(c.decode(video=0)):
        if i not in want: continue
        g=cv2.cvtColor(f.to_ndarray(format='rgb24'),cv2.COLOR_RGB2GRAY).astype(np.float32)
        dx=float(rows[i]['ref_x'])-cx0; dy=float(rows[i]['ref_y'])-cy0
        pts=[]
        # frame-30 mast: x ~ 323 (y 800) .. 327 (y 890); use rows y 805..850 (above roof, below tip)
        for y30 in range(803,852):
            y=int(round(y30+dy))
            xp=323+(y30-795)*4/96+dx
            x0=int(round(xp))-4; x1=int(round(xp))+5
            prof=g[y,x0:x1]
            w=np.clip(prof-np.percentile(g[y,x0-6:x1+6],30),0,None)
            if w.sum()<30: continue
            pts.append((y,(w*np.arange(x0,x1)).sum()/w.sum()))
        pts=np.array(pts)
        if len(pts)<20: continue
        p=np.polyfit(pts[:,0],pts[:,1],1)
        r=pts[:,1]-np.polyval(p,pts[:,0])
        ym=pts[:,0].mean(); xm=np.polyval(p,ym)
        res.append((i,xm,ym,p[0],r.std()))
        print(i,'x=%.1f y=%.1f dx/dy=%.4f resid=%.2f n=%d'%(xm,ym,p[0],r.std(),len(pts)))
res=np.array(res)
# model: dx/dy = (x - cxn)/(y - yn)  (line through nadir (cxn,yn)) -> x - cxn = slope*(y - yn)
# linear LSQ: x = cxn + slope*y - slope*yn  -> x - slope*y = cxn - slope*yn = a + b*slope with a=cxn, b=-yn
A=np.c_[np.ones(len(res)),res[:,3]]; b=res[:,1]-res[:,3]*res[:,2]
sol,*_=np.linalg.lstsq(A,b,rcond=None)
print('nadir x=%.0f y=%.0f'%(sol[0],-sol[1]))
# fixed cx=540
yn=np.median(res[:,2]-(res[:,1]-540)/res[:,3])
sl=res[:,3]; m=np.abs(sl)>0.01
print('with cx=540, yn per frame:',np.round(res[m,2]-(res[m,1]-540)/res[m,3]))
A2=res[:,3][:,None]; b2=(res[:,1]-540)-res[:,3]*res[:,2]
s2,*_=np.linalg.lstsq(A2,b2,rcond=None)
print('LSQ yn with cx=540: %.0f'%(-s2[0]))
