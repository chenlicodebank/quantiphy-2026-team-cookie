import numpy as np, csv
r=[x for x in csv.DictReader(open('scene/tracks/boat.csv'))]
f=np.array([int(x['frame']) for x in r]); X=np.array([float(x['ref_x']) for x in r]); Y=np.array([float(x['ref_y']) for x in r])
for lo in range(2,70,8):
    hi=min(lo+8,71)
    d=np.hypot(X[hi]-X[lo],Y[hi]-Y[lo])/(hi-lo)
    print(lo,hi,'speed %.3f  y %.1f x %.1f'%(d,(Y[lo]+Y[hi])/2,(X[lo]+X[hi])/2))
