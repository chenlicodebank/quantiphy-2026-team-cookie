import av, numpy as np, cv2, csv
# person's apparent head-top to lowest-foot extent per frame, from a 3-frame median background, sub-pixel 50% crossings
V='simulation_0041.mp4'
rows={int(r['frame']):r for r in csv.DictReader(open('scene/tracks/person.csv'))}
X0,X1,Y0,Y1=300,480,340,560
crops={}
with av.open(V) as c:
    for i,f in enumerate(c.decode(video=0)):
        crops[i]=f.to_ndarray(format='rgb24')[Y0:Y1,X0:X1].astype(np.float32)
bg=np.median(np.stack([crops[0],crops[36],crops[71]]),axis=0)
out=[]
for i in range(2,72):
    if i in (0,36,71): continue
    D=np.abs(crops[i]-bg).sum(axis=2)
    cx=float(rows[i]['ref_x'])-X0
    xa=int(cx-13); xb=int(cx+12)
    M=D[:,xa:xb]
    rowmax=M.max(axis=1)
    on=np.where(rowmax>60)[0]
    if len(on)==0: continue
    # head top: first row where row-max exceeds 50% of the head contrast
    top0=on.min(); hc=rowmax[top0:top0+4].max(); thr=0.5*hc
    k=top0
    while k>0 and rowmax[k-1]>thr: k-=1
    # interpolate crossing between k-1 and k
    a,b=rowmax[k-1],rowmax[k]; ytop=(k-1)+(thr-a)/(b-a) if b!=a else k
    # feet: last row with change, restricted to columns left of / under the body (shadow runs up-right)
    bot0=on.max(); fc=rowmax[bot0-4:bot0+1].max(); thr2=0.5*fc
    k2=bot0
    while k2<len(rowmax)-1 and rowmax[k2+1]>thr2: k2+=1
    a,b=rowmax[k2],rowmax[k2+1]; ybot=k2+(a-thr2)/(a-b) if a!=b else k2
    out.append((i,ytop+Y0,ybot+Y0,ybot-ytop))
o=np.array(out)
for r in o: print('%d top=%.1f bot=%.1f ext=%.1f'%tuple(r))
e=o[:,3]
print('extent: mean %.2f median %.2f p10 %.2f p90 %.2f min %.2f max %.2f'%(e.mean(),np.median(e),np.percentile(e,10),np.percentile(e,90),e.min(),e.max()))
np.save('person_extent.npy',o)
