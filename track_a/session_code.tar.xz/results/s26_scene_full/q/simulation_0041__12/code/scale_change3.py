import av, numpy as np, cv2, csv
# isotropic scale of the boat vs frame (frame-30 template, fine scale search, sub-step parabola)
V='simulation_0041.mp4'
want=set(range(2,61,4))|{30}
fr={}
with av.open(V) as c:
    for i,f in enumerate(c.decode(video=0)):
        if i in want: fr[i]=cv2.cvtColor(f.to_ndarray(format='rgb24'),cv2.COLOR_RGB2GRAY).astype(np.float32)
        if i>max(want): break
rows={int(r['frame']):r for r in csv.DictReader(open('scene/tracks/boat.csv'))}
cx0,cy0=float(rows[30]['ref_x']),float(rows[30]['ref_y'])
for name,(X0,Y0,X1,Y1) in {'whole':(180,860,520,1035),'hull':(185,930,515,1032),'cabin':(275,850,365,975)}.items():
    T=fr[30][Y0:Y1,X0:X1]
    out=[]
    for i in sorted(fr):
        tx=float(rows[i]['ref_x'])-cx0; ty=float(rows[i]['ref_y'])-cy0
        ss=np.arange(0.96,1.041,0.0025); vals=[]
        for s in ss:
            # scale template about its own centre, then search near the predicted place
            Ts=cv2.resize(T,None,fx=s,fy=s,interpolation=cv2.INTER_CUBIC)
            h,w=Ts.shape
            ccx=(X0+X1)/2+tx; ccy=(Y0+Y1)/2+ty
            xa=int(ccx-w/2-8); ya=int(ccy-h/2-8)
            S=fr[i][max(ya,0):ya+h+16,max(xa,0):xa+w+16]
            if S.shape[0]<h or S.shape[1]<w: vals.append(np.nan); continue
            vals.append(cv2.matchTemplate(S,Ts,cv2.TM_CCOEFF_NORMED).max())
        vals=np.array(vals); k=np.nanargmax(vals)
        if 0<k<len(ss)-1 and np.isfinite(vals[k-1:k+2]).all():
            a,b,cc=vals[k-1],vals[k],vals[k+1]; d=0.5*(a-cc)/(a-2*b+cc); sb=ss[k]+d*0.0025
        else: sb=ss[k]
        out.append((i,cy0+ty,sb,vals[k]))
    o=np.array(out)
    p=np.polyfit(o[:,1],np.log(o[:,2]),1)
    print(name,' '.join('%d:%.4f'%(a,b) for a,_,b,_ in out))
    print(name,'dln s/dy=%.3e -> y - y_h = %.0f px at y=940'%(p[0],1/p[0]))
