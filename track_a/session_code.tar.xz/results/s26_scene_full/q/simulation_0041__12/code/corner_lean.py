import av, numpy as np, cv2, csv
# lean of the cabin's vertical aft corner (white wall | grey wall) vs image x over the clip
V='simulation_0041.mp4'
rows={int(r['frame']):r for r in csv.DictReader(open('scene/tracks/boat.csv'))}
cx0,cy0=float(rows[30]['ref_x']),float(rows[30]['ref_y'])
want=set(range(0,63,2))
res=[]
with av.open(V) as c:
    for i,f in enumerate(c.decode(video=0)):
        if i not in want: continue
        g=cv2.cvtColor(f.to_ndarray(format='rgb24'),cv2.COLOR_RGB2GRAY).astype(np.float32)
        gx=cv2.Sobel(g,cv2.CV_32F,1,0,ksize=3)
        dx=float(rows[i]['ref_x'])-cx0; dy=float(rows[i]['ref_y'])-cy0
        pts=[]
        for y30 in range(924,958):
            y=int(round(y30+dy)); yf=y30+dy
            xp=339.5+(y30-940)*0.03+dx
            x0=int(round(xp))-5
            prof=-gx[y,x0:x0+11]
            k=int(np.argmax(prof))
            if prof[k]<60 or k==0 or k==10: continue
            a,b,cc=prof[k-1],prof[k],prof[k+1]
            d=0.5*(a-cc)/(a-2*b+cc)
            pts.append((y,x0+k+d))
        pts=np.array(pts)
        if len(pts)<20: print(i,'few',len(pts)); continue
        p=np.polyfit(pts[:,0],pts[:,1],1)
        r=pts[:,1]-np.polyval(p,pts[:,0])
        ok=np.abs(r)<2.5*r.std()+0.1
        p=np.polyfit(pts[ok,0],pts[ok,1],1); r=pts[ok,1]-np.polyval(p,pts[ok,0])
        ym=pts[ok,0].mean(); xm=np.polyval(p,ym)
        res.append((i,xm,ym,p[0],r.std()))
        print(i,'x=%.1f y=%.1f dx/dy=%.4f resid=%.2f n=%d'%(xm,ym,p[0],r.std(),ok.sum()))
res=np.array(res)
np.save('corner_lean.npy',res)
# lean = -(x - xn)/(yn - y) + d0 (d0: possible constant tilt of the edge) ; fit lean = a + b*x for a quick look
b,a=np.polyfit(res[:,1],res[:,3],1)
print('lean = %.4f + %.3e*x ; zero at x=%.0f ; 1/|b| = %.0f'%(a,b,-a/b,1/abs(b)))
