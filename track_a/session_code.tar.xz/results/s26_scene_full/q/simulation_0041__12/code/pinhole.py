import numpy as np
# pinhole model (pp at image centre, roll 0): camera at (0,0,h), pitch theta from nadir, looking toward +Y
CX=CY=540.0
def cam(theta,f,h=100.0):
    d=np.array([0,np.sin(theta),-np.cos(theta)]); up=np.array([0,np.cos(theta),np.sin(theta)]); C=np.array([0,0,h])
    def proj(P):
        P=np.atleast_2d(P)-C; z=P@d
        return np.c_[CX+f*P[:,0]/z, CY-f*(P@up)/z]
    def back(u,v,zp=0.0):
        r=np.array([ (u-CX)/f, 0,0])
        ray=np.array([(u-CX)/f,0,0])+d-((v-CY)/f)*up   # x right, d forward, image down = -up
        ray=np.array([(u-CX)/f,0,0])+d-((v-CY)/f)*up
        t=(zp-h)/ray[2]
        return C+t*ray
    return proj,back
def img_angle(proj,P,dirw,eps=0.01):
    a=proj(P)[0]; b=proj(P+eps*np.asarray(dirw))[0]; v=b-a
    return np.degrees(np.arctan2(v[1],v[0]))
if __name__=='__main__':
    meas_motion=(307,932,15.66)   # 'window' track: point, image angle of motion
    hatch=(250,900)
    for th_deg in (28,30,32,33,34,35,36,38,40,44,48):
        th=np.radians(th_deg); f=4523/np.tan(th)
        proj,back=cam(th,f)
        P=back(*meas_motion[:2],0.0)
        # find heading phi so that image angle of motion at P equals measured (direction toward stern = down-right)
        phis=np.radians(np.linspace(0,60,60001))
        angs=np.array([img_angle(proj,P,[np.cos(p),-np.sin(p),0]) for p in phis[::100]])
        k=np.argmin(np.abs(angs-meas_motion[2])); phi=phis[::100][k]
        Ph=back(*hatch,0.0)
        a_ax=img_angle(proj,Ph,[np.cos(phi),-np.sin(phi),0])
        a_bm=img_angle(proj,Ph,[np.sin(phi),np.cos(phi),0])
        # lean slope at boat & horizon
        yh=CY-f/np.tan(th)
        print('theta=%2d f=%6.0f HFOV=%.1f  y_h=%7.0f  phi=%.2f  hatch axis %.2f beam %.2f'%(th_deg,f,2*np.degrees(np.arctan(540/f)),yh,np.degrees(phi),a_ax,a_bm))
