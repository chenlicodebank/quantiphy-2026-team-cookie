import numpy as np, sys
import beam
from pinhole import cam
# full beam profile: centre line interpolated (linear fit) from the visible chords, half-beam from the near gunwale
beam.ZD=float(sys.argv[2]) if len(sys.argv)>2 else 0.8
beam.DMIN=float(sys.argv[3]) if len(sys.argv)>3 else 0.17
def run(th,verbose=False):
    th_r=np.radians(th); f=4523/np.tan(th_r)
    r=beam.solve(th); h=r['h']
    proj,back=cam(th_r,f,h)
    N=np.array([back(x,y,beam.ZD)[:2] for x,y in beam.near])
    F1=np.array([back(x,y,beam.ZD)[:2] for x,y in beam.farbow]); F2=np.array([back(x,y,beam.ZD)[:2] for x,y in beam.farmid])
    phi=np.radians(r['phi'])
    ax=np.array([np.cos(phi),-np.sin(phi)]); bm=np.array([np.sin(phi),np.cos(phi)])
    sN,lN=N@ax,N@bm; sb=sN.min()
    res=[]
    for F in (F1,F2):
        sF,lF=F@ax,F@bm; o=np.argsort(sF)
        for s_,l_ in zip(sN,lN):
            if sF.min()<=s_<=sF.max():
                lf=np.interp(s_,sF[o],lF[o]); res.append((s_,lf-l_,(lf+l_)/2))
    res=np.array(res)
    p=np.polyfit(res[:,0],res[:,2],1)
    width=2*(np.polyval(p,sN)-lN)
    k=np.argmax(width)
    # smooth width profile (5-pt) for the max
    ws=np.convolve(width[np.argsort(sN)],np.ones(5)/5,mode='same')
    if verbose:
        o=np.argsort(sN)
        for j in o[::12]: print('   station %.2f  width %.3f'%(sN[j]-sb,width[j]))
    return r, res[:,1].max(), width.max(), np.sort(ws)[-3], sN[k]-sb
for th in (30,32,33,34,34.5,35,36):
    r,ch,wmax,wsm,sk=run(th)
    print('theta=%.1f s_person=%.2f s_boat=%.2f | max visible chord %.3f | max width (interp. centre line) %.3f (smoothed %.3f) at station %.2f m, gunwale length %.2f'%(th,r['s_p'],r['s_b'],ch,wmax,wsm,sk,r['Lgun']))
run(float(sys.argv[1]) if len(sys.argv)>1 else 34.5,True)
