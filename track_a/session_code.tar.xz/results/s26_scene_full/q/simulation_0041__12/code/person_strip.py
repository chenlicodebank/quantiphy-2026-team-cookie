import av, numpy as np, cv2, csv
# montage of the person (scale 8) at several frames, with row ticks every 5 px
V='simulation_0041.mp4'
rows={int(r['frame']):r for r in csv.DictReader(open('scene/tracks/person.csv'))}
want=[2,6,10,14,18,22,26,30]
tiles=[]
with av.open(V) as c:
    for i,f in enumerate(c.decode(video=0)):
        if i in want:
            im=f.to_ndarray(format='rgb24')
            cx=int(round(float(rows[i]['ref_x']))); cy=int(round(float(rows[i]['ref_y'])))
            x0,y0=cx-14,cy-32
            t=cv2.resize(im[y0:y0+64,x0:x0+36],None,fx=8,fy=8,interpolation=cv2.INTER_NEAREST).copy()
            for k in range(0,64,5):
                yy=k*8; cv2.line(t,(0,yy),(12,yy),(255,255,0),1)
                cv2.putText(t,str(y0+k),(14,yy+4),cv2.FONT_HERSHEY_PLAIN,0.8,(255,255,0),1)
            cv2.putText(t,'f%d'%i,(150,20),cv2.FONT_HERSHEY_PLAIN,1.2,(255,0,255),2)
            tiles.append(t)
        if i>max(want): break
m=np.hstack(tiles[:4]); m2=np.hstack(tiles[4:])
cv2.imwrite('frames/person_strip.png',cv2.cvtColor(np.vstack([m,m2]),cv2.COLOR_RGB2BGR))
