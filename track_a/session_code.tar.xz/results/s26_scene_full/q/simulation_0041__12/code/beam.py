import numpy as np, sys
from pinhole import cam, img_angle, CX, CY
# Beam of the boat from the deck outline at frame 30, metric scale from the person's height
near=np.load('near_edge.npy')[:,:2]          # near gunwale (top of red hull band), frame 30
farbow=np.load('far_bow.npy')                 # far gunwale, bow part (water | white deck)
farmid=np.array([(359,895.6),(372,900.8),(385,906),(398,912.5),(410,919)])   # far bulwark top behind the cabin (read at scale 8)
farx=np.r_[farbow[:,0],farmid[:,0]]; fary=np.r_[farbow[:,1],farmid[:,1]]
E_MIN=37.3; Y_MIN=450.0       # mean of the four per-step minimum extents (px) and their mean image row of the head..toe midpoint
ZD=float(sys.argv[1]) if len(sys.argv)>1 else 0.8   # gunwale height above the water (m)
DMIN=float(sys.argv[2]) if len(sys.argv)>2 else 0.17
def solve(th_deg,verbose=False):
    th=np.radians(th_deg); f=4523/np.tan(th)
    proj0,back0=cam(th,f,1.0)
    # person: model extent of a 1.75 m person whose stance toe is DMIN ahead of the head (toward camera)
    # find h such that projected extent == E_MIN at row Y_MIN
    def extent(h):
        proj,back=cam(th,f,h)
        G=back(362,Y_MIN+18,0.0)                          # ground point under the toe
        r=0.11; zc=1.74-r
        head=G+np.array([0,DMIN,zc])                      # head centre is DMIN farther from camera than the toe
        # silhouette top of a sphere: project centre and offset by r*f/depth (sphere -> circle)
        d=np.array([0,np.sin(th),-np.cos(th)]); C=np.array([0,0,h])
        pc=proj(head)[0]; dep=(head-C)@d
        top=pc[1]-r*f/dep
        toe=proj(G)[0][1]
        return toe-top
    lo,hi=10.0,5000.0
    for _ in range(80):
        mid=np.sqrt(lo*hi)
        if extent(mid)>E_MIN: lo=mid
        else: hi=mid
    h=mid; proj,back=cam(th,f,h)
    # heading from the motion direction ('window' track at (307,932), 15.66 deg), at deck height
    P=back(307,932,ZD)
    phis=np.radians(np.linspace(5,40,3501))
    angs=np.array([img_angle(proj,P,[np.cos(p),-np.sin(p),0]) for p in phis])
    phi=phis[np.argmin(np.abs(angs-15.66))]
    ax=np.array([np.cos(phi),-np.sin(phi)]); bm=np.array([np.sin(phi),np.cos(phi)])  # bm points to the far side
    N=np.array([back(x,y,ZD)[:2] for x,y in near]); F=np.array([back(x,y,ZD)[:2] for x,y in zip(farx,fary)])
    # station coordinate along the axis and lateral coordinate
    sN,lN=N@ax,N@bm; sF,lF=F@ax,F@bm
    # chord widths where far edge exists at the same station
    oF=np.argsort(sF)
    widths=[]
    for s_,l_ in zip(sN,lN):
        # far edge pieces: interpolate only inside each visible piece
        for piece in (np.arange(len(farbow)),len(farbow)+np.arange(len(farmid))):
            ss=sF[piece]; ll=lF[piece]; o=np.argsort(ss)
            if ss.min()<=s_<=ss.max():
                widths.append((s_,np.interp(s_,ss[o],ll[o])-l_))
    widths=np.array(widths)
    # centre line from chord midpoints -> half-beam from the near edge everywhere (cabin hides the far edge mid-ship)
    mids=[]
    for s_,w_ in widths:
        k=np.argmin(np.abs(sN-s_)); mids.append(lN[k]+w_/2)
    cl=np.median(mids)
    half=cl-lN
    smin=sN.min()
    s_person=f/((back(362,Y_MIN+18,0)-np.array([0,0,h]))@np.array([0,np.sin(th),-np.cos(th)]))
    s_boat=f/((back(330,990,ZD)-np.array([0,0,h]))@np.array([0,np.sin(th),-np.cos(th)]))
    L=sN.max()-sN.min()
    if verbose:
        print('  chord widths (station from bow m, width m):')
        sb=sN.min()
        for s_,w_ in widths[::6]: print('   %.2f %.3f'%(s_-sb,w_))
        print('  centre-line spread (std of chord midpoints) %.3f m'%np.std(mids))
        prof=sorted(zip(sN-sb,2*half))
        print('  2*half-beam from near edge, every ~0.5 m:',' '.join('%.1f:%.2f'%(a,b) for a,b in prof[::15]))
    return dict(th=th_deg,f=f,h=h,phi=np.degrees(phi),s_p=s_person,s_b=s_boat,chord_max=widths[:,1].max(),beam=2*half.max(),Lgun=L,cl_sd=np.std(mids))
if __name__=='__main__':
    for th in (28,30,32,33,34,34.5,35,36,38):
        r=solve(th)
        print('theta=%.1f f=%.0f h=%.0f phi=%.1f s_person=%.2f s_boat=%.2f px/m | max chord %.3f m | beam(2*max half) %.3f m | gunwale length %.2f m | cl sd %.3f'%(r['th'],r['f'],r['h'],r['phi'],r['s_p'],r['s_b'],r['chord_max'],r['beam'],r['Lgun'],r['cl_sd']))
    solve(34.5,True)
