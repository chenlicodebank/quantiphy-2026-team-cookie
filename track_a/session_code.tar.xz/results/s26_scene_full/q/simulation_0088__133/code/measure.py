import av, numpy as np, cv2
bg = np.array([97, 149, 191])
c = av.open('simulation_0088.mp4')
rows = []
for i, f in enumerate(c.decode(video=0)):
    if i > 15:
        break
    a = f.to_ndarray(format='rgb24').astype(int)
    d = np.abs(a - bg).sum(2)
    m = (d > 40).astype(np.uint8)
    n, lab, st, cen = cv2.connectedComponentsWithStats(m)
    best = max(range(1, n), key=lambda k: st[k][4])
    sub = lab == best
    if i <= 1:
        sub[:, 1763:] = False
    ys, xs = np.nonzero(sub)
    x0, x1 = xs.min(), xs.max()
    m2 = d > 20
    m2[:, :max(x0 - 20, 0)] = False
    m2[:, x1 + 3:] = False
    y2 = np.nonzero(m2.any(1))[0]
    rows.append((i, x0, x1, x1 - x0 + 1, ys.min(), ys.max(), ys.max() - ys.min() + 1, y2.max() - y2.min() + 1))
    print(*rows[-1])
# speed: tail end x
tx = np.array([r[2] for r in rows])
print('tail steps', np.diff(tx))
step = (tx[1] - tx[14]) / 13
print('mean step f1->f14', step)
mpp = 17.98 / (step * 24)
print('m/px', mpp)
h = np.array([r[6] for r in rows[:15]])
print('max h', h.max(), '->', h.max() * mpp, 'm; min', h.min(), '->', h.min() * mpp)
print('mean h', h.mean() * mpp)
