import os, numpy as np, cv2
os.chdir(os.path.dirname(os.path.abspath(__file__)))
cap = cv2.VideoCapture('simulation_0057.mp4')
frames = {}
i = 0
while True:
    ok, fr = cap.read()
    if not ok: break
    if i in (0, 75): frames[i] = fr.astype(np.float32)
    i += 1
d = np.abs(frames[75] - frames[0]).sum(2)
m = (d > 40).astype(np.uint8)
m[:, :272] = 0
m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
ys = np.nonzero(m[:, 280:460].sum(1) > 30)[0]
print('y extent', ys.min(), ys.max(), ys.max() - ys.min() + 1)
ws = []
for y in range(ys.min() + 5, ys.max() - 5):
    xs = np.nonzero(m[y, 272:470])[0] + 272
    if len(xs) > 30: ws.append((y, xs.min(), xs.max(), xs.max() - xs.min() + 1))
ws = np.array(ws)
for row in ws[::15]: print(row)
print('width p50 %.1f p90 %.1f max %d' % (np.median(ws[:, 3]), np.percentile(ws[:, 3], 90), ws[:, 3].max()))
v = frames[75].copy(); v[m > 0] = (0, 255, 0); cv2.imwrite('frames/diff75.png', v[650:950, 260:460])
