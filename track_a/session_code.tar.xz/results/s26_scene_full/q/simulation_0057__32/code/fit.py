import csv, os, numpy as np
os.chdir(os.path.dirname(os.path.abspath(__file__)))
r = list(csv.DictReader(open('scene/tracks/orange_car.csv')))
print(list(r[0].keys()))
def col(k):
    return np.array([float(x[k]) if x[k] not in ('', 'nan') else np.nan for x in r])
f = col('frame').astype(int); y = col('cy_best_px'); xx = col('cx_best_px'); w = col('width_px')
for fps in (30.0, 30.003297):
    for a, b in ((7, 90), (17, 90), (7, 50), (50, 90)):
        m = (f >= a) & (f <= b); t = f[m] / fps
        p = np.polyfit(t, y[m], 2)
        s = np.hypot(np.diff(xx[m]), np.diff(y[m])) * fps
        print(fps, a, b, 'acc px/s2 %.2f v0 %.1f' % (2 * p[0], p[1]), 'speed slope %.2f' % np.polyfit(t[1:], s, 1)[0])
print('width median', np.nanmedian(w[17:]), w[17::8])
