import os, csv, numpy as np, cv2
os.chdir(os.path.dirname(os.path.abspath(__file__)))
r = list(csv.DictReader(open('scene/tracks/orange_car.csv')))
cap = cv2.VideoCapture('simulation_0057.mp4')
i = 0; out = []
while True:
    ok, fr = cap.read()
    if not ok: break
    if i in (30, 45, 60, 75, 90):
        hsv = cv2.cvtColor(fr, cv2.COLOR_BGR2HSV)
        m = ((hsv[..., 0] >= 5) & (hsv[..., 0] <= 25) & (hsv[..., 1] > 120) & (hsv[..., 2] > 100)).astype(np.uint8)
        m[:, :272] = 0
        y0, y1 = int(float(r[i]['y0'])), int(float(r[i]['y1']))
        ws = []
        for y in range(y0 + 10, y1 - 10):
            xs = np.nonzero(m[y])[0]
            if len(xs) > 20: ws.append(xs.max() - xs.min() + 1)
        ws = np.array(ws)
        # per-column coverage extent
        cols = np.nonzero(m[y0:y1].sum(0) > 5)[0]
        print(i, 'row-width max %d p95 %.1f median %.1f' % (ws.max(), np.percentile(ws, 95), np.median(ws)), 'col extent', cols.min(), cols.max(), cols.max() - cols.min() + 1)
        if i == 75:
            v = fr.copy(); v[m > 0] = (0, 255, 0); cv2.imwrite('frames/mask75.png', v[650:950, 260:460])
    i += 1
