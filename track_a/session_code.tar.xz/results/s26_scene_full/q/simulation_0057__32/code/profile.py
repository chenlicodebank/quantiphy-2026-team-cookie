import os, numpy as np, cv2
os.chdir(os.path.dirname(os.path.abspath(__file__)))
cap = cv2.VideoCapture('simulation_0057.mp4')
i = 0
while True:
    ok, fr = cap.read()
    if not ok: break
    if i == 75: f75 = fr.astype(np.float32)
    if i == 0: f0 = fr.astype(np.float32)
    i += 1
for (a, b) in ((720, 740), (790, 810), (860, 880), (920, 940)):
    p = f75[a:b, 270:430].mean(0); q = f0[a:b, 270:430].mean(0)
    print('rows', a, b)
    for k in range(0, 160, 2):
        x = 270 + k
        print(' x%d car BGR %s  bg %s' % (x, p[k].astype(int), q[k].astype(int)))
