import numpy as np, csv, os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
r=list(csv.DictReader(open('scene/tracks/orange_car.csv')))
print(list(r[0].keys()))
f=np.array([float(x['frame']) for x in r]); y=np.array([float(x['ref_y']) for x in r]); x=np.array([float(x['ref_x']) for x in r])
ok=np.array([x['ref_reliable']=='1' for x in r])
f,y,x=f[ok],y[ok],x[ok]
for lo,hi in [(15,90),(15,50),(50,90),(30,80),(25,90)]:
    m=(f>=lo)&(f<=hi); p=np.polyfit(f[m],y[m],2); res=y[m]-np.polyval(p,f[m])
    print(lo,hi,'a px/f2',2*p[0],'px/s2',2*p[0]*900,'rms',res.std())
d=np.hypot(np.diff(x),np.diff(y)); print(np.round(d,2))
for k in ['frame','length_px','width_px','bbox_y0','bbox_y1','truncated_by_frame_edge']:
    print(k,[x.get(k) for x in r][::4])
