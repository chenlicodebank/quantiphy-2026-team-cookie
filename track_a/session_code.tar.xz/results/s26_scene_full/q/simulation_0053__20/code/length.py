import numpy as np, av, os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
want=set(range(40,91,4))
c=av.open('simulation_0053.mp4')
for i,fr in enumerate(c.decode(video=0)):
    if i not in want: continue
    a=fr.to_ndarray(format='rgb24')[:,450:950].astype(int)
    r,g,b=a[...,0],a[...,1],a[...,2]
    m=(r>150)&(r-g>50)&(g-b>10)   # orange paint
    rows=np.where(m.sum(1)>20)[0]; cols=np.where(m.sum(0)>20)[0]
    # body column profile at the car's centreline
    print(i,'y',rows.min(),rows.max(),'len',rows.max()-rows.min()+1,'x',cols.min()+450,cols.max()+450,'w',cols.max()-cols.min()+1)
