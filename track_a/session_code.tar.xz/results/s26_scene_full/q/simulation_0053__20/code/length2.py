import numpy as np, av, os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
want={0,48,52,56,60,64}
c=av.open('simulation_0053.mp4'); F={}
for i,fr in enumerate(c.decode(video=0)):
    if i in want: F[i]=fr.to_ndarray(format='rgb24')[:,450:950].astype(int)
    if i>max(want): break
bg=F[0]
for i in sorted(want-{0}):
    d=np.abs(F[i]-bg).sum(2)
    for thr in (30,60,120):
        m=d>thr
        rows=np.where(m[:,150:330].sum(1)>30)[0]
        print(i,thr,'diff-mask y',rows.min(),rows.max(),'len',rows.max()-rows.min()+1)
    # central column profiles near ends
    col=d[:,240]
    ys=np.where(col>60)[0]; print('  col240',ys.min(),ys.max(),ys.max()-ys.min()+1)
