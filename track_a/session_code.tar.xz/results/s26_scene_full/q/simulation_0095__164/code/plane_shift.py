import av, numpy as np, cv2
c = av.open('simulation_0095.mp4'); fr = {}
for i, f in enumerate(c.decode(video=0)):
    if 6 <= i <= 18: fr[i] = cv2.cvtColor(f.to_ndarray(format='bgr24'), cv2.COLOR_BGR2GRAY).astype(np.float32)
    if i > 18: break
bg = 130.0
for i in range(7, 16):
    a = fr[i][160:510]; b = fr[i+1][160:510]
    # whole-plane template from frame i (bbox), matched in frame i+1
    m = np.abs(a - bg) > 6; xs = np.where(m.any(0))[0]; x0, x1 = xs[0], xs[-1]
    out = []
    for (u0, u1) in [(x0, x1), (x0 + 300, x0 + 700), (x0 + 700, x1)]:
        t = a[:, u0:u1]
        res = cv2.matchTemplate(b, t, cv2.TM_CCOEFF_NORMED)
        _, mv, _, ml = cv2.minMaxLoc(res)
        k = ml[0]; s = res[0]
        if 0 < k < len(s) - 1:
            d = (s[k-1] - s[k+1]) / (2 * (s[k-1] - 2*s[k] + s[k+1])); k = k + d
        out.append((round(k - u0, 2), round(mv, 3)))
    print(i, x0, x1, out)
