import csv, numpy as np
r = list(csv.DictReader(open('scene/tracks/car.csv')))
f = np.array([float(x['frame']) for x in r])
for k in ['ref_x', 'mask_cx', 'bbox_x0', 'bbox_x1']:
    x = np.array([float(e[k]) for e in r])
    for lo, hi in [(2, 71), (2, 36), (36, 71), (10, 71)]:
        m = (f >= lo) & (f <= hi); p = np.polyfit(f[m], x[m], 2)
        res = x[m] - np.polyval(p, f[m])
        print(k, lo, hi, 'a_px/f2 %.4f a_px/s2 %.2f t0 %.2f rms %.2f' % (2*p[0], 2*p[0]*576, -p[1]/(2*p[0]), res.std()))
    print('steps', np.round(np.diff(x)[:8], 2), np.round(np.diff(x)[-5:], 2))
p = list(csv.DictReader(open('scene/tracks/plane.csv')))
pf = np.array([float(x['frame']) for x in p]); px = np.array([float(x['ref_x']) for x in p])
print('plane ref steps', np.round(np.diff(px), 2))
for k in ['nose_x_fit', 'tail_x_fit']:
    v = np.array([float(e[k]) for e in p]); print(k, np.round(np.diff(v)[2:20], 2))
print([(e['frame'], e['bbox_centre_x'], e['vis_bbox_x0'], e['vis_bbox_x1']) for e in p if e['bbox_centre_x']])
