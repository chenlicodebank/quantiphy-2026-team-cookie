import av, numpy as np, cv2
V = '/private/tmp/qp_blind/scene_full_b/simulation_0111/q_224/simulation_0111.mp4'
X0, X1 = 540, 730
pre_ids = list(range(3, 70, 3))
post_ids = list(range(203, 211))
want = set(pre_ids + post_ids + [40, 200])
frames = {}
c = av.open(V)
for i, f in enumerate(c.decode(video=0)):
    if i in want:
        frames[i] = f.to_ndarray(format='gray').astype(float)[:, X0:X1]
c.close()
res = []
for i in sorted(set(pre_ids + post_ids)):
    bg = frames[200] if i < 100 else frames[40]
    g = frames[i]
    d = np.abs(g - bg)
    m = (d > 25) & (g > 60)
    m = cv2.morphologyEx(m.astype(np.uint8), cv2.MORPH_OPEN, np.ones((2, 2), np.uint8))
    n, lab, st, _ = cv2.connectedComponentsWithStats(m)
    k = 1 + np.argmax(st[1:, cv2.CC_STAT_AREA])
    bm = lab == k
    # merge components within 25 px vertically & overlapping columns (stem post)
    x, y, w, h, a = st[k]
    for j in range(1, n):
        if j == k: continue
        xj, yj, wj, hj, aj = st[j]
        if aj >= 5 and xj + wj > x and xj < x + w and (yj + hj > y - 25) and yj < y + h + 25:
            bm |= lab == j
    rows = np.where(bm.any(1))[0]
    widths = bm.sum(1)
    w10 = np.where(widths >= 10)[0]
    cols = np.where(bm.any(0))[0]
    res.append((i, rows[0], rows[-1], w10[0], w10[-1]))
    print(i, 'mask', rows[0], rows[-1], rows[-1] - rows[0] + 1, '| w>=10', w10[0], w10[-1], w10[-1] - w10[0] + 1,
          '| width', cols[0] + X0, cols[-1] + X0, cols[-1] - cols[0] + 1)
r = np.array(res, float)
pre = r[r[:, 0] < 100]; post = r[r[:, 0] > 200]
pre = pre[pre[:, 0] >= 3]
for name, col in [('mask top', 1), ('bottom tip', 2), ('hull top', 3)]:
    print(name, 'pre slope', np.polyfit(pre[:, 0], pre[:, col], 1))
A = np.r_[pre[:, [0, 2]], post[:, [0, 2]]]
p = np.polyfit(A[:, 0], A[:, 1], 1)
print('overall bottom tip slope px/frame', p, 'resid rms', np.std(A[:, 1] - np.polyval(p, A[:, 0])))
