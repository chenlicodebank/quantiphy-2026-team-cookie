import av, numpy as np
V = '/private/tmp/qp_blind/scene_full_b/simulation_0111/q_224/simulation_0111.mp4'
X0, X1 = 590, 680
want = {36, 40, 200, 209}
fr = {}
c = av.open(V)
for i, f in enumerate(c.decode(video=0)):
    if i in want:
        fr[i] = f.to_ndarray(format='gray').astype(float)[:, X0:X1]
c.close()
for i, bg, ys in [(36, 200, list(range(336, 366)) + list(range(575, 597))),
                  (209, 40, list(range(1284, 1312)) + list(range(1528, 1548)))]:
    d = fr[i] - fr[bg]
    print('frame', i)
    for y in ys:
        row = d[y]
        on = np.where(row > 20)[0]
        print(y, 'n>20:', len(on), 'cols', (on.min() + X0, on.max() + X0) if len(on) else '', 'max diff %.0f' % row.max(),
              'at', row.argmax() + X0)
