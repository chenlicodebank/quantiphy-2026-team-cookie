"""(1) B speed constancy (constant depth check). (2) Focal length from B's off-axis growth of the body area
(sphere at fixed depth: area ~ 1/cos(theta)). (3) projective fit of A's track."""
import json, numpy as np


class _R: pass
def least_squares(fun, x0, iters=200):
    x = np.array(x0, float)
    lam = 1e-3
    for _ in range(iters):
        r = fun(x)
        J = np.empty((len(r), len(x)))
        for j in range(len(x)):
            h = 1e-6 * max(abs(x[j]), 1e-3)
            xp = x.copy(); xp[j] += h
            J[:, j] = (fun(xp) - r) / h
        A = J.T @ J; g = J.T @ r
        dx = -np.linalg.solve(A + lam * np.diag(np.diag(A)), g)
        if (fun(x + dx) ** 2).sum() < (r ** 2).sum():
            x = x + dx; lam *= 0.3
        else:
            lam *= 10
    o = _R(); o.x = x; o.fun = fun(x); o.jac = J
    return o

fl = json.load(open('scene/scripts/flow.json'))
el = json.load(open('ellipse.json'))
cx, cy = 960.0, 540.0

B = np.array([x[:3] for x in fl['B'][:59]], float)
print('B per-frame |d| frames 2..30:', np.round(np.hypot(B[1:30, 1], B[1:30, 2]), 3))
k = np.arange(2, 24)
sp = np.hypot(B[1:23, 1], B[1:23, 2])
print('B speed slope px/frame^2:', np.polyfit(k, sp, 1)[0], ' rel change over 2..23:', np.polyfit(k, sp, 1)[0] * 21 / sp.mean())

eb = el['B'][1:]
r2 = np.array([(e['ex'] - cx) ** 2 + (e['ey'] - cy) ** 2 for e in eb])
area = np.array([e['area'] for e in eb], float)
# area = A0 / cos(theta) = A0 * sqrt(1 + r^2/f^2)
def res(p):
    A0, f = p
    return area - A0 * np.sqrt(1 + r2 / f ** 2)
s = least_squares(res, [area[0], 2500])
J = s.jac; cov = np.linalg.inv(J.T @ J) * (s.fun ** 2).sum() / (len(area) - 2)
print('B area fit: A0=%.0f f=%.0f +- %.0f   rms=%.1f' % (s.x[0], s.x[1], np.sqrt(cov[1, 1]), np.sqrt((s.fun ** 2).mean())))

# A: cumulative centre from flow, anchored to scene track at frame 0
A = np.array([x[:3] for x in fl['A'][:61]], float)
pos = [np.array([721.48, 568.44])]
for row in A[:, 1:3]:
    pos.append(pos[-1] + row)
pos = np.array(pos)  # index = frame
np.save('A_pos.npy', pos)
fr = np.arange(1, 48)
P = pos[fr]
# model: u = cx + (a + b k)/(1+g k), v = cy + (c + d k)/(1+g k), k = frame-1
def resA(p, cxx=cx):
    a, b, c, d, g = p
    kk = fr - 1
    return np.r_[P[:, 0] - (cxx + (a + b * kk) / (1 + g * kk)), P[:, 1] - (cy + (c + d * kk) / (1 + g * kk))]
s = least_squares(resA, [-238, 0, 28, -11.4, -0.0018])
print('A projective fit (cx=960):', np.round(s.x, 6), 'rms', np.sqrt((s.fun ** 2).mean()))
# with b=0 forced, free cx
def resA2(p):
    a, c, d, g, cxx = p
    return resA([a, 0, c, d, g], cxx)
s2 = least_squares(resA2, [-238, 28, -11.4, -0.0018, 960])
print('A fit b=0, free cx:', np.round(s2.x, 6), 'rms', np.sqrt((s2.fun ** 2).mean()))
ea = el['A'][1:]
kA = np.array([e['f'] for e in ea]) - 1
eqA = np.array([2 * np.sqrt(e['area'] / np.pi) for e in ea])
print('A 1/eqdiam slope rel:', np.polyfit(kA, 1 / eqA, 1)[0] / np.polyfit(kA, 1 / eqA, 1)[1])
