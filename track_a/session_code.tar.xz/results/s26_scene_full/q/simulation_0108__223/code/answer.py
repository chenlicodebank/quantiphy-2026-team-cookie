"""3D reconstruction (units: pixel-equivalents at A's start depth Z0) and distance at t=2.0 s (frame 48).
A: constant 3D velocity, projective fit u = cx+(a+b k)/(1+g k), v = cy+(c+d k)/(1+g k), k = frame-1.
B: constant pixel velocity (constant depth). Depth of B: H1 = same world plane as A's motion (pitched camera),
H2 = same depth as A at start."""
import json, numpy as np

cx, cy = 960.0, 540.0
a, b, c, d, g = -238.408694, -0.01682, 28.571465, -11.550432, -0.001413
fl = json.load(open('scene/scripts/flow.json'))
Bd = np.array([x[1:3] for x in fl['B'][1:30]], float)  # frames 2..30 steps
vB = Bd.mean(0)
B0 = np.array([1305.72, 614.64])
pos = np.load('A_pos.npy')
FR = 48
k = FR - 1
uA = cx + (a + b * k) / (1 + g * k); vA = cy + (c + d * k) / (1 + g * k)
print('A model at 48:', uA, vA, ' flow-cumulative:', pos[FR])
uB, vB_ = B0 + vB * k
print('B at 48 (const vel):', uB, vB_, ' vB', vB)
SPEED = 1.7393
for f in [1500, 2000, 2667, 3000, 3461, 4000, 5000]:
    ZA = f * (1 + g * k)
    PA = np.array([(uA - cx) * (1 + g * k), (vA - cy) * (1 + g * k), ZA])
    vel = np.array([b, d, f * g])
    sp = np.linalg.norm(vel)
    tanp = f * abs(g) / abs(d)
    out = []
    for hyp in ('H1', 'H2'):
        if hyp == 'H1':
            # plane through A start spanned by X axis and A velocity: normal n = (0, -vel_z, vel_y) approx
            n = np.cross([1, 0, 0], vel); n /= np.linalg.norm(n)
            PA0 = np.array([a, c, f])
            ray = np.array([uB - cx, vB_ - cy, f]) / f
            ZB = (n @ PA0) / (n @ ray)
        else:
            ZB = f
        PB = np.array([(uB - cx) * ZB / f, (vB_ - cy) * ZB / f, ZB])
        D = np.linalg.norm(PA - PB)
        out.append((hyp, round(ZB / f, 4), round(D, 1), round(D / sp * SPEED / 24, 4)))
    print('f=%d pitch=%.1fdeg speed=%.3f px/fr' % (f, np.degrees(np.arctan(tanp)), sp), out)
# naive 2D: pixel distance / pixel speed
pd = np.hypot(uA - uB, vA - vB_)
for kk in (1, 47):
    s = np.hypot(b, d / (1 + g * kk) ** 2)
print('naive 2D: pixel dist %.1f; with A pixel speed at frame 48 (%.2f): %.3f m; frame 2 (%.2f): %.3f m' % (
    pd, np.linalg.norm(pos[48] - pos[47]), pd / np.linalg.norm(pos[48] - pos[47]) * SPEED / 24 * 1,
    np.linalg.norm(pos[2] - pos[1]), pd / np.linalg.norm(pos[2] - pos[1]) * SPEED / 24))
