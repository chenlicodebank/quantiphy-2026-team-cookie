"""Fit ellipses to the spike-free body of each virus; report width/height and radial/tangential axes."""
import av, json, numpy as np, cv2

V = 'simulation_0108.mp4'
ker = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (61, 61))
res = {'A': [], 'B': []}
with av.open(V) as c:
    for i, fr in enumerate(c.decode(video=0)):
        if i > 27:
            break
        img = fr.to_ndarray(format='bgr24').astype(np.int16)
        diff = np.abs(img - np.array([204, 204, 204])).max(2)
        m = (diff > 25).astype(np.uint8)
        for name, xr in (('A', (0, 1000)), ('B', (1000, 1920))):
            if name == 'B' and i > 23:
                continue
            mk = np.zeros_like(m)
            mk[:, xr[0]:xr[1]] = m[:, xr[0]:xr[1]]
            core = cv2.morphologyEx(mk, cv2.MORPH_OPEN, ker)
            n, lab, st, cen = cv2.connectedComponentsWithStats(core)
            k = 1 + np.argmax(st[1:, cv2.CC_STAT_AREA])
            core = (lab == k).astype(np.uint8)
            cnts, _ = cv2.findContours(core, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
            pts = cnts[0][:, 0, :].astype(np.float32)
            (ex, ey), (a1, a2), ang = cv2.fitEllipse(pts)
            # moments-based second moments of the core region
            ys, xs = np.nonzero(core)
            sx, sy = xs.std(), ys.std()
            res[name].append(dict(f=i, ex=ex, ey=ey, a1=a1, a2=a2, ang=ang, sx=float(sx), sy=float(sy),
                                  area=int(core.sum())))
for name in res:
    for r in res[name]:
        print(name, r['f'], round(r['ex'], 1), round(r['ey'], 1), round(r['a1'], 1), round(r['a2'], 1), round(r['ang'], 1),
              'sx/sy', round(r['sx'] / r['sy'], 4), 'eqdiam', round(2 * np.sqrt(r['area'] / np.pi), 2))
json.dump(res, open('ellipse.json', 'w'))
