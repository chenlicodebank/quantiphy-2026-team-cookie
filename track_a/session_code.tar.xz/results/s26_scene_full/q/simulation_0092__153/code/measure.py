import av, numpy as np
import cv2
want = set(range(0, 73, 4)) | {22, 23, 24, 25, 26, 30, 34}
frames = {}
c = av.open('simulation_0092.mp4')
for i, f in enumerate(c.decode(video=0)):
    if i in want:
        frames[i] = f.to_ndarray(format='rgb24').astype(np.int16)
bg = np.median(np.stack([frames[i] for i in range(0, 73, 4)]), axis=0)
def mask(i, rows):
    d = np.abs(frames[i] - bg).max(2) > 12
    d = cv2.morphologyEx(d.astype(np.uint8), cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    m = np.zeros_like(d); m[rows[0]:rows[1]] = d[rows[0]:rows[1]]
    n, lab, st, _ = cv2.connectedComponentsWithStats(m)
    keep = np.isin(lab, [k for k in range(1, n) if st[k, 4] >= 30])
    ys, xs = np.nonzero(keep)
    return xs.min(), xs.max(), ys.min(), ys.max()
for i in [22, 23, 24, 25, 26, 30, 34]:
    a = mask(i, (250, 590)); cr = mask(i, (590, 760))
    print(i, 'plane x0,x1', a[0], a[1], 'L', a[1]-a[0]+1, ' car x0,x1', cr[0], cr[1], 'L', cr[1]-cr[0]+1)
