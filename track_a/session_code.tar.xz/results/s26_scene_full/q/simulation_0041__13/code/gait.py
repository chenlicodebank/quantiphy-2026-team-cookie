# Gait periodicity of the person: detrended centroid y / x, height, feet_y
import csv, numpy as np
rows = list(csv.DictReader(open('scene/tracks/person.csv')))
fr = np.array([int(r['frame']) for r in rows])
def col(k): return np.array([float(r[k]) for r in rows])
sel = fr >= 1
for k in ['ref_x', 'ref_y', 'head_top_y', 'feet_y', 'bb_w']:
    v = col(k)[sel]; f = fr[sel]
    p = np.polyfit(f, v, 1); res = v - np.polyval(p, f)
    F = np.abs(np.fft.rfft(res * np.hanning(len(res)), 512))
    fq = np.fft.rfftfreq(512, 1 / 24.)
    m = (fq > 0.5) & (fq < 5)
    print(k, 'slope px/frame %.3f' % p[0], 'peak freq %.2f Hz' % fq[m][np.argmax(F[m])])
fy = col('feet_y')
print('feet_y per frame:', ' '.join('%d' % v for v in fy))
print('head_top_y:', ' '.join('%d' % v for v in col('head_top_y')))
print('feet_x:', ' '.join('%d' % v for v in col('feet_x')))
