# Person vertical extent (head top to sole) at feet-together and stride frames, from colour-difference to sand
import av, numpy as np, cv2, csv
rows = list(csv.DictReader(open('scene/tracks/person.csv')))
want = {10, 17, 26, 34, 45, 51, 61, 67}
c = av.open('simulation_0041.mp4')
for i, f in enumerate(c.decode(video=0)):
    if i not in want: continue
    img = f.to_ndarray(format='rgb24').astype(np.float32)
    ht = int(float(rows[i]['head_top_y'])); fx = int(float(rows[i]['feet_x']))
    y0, x0 = ht - 12, 345
    cr = img[y0:y0 + 70, x0:x0 + 34]
    # sand reference: left part of crop (shadow goes right)
    sand = np.median(np.concatenate([cr[:6].reshape(-1, 3), cr[:, :4].reshape(-1, 3)]), axis=0)
    d = np.linalg.norm(cr - sand, axis=2)
    # exclude shadow: shadow is dark & extends to the right: limit columns to body column via bright shirt columns
    sh = cr.mean(axis=2) > sand.mean() + 25
    cols = np.nonzero(sh.any(axis=0))[0]
    c0, c1 = max(cols.min() - 2, 0), cols.max() + 3
    prof = d[:, c0:c1].max(axis=1)
    thr = 0.5 * np.percentile(prof, 90)
    on = np.nonzero(prof > thr)[0]
    top = on.min(); bot = on.max()
    # sub-pixel: linear interpolate the crossing
    def cross(a, b):
        return a + (thr - prof[a]) / (prof[b] - prof[a]) * (b - a)
    tops = cross(top - 1, top); bots = cross(bot + 1, bot)
    print(i, 'cols %d-%d' % (c0 + x0, c1 + x0), 'top %.1f bottom %.1f extent %.1f' % (tops + y0, bots + y0, bots - tops),
          ' (csv %s-%s)' % (rows[i]['head_top_y'], rows[i]['feet_y']))
