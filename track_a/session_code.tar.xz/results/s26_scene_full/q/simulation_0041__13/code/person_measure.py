# Measure person extent (height, shoulder-row width) on several frames; save zoom crops with profile
import av, numpy as np, cv2, csv
rows = list(csv.DictReader(open('scene/tracks/person.csv')))
want = set(range(0, 72, 6))
c = av.open('simulation_0041.mp4')
# background: median of a few frames far apart in person-free sense isn't possible; use local sand colour
out = []
for i, f in enumerate(c.decode(video=0)):
    if i not in want: continue
    img = f.to_ndarray(format='rgb24').astype(np.float32)
    r = rows[i]
    cx, cy = float(r['ref_x']), float(r['ref_y'])
    x0, y0 = int(cx) - 25, int(cy) - 40
    crop = img[y0:y0 + 80, x0:x0 + 50]
    sand = np.median(crop[:8].reshape(-1, 3), axis=0)
    d = np.linalg.norm(crop - sand, axis=2)
    bright = crop.mean(axis=2) > sand.mean() + 25  # shirt / skin
    ys, xs = np.nonzero(bright)
    # width of bright (shirt + arms) per row
    widths = []
    for yy in np.unique(ys):
        xx = xs[ys == yy]
        widths.append((yy + y0, xx.min() + x0, xx.max() + x0, xx.max() - xx.min() + 1))
    wmax = max(w[3] for w in widths)
    # sub-pixel width: at the row of max width, threshold profile at half contrast
    print(i, 'bbox_h', r['bb_y1'] if 'bb_y1' in r else '', 'head_top', r['head_top_y'], 'feet', r['feet_y'],
          'H=%.1f' % (float(r['feet_y']) - float(r['head_top_y'])), 'bright rows', ys.min() + y0, ys.max() + y0,
          'max bright width', wmax, 'bb_w', r.get('bb_w'))
    if i in (24, 48):
        big = cv2.resize(crop.astype(np.uint8), None, fx=8, fy=8, interpolation=cv2.INTER_NEAREST)
        cv2.imwrite('frames/pz_%02d.png' % i, cv2.cvtColor(big, cv2.COLOR_RGB2BGR))
        for w in widths: print('   row', w)
