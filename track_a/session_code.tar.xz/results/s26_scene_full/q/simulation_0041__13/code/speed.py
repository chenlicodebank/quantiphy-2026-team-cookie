# Boat pixel velocity: windows and local fit around frame 24
import csv, numpy as np
rows = list(csv.DictReader(open('scene/tracks/boat.csv')))
x = np.array([float(r['ref_x']) for r in rows]); y = np.array([float(r['ref_y']) for r in rows])
f = np.arange(len(x))
for a, b in [(2, 22), (22, 42), (42, 62), (2, 32), (32, 62)]:
    d = np.hypot(x[b] - x[a], y[b] - y[a]) / (b - a)
    print('frames %d-%d: %.4f px/frame  vx %.3f vy %.3f  mean y %.1f' % (a, b, d, (x[b]-x[a])/(b-a), (y[b]-y[a])/(b-a), y[a:b+1].mean()))
for half in (5, 8, 12):
    s = slice(24 - half, 24 + half + 1)
    px = np.polyfit(f[s], x[s], 1)[0]; py = np.polyfit(f[s], y[s], 1)[0]
    print('fit +-%d around 24: vx %.3f vy %.3f |v| %.3f' % (half, px, py, np.hypot(px, py)))
print('raw backward diff at 24: vx %.3f vy %.3f |v| %.3f' % (x[24]-x[23], y[24]-y[23], np.hypot(x[24]-x[23], y[24]-y[23])))
st = np.hypot(np.diff(x), np.diff(y))
print('per-frame steps 18..30:', np.round(st[17:30], 2))
