# Check apparent boat scale change vs frame (perspective) with template scale search
import av, numpy as np, cv2, csv
rows = list(csv.DictReader(open('scene/tracks/boat.csv')))
want = {4, 16, 30, 44, 58}
frames = {}
c = av.open('simulation_0041.mp4')
for i, f in enumerate(c.decode(video=0)):
    if i in want:
        frames[i] = cv2.cvtColor(f.to_ndarray(format='bgr24'), cv2.COLOR_BGR2GRAY).astype(np.float32)
    if i > max(want): break
ref = frames[30]
r30 = rows[30]
# template: boat bbox at frame 30 (shrink a bit to stay inside boat)
x0, y0, x1, y1 = [int(float(r30[k])) for k in ('bb_x0', 'bb_y0', 'bb_x1', 'bb_y1')]
x0 += 15; x1 -= 15; y0 += 40; y1 -= 5
tpl = ref[y0:y1, x0:x1]
cx, cy = float(r30['ref_x']), float(r30['ref_y'])
for i in sorted(want):
    if i == 30: continue
    dx = float(rows[i]['ref_x']) - cx; dy = float(rows[i]['ref_y']) - cy
    best = None
    for s in np.arange(0.96, 1.041, 0.004):
        # scale template about the reference centroid
        M = np.array([[s, 0, (1 - s) * (cx - x0)], [0, s, (1 - s) * (cy - y0)]], np.float32)
        t = cv2.warpAffine(tpl, M, (tpl.shape[1], tpl.shape[0]), flags=cv2.INTER_LINEAR)
        m = 25
        t = t[m:-m, m:-m]
        sx0 = int(round(x0 + dx)) + m - 8; sy0 = int(round(y0 + dy)) + m - 8
        win = frames[i][sy0:sy0 + t.shape[0] + 16, sx0:sx0 + t.shape[1] + 16]
        if win.shape[1] < t.shape[1] + 16: continue
        res = cv2.matchTemplate(win, t, cv2.TM_CCOEFF_NORMED)
        v = res.max()
        if best is None or v > best[0]: best = (v, s)
    print(i, 'ref_y=%.1f' % float(rows[i]['ref_y']), 'best scale %.3f ncc %.4f' % (best[1], best[0]))
