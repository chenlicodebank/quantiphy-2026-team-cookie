# Fine scale search of boat template (frame 30) at frames 4..60 -> perspective gradient d ln s / dy
import av, numpy as np, cv2, csv
rows = list(csv.DictReader(open('scene/tracks/boat.csv')))
want = set(range(4, 61, 4)) | {30}
frames = {}
c = av.open('simulation_0041.mp4')
for i, f in enumerate(c.decode(video=0)):
    if i in want:
        frames[i] = cv2.cvtColor(f.to_ndarray(format='bgr24'), cv2.COLOR_BGR2GRAY).astype(np.float32)
    if i > max(want): break
r30 = rows[30]
x0, y0, x1, y1 = [int(float(r30[k])) for k in ('bb_x0', 'bb_y0', 'bb_x1', 'bb_y1')]
x0 += 10; x1 -= 10; y0 += 60; y1 -= 5   # exclude mast tip / keep hull, cabin, deck
tpl = frames[30][y0:y1, x0:x1]
cx, cy = float(r30['ref_x']), float(r30['ref_y'])
res_s = []
for i in sorted(want):
    if i == 30: continue
    dx = float(rows[i]['ref_x']) - cx; dy = float(rows[i]['ref_y']) - cy
    scores = []
    ss = np.arange(0.97, 1.0301, 0.002)
    for s in ss:
        M = np.array([[s, 0, (1 - s) * (cx - x0)], [0, s, (1 - s) * (cy - y0)]], np.float32)
        t = cv2.warpAffine(tpl, M, (tpl.shape[1], tpl.shape[0]), flags=cv2.INTER_CUBIC)
        m = 20; t = t[m:-m, m:-m]
        sx0 = int(round(x0 + dx)) + m - 6; sy0 = int(round(y0 + dy)) + m - 6
        if sx0 < 0: scores.append(-1); continue
        win = frames[i][sy0:sy0 + t.shape[0] + 12, sx0:sx0 + t.shape[1] + 12]
        r = cv2.matchTemplate(win, t, cv2.TM_CCOEFF_NORMED)
        scores.append(r.max())
    scores = np.array(scores); j = np.argmax(scores)
    # parabolic refine
    if 0 < j < len(ss) - 1:
        a, b, cc = scores[j - 1:j + 2]; off = 0.5 * (a - cc) / (a - 2 * b + cc)
    else: off = 0
    s_best = ss[j] + off * 0.002
    res_s.append((i, cy + dy, s_best))
    print(i, 'y=%.1f scale=%.4f ncc=%.4f' % (cy + dy, s_best, scores[j]))
a = np.array(res_s)
p = np.polyfit(a[:, 1] - cy, np.log(a[:, 2]), 1)
print('d ln s / dy = %.2e per px' % p[0], ' -> ratio boat(y=945)/person(y=428): %.4f' % np.exp(p[0] * (945 - 428)))
