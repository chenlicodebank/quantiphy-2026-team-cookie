# Teal aft-deck hatch (a horizontal rectangle): fit quadrilateral -> image directions of boat axis and transverse
import av, numpy as np, cv2
want = {10, 20, 30, 40, 50}
c = av.open('simulation_0041.mp4')
for i, f in enumerate(c.decode(video=0)):
    if i not in want: continue
    img = f.to_ndarray(format='bgr24')
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    b, g, r = [img[..., k].astype(int) for k in range(3)]
    teal = ((g > r + 25) & (b > r + 10) & (g > 120)).astype(np.uint8)
    teal[:700] = 0
    n, lab, st, cen = cv2.connectedComponentsWithStats(teal)
    k = 1 + np.argmax(st[1:, 4])
    m = (lab == k).astype(np.uint8)
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((3, 3), np.uint8))
    cnts, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    cnt = max(cnts, key=cv2.contourArea)
    hull = cv2.convexHull(cnt)
    # minimal-area enclosing quadrilateral via approxPolyDP with increasing eps until 4 vertices
    for eps in np.arange(1, 15, 0.5):
        poly = cv2.approxPolyDP(hull, eps, True).reshape(-1, 2)
        if len(poly) <= 4: break
    P = poly.astype(float)
    out = []
    for a in range(len(P)):
        d = P[(a + 1) % len(P)] - P[a]
        out.append('%.1f@%.1f' % (np.hypot(*d), np.degrees(np.arctan2(d[1], d[0]))))
    print(i, 'area', st[k][4], 'bbox', st[k][:4], 'eps', eps, 'quad', P.tolist(), out)
    if i == 30:
        x, y, w, h = st[k][:4]
        big = cv2.resize(img[y - 10:y + h + 10, x - 10:x + w + 10], None, fx=8, fy=8, interpolation=cv2.INTER_NEAREST)
        for p, q in zip(P, np.roll(P, -1, axis=0)):
            cv2.line(big, tuple(((p - [x - 10, y - 10]) * 8 + 4).astype(int)), tuple(((q - [x - 10, y - 10]) * 8 + 4).astype(int)), (0, 0, 255), 1)
        cv2.imwrite('frames/hatch30.png', big)
