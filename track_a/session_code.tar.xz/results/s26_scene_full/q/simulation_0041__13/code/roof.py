# Extract red cabin roof polygon to get the image direction of the boat's transverse axis
import av, numpy as np, cv2
want = {10, 30, 50}
c = av.open('simulation_0041.mp4')
for i, f in enumerate(c.decode(video=0)):
    if i not in want: continue
    img = f.to_ndarray(format='bgr24')
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    red = (((hsv[..., 0] < 8) | (hsv[..., 0] > 172)) & (hsv[..., 1] > 120) & (hsv[..., 2] > 90)).astype(np.uint8)
    n, lab, st, cen = cv2.connectedComponentsWithStats(red)
    # the roof: compact red blob above the hull, area 2000-8000, y < hull
    cands = [(k, st[k]) for k in range(1, n) if 1500 < st[k][4] < 12000]
    for k, s in cands:
        print(i, 'blob', k, s, cen[k])
    # choose blob whose bbox height/width ~ roof (not elongated hull)
    k = min(cands, key=lambda ks: ks[1][1])[0]  # topmost
    m = (lab == k).astype(np.uint8)
    cnts, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    cnt = max(cnts, key=cv2.contourArea)
    hull = cv2.convexHull(cnt)
    for eps in (3, 5, 8):
        poly = cv2.approxPolyDP(hull, eps, True).reshape(-1, 2)
        print('  eps', eps, 'poly', poly.tolist())
        P = poly.astype(float)
        for a in range(len(P)):
            b = (a + 1) % len(P)
            d = P[b] - P[a]
            print('    edge %s->%s len %.1f angle %.1f deg' % (P[a].tolist(), P[b].tolist(), np.hypot(*d), np.degrees(np.arctan2(d[1], d[0]))))
    x, y, w, h = cv2.boundingRect(cnt)
    big = cv2.resize(img[y - 20:y + h + 20, x - 20:x + w + 20], None, fx=6, fy=6, interpolation=cv2.INTER_NEAREST)
    poly = cv2.approxPolyDP(hull, 5, True).reshape(-1, 2)
    for p, q in zip(poly, np.roll(poly, -1, axis=0)):
        cv2.line(big, tuple(((p - [x - 20, y - 20]) * 6 + 3).astype(int)), tuple(((q - [x - 20, y - 20]) * 6 + 3).astype(int)), (255, 255, 0), 1)
    cv2.imwrite('frames/roof_%02d.png' % i, big)
