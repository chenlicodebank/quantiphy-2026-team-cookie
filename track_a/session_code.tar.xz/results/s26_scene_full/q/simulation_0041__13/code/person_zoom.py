# zoom crops of the person at chosen frames, side by side, with 5px grid
import av, numpy as np, cv2, csv, sys
rows = list(csv.DictReader(open('scene/tracks/person.csv')))
want = [int(a) for a in sys.argv[1:]]
c = av.open('simulation_0041.mp4')
tiles = {}
for i, f in enumerate(c.decode(video=0)):
    if i in want:
        img = f.to_ndarray(format='bgr24')
        y0 = int(float(rows[i]['head_top_y'])) - 8; x0 = 340
        cr = img[y0:y0 + 64, x0:x0 + 48]
        big = cv2.resize(cr, None, fx=8, fy=8, interpolation=cv2.INTER_NEAREST)
        for yy in range(0, 64, 5):
            cv2.line(big, (0, yy * 8), (8, yy * 8), (0, 255, 255), 1)
        cv2.putText(big, '%d y0=%d' % (i, y0), (5, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
        tiles[i] = big
    if i > max(want): break
cv2.imwrite('frames/pz_multi.png', np.hstack([tiles[i] for i in want]))
