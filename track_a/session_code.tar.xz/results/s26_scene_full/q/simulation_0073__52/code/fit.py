import numpy as np, csv, os
D = os.path.dirname(os.path.abspath(__file__))
def load(n):
    r = list(csv.DictReader(open(f'{D}/scene/tracks/{n}.csv')))
    return r, np.array([float(x['frame']) for x in r])
r, f = load('van'); print(list(r[0].keys()))
rc, fc = load('cyclist')
def col(rows, end):
    c = [k for k in rows[0] if k.endswith(end)][0]
    return np.array([float(x[c]) for x in rows])
y = col(r, 'cy_px'); yc = col(rc, 'cy_px')
m = fc >= 2
p = np.polyfit(fc[m], yc[m], 1); print('cyc centroid px/frame', p[0], 'rms', np.std(yc[m] - np.polyval(p, fc[m])))
for e in ['y0', 'y1']:
    print('cyc', e, np.polyfit(fc[m], col(rc, e)[m], 1)[0])
for a, b in [(0, 72), (0, 48), (10, 40), (24, 72), (14, 34)]:
    q = np.polyfit(f[a:b], y[a:b], 2); print(a, b, 'van accel px/f2', 2 * q[0])
for e in ['y0', 'y1']:
    print('van', e, 2 * np.polyfit(f, col(r, e), 2)[0])
s = abs(p[0]) * 24; mpp = 5.33 / s
print('cyc px/s', s, 'm/px', mpp)
q = np.polyfit(f, y, 2); print('accel m/s2', 2 * abs(q[0]) * 576 * mpp)
