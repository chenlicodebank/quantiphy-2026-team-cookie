import av, numpy as np, cv2
c = av.open('simulation_0084.mp4'); res = {}
for i, f in enumerate(c.decode(video=0)):
    if i < 12: continue
    im = f.to_ndarray(format='rgb24')
    hsv = cv2.cvtColor(im, cv2.COLOR_RGB2HSV); g = cv2.cvtColor(im, cv2.COLOR_RGB2GRAY)
    m = ((g < 113) | (g > 176) | (hsv[..., 1] > 40))[480:571]
    cols = np.where(m.any(0))[0]
    ym = (hsv[480:571, :, 1] > 80) & (hsv[480:571, :, 0] > 15) & (hsv[480:571, :, 0] < 40)
    yc = np.where(ym.any(0))[0]
    cols = cols[(cols > yc.min() - 40) & (cols < yc.max() + 40)]
    res[i] = (cols.min(), cols.max(), yc.min(), yc.max())
fr = np.array(sorted(res))
x0 = np.array([res[i][0] for i in fr]); x1 = np.array([res[i][1] for i in fr])
L = x1 - x0 + 1; cx = (x0 + x1) / 2
for k in range(0, len(fr), 6): print(fr[k], x0[k], x1[k], L[k], res[fr[k]][2:])
p = np.polyfit(fr, cx, 1)
print('cx slope', p[0], 'front slope', np.polyfit(fr, x0, 1)[0], 'rear slope', np.polyfit(fr, x1, 1)[0])
v = abs(p[0]) * 24; s = 5.07 / v
print('px/s', v, 'm/px', s, 'L mean', L.mean(), 'len m', L.mean() * s, L.min() * s, L.max() * s)
