import av, numpy as np, sys
# print luminance rows near the tyre bottoms to locate near/far tyre edges
frames = [int(a) for a in sys.argv[1:]]
c = av.open('simulation_0112.mp4')
for i, fr in enumerate(c.decode(video=0)):
    if i in frames:
        g = fr.to_ndarray(format='gray').astype(int)
        print('frame', i)
        for y in (505, 515, 525, 532):
            row = g[y]
            if i < 27:
                xs = range(120, 260, 3)
            else:
                xs = range(900, 1040, 3)
            print(y, ' '.join(f'{x}:{row[x]}' for x in xs))
    if i > max(frames):
        break
