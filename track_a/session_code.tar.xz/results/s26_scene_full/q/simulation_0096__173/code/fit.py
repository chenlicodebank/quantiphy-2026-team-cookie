import numpy as np, csv
r=list(csv.DictReader(open('scene/tracks/car.csv')))
f=np.array([int(x['frame']) for x in r])
for key in ['ref_x','mask_cx','bbox_x0','bbox_x1']:
    x=np.array([float(q[key]) for q in r])
    for lo in [1,2,5]:
        m=f>=lo
        c=np.polyfit(f[m],x[m],2); res=x[m]-np.polyval(c,f[m])
        print(key,lo,'a px/f^2=%.4f'%(2*c[0]),'t0=%.2f'%(-c[1]/(2*c[0])),'rms %.2f'%res.std())
