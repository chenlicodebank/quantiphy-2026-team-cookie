import av, numpy as np, cv2
c = av.open('simulation_0096.mp4')
fr = {}
for i, f in enumerate(c.decode(video=0)):
    g = f.to_ndarray(format='rgb24')
    fr[i] = g[540:700].astype(np.float32).mean(axis=2)  # car band only
    if i in (3, 5, 8):
        d = np.abs(g.astype(np.int16) - g[20, 20].astype(np.int16)).max(axis=2)
        for th in (10, 18, 30):
            m = d[:540] > th
            m = cv2.morphologyEx(m.astype(np.uint8), cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
            n, lab, st, _ = cv2.connectedComponentsWithStats(m)
            k = 1 + np.argmax(st[1:, 4])
            ys, xs = np.nonzero(lab == k)
            print('plane frame', i, 'th', th, 'height', ys.max() - ys.min() + 1, 'length', xs.max() - xs.min() + 1, 'y', ys.min(), ys.max())
c.close()
# car: subpixel shift vs frame 0 by phase correlation on a window following the car
bgv = fr[0][20:150, 20].mean()
xs = []
tmpl = fr[1][30:100, 830:970] - bgv
for i in range(41):
    # search by brute force over shifts with parabolic refinement
    best = None
    sc = []
    for s in range(-320, 5):
        win = fr[i][30:100, 830 + s:970 + s] - bgv
        sc.append(((win - tmpl) ** 2).sum())
    sc = np.array(sc); k = sc.argmin()
    if 0 < k < len(sc) - 1:
        dk = 0.5 * (sc[k - 1] - sc[k + 1]) / (sc[k - 1] - 2 * sc[k] + sc[k + 1])
    else:
        dk = 0
    xs.append(-320 + k + dk)
xs = np.array(xs); f = np.arange(41)
for lo in (1, 2, 4):
    m = f >= lo
    cc = np.polyfit(f[m], xs[m], 2)
    print('template fit from', lo, 'a px/f^2 = %.4f' % (2 * cc[0]), 'vertex %.2f' % (-cc[1] / (2 * cc[0])), 'rms %.3f' % (xs[m] - np.polyval(cc, f[m])).std())
print(np.round(np.diff(xs), 2))
