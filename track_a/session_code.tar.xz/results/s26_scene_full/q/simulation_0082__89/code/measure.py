import av, numpy as np, cv2
# measure front/rear x for both trucks per frame from a mask (non-ground pixels), core rows
c = av.open('simulation_0082.mp4')
res = []
for i, fr in enumerate(c.decode(video=0)):
    img = fr.to_ndarray(format='rgb24').astype(int)
    mn = img.min(2); mx = img.max(2)
    hsv = cv2.cvtColor(img.astype(np.uint8), cv2.COLOR_RGB2HSV)
    m = (mn < 100) | (mx > 172) | (hsv[..., 1] > 50)
    out = [i]
    for (y0, y1) in [(375, 430), (515, 580)]:
        cols = np.where(m[y0:y1].sum(0) >= 3)[0]
        # largest contiguous run
        runs = np.split(cols, np.where(np.diff(cols) > 40)[0] + 1)
        r = max(runs, key=len)
        out += [r[0], r[-1], r[-1] - r[0] + 1]
    res.append(out)
res = np.array(res)
np.savetxt('lengths.csv', res, fmt='%d', delimiter=',', header='f,y0,y1,yl,w0,w1,wl')
yl, wl = res[:, 3], res[:, 6]
print('same-frame ratio median', np.median(wl / yl))
for i in [0, 1, 20, 40, 55, 71]:
    print(res[i])
# position-matched: for each white frame, yellow frame whose centre is closest
yc = (res[:, 1] + res[:, 2]) / 2; wc = (res[:, 4] + res[:, 5]) / 2
rat = []
for i in range(72):
    j = np.argmin(abs(yc - wc[i]))
    if abs(yc[j] - wc[i]) < 6:
        rat.append(wl[i] / yl[j])
print('pos-matched ratio', np.median(rat), np.mean(rat), len(rat))
print('median lengths', np.median(yl), np.median(wl))
