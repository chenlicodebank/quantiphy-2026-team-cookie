import av, numpy as np, cv2
from scipy import ndimage
V = 'simulation_0072.mp4'
frames = []
with av.open(V) as c:
    for f in c.decode(video=0):
        a = f.to_ndarray(format='rgb24')
        # keep only ROIs: cyclist column and pedestrian strip
        frames.append((a[150:900, 850:990].astype(np.int16).copy(), a[780:900, 1280:1520].astype(np.int16).copy()))
def track(idx, off):
    stack = np.stack([fr[idx] for fr in frames])
    bg = np.median(stack, axis=0)
    out = []
    for k, im in enumerate(stack):
        d = np.abs(im - bg).max(axis=2) > 25
        d = ndimage.binary_opening(d, iterations=1)
        lab, n = ndimage.label(d)
        if n == 0: out.append((np.nan, np.nan)); continue
        sizes = ndimage.sum(d, lab, range(1, n + 1))
        # keep components >= 10% of the largest, near the largest
        big = np.argmax(sizes) + 1
        cy, cx = ndimage.center_of_mass(d, lab, big)
        keep = np.zeros_like(d)
        for i in range(1, n + 1):
            yy, xx = ndimage.center_of_mass(d, lab, i)
            if sizes[i-1] >= 5 and abs(yy-cy) < 45 and abs(xx-cx) < 45: keep |= lab == i
        ys, xs = np.nonzero(keep)
        out.append((xs.mean() + off[0], ys.mean() + off[1], xs.min()+off[0], xs.max()+off[0], ys.min()+off[1], ys.max()+off[1]))
    return np.array(out)
cyc = track(0, (850, 150)); ped = track(1, (1280, 780))
np.save('cyc.npy', cyc); np.save('ped.npy', ped)
t = np.arange(len(frames))
for name, tr, ax in (('cyc', cyc, 1), ('ped', ped, 0)):
    p = tr[:, ax]
    m = t >= 2
    s = np.polyfit(t[m], p[m], 1)[0]
    print(name, 'fit slope px/frame (frames 2..71):', s)
    steps = np.hypot(np.diff(tr[:, 0]), np.diff(tr[:, 1]))
    print(name, 'mean step 2..71', steps[1:].mean())
    if name == 'ped':
        for a, b in ((14, 34), (18, 30), (12, 36), (2, 40), (20, 28)):
            mm = (t >= a) & (t <= b)
            print(' ped window', a, b, np.polyfit(t[mm], p[mm], 1)[0], 'vy', np.polyfit(t[mm], tr[mm, 1], 1)[0])
        # bbox right/left edges
        for col, nm in ((2, 'x0'), (3, 'x1')):
            print(' ped', nm, 'slope 2..71', np.polyfit(t[m], tr[m, col], 1)[0])
    else:
        for col, nm in ((4, 'y0'), (5, 'y1')):
            print(' cyc', nm, 'slope 2..71', np.polyfit(t[m], tr[m, col], 1)[0])
print('ped frames 18..30:'); print(np.round(ped[18:31, :2], 1))
