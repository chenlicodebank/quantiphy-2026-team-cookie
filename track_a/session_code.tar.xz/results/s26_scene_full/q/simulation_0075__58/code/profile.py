import av, numpy as np, os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
def get(idx):
    c=av.open('simulation_0075.mp4')
    for i,f in enumerate(c.decode(video=0)):
        if i in idx: yield i,f.to_ndarray(format='rgb24').astype(int)
        if i>=max(idx): break
fr=dict(get({0,71}))
f0,f71=fr[0],fr[71]
np.set_printoptions(linewidth=250)
def dif(a,b): return np.abs(a-b).max(-1)
# van vertical profile f0, columns 800-860 averaged, diff vs f71 (road)
d=dif(f0,f71)
print('van f0 col profile (rows 790-815, 1035-1060):')
for r in list(range(790,816))+list(range(1035,1060)):
    print(r, d[r,800:860].mean().round(1), f0[r,800:860].mean(0).round(0))
d2=dif(f71,f0)
print('van f71 rows 70-90 / 310-330')
for r in list(range(70,92))+list(range(308,330)):
    print(r, d2[r,800:860].mean().round(1))
print('tan f0 row profile x 940-1045, rows 880-920 avg and 830-850 avg (mirrors)')
for x in range(940,1046):
    print(x, d[880:920,x].mean().round(1), d[830:850,x].max(), d[930:950,x].mean().round(1))
print('tan f71 col profile y 580-690 avg over x 1300-1440')
for y in range(580,692):
    print(y, d2[y,1300:1440].mean().round(1), d2[y,1240:1500].max())
