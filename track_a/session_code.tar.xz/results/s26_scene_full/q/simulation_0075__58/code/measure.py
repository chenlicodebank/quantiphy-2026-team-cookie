import av, numpy as np, cv2, os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
def get(idx):
    c=av.open('simulation_0075.mp4')
    for i,f in enumerate(c.decode(video=0)):
        if i in idx: yield i,f.to_ndarray(format='rgb24').astype(int)
        if i>=max(idx): break
fr=dict(get({0,71}))
f0,f71=fr[0],fr[71]
def meas(img,bg,box,thr,name):
    x0,y0,x1,y1=box
    d=np.abs(img[y0:y1,x0:x1]-bg[y0:y1,x0:x1]).max(2)
    m=(d>thr).astype(np.uint8)
    m=cv2.morphologyEx(m,cv2.MORPH_CLOSE,np.ones((5,5),np.uint8))
    n,l,st,_=cv2.connectedComponentsWithStats(m)
    k=1+np.argmax(st[1:,4]); mm=(l==k)
    ys,xs=np.nonzero(mm)
    rect=cv2.minAreaRect(np.c_[xs,ys].astype(np.float32))
    print(name,thr,'bbox w',xs.max()-xs.min()+1,'h',ys.max()-ys.min()+1,'rect',np.round(rect[1],1))
    return mm
for thr in (15,25,40):
    meas(f0,f71,(900,700,1080,1000),thr,'tan f0')
    meas(f0,f71,(740,780,920,1075),thr,'van f0')
    meas(f71,f0,(1230,560,1520,720),thr,'tan f71')
    meas(f71,f0,(760,40,910,350),thr,'van f71')
