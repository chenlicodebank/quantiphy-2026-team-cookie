import av, numpy as np
V = 'simulation_0102.mp4'
frames = {}
c = av.open(V)
fr = []
for i, f in enumerate(c.decode(video=0)):
    fr.append(f.to_ndarray(format='rgb24')[::, :, :].astype(np.int16) if i in (0, 72) else None)
c.close()
f0, f72 = fr[0], fr[72]
# composite background: underwater uses frame72 for x>200, frame0 for x<=200 ; sky uses frame72 for x<1400
bg = f72.copy()
bg[:, :200] = f0[:, :200]
bg[:672, 1400:] = f0[:672, 1400:]

# boat length on frame 0
d = np.abs(f0 - bg).max(2)[:660]
m = d > 40
cols = np.where(m[300:560].sum(0) > 3)[0]
print('boat frame0 x range', cols.min(), cols.max(), 'len', cols.max() - cols.min() + 1)
# per-row extents
rows = np.where(m.any(1))[0]
print('boat rows', rows.min(), rows.max())

# shark tracking
c = av.open(V)
res = []
for i, f in enumerate(c.decode(video=0)):
    a = f.to_ndarray(format='rgb24').astype(np.int16)
    d = np.abs(a - bg).max(2)[680:]
    ms = d > 60
    ys, xs = np.nonzero(ms)
    if len(xs) == 0:
        res.append((i, np.nan, np.nan, np.nan)); continue
    colsum = ms.sum(0)
    cc = np.where(colsum > 2)[0]
    res.append((i, cc.min(), cc.max(), xs.mean()))
c.close()
res = np.array(res, float)
np.savetxt('shark_track.csv', res, delimiter=',', fmt='%.3f', header='frame,left,right,centroid')
f = res[:, 0]
for k, name in [(1, 'nose(left)'), (2, 'tail(right)'), (3, 'centroid')]:
    for a, b in [(2, 59), (2, 30), (30, 59)]:
        mm = (f >= a) & (f <= b) & ~np.isnan(res[:, k])
        p = np.polyfit(f[mm], res[mm, k], 2)
        print(name, a, b, 'acc px/fr^2', round(2 * p[0], 4))
