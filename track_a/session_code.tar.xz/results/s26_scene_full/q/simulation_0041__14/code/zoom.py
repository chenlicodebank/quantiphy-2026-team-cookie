import av, numpy as np, cv2, sys
frames = [int(a) for a in sys.argv[1:]]
c = av.open('simulation_0041.mp4')
out = []
for i, f in enumerate(c.decode(video=0)):
    if i in frames:
        img = f.to_ndarray(format='bgr24')[380:520, 330:400]
        img = cv2.resize(img, None, fx=6, fy=6, interpolation=cv2.INTER_NEAREST)
        for k in range(0, img.shape[0], 30):
            cv2.line(img, (0, k), (img.shape[1], k), (0, 255, 255), 1)
        for k in range(0, img.shape[1], 30):
            cv2.line(img, (k, 0), (k, img.shape[0]), (0, 255, 255), 1)
        cv2.putText(img, str(i), (5, 20), 0, 0.6, (0, 0, 255), 2)
        out.append(img)
    if i > max(frames): break
cv2.imwrite('frames/zoom.png', np.hstack(out))
