import av, numpy as np, cv2
# background: median over frames of the person region (person moves ~106 px down)
X0, X1, Y0, Y1 = 330, 400, 360, 530
crops = []
c = av.open('simulation_0041.mp4')
for i, f in enumerate(c.decode(video=0)):
    crops.append(f.to_ndarray(format='rgb24')[Y0:Y1, X0:X1].astype(np.float32))
crops = np.array(crops)
bg = np.median(crops, axis=0)
for fr in [0, 17, 34, 51, 68, 25, 42]:
    im = crops[fr]
    diff = np.abs(im - bg).sum(2)
    m = diff > 40
    # light pixels (shirt/skin)
    lum = im.mean(2)
    rows = np.where(m.any(1))[0]
    print('frame', fr)
    for r in rows:
        cols = np.where(m[r])[0]
        lcols = np.where(m[r] & (lum[r] > 150))[0]
        s = ''.join('#' if m[r, k] and lum[r, k] > 150 else ('+' if m[r, k] else '.') for k in range(20, 70))
        print(f'{Y0 + r:4d} {s}')
