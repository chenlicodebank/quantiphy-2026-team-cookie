import av, numpy as np, cv2, sys
fr = int(sys.argv[1]); x0, y0, x1, y1, sc, g = [int(a) for a in sys.argv[2:8]]
c = av.open('simulation_0041.mp4')
for i, f in enumerate(c.decode(video=0)):
    if i == fr:
        img = f.to_ndarray(format='bgr24')[y0:y1, x0:x1]
        break
img = cv2.resize(img, None, fx=sc, fy=sc, interpolation=cv2.INTER_CUBIC)
for k in range(0, y1 - y0, g):
    cv2.line(img, (0, k * sc), (img.shape[1], k * sc), (0, 255, 255), 1)
    cv2.putText(img, str(y0 + k), (2, k * sc + 12), 0, 0.4, (0, 0, 255), 1)
for k in range(0, x1 - x0, g):
    cv2.line(img, (k * sc, 0), (k * sc, img.shape[0]), (0, 255, 255), 1)
    cv2.putText(img, str(x0 + k), (k * sc + 2, 12), 0, 0.4, (255, 0, 0), 1)
cv2.imwrite(sys.argv[8], img)
