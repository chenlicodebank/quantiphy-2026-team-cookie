import av, numpy as np, cv2
want = {0, 16, 20, 23, 24, 28, 32}
out = {}
with av.open('simulation_0083.mp4') as c:
    for i, f in enumerate(c.decode(video=0)):
        if i in want:
            a = f.to_ndarray(format='rgb24').astype(int)
            m = ((a[..., 0] - a[..., 2]) > 30)[340:490]  # yellow chroma, upper lane
            m = cv2.morphologyEx(m.astype(np.uint8), cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8))
            cols = np.where(m.sum(0) > 5)[0]
            out[i] = (cols.min(), cols.max())
            print(i, cols.min(), cols.max(), cols.max() - cols.min() + 1)
        if i > max(want): break
for a, b in [(16, 24), (20, 28), (23, 24), (24, 32)]:
    d = ((out[b][0] + out[b][1]) - (out[a][0] + out[a][1])) / 2 / (b - a)
    print(a, b, 'px/frame', d)
L = out[24][1] - out[24][0] + 1
print('speed m/s', 10 * 24 * 5.67 / L, 'with 270:', 240 * 5.67 / 270)
