import av, numpy as np, cv2, json
V = '/private/tmp/qp_blind/scene_full_a/simulation_0078/q_74/simulation_0078.mp4'
res = {}
c = av.open(V)
for i, fr in enumerate(c.decode(video=0)):
    img = fr.to_ndarray(format='rgb24').astype(int)
    r, g, b = img[..., 0], img[..., 1], img[..., 2]
    # brown hair: r>g>b, darkish, saturated
    hair = (r >= b + 8) & (r >= g + 6) & (r < 125) & (r > 50)
    hair = cv2.morphologyEx(hair.astype(np.uint8), cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
    n, lab, st, cen = cv2.connectedComponentsWithStats(hair)
    out = []
    for k in range(1, n):
        if st[k, 4] > 600:
            out.append((float(cen[k, 0]), float(cen[k, 1]), int(st[k, 4])))
    res[i] = out
c.close()
json.dump(res, open('/private/tmp/qp_blind/scene_full_a/simulation_0078/q_74/heads.json', 'w'))
for i in (6, 17, 24, 40, 71):
    print(i, [(round(x, 1), round(y, 1), n) for x, y, n in res[i]])
