import av, numpy as np
V = '/private/tmp/qp_blind/scene_full_a/simulation_0078/q_74/simulation_0078.mp4'
c = av.open(V)
for i, fr in enumerate(c.decode(video=0)):
    if i == 24:
        img = fr.to_ndarray(format='rgb24').astype(int)
        for (x, y) in [(258, 549), (250, 540), (265, 560), (1757, 560), (1765, 555), (275, 520), (1740, 600), (150, 300)]:
            print((x, y), img[y-2:y+3, x-2:x+3].reshape(-1, 3).mean(0).round())
        break
c.close()
