import json, numpy as np
d = json.load(open('/private/tmp/qp_blind/scene_full_a/simulation_0078/q_74/heads.json'))
A, B = {}, {}
for k, v in d.items():
    i = int(k)
    for x, y, n in v:
        if x < 960 and i >= 6: A[i] = (x, y)
        if x > 960 and i >= 17: B[i] = (x, y)
fa = np.array(sorted(A)); fb = np.array(sorted(B))
pa = np.array([A[i] for i in fa]); pb = np.array([B[i] for i in fb])
for name, f, p in (('A', fa, pa), ('B', fb, pb)):
    s = np.polyfit(f, p[:, 0], 1)
    step = np.hypot(*np.diff(p, axis=0).T)
    print(name, 'fit slope px/frame', s[0].round(3), 'mean per-frame step', step.mean().round(3),
          'net', (np.hypot(*(p[-1] - p[0])) / (f[-1] - f[0])).round(3))
# B speed over windows (one gait cycle ~16.7 frames)
for a, b in ((17, 34), (17, 50), (24, 57), (34, 67), (17, 71)):
    print('B net speed', a, b, round(abs(B[b][0] - B[a][0]) / (b - a), 3))
gap24 = np.hypot(B[24][0] - A[24][0], B[24][1] - A[24][1])
print('head gap @24', round(gap24, 1))
# smoothed gap from linear fits near frame 24 (window 17-40)
fitA = np.polyfit(fa[(fa >= 8) & (fa <= 40)], pa[(fa >= 8) & (fa <= 40), 0], 1)
fitB = np.polyfit(fb[(fb >= 17) & (fb <= 40)], pb[(fb >= 17) & (fb <= 40), 0], 1)
print('fit gap @24', round(np.polyval(fitB, 24) - np.polyval(fitA, 24), 1))
vB = abs(np.polyfit(fb, pb[:, 0], 1)[0])
for v in (vB, 15.0, 14.5):
    print('vB px/fr', round(v, 3), 'D m', round(gap24 / v * 1.3 / 24, 3))
