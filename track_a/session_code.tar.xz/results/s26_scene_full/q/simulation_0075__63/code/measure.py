import av, numpy as np, csv
# measure white van extents by brightness profiles (body is near-white vs grey asphalt)
tr = {int(r['frame']): r for r in csv.DictReader(open('scene/tracks/white_van.csv'))}
c = av.open('simulation_0075.mp4')
res = []
for i, f in enumerate(c.decode(video=0)):
    if i not in (10, 20, 30, 36, 45, 55, 65, 71):
        continue
    img = f.to_ndarray(format='rgb24').astype(float)
    cx, cy = float(tr[i]['ref_x']), float(tr[i]['ref_y'])
    x0, x1 = int(cx - 90), int(cx + 90)
    y0, y1 = max(0, int(cy - 160)), min(1080, int(cy + 160))
    g = img[y0:y1, x0:x1].mean(2)
    bg = np.median(img[y0:y1, x0 - 40:x0 - 10].mean(2))
    m = np.abs(g - bg) > 25
    # width: columns where mask fraction across central rows > 0.5
    rows = m[int(cy) - y0 - 60:int(cy) - y0 + 60]
    colfrac = rows.mean(0)
    cols = np.where(colfrac > 0.5)[0]
    W = cols.max() - cols.min() + 1
    cmid = int(cx) - x0
    rowfrac = m[:, cmid - 25:cmid + 25].mean(1)
    rr = np.where(rowfrac > 0.5)[0]
    L = rr.max() - rr.min() + 1
    res.append((i, L, W, x0 + cols.min(), x0 + cols.max()))
    print(i, 'L', L, 'W', W, 'cols', x0 + cols.min(), x0 + cols.max(), 'rows', y0 + rr.min(), y0 + rr.max(), 'bg', round(bg, 1))
a = np.array(res)
print('median L', np.median(a[:, 1]), 'median W', np.median(a[:, 2]), 'W/L*6', np.median(a[:, 2] / a[:, 1]) * 6)
