import av, numpy as np, cv2
D = '/private/tmp/qp_blind/scene_full_a/simulation_0093/q_156/'
bg = np.array([80, 81, 88.])
c = av.open(D + 'simulation_0093.mp4')
for i, fr in enumerate(c.decode(video=0)):
    a = fr.to_ndarray(format='rgb24').astype(float)
    d = np.abs(a - bg).max(2)
    out = []
    for name, (y0, y1) in [('plane', (330, 580)), ('car', (590, 650))]:
        for th in (12, 25, 40):
            m = (d[y0:y1] > th).astype(np.uint8)
            m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((2, 2), np.uint8))
            n, lab, st, _ = cv2.connectedComponentsWithStats(m)
            k = 1 + np.argmax(st[1:, cv2.CC_STAT_AREA])
            x0 = st[k, 0]; w = st[k, 2]
            out.append(f"{name}{th}:{x0}-{x0+w-1} L={w}")
    print(i, ' '.join(out))
