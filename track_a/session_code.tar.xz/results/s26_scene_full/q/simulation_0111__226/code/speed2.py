import csv, numpy as np
r = list(csv.DictReader(open('scene/tracks/boat.csv')))
print(r[0].keys())
fr = np.array([float(x['frame']) for x in r])
st = [x['state'] for x in r]
y1 = np.array([float(x['y1']) if x['y1'] else np.nan for x in r])
cm = np.array([float(x['cy_meas']) if x['cy_meas'] else np.nan for x in r])
for lo, hi in ((2, 40), (40, 76), (2, 76), (203, 210)):
    s = (fr >= lo) & (fr <= hi) & np.isfinite(y1)
    print(lo, hi, 'y1 slope %.3f' % np.polyfit(fr[s], y1[s], 1)[0], 'cy_meas slope %.3f' % np.polyfit(fr[s], cm[s], 1)[0])
s = np.isfinite(cm) & (fr >= 2)
print('all cy_meas slope', np.polyfit(fr[s], cm[s], 1))
