import av, numpy as np, cv2
c = av.open('simulation_0111.mp4')
for i, f in enumerate(c.decode(video=0)):
    if i == 144: img = f.to_ndarray(format='bgr24'); break
hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV).astype(int)
# orange: hue 5-25, sat>100, val>100
orange = (hsv[..., 0] >= 5) & (hsv[..., 0] <= 25) & (hsv[..., 1] > 90) & (hsv[..., 2] > 90)
res = {}
for name, (y0, y1) in {'top': (740, 900), 'bot': (1150, 1330)}.items():
    pts_out, pts_in = [], []
    for x in range(250, 1100, 10):
        r = np.nonzero(orange[y0:y1, x])[0] + y0
        if len(r) < 3: continue
        # largest contiguous run
        runs = np.split(r, np.nonzero(np.diff(r) > 2)[0] + 1); run = max(runs, key=len)
        if len(run) < 3: continue
        pts_out.append((x, run.min() if name == 'top' else run.max()))
        pts_in.append((x, run.max() if name == 'top' else run.min()))
    po = np.array(pts_out, float)
    # robust line fit
    for _ in range(3):
        p = np.polyfit(po[:, 0], po[:, 1], 1); rsd = po[:, 1] - np.polyval(p, po[:, 0])
        po = po[np.abs(rsd) < max(2.5 * rsd.std(), 1.5)]
    print(name, 'outer fit slope %.4f icpt %.2f n=%d rms %.2f' % (p[0], p[1], len(po), rsd.std()))
    pi = np.array(pts_in, float)
    for _ in range(3):
        q = np.polyfit(pi[:, 0], pi[:, 1], 1); rsd = pi[:, 1] - np.polyval(q, pi[:, 0])
        pi = pi[np.abs(rsd) < max(2.5 * rsd.std(), 1.5)]
    print(name, 'inner fit slope %.4f icpt %.2f n=%d' % (q[0], q[1], len(pi)))
    res[name] = (p, q)
for k in (0, 1):
    pt, pb = res['top'][k], res['bot'][k]
    s = (pt[0] + pb[0]) / 2
    ang = np.degrees(np.arctan(s))
    for x in (400, 631, 900):
        dv = np.polyval(pb, x) - np.polyval(pt, x)
        print(['outer', 'inner'][k], x, 'vertical %.1f perp %.1f ang %.2f' % (dv, dv * np.cos(np.arctan(s)), ang))
