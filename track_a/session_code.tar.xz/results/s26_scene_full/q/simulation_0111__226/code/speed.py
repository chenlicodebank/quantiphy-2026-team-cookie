import av, numpy as np, cv2
# independent boat track: bright boat mask in column band, bottom (bow) tip and top tip in full frames
c = av.open('simulation_0111.mp4')
rows = []
for i, f in enumerate(c.decode(video=0)):
    if i < 3: continue
    if not (i <= 60 or i >= 204): continue
    g = cv2.cvtColor(f.to_ndarray(format='bgr24'), cv2.COLOR_BGR2GRAY)
    band = g[:, 560:700].astype(float)
    m = band > 150
    if i <= 60: m[790:] = False
    else: m[:1290] = False
    prof = m.sum(1)
    r = np.nonzero(prof >= 3)[0]
    if len(r): rows.append((i, r.min(), r.max()))
    else: print('none', i)
a = np.array(rows, float)
for sel, nm in ((a[:, 0] <= 60, 'before'), (a[:, 0] >= 204, 'after')):
    b = a[sel]
    for k, lab in ((1, 'top'), (2, 'bottom')):
        p = np.polyfit(b[:, 0], b[:, k], 1)
        print(nm, lab, 'slope %.3f px/frame' % p[0])
