import av, numpy as np, cv2
want = {5, 10, 70, 75, 205, 210}
F = {}
c = av.open('simulation_0111.mp4')
for i, f in enumerate(c.decode(video=0)):
    if i in want: F[i] = cv2.cvtColor(f.to_ndarray(format='bgr24'), cv2.COLOR_BGR2GRAY).astype(np.float32)
    if i > max(want): break
def loc(i, ref):
    t = F[ref][ref_box[1]:ref_box[3], ref_box[0]:ref_box[2]]
    r = cv2.matchTemplate(F[i], t, cv2.TM_CCOEFF_NORMED)
    _, mx, _, p = cv2.minMaxLoc(r)
    y, x = p[1], p[0]
    # subpixel parabola
    dy = 0.5 * (r[y-1, x] - r[y+1, x]) / (r[y-1, x] - 2*r[y, x] + r[y+1, x])
    return y + dy, x, mx
# boat at frame 10: cy ~ 5.496*10+274 = 329; box around it
cy10 = 5.496 * 10 + 273.8
ref_box = (580, int(cy10 - 125), 690, int(cy10 + 125))
for i in (5, 70, 75):
    y, x, mx = loc(i, 10)
    print(i, 'dy from f10 %.2f per frame %.4f corr %.3f' % (y - ref_box[1], (y - ref_box[1]) / (i - 10), mx))
cy205 = 5.496 * 205 + 273.8
ref_box = (580, int(cy205 - 120), 690, int(cy205 + 120))
for i in (210,):
    y, x, mx = loc(i, 205)
    print(i, 'dy from f205 %.2f per frame %.4f corr %.3f' % (y - ref_box[1], (y - ref_box[1]) / (i - 205), mx))
