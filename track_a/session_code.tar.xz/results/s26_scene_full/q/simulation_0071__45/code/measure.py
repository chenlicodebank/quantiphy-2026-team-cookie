import av, numpy as np, cv2
bg = cv2.imread('scene/scripts/background.jpg')
if bg is None:
    import glob; print(glob.glob('scene/*'), glob.glob('scene/scripts/*'))
want = {0, 1, 66, 68, 70, 71}
c = av.open('simulation_0071.mp4')
for i, fr in enumerate(c.decode(video=0)):
    if i not in want: continue
    img = fr.to_ndarray(format='bgr24')
    d = np.abs(img.astype(int) - bg.astype(int)).sum(2)
    for th in (30, 60):
        m = (d > th).astype(np.uint8)
        m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
        n, lab, st, cen = cv2.connectedComponentsWithStats(m)
        k = 1 + np.argmax(st[1:, 4])
        x, y, w, h, a = st[k]
        mk = lab == k
        # extents per row/col: robust width (median of row widths across middle)
        if h > w:  # vertical car
            rows = [mk[r].sum() for r in range(y, y + h)]
            cols = mk.sum(0)
            span = np.where(cols > 3)[0]
            print(i, th, 'bbox', x, y, w, h, 'len', h, 'wid(cols>3)', span[-1] - span[0] + 1, 'rowwidth pct50/90/max', np.percentile(rows, 50), np.percentile(rows, 90), max(rows))
        else:
            cols = [mk[:, cc].sum() for cc in range(x, x + w)]
            rows = mk.sum(1)
            span = np.where(rows > 3)[0]
            print(i, th, 'bbox', x, y, w, h, 'len', w, 'wid(rows>3)', span[-1] - span[0] + 1, 'colwidth pct50/90/max', np.percentile(cols, 50), np.percentile(cols, 90), max(cols))
