import av, numpy as np, cv2
bg = cv2.imread('scene/scripts/background.jpg').astype(float)
c = av.open('simulation_0071.mp4')
def edges(p):
    # half-max crossings of a 1D difference profile, subpixel
    mx = np.percentile(p, 95); hm = mx / 2
    idx = np.where(p > hm)[0]
    a, b = idx[0], idx[-1]
    l = a - 1 + (hm - p[a - 1]) / (p[a] - p[a - 1])
    r = b + (p[b] - hm) / (p[b] - p[b + 1])
    return l, r, r - l
for i, fr in enumerate(c.decode(video=0)):
    if i not in (0, 70, 71): continue
    img = fr.to_ndarray(format='bgr24').astype(float)
    d = np.abs(img - bg).sum(2)
    if i == 0:
        sub = d[700:1000, 900:1080]  # rows y, cols x
        # length: column-mean profile along y over central x band
        L = edges(sub[:, 60:120].mean(1)); print(i, 'length y', L[0] + 700, L[1] + 700, L[2])
        for y in range(760, 960, 20):
            W = edges(d[y, 900:1080]); print('  row', y, 'x', round(W[0] + 900, 1), round(W[1] + 900, 1), 'w', round(W[2], 1))
        W = edges(sub[:, :].max(0)); print(' width from max-proj', W)
    else:
        sub = d[550:720, 1200:1520]
        L = edges(sub[60:110, :].mean(0)); print(i, 'length x', L[0] + 1200, L[1] + 1200, L[2])
        for x in range(1280, 1480, 20):
            W = edges(d[550:720, x]); print('  col', x, 'y', round(W[0] + 550, 1), round(W[1] + 550, 1), 'w', round(W[2], 1))
        W = edges(sub.max(1)); print(' width from max-proj', W)
