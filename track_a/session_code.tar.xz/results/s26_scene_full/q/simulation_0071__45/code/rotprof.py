import av, numpy as np, cv2, csv
# per frame: rotate the colour-distance map so the car axis is horizontal, then half-max extents
tr = {int(r['frame']): r for r in csv.DictReader(open('scene/tracks/car.csv'))}
c = av.open('simulation_0071.mp4')
def edges(p, hm):
    idx = np.where(p > hm)[0]
    a, b = idx[0], idx[-1]
    l = a - 1 + (hm - p[a - 1]) / (p[a] - p[a - 1])
    r = b + (p[b] - hm) / (p[b] - p[b + 1])
    return r - l
res = []
for i, fr in enumerate(c.decode(video=0)):
    if i % 3: continue
    t = tr[i]; cx, cy, h = float(t['cx']), float(t['cy']), float(t['heading_deg'])
    img = fr.to_ndarray(format='bgr24').astype(float)
    x0, y0 = int(cx) - 160, int(cy) - 160
    crop = img[y0:y0 + 320, x0:x0 + 320]
    road = np.median(np.concatenate([crop[:15].reshape(-1, 3), crop[-15:].reshape(-1, 3)]), 0)
    d = np.linalg.norm(crop - road, axis=2)
    M = cv2.getRotationMatrix2D((cx - x0, cy - y0), -h, 1.0)  # rotate so heading -> +x
    M[:, 2] += [160 - (cx - x0), 160 - (cy - y0)]
    R = cv2.warpAffine(d, M, (320, 320), flags=cv2.INTER_LINEAR)
    body = np.median(R[150:170, 150:170]); hm = body / 2
    try:
        L = edges(R[150:171, 25:296].mean(0), hm)
        ws = [edges(R[95:226, x], hm) for x in range(160 - 80, 160 + 81, 2)]
    except IndexError:
        print(i, 'skip (background structure in profile)'); continue
    W = np.median(ws)
    res.append((i, h, L, W))
    print(i, round(h, 1), 'L', round(L, 1), 'W', round(W, 1), 'ratio', round(W / L, 4))
res = np.array(res)
print('median L', np.median(res[:, 2]), 'median W', np.median(res[:, 3]), 'median ratio', np.median(res[:, 3] / res[:, 2]))
print('answer m', 5.44 * np.median(res[:, 3] / res[:, 2]))
