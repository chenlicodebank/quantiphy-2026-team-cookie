import av, numpy as np, cv2
# edge-based profile: road is uniform grey; distance of pixel colour from the road colour, half-max crossings
c = av.open('simulation_0071.mp4')
def edges(p, hm):
    idx = np.where(p > hm)[0]
    a, b = idx[0], idx[-1]
    l = a - 1 + (hm - p[a - 1]) / (p[a] - p[a - 1])
    r = b + (p[b] - hm) / (p[b] - p[b + 1])
    return l, r, r - l
for i, fr in enumerate(c.decode(video=0)):
    if i not in (0, 1, 70, 71): continue
    img = fr.to_ndarray(format='bgr24').astype(float)
    if i < 2:
        road = np.median(img[760:940, 905:935].reshape(-1, 3), 0)
        d = np.linalg.norm(img - road, axis=2)
        body = np.median(d[850:870, 990:1000]); hm = body / 2
        ws = []
        for y in range(745, 962, 2):
            try: ws.append((y,) + edges(d[y, 900:1080], hm))
            except Exception: pass
        ws = np.array(ws)
        L = edges(d[700:1000, 985:995].mean(1), hm)
    else:
        road = np.median(img[560:590, 1260:1480].reshape(-1, 3), 0)
        d = np.linalg.norm(img - road, axis=2)
        body = np.median(d[630:640, 1330:1340]); hm = body / 2
        ws = []
        for x in range(1250, 1490, 2):
            try: ws.append((x,) + edges(d[550:720, x], hm))
            except Exception: pass
        ws = np.array(ws)
        L = edges(d[630:645, 1200:1520].mean(0), hm)
    w = ws[:, 3]
    print(i, 'length', round(L[2], 1), 'width median', round(np.median(w), 1), 'p75', round(np.percentile(w, 75), 1), 'max', round(w.max(), 1),
          'at', ws[w.argmax(), 0], 'overall extent', round(ws[:, 2].max() - ws[:, 1].min(), 1))
    big = ws[w > np.median(w) + 3]
    print('   wide rows:', big[:, 0], np.round(big[:, 3], 1))
