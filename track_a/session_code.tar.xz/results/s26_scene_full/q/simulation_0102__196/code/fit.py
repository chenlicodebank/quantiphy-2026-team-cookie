import csv, numpy as np
r = list(csv.DictReader(open('scene/tracks/shark.csv')))
f = np.array([int(x['frame']) for x in r])
for col, hi in [('ref_x', 60), ('nose_x_sub', 58), ('tail_x_sub', 66)]:
    X = np.array([float(x[col]) if x[col] else np.nan for x in r])
    m = (f >= 1) & (f <= hi) & np.isfinite(X)
    p = np.polyfit(f[m], X[m], 2)
    acc = -2 * p[0] * 576; v0 = -p[1] * 24; v1 = -(p[1] + 2 * p[0]) * 24
    print(col, 'acc px/s2 %.2f  v(f0) %.2f  v(f1) %.2f px/s -> m/s %.3f %.3f  res %.2f' % (
        acc, v0, v1, v0 / acc, v1 / acc, np.std(X[m] - np.polyval(p, f[m]))))
    print('  f0,f1,f2 data', X[:3], 'fit at f0,f1', np.polyval(p, [0, 1]))
