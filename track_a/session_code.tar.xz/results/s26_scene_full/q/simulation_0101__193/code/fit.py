import csv,numpy as np
D='/private/tmp/qp_blind/scene_full_b/simulation_0101/q_193/'
r=list(csv.DictReader(open(D+'scene/tracks/shark.csv')))
print(list(r[0].keys()))
f=np.array([int(x['frame']) for x in r]);t=f/24
for k in ['centroid_x','bbox_cx','nose_x','tail_x','ref_x','x_min','x_max']:
    if k not in r[0]: continue
    x=np.array([float(q[k]) for q in r])
    for a,b in [(1,72),(2,72),(1,36),(36,72)]:
        m=(f>=a)&(f<=b); p=np.polyfit(t[m],x[m],2)
        print(k,a,b,'acc px/s2 %.1f'%(2*p[0]),'v0 %.1f'%(p[1]+2*p[0]*t[m][0]), 'rms %.2f'%np.std(x[m]-np.polyval(p,t[m])))
    d=np.diff(x)*24; print(k,'speeds',np.round(d[:8],1),np.round(d[-5:],1))
b=list(csv.DictReader(open(D+'scene/tracks/boat.csv')))
bx=np.array([float(q['bow_x']) for q in b]); print('boat bow',bx[:4],bx[-3:])
L=np.array([float(q['length_px']) for q in b]);print('boat len',L[26:].mean(),L[26:].min(),L[26:].max())
