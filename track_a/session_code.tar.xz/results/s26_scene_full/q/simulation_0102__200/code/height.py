import av,numpy as np,os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
c=av.open('simulation_0102.mp4')
hs=[]
for i,fr in enumerate(c.decode(video=0)):
    if i>60: break
    if i%4: continue
    a=fr.to_ndarray(format='rgb24').astype(int)[680:1080]
    # background: per-row median colour (flat blue)
    bg=np.median(a,axis=1,keepdims=True)
    d=np.abs(a-bg).max(2)
    for th in (25,40,60):
        m=d>th
        cols=m.sum(0)>0; rows=np.where(m.sum(1)>=2)[0]
        if th==40: hs.append(rows[-1]-rows[0]+1)
        if i%20==0: print(i,th,'rows',rows[0]+680,rows[-1]+680,'h',rows[-1]-rows[0]+1)
print('h th40 per frame',hs,'mean',np.mean(hs))
