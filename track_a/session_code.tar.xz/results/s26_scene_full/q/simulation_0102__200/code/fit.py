import csv,numpy as np,os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
r=list(csv.DictReader(open('scene/tracks/shark.csv')))
f=np.array([int(x['frame']) for x in r])
for key in ['mask_centroid_x','nose_x_sub','tail_x_sub']:
    m=np.array([x[key]!='' for x in r])
    ff=f[m]; v=np.array([float(x[key]) for x in r if x[key]!=''])
    sel=(ff>=1)&(ff<=60) if key!='tail_x_sub' else (ff>=1)
    p=np.polyfit(ff[sel],v[sel],2); res=v[sel]-np.polyval(p,ff[sel])
    print(key,'a px/frame^2',2*p[0],'px/s^2',2*p[0]*576,'rms',res.std(), 'v at f1',np.polyval(np.polyder(p),1))
    for lo,hi in [(1,30),(30,60),(1,60),(40,72)]:
        s=sel&(ff>=lo)&(ff<=hi)
        if s.sum()<5: continue
        q=np.polyfit(ff[s],v[s],2); print('  ',lo,hi,2*q[0]*576)
    print('  steps',np.round(np.diff(v),2))
