import numpy as np,csv,os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
cx,cy=960,540
for n,rng in [('virus_left_small',(1,36)),('virus_right_large',(1,27))]:
    d=list(csv.DictReader(open(f'scene/tracks/{n}.csv')))
    f=np.array([int(r['frame']) for r in d]);x=np.array([float(r['ref_x']) for r in d]);y=np.array([float(r['ref_y']) for r in d]);rad=np.array([float(r['body_radius']) for r in d])
    m=(f>=rng[0])&(f<=rng[1])
    t=f[m];a=(x[m]-cx)/rad[m];b=(y[m]-cy)/rad[m];c=1/rad[m]
    for nm,q in [('a',a),('b',b),('c',c),('v',y[m]),('r',rad[m])]:
        p1=np.polyfit(t,q,1);p2=np.polyfit(t,q,2)
        print(n,nm,'lin',p1,'rms',np.std(q-np.polyval(p1,t)),'quad',p2,'rms',np.std(q-np.polyval(p2,t)))
