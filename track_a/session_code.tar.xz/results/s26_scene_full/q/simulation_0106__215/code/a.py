import numpy as np,csv,os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
for n in ['virus_left_small','virus_right_large']:
    d=list(csv.DictReader(open(f'scene/tracks/{n}.csv')))
    f=np.array([int(r['frame']) for r in d]);x=np.array([float(r['ref_x']) for r in d]);y=np.array([float(r['ref_y']) for r in d]);rad=np.array([float(r['body_radius']) for r in d])
    s=np.hypot(np.diff(x),np.diff(y))
    print(n)
    for i in range(1,len(f)): print(f[i],round(x[i],1),round(y[i],1),round(rad[i],2),round(s[i-1],2))
