import csv, numpy as np
def load(n):
    return list(csv.DictReader(open(f'scene/tracks/{n}.csv')))
t=load('tan_car'); v=load('white_van')
x=np.array([float(a['ref_x']) for a in t]); y=np.array([float(a['ref_y']) for a in t])
cx=np.array([float(a['centroid_x']) for a in t]); cy=np.array([float(a['centroid_y']) for a in t])
s=np.hypot(np.diff(x),np.diff(y)); sc=np.hypot(np.diff(cx),np.diff(cy))
for i in range(40,71): print(i+1, round(s[i],2), round(sc[i],2), t[i+1]['length_px'], t[i+1]['axis_angle_deg'])
print('mean step f2-71 ref', s[1:].mean(), 'centroid', sc[1:].mean())
print('path ref', s.sum())
vl=np.array([float(a['length_px']) for a in v]); print('van length med', np.median(vl))
tl=np.array([float(a['length_px']) for a in t]); print('tan length med', np.median(tl))
