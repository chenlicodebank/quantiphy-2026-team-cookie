import av, numpy as np, cv2
# independent: background = median of frames 0 & 71 not reliable; use frame-pair: van mask from difference against frame where van far away
want={0,20,36,50,52,56,60,64,68,71}
fr={}
c=av.open('simulation_0075.mp4')
for i,f in enumerate(c.decode(video=0)):
    if i in want: fr[i]=f.to_ndarray(format='rgb24').astype(np.int16)
# van: column profile along x 790..870, white pixels (all channels > 225)
for i in [0,36,71]:
    a=fr[i][:, 790:875]
    white=(a.min(axis=2)>215)
    rows=np.where(white.sum(axis=1)>20)[0]
    print('van f',i,'white rows',rows.min(),rows.max(),rows.max()-rows.min()+1)
# tan car: yellow/peach: R high, B lower
for i in [52,56,60,64,68,71]:
    a=fr[i]
    m=((a[:,:,0]-a[:,:,2])>40)&(a[:,:,0]>180)
    m[:500]=False; m[:, :1000]=False
    m=cv2.morphologyEx(m.astype(np.uint8),cv2.MORPH_OPEN,np.ones((3,3),np.uint8))
    n,l,st,cen=cv2.connectedComponentsWithStats(m)
    k=1+np.argmax(st[1:,4])
    print('tan f',i,st[k],cen[k])
