import av, numpy as np
c = av.open('simulation_0086.mp4'); fr = []
for i, f in enumerate(c.decode(video=0)):
    fr.append(f.to_ndarray(format='gray').astype(float)[540:770])
bg = fr[71]
xs = []; ws = []
for i in range(0, 57):
    d = np.abs(fr[i] - bg)
    band = d[80:150]            # rows y=620..690, body centre band
    col = band.mean(0)
    idx = np.where(col > 30)[0][0]
    x = idx - 1 + (30 - col[idx - 1]) / (col[idx] - col[idx - 1])
    xs.append(x)
    m = d > 30
    rows = np.where(m.any(1))[0]
    ws.append((rows.min() + 540, rows.max() + 540))
xs = np.array(xs); f = np.arange(57)
print(np.round(np.diff(xs), 2))
for a, b in [(2, 56), (5, 50), (10, 56), (2, 30), (1, 56)]:
    p = np.polyfit(f[a:b + 1], xs[a:b + 1], 2); print(a, b, 2 * p[0], p, 'vertex', -p[1] / (2 * p[0]))
print(ws[:3], ws[30], ws[56])
# width profile at frame 0: extent of diff>30 per column
d = np.abs(fr[0] - bg) > 30
for x in range(880, 1320, 20):
    r = np.where(d[:, x])[0]
    if len(r): print(x, r.min() + 540, r.max() + 540, r.max() - r.min() + 1)
