import csv,numpy as np
r=list(csv.DictReader(open('scene/tracks/cyclist.csv')))
f=np.array([int(x['frame']) for x in r]);x0=np.array([float(x['bbox_x0']) for x in r]);x1=np.array([float(x['bbox_x1']) for x in r])
L=x1-x0; print('len',L[4:68])
m=(f>=4)&(f<=67)
for arr,n in [(x0,'x0'),(x1,'x1'),((x0+x1)/2,'c')]:
    p=np.polyfit(f[m],arr[m],2); print(n,p, 'rms',(arr[m]-np.polyval(p,f[m])).std())
c=(x0+x1)/2
for a in range(4,64,8): print(a, c[a], (c[a+8]-c[a])/8 if a+8<len(c) else None)
