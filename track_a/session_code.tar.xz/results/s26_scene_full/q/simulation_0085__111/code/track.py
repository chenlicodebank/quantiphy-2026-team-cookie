import av,numpy as np,cv2
frames=[]
c=av.open('simulation_0085.mp4')
for fr in c.decode(video=0):
    g=fr.to_ndarray(format='gray').astype(np.float32)
    frames.append(g[560:900].copy())
c.close()
N=len(frames)
def sub(r):
    # subpixel peak along x
    _,_,_,mx=cv2.minMaxLoc(r); x,y=mx
    if 0<x<r.shape[1]-1:
        a,b,cc=r[y,x-1],r[y,x],r[y,x+1]; d=0.5*(a-cc)/(a-2*b+cc)
    else: d=0
    return x+d,y
# front template: from frame 50, front edge at 737 -> take cols 730..830 (front tip ~100 px)
ref=frames[50]
res={}
for name,(t0,t1) in {'front':(728,828),'rear':(1372,1468),'mid':(1050,1250)}.items():
    T=ref[:,t0:t1]
    xs=[]
    for i in range(N):
        r=cv2.matchTemplate(frames[i],T,cv2.TM_CCOEFF_NORMED)
        x,y=sub(r); xs.append((x,r.max()))
    res[name]=np.array(xs)
np.save('track_tm.npy',np.stack([res[k] for k in ['front','rear','mid']]))
for i in range(N):
    print(i,' '.join('%s %8.2f %.3f'%(k,res[k][i,0],res[k][i,1]) for k in res))
