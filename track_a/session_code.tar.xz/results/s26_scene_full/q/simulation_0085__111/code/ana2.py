import numpy as np,csv
d=np.load('track_tm.npy')
f=np.arange(72)
def fit(x,lo,hi,excl=()):
    m=(f>=lo)&(f<=hi)&~np.isin(f,excl); p=np.polyfit(f[m],x[m],2)
    return round(-2*p[0],4),round((x[m]-np.polyval(p,f[m])).std(),3)
fr=d[0,:,0]; mid=d[2,:,0]
for hi in [30,40,44,46,48]: print('front tm 10-',hi,fit(fr,10,hi,(34,)))
print('mid 34-46',fit(mid,34,46))
r=list(csv.DictReader(open('scene/tracks/car.csv')))
x0=np.array([float(x['bbox_x0']) for x in r])
for lo,hi in [(2,30),(3,46),(5,46)]: print('edge',lo,hi,fit(-x0*-1,lo,hi))
