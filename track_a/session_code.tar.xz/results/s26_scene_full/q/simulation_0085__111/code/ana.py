import numpy as np
d=np.load('track_tm.npy')
valid={'front':(10,63),'rear':(39,71),'mid':(34,68)}
for k,name in enumerate(['front','rear','mid']):
    a,b=valid[name]; x=d[k,a:b+1,0]; f=np.arange(a,b+1)
    v=-np.diff(x); print(name,'v',np.round(v,2))
    print(name,'acc',np.round(np.diff(v),2))
    for lo,hi in [(a,min(b,40)),(max(a,40),min(b,55)),(max(a,45),min(b,63)),(a,b)]:
        if hi-lo<4: continue
        m=(f>=lo)&(f<=hi); p=np.polyfit(f[m],x[m],2); print('  fit',lo,hi,'acc',round(-2*p[0],4),'rms',round((x[m]-np.polyval(p,f[m])).std(),3))
