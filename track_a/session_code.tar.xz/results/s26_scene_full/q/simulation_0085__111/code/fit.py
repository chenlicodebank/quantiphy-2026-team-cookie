import csv,numpy as np
r=list(csv.DictReader(open('scene/tracks/car.csv')))
f=np.array([int(x['frame']) for x in r]);x0=np.array([float(x['bbox_x0']) for x in r]);x1=np.array([float(x['bbox_x1']) for x in r])
for a,b,name,arr in [(3,63,'front',x0),(10,63,'front',x0),(20,63,'front',x0),(3,40,'front',x0),(3,30,'front',x0),(40,71,'rear',x1),(40,64,'rear',x1)]:
    m=(f>=a)&(f<=b); p=np.polyfit(f[m],arr[m],2); res=arr[m]-np.polyval(p,f[m])
    print(name,a,b,'acc px/f2',2*p[0],'rms',res.std())
dx=-np.diff(x0); print(dx[:64])
dx1=-np.diff(x1); print(dx1[39:])
