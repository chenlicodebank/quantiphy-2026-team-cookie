import av, numpy as np, csv
# subpixel front edge of car (left edge) and cyclist bbox centre, via diff from empty frame 71
frames = {}
c = av.open('simulation_0086.mp4')
for i, fr in enumerate(c.decode(video=0)):
    g = fr.to_ndarray(format='gray')
    frames[i] = g[430:760].astype(np.int16)  # only object bands kept
    if i >= 71: break
bg = frames[71]
car_front, cyc = [], []
for i in range(0, 57):
    d = np.abs(frames[i] - bg)
    band = d[130:315]  # car rows
    prof = band.max(axis=0)
    cols = np.where(prof > 30)[0]
    x0 = cols.min()
    # subpixel: interpolate crossing of 30 on the rising edge using column profile
    p0, p1 = prof[x0 - 1], prof[x0]
    xs = x0 - 1 + (30 - p0) / (p1 - p0) if p1 != p0 else x0
    car_front.append((i, xs, x0))
    bandc = d[10:85]
    pc = bandc.max(axis=0)
    cc = np.where(pc > 30)[0]
    cyc.append((i, (cc.min() + cc.max()) / 2.0, cc.min(), cc.max()))
car_front = np.array(car_front); cyc = np.array(cyc)
f = car_front[:, 0]; x = car_front[:, 1]
m = f >= 2
def model(f, xa, a, f0):
    return xa - 0.5 * a * np.clip(f - f0, 0, None) ** 2
best=None
for f0 in np.arange(0,3,0.005):
    A=np.c_[np.ones_like(f), -0.5*np.clip(f-f0,0,None)**2]
    sol,r,_,_=np.linalg.lstsq(A,x,rcond=None)
    e=((A@sol-x)**2).sum()
    if best is None or e<best[0]: best=(e,sol[0],sol[1],f0)
p=best[1:]
print('car fit xa=%.2f a=%.4f px/fr^2 f0=%.3f' % tuple(p))
res = x - model(f, *p); print('resid rms', res.std(), 'max', np.abs(res).max())
# pure quadratic with free linear term over frames 3..56
q = np.polyfit(f[3:], x[3:], 2); print('poly2 a=', -2 * q[0])
a_px = p[1] * 24 ** 2  # px/s^2
scale = 4.03 / a_px
print('a px/s^2', a_px, 'm/px', scale, 'car length m', 438 * scale)
# cyclist speed
cf = cyc[2:57, 0]; cx = cyc[2:57, 1]
qc = np.polyfit(cf, cx, 1); print('cyc px/frame', qc[0], 'speed m/s', qc[0] * 24 * scale)
i = 24
carx = car_front[i, 1] + 218.5
cycx = cyc[i, 1]
print('frame24 car front', car_front[i], 'car ref', carx, 'cyc', cyc[i])
for (cy_ref, label) in [(cycx, 'bike centre'), (cycx - 11, 'rider proxy')]:
    dx = cy_ref - carx; dy = 477.25 - 651.75
    dpx = np.hypot(dx, dy)
    print(label, 'dx', dx, 'dy', dy, 'dpx', dpx, 'm', dpx * scale)

print('residuals', np.round(res,1))
# alternative: fit only frames 10..56 (avoid start transient)
q2=np.polyfit(f[10:],x[10:],2); print('poly2 10..56 a=',-2*q2[0])
for lo,hi in [(2,50),(5,52),(2,40),(10,50),(15,54),(20,30)]:
    qq=np.polyfit(f[lo:hi+1],x[lo:hi+1],2); print('poly2',lo,hi,'a=',round(-2*qq[0],4),'v24=',round(-(2*qq[0]*24+qq[1]),2))
st=np.diff(x); print('steps',np.round(st,1))
