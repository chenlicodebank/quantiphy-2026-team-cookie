import av, numpy as np
V='simulation_0068.mp4'
frames={}
want=set(range(72))
c=av.open(V)
van_top=[];van_bot=[]
sed={}
for i,f in enumerate(c.decode(video=0)):
    a=f.to_ndarray(format='rgb24').astype(int)
    # van: column strip x 800-860, white pixels (all channels > 215 and low saturation)
    strip=a[:, 800:862]
    w=(strip.min(axis=2)>200)&(strip.max(axis=2)-strip.min(axis=2)<25)
    rows=np.where(w.sum(1)>20)[0]
    # largest contiguous run
    if len(rows):
        runs=np.split(rows,np.where(np.diff(rows)>3)[0]+1)
        r=max(runs,key=len); van_top.append(r[0]); van_bot.append(r[-1])
    if i in (0,71):
        # sedan: tan colour mask
        R,G,B=a[...,0],a[...,1],a[...,2]
        m=(R-B>25)&(R>180)
        if i==0: sub=m[700:1050,900:1080]; ys=np.where(sub.sum(1)>15)[0]; sed[i]=(ys[0]+700,ys[-1]+700,ys[-1]-ys[0]+1)
        else: sub=m[580:700,1200:1550]; xs=np.where(sub.sum(0)>15)[0]; sed[i]=(xs[0]+1200,xs[-1]+1200,xs[-1]-xs[0]+1)
print('sedan',sed)
vt=np.array(van_top,float);vb=np.array(van_bot,float);vc=(vt+vb)/2
print('van length px',np.median(vb-vt+1))
for name,y in [('top',vt),('bot',vb),('ctr',vc)]:
    for lo,hi in [(4,71),(10,71),(4,40),(36,71)]:
        fr=np.arange(lo,hi+1)
        p=np.polyfit(fr,y[lo:hi+1],2)
        res=y[lo:hi+1]-np.polyval(p,fr)
        print(name,lo,hi,'acc px/frame^2',2*p[0],'rms',res.std(), 'v0 at frame', -p[1]/(2*p[0]))
