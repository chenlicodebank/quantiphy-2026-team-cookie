import av, numpy as np, cv2
D = '/private/tmp/qp_blind/scene_full_a/simulation_0087/q_124/'
frames = []
for fr in av.open(D + 'simulation_0087.mp4').decode(video=0):
    frames.append(fr.to_ndarray(format='gray')[390:480].astype(np.float32))
N = len(frames)
def ext(g):
    dev = np.abs(g[25:65] - 140).max(axis=0)
    c = np.where(dev > 25)[0]; c = c[c < 1500]
    return c.min(), c.max()
sp = []; cen = []
for i in range(8, N):
    a, b = ext(frames[i - 1]); a -= 4; b += 4
    T = frames[i - 1][:, a:b]
    res = cv2.matchTemplate(frames[i], T, cv2.TM_SQDIFF_NORMED)[0]
    k = int(np.argmin(res))
    d = 0.5 * (res[k - 1] - res[k + 1]) / (res[k - 1] - 2 * res[k] + res[k + 1])
    sp.append(k + d - a); cen.append((a + b) / 2)
sp = np.array(sp)
print(np.round(sp, 2).tolist())
print('mean %.3f  first10 %.3f last10 %.3f' % (sp.mean(), sp[:10].mean(), sp[-10:].mean()))
print('centre range', cen[0], cen[-1])
# bike length per frame with subpixel half-max edges on the wheel line row profile
for i in [10, 20, 30, 40, 45, 50, 53]:
    g = frames[i]
    dev = np.abs(g[25:65] - 140).max(axis=0)
    c = np.where(dev > 25)[0]; c = c[c < 1500]
    print(i, c.min(), c.max(), c.max() - c.min() + 1)
