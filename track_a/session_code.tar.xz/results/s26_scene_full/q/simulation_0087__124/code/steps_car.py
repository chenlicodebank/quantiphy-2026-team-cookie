import av, numpy as np, cv2
# frame-to-frame shift of the car (consecutive frames match well despite parallax changes)
D = '/private/tmp/qp_blind/scene_full_a/simulation_0087/q_124/'
frames = []
for fr in av.open(D + 'simulation_0087.mp4').decode(video=0):
    frames.append(fr.to_ndarray(format='gray')[560:820].astype(np.float32))
N = len(frames)
def front_x(g):
    dev = np.abs(g[40:220] - 140).max(axis=0)
    c = np.where(dev > 40)[0]; c = c[c > 400]
    return c.min()
steps = []
for i in range(2, N):
    g0, g1 = frames[i - 1], frames[i]
    x0 = front_x(g0)
    a, b = x0 - 5, min(1915, x0 + 400)
    if b - a < 60:
        steps.append(np.nan); continue
    T = g0[:, a:b]
    res = cv2.matchTemplate(g1, T, cv2.TM_SQDIFF_NORMED)[0]
    k = int(np.argmin(res))
    d = 0.5 * (res[k - 1] - res[k + 1]) / (res[k - 1] - 2 * res[k] + res[k + 1])
    steps.append(k + d - a)
s = -np.array(steps); fi = np.arange(2, N)
print('speeds px/frame', np.round(s, 2).tolist())
for lo, hi in [(3, 54), (3, 20), (20, 37), (37, 54), (10, 50)]:
    m = (fi >= lo) & (fi < hi) & ~np.isnan(s)
    c = np.polyfit(fi[m], s[m], 1)
    print('accel [%d,%d) = %.4f px/f2' % (lo, hi, c[0]))
