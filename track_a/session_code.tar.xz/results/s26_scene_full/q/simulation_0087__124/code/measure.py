import av, numpy as np
D = '/private/tmp/qp_blind/scene_full_a/simulation_0087/q_124/'
cont = av.open(D + 'simulation_0087.mp4')
car_front, car_rear, bike = [], [], []
for i, fr in enumerate(cont.decode(video=0)):
    g = fr.to_ndarray(format='gray').astype(float)
    # car: rows inside body band, column-wise max deviation from background
    band = g[600:780]
    dev = np.abs(band - 140).max(axis=0)
    cols = np.where(dev > 40)[0]
    cols = cols[cols > 400]
    car_front.append(cols.min() if len(cols) else np.nan)
    car_rear.append(cols.max() if len(cols) and cols.max() < 1915 else np.nan)
    # bike: the thin wheel line, rows 425-450
    b = g[415:455]
    devb = np.abs(b - 140).max(axis=0)
    cb = np.where(devb > 25)[0]
    cb = cb[cb < 1500]
    if len(cb) and cb.min() > 2:
        bike.append((i, cb.min(), cb.max(), cb.max() - cb.min() + 1))
car_front = np.array(car_front, float); car_rear = np.array(car_rear, float)
f = np.arange(len(car_front))
print('front', car_front.tolist())
print('rear', car_rear.tolist())
for name, x, lo in [('front', car_front, 3), ('rear', car_rear, 37)]:
    m = (f >= lo) & ~np.isnan(x)
    p = np.polyfit(f[m], x[m], 2)
    res = x[m] - np.polyval(p, f[m])
    print(name, 'a_px/frame2 =', 2 * p[0], 'rms', res.std())
# windows
for lo, hi in [(3, 20), (20, 37), (37, 54), (10, 54)]:
    m = (f >= lo) & (f < hi)
    p = np.polyfit(f[m], car_front[m], 2); print('front win', lo, hi, 2 * p[0])
# fit with t0 free: x = x0 - 0.5 a (f - f0)^2 for f>=f0
best = None
for f0 in np.arange(0.0, 3.01, 0.05):
    tt = np.clip(f - f0, 0, None)
    A = np.vstack([np.ones_like(tt), tt, tt**2]).T
    m = f >= 1
    c, *_ = np.linalg.lstsq(A[m], car_front[m], rcond=None)
    rr = np.std(A[m] @ c - car_front[m])
    if best is None or rr < best[0]: best = (rr, f0, c)
print('start-fit rms,f0,coef', best[0], best[1], best[2], 'a=', 2 * best[2][2])
L = np.array([b[3] for b in bike]); print('bike lens', [(b[0], b[3]) for b in bike])
print('bike median', np.median(L[L > 100]))
