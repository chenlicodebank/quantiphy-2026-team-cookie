import av, numpy as np, cv2
D = '/private/tmp/qp_blind/scene_full_a/simulation_0087/q_124/'
frames = []
cont = av.open(D + 'simulation_0087.mp4')
for fr in cont.decode(video=0):
    frames.append(fr.to_ndarray(format='gray')[560:820].astype(np.float32))  # car band only (small)
N = len(frames)
# template: car in frame 53 (x0 813 .. 1389), cab/front part that enters early
def track(tx0, tx1, ref=53, guess=None):
    T = frames[ref][:, tx0:tx1]
    pos = {}
    for i in range(N):
        g = frames[i]
        res = cv2.matchTemplate(g, T, cv2.TM_SQDIFF_NORMED)[0]
        # search near guess
        k = int(np.argmin(res))
        if res[k] > 0.05:
            continue
        if 0 < k < len(res) - 1:
            a, b, c = res[k - 1], res[k], res[k + 1]
            d = 0.5 * (a - c) / (a - 2 * b + c)
        else:
            d = 0
        pos[i] = k + d - tx0  # shift of this frame vs ref
    return pos
f = np.arange(N)
for name, (a, b) in {'nose+cab': (800, 1000), 'cab': (900, 1150), 'whole': (800, 1400), 'bed': (1200, 1400)}.items():
    p = track(a, b)
    ks = np.array(sorted(p)); x = np.array([p[k] for k in ks])
    m = ks >= 3
    c = np.polyfit(ks[m], x[m], 2)
    r = x[m] - np.polyval(c, ks[m])
    out = [name, 'frames', ks.min(), ks.max(), 'a=%.4f' % (2 * c[0]), 'rms %.3f' % r.std()]
    for lo, hi in [(3, 25), (25, 54), (37, 54)]:
        mm = (ks >= lo) & (ks < hi)
        if mm.sum() > 5:
            out.append('[%d,%d) %.4f' % (lo, hi, 2 * np.polyfit(ks[mm], x[mm], 2)[0]))
    print(*out)
    if name == 'whole' or name == 'nose+cab':
        v = np.diff(x); print(' steps', np.round(v, 2).tolist())
