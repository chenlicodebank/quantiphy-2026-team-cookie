import numpy as np, av, csv
# 1) car track from record: fit acceleration
rows = list(csv.DictReader(open('scene/tracks/car.csv')))
f = np.array([float(r['frame']) for r in rows]); x = np.array([float(r['cx_centroid']) for r in rows])
for lo in (1, 2, 5):
    m = f >= lo
    c = np.polyfit(f[m], x[m], 2); print('fit from f', lo, c, 'acc px/s^2', 2*c[0]*576)
v = np.diff(x)*24; a = np.diff(v)*24
print('per-frame speeds px/s', np.round(v, 1))
print('mean accel (f2..40) from speed diffs', a[1:].mean())
# 2) own car mask: height & length per frame
cont = av.open('simulation_0097.mp4'); hs = []; ls = []; xs = []
for i, fr in enumerate(cont.decode(video=0)):
    img = fr.to_ndarray(format='rgb24').astype(int)
    bg = np.median(img.reshape(-1, 3), axis=0)
    sub = img[545:, :]
    d = np.abs(sub - bg).max(axis=2)
    for thr in (4, 6, 10):
        mk = d > thr
        ys, xx = np.nonzero(mk)
        if thr == 6:
            hs.append(ys.max()-ys.min()+1); ls.append(xx.max()-xx.min()+1); xs.append(xx.mean())
        if i in (0, 20, 40): print(i, thr, 'y', ys.min()+545, ys.max()+545, 'x', xx.min(), xx.max())
print('heights', hs); print('lengths', ls)
xs = np.array(xs); ff = np.arange(len(xs)); c = np.polyfit(ff[2:], xs[2:], 2); print('own fit acc', 2*c[0]*576)
