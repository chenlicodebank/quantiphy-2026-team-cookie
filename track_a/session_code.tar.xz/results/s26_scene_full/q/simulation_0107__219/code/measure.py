import csv, numpy as np
def load(n):
    r=list(csv.DictReader(open('scene/tracks/%s.csv'%n)))
    return {int(x['frame']):x for x in r}
S=load('virus_small_left'); L=load('virus_large_right')
def fit(T,f0,f1,kx='cx',ky='cy'):
    f=np.arange(f0,f1+1); x=np.array([float(T[i][kx]) for i in f]); y=np.array([float(T[i][ky]) for i in f])
    px=np.polyfit(f,x,1); py=np.polyfit(f,y,1); return px,py
pxL,pyL=fit(L,2,35); pxS,pyS=fit(S,2,40)
stepL=np.hypot(pxL[0],pyL[0]); print('large step',pxL[0],pyL[0],stepL)
raw=np.hypot(float(L[24]['cx'])-float(L[23]['cx']),float(L[24]['cy'])-float(L[23]['cy'])); print('raw step 23-24',raw)
mpp=1.7393/(stepL*24); print('m/px',mpp)
d_raw=np.hypot(float(L[24]['cx'])-float(S[24]['cx']),float(L[24]['cy'])-float(S[24]['cy']))
d_fit=np.hypot(np.polyval(pxL,24)-np.polyval(pxS,24),np.polyval(pyL,24)-np.polyval(pyS,24))
print('d px raw/fit',d_raw,d_fit,'m',d_raw*mpp,d_fit*mpp)
# template route
pxL2,pyL2=fit(L,2,20,'cx_template','cy_template'); pxS2,pyS2=fit(S,2,20,'cx_template','cy_template')
st2=np.hypot(pxL2[0],pyL2[0]); d2=np.hypot(float(L[24]['cx_template'])-float(S[24]['cx_template']),float(L[24]['cy_template'])-float(S[24]['cy_template']))
print('template step',st2,'d',d2,'m',d2*1.7393/(st2*24))
