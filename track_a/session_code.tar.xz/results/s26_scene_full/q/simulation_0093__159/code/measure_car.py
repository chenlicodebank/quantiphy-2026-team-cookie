import av, numpy as np
bg = np.array([80, 81, 88], float)
c = av.open('simulation_0093.mp4')
rows = []
for i, fr in enumerate(c.decode(video=0)):
    a = fr.to_ndarray(format='rgb24').astype(float)[590:650]
    d = np.abs(a - bg).max(axis=2)
    for th in (12, 18, 30):
        cols = np.where((d > th).sum(axis=0) >= 2)[0]
        # longest contiguous run near car
        runs = np.split(cols, np.where(np.diff(cols) > 3)[0] + 1)
        r = max(runs, key=len)
        if th == 18:
            x0, x1 = r[0], r[-1]
        rows.append((i, th, r[0], r[-1], r[-1] - r[0] + 1))
    # column-weighted centroid of the difference mask
    m = d > 18
    xs = np.nonzero(m)[1]
    cx = xs.mean()
    print(i, [(t, a0, a1, L) for (_, t, a0, a1, L) in rows[-3:]], round(cx, 2))
