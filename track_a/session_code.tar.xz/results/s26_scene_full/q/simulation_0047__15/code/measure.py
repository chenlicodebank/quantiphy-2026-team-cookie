import av, numpy as np, csv
c=av.open('simulation_0047.mp4')
for i,fr in enumerate(c.decode(video=0)):
    if i==50: img=fr.to_ndarray(format='rgb24').astype(float); break
g=img.mean(2)
# top face of booth: bright region; edge profiles
for y in [270,300,330,350]:
    row=g[y,330:480]; d=np.diff(row)
    print('row',y,'left edge x',330+np.argmax(d)+0.5,'right edge x',330+np.argmin(d)+0.5)
for x in [360,390,420,450]:
    col=g[235:375,x]; d=np.diff(col)
    print('col',x,'top edge y',235+np.argmax(d)+0.5,'bottom edge y',235+np.argmin(d)+0.5)
for thr in [170,185,200]:
    m=(g[240:375,335:470]>thr)
    ys,xs=np.nonzero(m); print('thr',thr,'bright mask x',xs.min()+335,xs.max()+335,'y',ys.min()+240,ys.max()+240,'area',m.sum())
rows=list(csv.DictReader(open('scene/tracks/pedestrian.csv')))
x=np.array([float(r['ref_x']) for r in rows]); y=np.array([float(r['ref_y']) for r in rows])
st=np.hypot(np.diff(x),np.diff(y))
print('mean step',st.mean(),'px/s',st.mean()*33,'net px/s',np.hypot(x[-1]-x[0],y[-1]-y[0])/(len(x)-1)*33)
print('f2-f88 net px/s',np.hypot(x[88]-x[2],y[88]-y[2])/86*33)
print('f0-f92 net px/s',np.hypot(x[92]-x[0],y[92]-y[0])/92*33)
