import csv,numpy as np
def load(n):
    r=list(csv.DictReader(open('scene/tracks/'+n+'.csv')))
    return np.array([[float(x['frame']),float(x['ref_x']),float(x['ref_y']),float(x['body_radius'])] for x in r if x['ref_reliable']=='1'])
L=load('virus_left_small'); R=load('virus_right_large')
cx,cy=960,540
def fits(a,rng):
    m=(a[:,0]>=rng[0])&(a[:,0]<=rng[1])
    t=a[m,0]; u=a[m,1]; v=a[m,2]; r=a[m,3]
    return [np.polyfit(t,y,1) for y in ((u-cx)/r,(v-cy)/r,1/r)]
fL=fits(L,(1,36)); fR=fits(R,(1,27))   # body untruncated frames
def pos(fs,f,t):
    X,Y,S=[np.polyval(p,t) for p in fs]; return np.array([X,Y,f*S])
def vel(fs,f):
    return np.array([fs[0][0],fs[1][0],f*fs[2][0]])*24
for f in [1000,1500,2000,2667,3500,5000,8000]:
    vR=np.linalg.norm(vel(fR,f)); vL=np.linalg.norm(vel(fL,f))
    RR=1.5667/vR
    out=[]
    for k in [1.0, vR/vL]:
        RL=k*RR
        d=np.linalg.norm(pos(fL,f,48)*RL-pos(fR,f,48)*RR)
        d0=np.linalg.norm(pos(fL,f,1)*RL-pos(fR,f,1)*RR)
        zL=f*np.polyval(fL[2],1)*RL; zR=f*np.polyval(fR[2],1)*RR
        out.append((round(k,3),round(d,3),round(d0,3),round(zL,2),round(zR,2)))
    print(f,'RR',round(RR,4),'vL/vR(A)',round(vL/vR,3),out)
