import csv,numpy as np
def load(n):
    r=list(csv.DictReader(open('scene/tracks/'+n+'.csv')))
    a=np.array([[float(x['frame']),float(x['ref_x']),float(x['ref_y']),float(x['body_radius'])] for x in r if x['ref_reliable']=='1'])
    return a
L=load('virus_left_small'); R=load('virus_right_large')
cx,cy=960,540
for name,a,rng in [('L',L,(1,47)),('R',R,(1,40))]:
    m=(a[:,0]>=rng[0])&(a[:,0]<=rng[1])
    t=a[m,0]; u=a[m,1]; v=a[m,2]; r=a[m,3]
    for lab,y in [('1/r',1/r),('(u-cx)/r',(u-cx)/r),('(v-cy)/r',(v-cy)/r),('v',v),('u',u)]:
        p=np.polyfit(t,y,1); p2=np.polyfit(t,y,2)
        res=y-np.polyval(p,t)
        print(name,lab,p,'quad',p2,'rms',res.std())
