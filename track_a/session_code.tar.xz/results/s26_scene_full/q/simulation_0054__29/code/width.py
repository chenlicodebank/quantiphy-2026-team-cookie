import numpy as np, cv2, av
bg=cv2.imread('scene/bg.png')[:,:,::-1].astype(int)
c=av.open('simulation_0054.mp4')
res=[]
K5=np.ones((5,5),np.uint8); K15=np.ones((15,15),np.uint8)
for i,fr in enumerate(c.decode(video=0)):
    if i<38 or i>70: continue
    im=fr.to_ndarray(format='rgb24').astype(int)
    d=np.abs(im-bg).max(2)
    for th in (25,40,60):
        m=(d>th).astype(np.uint8); m[:, :575]=0
        m=cv2.morphologyEx(m,cv2.MORPH_OPEN,K5); m=cv2.morphologyEx(m,cv2.MORPH_CLOSE,K15)
        n,lab,st,_=cv2.connectedComponentsWithStats(m)
        if n<2: continue
        k=1+np.argmax(st[1:,cv2.CC_STAT_AREA]); mm=lab==k
        ys,xs=np.nonzero(mm)
        rowsw=mm.sum(1); rowsw=rowsw[rowsw>0]
        res.append((i,th,xs.max()-xs.min()+1,ys.max()-ys.min()+1,np.percentile(rowsw,90),np.median(rowsw)))
        if i==55 and th==40:
            ov=im.copy().astype(np.uint8); ov[mm]=(ov[mm]*0.5+np.array([255,0,0])*0.5).astype(np.uint8)
            cv2.imwrite('frames/mask55.png',ov[300:800,560:800,::-1])
r=np.array(res)
for th in (25,40,60):
    s=r[r[:,1]==th]
    print(th,'bboxW med %.1f min %d max %d'%(np.median(s[:,2]),s[:,2].min(),s[:,2].max()),'L %.1f'%np.median(s[:,3]),'row p90 %.1f row med %.1f'%(np.median(s[:,4]),np.median(s[:,5])))
