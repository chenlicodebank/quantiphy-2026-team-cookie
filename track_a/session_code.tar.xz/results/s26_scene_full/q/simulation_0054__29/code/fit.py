import numpy as np, csv
fps=30.003
def load(n):
    return list(csv.DictReader(open(f'scene/tracks/{n}.csv')))
o=load('orange_car')
f=np.array([int(x['frame']) for x in o])
cyb=np.array([float(x['cy_bbox']) for x in o]); cym=np.array([float(x['cy_mask']) for x in o])
for lo,hi in [(16,90),(25,90),(40,90),(16,60),(50,90)]:
    m=(f>=lo)&(f<=hi)
    for nm,y in [('bbox',cyb),('mask',cym)]:
        p=np.polyfit(f[m]/fps,y[m],2); res=y[m]-np.polyval(p,f[m]/fps)
        print(lo,hi,nm,'acc px/s2 %.2f'%(2*p[0]),'v0 %.1f'%p[1],'rms %.2f'%res.std())
m=(f>=16)&(f<=90)
p=np.polyfit(f[m]/fps,cyb[m],3); print('cubic acc at ends', 6*p[0]*np.array([16,90])/fps+2*p[1])
g=load('black_car')
w=np.array([float(x['wid_px']) for x in g]); gf=np.array([int(x['frame']) for x in g])
x0=np.array([float(x['x0']) for x in g]);x1=np.array([float(x['x1']) for x in g])
m=(gf>=37)&(gf<=70)
print('green wid_px',np.median(w[m]),w[m].min(),w[m].max(),'bbox w',np.median(x1[m]-x0[m]))
ow=np.array([float(x['wid_px']) for x in o]); ox0=np.array([float(x['x0']) for x in o]);ox1=np.array([float(x['x1']) for x in o])
m=(f>=40)
print('orange wid',np.median(ow[m]),np.median(ox1[m]-ox0[m]))
