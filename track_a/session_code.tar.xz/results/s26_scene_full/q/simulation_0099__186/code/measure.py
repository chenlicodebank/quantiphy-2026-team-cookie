import av, numpy as np, cv2
frames = {}
c = av.open('simulation_0099.mp4')
for i, f in enumerate(c.decode(video=0)):
    if i in (0, 10, 20, 30, 40, 50, 60):
        frames[i] = f.to_ndarray(format='rgb24').astype(int)
c.close()
# underwater background colour: per-row median of right part (x 1500-1900)
for i, im in frames.items():
    sub = im[680:1075]
    bg = np.median(im[680:1075, 1700:1900], axis=1)  # per-row bg
    d = np.abs(sub - bg[:, None, :]).sum(2)
    for thr in (30, 60):
        m = (d > thr).astype(np.uint8)
        m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((2, 2), np.uint8))
        n, lab, st, _ = cv2.connectedComponentsWithStats(m)
        k = 1 + np.argmax(st[1:, 4])
        x, y, w, h, a = st[k]
        print(i, thr, 'shark bbox x', x, x + w - 1, 'y', y + 680, y + h - 1 + 680, 'w', w, 'h', h)
# boat length at frame 0: rows 360-610, sky/sea bg from right columns
im = frames[0]
bg = np.median(im[:, 1500:1900], axis=1)
d = np.abs(im - bg[:, None, :]).sum(2)
for thr in (40, 80):
    m = d[300:640] > thr
    cols = np.where(m.sum(0) > 2)[0]
    print('boat thr', thr, 'x range', cols.min(), cols.max(), 'len', cols.max() - cols.min() + 1)
    # hull only rows 380-600
    m2 = d[380:600] > thr
    cols = np.where(m2.sum(0) > 2)[0]
    print('  hull rows', cols.min(), cols.max(), cols.max() - cols.min() + 1)
