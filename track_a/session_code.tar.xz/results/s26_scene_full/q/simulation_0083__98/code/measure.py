import av, numpy as np, cv2
# independent bbox measurement of both cars at frame 24 (t=1.0s) and neighbours
frames = {}
with av.open('simulation_0083.mp4') as c:
    for i, f in enumerate(c.decode(video=0)):
        if i in (0, 23, 24, 25, 36, 48, 60, 71):
            frames[i] = f.to_ndarray(format='rgb24').astype(int)
        if i > 71: break
# background: per-pixel median of frames 0, 36, 71 (cars far apart between them)
bg = np.median(np.stack([frames[0], frames[36], frames[71]]), axis=0)
L = 5.67
res = {}
for i in (23, 24, 25):
    im = frames[i]
    d = np.abs(im - bg).max(axis=2)
    yel = (im[..., 0] - im[..., 2]) > 30
    bright = (im - bg).min(axis=2) > 12  # white/silver front of the black car
    m = ((d > 35) | bright | yel).astype(np.uint8)
    m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    out = {}
    for name, (y0, y1) in {'yellow': (300, 479), 'black': (479, 660)}.items():
        sub = m[y0:y1]
        ys, xs = np.nonzero(sub)
        # keep largest component
        n, lab, st, _ = cv2.connectedComponentsWithStats(sub)
        k = 1 + np.argmax(st[1:, cv2.CC_STAT_AREA])
        ys, xs = np.nonzero(lab == k)
        x0, x1, yy0, yy1 = xs.min(), xs.max(), ys.min() + y0, ys.max() + y0
        out[name] = ((x0 + x1) / 2, (yy0 + yy1) / 2, x1 - x0 + 1, yy1 - yy0 + 1)
    res[i] = out
    print(i, out)
for i in res:
    y, b = res[i]['yellow'], res[i]['black']
    dx, dy = b[0] - y[0], b[1] - y[1]
    dpx = np.hypot(dx, dy)
    print(i, 'dpx', dpx, 'dx', dx, 'dy', dy, 'm (yellow len px %d)' % y[2], dpx * L / y[2], 'm (270)', dpx * L / 270)
