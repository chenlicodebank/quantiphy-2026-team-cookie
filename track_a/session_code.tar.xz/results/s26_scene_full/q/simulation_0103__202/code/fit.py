import csv, numpy as np
r = list(csv.DictReader(open('scene/tracks/shark.csv')))
f = np.array([int(x['frame']) for x in r])
for col in ['cx', 'bbox_cx', 'x0', 'x1']:
    x = np.array([float(q[col]) for q in r])
    for lo in [1, 2]:
        m = f >= lo
        c = np.polyfit(f[m], x[m], 2)
        res = x[m] - np.polyval(c, f[m])
        a = 2 * c[0]
        v = lambda F: 2 * c[0] * F + c[1]
        print(col, lo, 'a px/f2 %.4f' % a, 'v(0) %.3f v(1) %.3f' % (v(0), v(1)), 'rms %.2f' % res.std(),
              'v0/a s %.4f v1/a %.4f vhalf/a %.4f' % (v(0) / a / 24, v(1) / a / 24, v(0.5) / a / 24))
