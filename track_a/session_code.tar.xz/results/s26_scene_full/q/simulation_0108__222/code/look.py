import csv, os, subprocess, sys
D = os.path.dirname(os.path.abspath(__file__))
os.makedirs(os.path.join(D, 'frames'), exist_ok=True)
P = sys.executable
FK = os.path.join(D, '..', '..', 'tools', 'framekit2.py')
V = os.path.join(D, 'simulation_0108.mp4')
subprocess.run([P, FK, 'sheet', V, '--n', '8', '--out', os.path.join(D, 'frames/sheet.png')])
subprocess.run([P, FK, 'frame', V, '--t', '1.0', '--grid', '100', '--out', os.path.join(D, 'frames/f24.png')])
for n in ['A', 'B']:
    r = list(csv.DictReader(open(os.path.join(D, 'scene/tracks/virus_' + n + '.csv'))))
    for i in range(0, 28, 3):
        x = r[i]
        print(n, i, x['core_w'], x['core_h'], x['bbox_w'], x['bbox_h'])
