import csv, os
import numpy as np
D = os.path.dirname(os.path.abspath(__file__))
def load(n):
    r = list(csv.DictReader(open(os.path.join(D, 'scene/tracks/virus_' + n + '.csv'))))
    return np.array([[float(x['cx']), float(x['cy'])] for x in r]), r
A, rA = load('A'); B, rB = load('B')
cx, cy = 960.0, 540.0
# body diameter of A vs frame (size ~ 1/Z)
fr = np.arange(0, 28)
dA = np.array([float(rA[i]['core_circle_diam']) for i in fr])
# fit A track frames 1..45 with uniform 3D motion: p(n) = (P0 + Q*n)/(1 + w*n), n = frame-1
n = np.arange(1, 46) - 1.0
P = A[1:46]
def res(q):
    px, py, qx, qy, w = q
    s = 1 + w * n
    return np.concatenate([(px + qx * n) / s - P[:, 0], (py + qy * n) / s - P[:, 1]])
# linearised: px + qx n - u w n = u ; py + qy n - v w n = v
z = np.zeros_like(n); o = np.ones_like(n)
M = np.vstack([np.column_stack([o, z, n, z, -P[:, 0] * n]), np.column_stack([z, o, z, n, -P[:, 1] * n])])
q = np.linalg.lstsq(M, np.concatenate([P[:, 0], P[:, 1]]), rcond=None)[0]
r = res(q)
print('fit', q, 'rms', np.sqrt(np.mean(r ** 2)), 'max', np.abs(r).max())
w = q[4]
# size check: diam*(1+w n) should be const
s = 1 + w * (fr[1:] - 1.0)
print('diam*(1+wn) frames 1..27:', np.round(dA[1:] * s, 1)[::3])
print('size-based w:', np.polyfit(fr[2:] - 1.0, 1 / dA[2:] * dA[1], 1))
# also fit with zero-w for comparison: constant acceleration in image
for f in [800, 1200, 1600, 2000, 2667, 3500, 5000, 8000]:
    # A position in camera coords, units of Z0: X = (u-cx)/f * Z, Z = 1 + w n
    def pos3(u, v, Z):
        return np.array([(u - cx) / f * Z, (v - cy) / f * Z, Z])
    nn = np.arange(0, 46)
    PA = np.array([pos3(*A[k], 1 + w * (k - 1)) if k >= 1 else pos3(*A[0], 1.0) for k in nn])
    sp = np.linalg.norm(np.diff(PA, axis=0), axis=1)  # per frame in Z0 units
    v = np.median(sp[2:25])
    Z0 = (1.7393 / 24) / v
    PB = pos3(*B[24], 1.0)
    d = np.linalg.norm(PA[24] - PB) * Z0
    d2 = np.linalg.norm(A[24] - B[24]) * Z0 / f
    print(f'f={f}: Z0={Z0:.3f} m, speed spread {sp[2:25].min()/v:.3f}-{sp[2:25].max()/v:.3f}, dist3D={d:.4f}, planar={d2:.4f}, dz={(PA[24][2]-1)*Z0:.3f}')
# pure 2D: scale from A pixel speed at frame 24
vp = np.linalg.norm(A[24] - A[23])
print('2D: pixel speed f24', vp, 'dist', np.linalg.norm(A[24] - B[24]) * 1.7393 / 24 / vp)
vp0 = np.mean(np.linalg.norm(np.diff(A[1:25], axis=0), axis=1))
print('2D: mean pixel speed 1..24', vp0, 'dist', np.linalg.norm(A[24] - B[24]) * 1.7393 / 24 / vp0)
print('pixel dist f24', np.linalg.norm(A[24] - B[24]))
