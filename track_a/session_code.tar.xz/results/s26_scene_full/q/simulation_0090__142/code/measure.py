import av, numpy as np, cv2
frames = [f.to_ndarray(format='bgr24') for f in av.open('simulation_0090.mp4').decode(video=0)]
bg = np.median(np.stack(frames[24:30]), axis=0).astype(np.int16)
def mask(i):
    m = (np.abs(frames[i].astype(np.int16) - bg).sum(2) > 20).astype(np.uint8)
    n, lab, st, _ = cv2.connectedComponentsWithStats(m)
    return lab, st
# x-edges per component per frame
for i in range(0, 20):
    lab, st = mask(i)
    comps = [s for s in st[1:] if s[4] > 300]
    print(i, [(s[0], s[0] + s[2] - 1, s[4]) for s in sorted(comps, key=lambda s: s[0])])
# template matching of eagle body (frame 4 -> 5) and crow
def tm(i, j, box):
    x0, y0, x1, y1 = box
    t = frames[i][y0:y1, x0:x1]
    r = cv2.matchTemplate(frames[j], t, cv2.TM_SQDIFF_NORMED)
    _, _, mn, _ = cv2.minMaxLoc(r)
    return mn[0] - x0, mn[1] - y0
print('eagle body 4->5', tm(4, 5, (1080, 580, 1260, 625)), '5->6', tm(5, 6, (923, 580, 1103, 625)))
print('crow body 4->5', tm(4, 5, (1411, 595, 1523, 625)), '5->6', tm(5, 6, (1316, 597, 1428, 625)))
