import numpy as np
r = np.load('/private/tmp/qp_blind/scene_full_a/simulation_0086/q_121/edges.npy')
f = r[:, 0].astype(float); front = r[:, 1].astype(float)
# car front edge, frames 2..56 (front visible, motion started)
for lo, hi in [(2, 56), (2, 30), (25, 56), (6, 50)]:
    m = (f >= lo) & (f <= hi)
    p = np.polyfit(f[m], front[m], 2)
    print(lo, hi, 'a px/frame^2 =', 2 * p[0], 'resid', np.std(front[m] - np.polyval(p, f[m])), 't0 root', np.roots(np.polyder(p)))
m = (f >= 2) & (f <= 56)
p = np.polyfit(f[m], front[m], 2)
a_pf = abs(2 * p[0])
a_ps2 = a_pf * 24**2
s = 4.03 / a_ps2
print('scale m/px', s, 'car length 438px ->', 438 * s, 'bike 129px ->', 129 * s)
# per-frame speed differences
sp = -np.diff(front)
print('speeds', sp[:60])
# distance at frame 48
i = 48
carx = front[i] + 218.5; cyc = (r[i, 3] + r[i, 4]) / 2
print('frame', i, 'car ref', carx, 'cyc ref', cyc, 'edges', r[i])
dx = cyc - carx; dy = 651.75 - 477.25
dpx = np.hypot(dx, dy)
print('dx dy dpx', dx, dy, dpx, 'dist m', dpx * s)
