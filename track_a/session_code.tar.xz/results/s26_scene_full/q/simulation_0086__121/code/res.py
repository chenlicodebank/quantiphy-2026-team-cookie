import numpy as np
P = '/private/tmp/qp_blind/scene_full_a/simulation_0086/q_121/'
o = np.load(P + 'tm.npy'); f = o[:, 0]; x = o[:, 1]
e = np.load(P + 'edges.npy')
m = (f >= 2) & (f <= 30)
p = np.polyfit(f[m], x[m], 2)
print('quad 2-30', p)
for i in range(1, 57):
    print(i, round(x[i] - np.polyval(p, i), 2), 'front-res', round(e[i, 1] + 218.5 - np.polyval(p, i), 1), 'rear-res', round(e[i, 2] - 218.5 - np.polyval(p, i), 1))
v = -np.diff(x)
print('speed', np.round(v, 2))
print('dv', np.round(np.diff(v), 3))
