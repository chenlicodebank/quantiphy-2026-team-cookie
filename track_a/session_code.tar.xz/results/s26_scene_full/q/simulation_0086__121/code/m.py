import av, numpy as np
c = av.open('/private/tmp/qp_blind/scene_full_a/simulation_0086/q_121/simulation_0086.mp4')
fr = []
for f in c.decode(video=0):
    fr.append(f.to_ndarray(format='gray').astype(np.int16)[300:800])
bg = fr[71]
rows = []
for i, g in enumerate(fr[:70]):
    d = np.abs(g - bg) > 30
    cb = d[260:460]; cols = np.where(cb.sum(0) > 3)[0]
    cy = d[80:275]; cc = np.where(cy.sum(0) > 3)[0]
    rows.append([i, cols.min() if len(cols) else -1, cols.max() if len(cols) else -1,
                 cc.min() if len(cc) else -1, cc.max() if len(cc) else -1])
rows = np.array(rows)
np.save('/private/tmp/qp_blind/scene_full_a/simulation_0086/q_121/edges.npy', rows)
for r in rows: print(*r)
