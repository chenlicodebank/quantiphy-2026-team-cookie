import numpy as np, json
P = '/private/tmp/qp_blind/scene_full_a/simulation_0086/q_121/'
o = np.load(P + 'tm.npy'); f = o[:, 0]; x = o[:, 1]
for lo, hi in [(2, 30), (2, 40), (2, 45), (10, 40)]:
    m = (f >= lo) & (f <= hi); p = np.polyfit(f[m], x[m], 2)
    print(lo, hi, 'a px/f2', -2 * p[0], 'pos48 model', np.polyval(p, 48))
m = (f >= 2) & (f <= 40); p = np.polyfit(f[m], x[m], 2)
a = -2 * p[0]
s = 4.03 / (a * 24 ** 2)
car48 = np.mean([np.polyval(p, 48), x[48], 264 + 218.5])
bike48 = 1702.5  # wheel-to-wheel bbox centre (scene track, verified on frame)
d = np.hypot(bike48 - car48, 651.75 - 477.25)
print('scale', s, 'car len m', 438 * s, 'bike speed m/s', 16.02 * 24 * s)
print('car48', car48, 'dpx', d, 'dist m', d * s)
# alternative: pelvis proxy 11 px behind bike centre
print('pelvis variant', np.hypot(bike48 - 11 - car48, 174.5) * s)
json.dump({"121": round(float(d * s), 2)}, open(P + 'answers.json', 'w'))
