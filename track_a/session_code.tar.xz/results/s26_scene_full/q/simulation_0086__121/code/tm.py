import av, numpy as np, cv2
P = '/private/tmp/qp_blind/scene_full_a/simulation_0086/q_121/'
c = av.open(P + 'simulation_0086.mp4')
fr = [f.to_ndarray(format='gray').astype(np.float32) for f in c.decode(video=0)]
fr = [g[380:780] for g in fr]  # keep band
# car template from frame 0: x 874..1311, rows 560..745 -> band rows 180..365
tc = fr[0][175:370, 870:1316].copy()
tb = fr[0][60:200, 880:1016].copy()  # cyclist band rows 440..580? cyclist y~477 -> band 97
def match(img, t, ylo, yhi):
    sub = img[ylo:yhi]
    r = cv2.matchTemplate(sub, t, cv2.TM_CCOEFF_NORMED)[0] if sub.shape[0] == t.shape[0] else cv2.matchTemplate(sub, t, cv2.TM_CCOEFF_NORMED).max(0)
    k = int(np.argmax(r))
    if 0 < k < len(r) - 1:
        a, b, cc = r[k - 1], r[k], r[k + 1]
        k = k + 0.5 * (a - cc) / (a - 2 * b + cc)
    return k, r.max()
out = []
for i in range(0, 57):
    xc, sc = match(fr[i], tc, 175, 370)
    xb, sb = match(fr[i], tb, 60, 200)
    out.append((i, xc + (1092.5 - 870), sc, xb + (948 - 880), sb))
    print(i, round(xc + 222.5, 2), round(sc, 3), round(xb + 68, 2), round(sb, 3))
o = np.array(out); np.save(P + 'tm.npy', o)
f = o[:, 0]; x = o[:, 1]
for lo, hi in [(2, 56), (2, 30), (25, 56), (6, 50)]:
    m = (f >= lo) & (f <= hi)
    p = np.polyfit(f[m], x[m], 2)
    p3 = np.polyfit(f[m], x[m], 3)
    print(lo, hi, 'a=', 2 * p[0], 'res', np.std(x[m] - np.polyval(p, f[m])), 'cubic', p3)
m = (f >= 2) & (f <= 50)
pb = np.polyfit(f[m], o[m, 3], 1); print('bike px/frame', pb)
