import av, numpy as np, cv2
c = av.open('simulation_0084.mp4')
res = {}
for i, fr in enumerate(c.decode(video=0)):
    im = fr.to_ndarray(format='rgb24')
    hsv = cv2.cvtColor(im, cv2.COLOR_RGB2HSV)
    g = cv2.cvtColor(im, cv2.COLOR_RGB2GRAY).astype(int)
    yel = (hsv[..., 1] > 80) & (hsv[..., 0] > 15) & (hsv[..., 0] < 40)
    ys, xs = np.nonzero(yel[400:600])
    mask = (g < 113) | (g > 176) | (hsv[..., 1] > 40)
    ycols = np.nonzero(mask[480:570].sum(0) > 5)[0]
    dcols = np.nonzero(mask[600:685].sum(0) > 5)[0]
    drows = np.nonzero(mask[:, dcols.min():dcols.max()].sum(1) > 5)[0]
    res[i] = (xs.mean() if len(xs) else np.nan, ys.mean() + 400 if len(ys) else np.nan, len(xs),
              ycols.min(), ycols.max(), dcols.min(), dcols.max())
for i in sorted(res):
    if i % 6 == 0 or i in (47, 48, 49):
        print(i, ['%.1f' % v for v in res[i]])
yc = np.array([res[i][0] for i in range(72)])
print('yellow centroid step 12->71', (yc[71] - yc[12]) / 59, '24->71', (yc[71] - yc[24]) / 47, '12->48', (yc[48] - yc[12]) / 36)
yf = np.array([res[i][3] for i in range(72)])
print('front bumper 1->71', (yf[71] - yf[1]) / 70, '24->60', (yf[60] - yf[24]) / 36)
yr = np.array([res[i][4] for i in range(72)])
print('rear 12->71', (yr[71] - yr[12]) / 59)
print('centroid steps 40..55', np.round(np.diff(yc)[40:56], 2))
df = np.array([res[i][5] for i in range(72)]); dr = np.array([res[i][6] for i in range(72)])
print('dark rear/front steps 2->71', (df[71] - df[1]) / 70, (dr[71] - dr[1]) / 70)
print('frame48 yellow ext', yf[48], yr[48], 'mid', (yf[48] + yr[48]) / 2, 'dark ext', df[48], dr[48], 'mid', (df[48] + dr[48]) / 2)
