import av, numpy as np, csv
P='/private/tmp/qp_blind/scene_full_b/simulation_0080/q_83/'
# bike (cyan) extents per frame, measured fresh
def frames():
    c=av.open(P+'simulation_0080.mp4')
    for i,f in enumerate(c.decode(video=0)):
        yield i,f.to_ndarray(format='rgb24').astype(int)
res={}
for i,a in frames():
    r,g,b=a[...,0],a[...,1],a[...,2]
    cyan=(b-r>40)&(g-r>30)
    ys,xs=np.nonzero(cyan[550:740]);
    bike=(xs.min(),xs.max()) if len(xs) else None
    # walker torso: light shirt, brighter than floor, region y 350-540, x>800
    sub=a[350:540,800:1500]; s=sub.sum(2)/3
    sh=(s>185)&(np.abs(sub[...,0]-sub[...,2])<25)
    yy,xx=np.nonzero(sh)
    res[i]=(bike, (xx.mean()+800, yy.mean()+350) if len(xx) else None, (np.median(xx)+800) if len(xx) else None)
    print(i,bike,res[i][1],res[i][2])
fr=np.arange(2,17)
cx=np.array([(res[i][0][0]+res[i][0][1])/2 for i in fr])
L=np.array([res[i][0][1]-res[i][0][0]+1 for i in fr])
p=np.polyfit(fr,cx,1); print('bike len px',L.mean(),L.std(),'fit',p,'resid',np.abs(cx-np.polyval(p,fr)).max())
print('bike cx at 24 extrap',np.polyval(p,24))
# rear-edge route
x1=np.array([res[i][0][1] for i in range(2,25)]); f2=np.arange(2,25)
q=np.polyfit(f2[:15],x1[:15],1); print('rear edge fit',q,'pred 24',np.polyval(q,24),'meas',res[24][0])
print('bike cx 24 from rear meas', res[24][0][1]-(L.mean()-1)/2)
