import av, numpy as np, csv
# van length per frame: subpixel crossings of level 195 on columns through the van body
tr = {int(r['frame']): r for r in csv.DictReader(open('scene/tracks/white_van.csv'))}
c = av.open('simulation_0075.mp4')
L = []
for i, f in enumerate(c.decode(video=0)):
    g = f.to_ndarray(format='gray').astype(float)
    cy = float(tr[i]['ref_y'])
    lens = []
    for x in (805, 815, 831, 845, 855):
        col = g[:, x - 1:x + 2].mean(1)
        y0 = int(cy - 160); y1 = min(int(cy + 160), 1079)
        seg = col[y0:y1]
        above = np.where(seg > 195)[0]
        a, b = above[0], above[-1]
        # subpixel
        ya = y0 + a - 1 + (195 - seg[a - 1]) / (seg[a] - seg[a - 1])
        yb = y0 + b + (seg[b] - 195) / (seg[b] - seg[b + 1]) if b + 1 < len(seg) else np.nan
        lens.append(yb - ya)
    L.append(np.median(lens))
    if i % 10 == 0 or i == 71: print(i, np.round(lens, 1))
L = np.array(L)
print('median van length', np.median(L), 'mean', L.mean(), 'std', L.std())
