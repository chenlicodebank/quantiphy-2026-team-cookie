import av, numpy as np
# green parked car: per-row extents; body by chroma (G-R), full extent by distance from local asphalt
c = av.open('simulation_0075.mp4')
imgs = []
for i, f in enumerate(c.decode(video=0)):
    if i in (0, 35, 71): imgs.append(f.to_ndarray(format='rgb24').astype(float))
    if i > 71: break
for img in imgs:
    res = []
    for y in range(570, 634, 4):
        row = img[y - 1:y + 2, 300:580].mean(0)
        chroma = row[:, 1] - row[:, 0]
        g = np.where(chroma > 15)[0]
        dev = np.abs(row - 166).max(1)
        d = np.where(dev > 12)[0]
        res.append((y, 300 + g[0], 300 + g[-1], 300 + d[0], 300 + d[-1]) if len(g) else (y,))
    for r in res: print(r)
    print('---')
