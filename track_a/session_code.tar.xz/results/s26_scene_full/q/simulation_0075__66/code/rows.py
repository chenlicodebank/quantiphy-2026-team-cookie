import av, numpy as np
c = av.open('simulation_0075.mp4')
for i, f in enumerate(c.decode(video=0)):
    if i == 0: img0 = f.to_ndarray(format='rgb24').astype(int)
    if i == 71: img71 = f.to_ndarray(format='rgb24').astype(int); break
for y in (580, 601, 625):
    print('green row', y)
    print(' '.join(f'{x}:{tuple(img0[y, x])}' for x in list(range(325, 342)) + list(range(512, 550))))
for x in (810, 831, 855):
    print('van col', x)
    print(' '.join(f'{y}:{tuple(img71[y, x])}' for y in list(range(72, 90)) + list(range(305, 340))))
