import av, numpy as np
c = av.open('simulation_0075.mp4')
fr = {}
for i, f in enumerate(c.decode(video=0)):
    if i in (0, 36, 71):
        fr[i] = f.to_ndarray(format='rgb24').astype(float)
    if i > 71: break
road = np.array([168, 168, 168.])  # approximate asphalt

def prof(img, axis, band, rng):
    # mean colour distance from local asphalt along a line band
    if axis == 'x':
        sub = img[band[0]:band[1], rng[0]:rng[1]]
        bg = np.median(np.concatenate([img[band[0]:band[1], rng[0]-20:rng[0]], img[band[0]:band[1], rng[1]:rng[1]+20]], 1).reshape(-1, 3), 0)
        d = np.abs(sub - bg).max(2).mean(0)
    else:
        sub = img[rng[0]:rng[1], band[0]:band[1]]
        bg = np.median(np.concatenate([img[rng[0]-20:rng[0], band[0]:band[1]], img[rng[1]:rng[1]+20, band[0]:band[1]]], 0).reshape(-1, 3), 0)
        d = np.abs(sub - bg).max(2).mean(1)
    return d, bg

def edges(d, off, thr):
    idx = np.where(d > thr)[0]
    return off + idx[0], off + idx[-1]

# green car: horizontal, centre y~601; take central band across width
img = fr[0]
for band in [(585, 618), (595, 608), (575, 628)]:
    d, bg = prof(img, 'x', band, (300, 580))
    print('green band', band, 'bg', bg.round(), [(t, edges(d, 300, t)) for t in (6, 10, 15, 25)])
d, _ = prof(img, 'x', (590, 612), (300, 580))
print('green profile 320-360', d[20:60].round(1))
print('green profile 515-560', d[215:260].round(1))
# van: vertical, centre x~831
for i in (0, 36, 71):
    img = fr[i]
    yc = {0: 929, 36: 735, 71: 199}[i]
    for band in [(815, 848), (823, 840)]:
        d, bg = prof(img, 'y', band, (yc - 150, min(yc + 150, 1059)))
        print('van f', i, band, 'bg', bg.round(), [(t, edges(d, yc - 150, t)) for t in (6, 10, 15, 25)])
    if i == 71:
        d, _ = prof(img, 'y', (815, 848), (yc - 150, yc + 150))
        print('van71 top', d[20:60].round(1)); print('van71 bottom', d[245:290].round(1))
