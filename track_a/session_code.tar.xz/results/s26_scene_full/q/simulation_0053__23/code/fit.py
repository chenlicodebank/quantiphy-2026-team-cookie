import csv,numpy as np,os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
def load(f):
    return list(csv.DictReader(open(f)))
o=[r for r in load('scene/tracks/orange_car.csv') if r['ref_reliable']=='1']
f=np.array([int(r['frame']) for r in o]); y=np.array([float(r['ref_y']) for r in o]); x=np.array([float(r['ref_x']) for r in o])
for lo in [15,20,30,50]:
    m=f>=lo
    c=np.polyfit(f[m]/30,y[m],2); print('orange fit from',lo,'acc px/s2',2*c[0], 'resid',np.std(y[m]-np.polyval(c,f[m]/30)))
d=np.hypot(np.diff(x),np.diff(y)); print(f[1:].tolist()); print(np.round(d,2).tolist())
p=load('scene/tracks/person.csv')
pf=np.array([int(r['frame']) for r in p]); px=np.array([float(r['ref_x']) for r in p]); py=np.array([float(r['ref_y']) for r in p])
for i in range(len(pf)): print(pf[i],px[i],py[i],p[i]['truncated_by_frame_edge'],p[i]['jacket_area'])
