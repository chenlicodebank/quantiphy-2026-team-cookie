import av, numpy as np, cv2, os, sys
os.chdir(os.path.dirname(os.path.abspath(__file__)))
# crop sheet of the person region
x0,y0,x1,y1=250,1800,550,2048
frames=list(range(int(sys.argv[1]),int(sys.argv[2]),int(sys.argv[3])))
tiles=[]
c=av.open('simulation_0053.mp4')
for i,fr in enumerate(c.decode(video=0)):
    if i in frames:
        im=fr.to_ndarray(format='bgr24')[y0:y1,x0:x1].copy()
        im=cv2.resize(im,None,fx=2,fy=2,interpolation=cv2.INTER_CUBIC)
        for gy in range(1850,2048,50):
            cv2.line(im,(0,(gy-y0)*2),(im.shape[1],(gy-y0)*2),(0,255,255),1)
        for gx in range(300,550,50):
            cv2.line(im,((gx-x0)*2,0),((gx-x0)*2,im.shape[0]),(0,255,255),1)
        cv2.putText(im,str(i),(5,30),cv2.FONT_HERSHEY_SIMPLEX,1,(0,0,255),2)
        tiles.append(im)
    if i>max(frames): break
cols=4
while len(tiles)%cols: tiles.append(np.zeros_like(tiles[0]))
rows=[np.hstack(tiles[r*cols:(r+1)*cols]) for r in range(len(tiles)//cols)]
cv2.imwrite(sys.argv[4],np.vstack(rows))
