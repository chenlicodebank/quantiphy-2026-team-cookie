import numpy as np, os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
R=np.load('tm_res.npy')  # (3 templates, n, [frame,dx,dy,score])
names=[70,75,80]
for k in range(3):
    f,dx,dy,s=R[k].T
    ok=(s>0.6)&(np.abs(dy)<60)
    for lo,hi,deg in [(54,66,1),(55,65,1),(56,64,1),(54,75,2),(54,80,2),(54,90,2),(54,90,3)]:
        m=ok&(f>=lo)&(f<=hi)
        cy=np.polyfit(f[m],dy[m],deg); cx=np.polyfit(f[m],dx[m],deg)
        vy=np.polyval(np.polyder(cy),60); vx=np.polyval(np.polyder(cx),60)
        print(f'tmpl{names[k]} f{lo}-{hi} deg{deg}: vy={vy:.3f} vx={vx:.3f} |v|={np.hypot(vx,vy):.3f}')
