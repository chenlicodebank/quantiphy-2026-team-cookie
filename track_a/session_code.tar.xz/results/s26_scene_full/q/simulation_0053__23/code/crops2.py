import av, numpy as np, cv2, os, sys
os.chdir(os.path.dirname(os.path.abspath(__file__)))
# zoomed crop sheet: args f0 f1 step out x0 y0 x1 y1 scale
f0,f1,st=map(int,sys.argv[1:4]); out=sys.argv[4]
x0,y0,x1,y1,s=map(int,sys.argv[5:10])
frames=list(range(f0,f1,st))
tiles=[]
c=av.open('simulation_0053.mp4')
for i,fr in enumerate(c.decode(video=0)):
    if i in frames:
        im=fr.to_ndarray(format='bgr24')[y0:y1,x0:x1].copy()
        im=cv2.resize(im,None,fx=s,fy=s,interpolation=cv2.INTER_CUBIC)
        for gy in range((y0//10+1)*10,y1,10):
            col=(0,255,255) if gy%50==0 else (0,140,140)
            if gy%50==0 or s>=4: cv2.line(im,(0,(gy-y0)*s),(im.shape[1],(gy-y0)*s),col,1)
        for gx in range((x0//10+1)*10,x1,10):
            col=(0,255,255) if gx%50==0 else (0,140,140)
            if gx%50==0 or s>=4: cv2.line(im,((gx-x0)*s,0),((gx-x0)*s,im.shape[0]),col,1)
        cv2.putText(im,str(i),(5,30),cv2.FONT_HERSHEY_SIMPLEX,1,(0,0,255),2)
        tiles.append(im)
    if i>max(frames): break
cols=int(sys.argv[10]) if len(sys.argv)>10 else 4
while len(tiles)%cols: tiles.append(np.zeros_like(tiles[0]))
rows=[np.hstack(tiles[r*cols:(r+1)*cols]) for r in range(len(tiles)//cols)]
cv2.imwrite(out,np.vstack(rows))
