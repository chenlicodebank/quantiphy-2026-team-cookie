import av, numpy as np, cv2, os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
# template-match the person's torso (jacket region) across frames, several templates
X0,Y0,X1,Y1=240,1820,500,2048
fr={}
c=av.open('simulation_0053.mp4')
for i,f in enumerate(c.decode(video=0)):
    if i>=50: fr[i]=cv2.cvtColor(f.to_ndarray(format='bgr24')[Y0:Y1,X0:X1],cv2.COLOR_BGR2GRAY).astype(np.float32)
def sub(r,ix,iy):
    def p(a,b,cc):
        den=a-2*b+cc; return 0 if den==0 else 0.5*(a-cc)/den
    dx=p(r[iy,ix-1],r[iy,ix],r[iy,ix+1]) if 0<ix<r.shape[1]-1 else 0
    dy=p(r[iy-1,ix],r[iy,ix],r[iy+1,ix]) if 0<iy<r.shape[0]-1 else 0
    return ix+dx,iy+dy
res={}
for tf,(tx0,ty0,tx1,ty1) in {70:(318,1965,392,2015),80:(318,1950,392,2000),75:(318,1955,392,2008)}.items():
    T=fr[tf][ty0-Y0:ty1-Y0,tx0-X0:tx1-X0]
    out=[]
    for i in range(54,91):
        r=cv2.matchTemplate(fr[i],T,cv2.TM_CCOEFF_NORMED)
        _,mv,_,ml=cv2.minMaxLoc(r)
        x,y=sub(r,*ml)
        out.append((i,x+X0-tx0,y+Y0-ty0,mv))
    res[tf]=np.array(out)
    print('template',tf)
    for o in out: print('  %d dx=%.2f dy=%.2f score=%.3f'%o)
np.save('tm_res.npy',np.stack([res[k] for k in (70,75,80)]))
