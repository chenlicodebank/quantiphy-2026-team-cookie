import numpy as np, re, subprocess, sys, os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
out=subprocess.run([sys.executable,'person_track.py'],capture_output=True,text=True).stdout
d={}
for l in out.splitlines():
    v=list(map(float,re.findall(r'[-\d.]+',l)))
    d[int(v[0])]=v[1:]
bad={48,49,50,63,64,65,66,67,68,78,79}
def fit(key,idx,lo,hi,deg):
    f=np.array([k for k in sorted(d) if lo<=k<=hi and k not in bad])
    y=np.array([d[k][idx] for k in f]); x=np.array([d[k][0] for k in f])
    cy=np.polyfit(f,y,deg); cx=np.polyfit(f,x,deg)
    vy=np.polyval(np.polyder(cy),60); vx=np.polyval(np.polyder(cx),60)
    r=np.std(y-np.polyval(cy,f))
    print(f'{key} f{lo}-{hi} deg{deg}: vy={vy:.3f} vx={vx:.3f} |v|={np.hypot(vx,vy):.3f} px/frame resid {r:.2f}')
    return np.hypot(vx,vy)
for lo,hi in [(52,90),(55,75),(55,90),(59,90),(52,70)]:
    for deg in (1,2):
        fit('centroid',1,lo,hi,deg); fit('ymax',3,lo,hi,deg)
