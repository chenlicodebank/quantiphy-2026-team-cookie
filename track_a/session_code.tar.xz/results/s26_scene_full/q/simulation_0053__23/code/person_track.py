import av, numpy as np, cv2, os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
# region around person
x0,y0,x1,y1=280,1880,480,2048
c=av.open('simulation_0053.mp4')
bg=None
rows=[]
dbg={}
for i,fr in enumerate(c.decode(video=0)):
    im=fr.to_ndarray(format='bgr24')[y0:y1,x0:x1].astype(np.int16)
    if i==0: bg=im.copy(); continue
    if i<40: continue
    b,g,r=im[...,0],im[...,1],im[...,2]
    v=im.max(2)
    navy=(v<70)&(b>=r)              # dark navy jacket (and shoes, lamp pole)
    # exclude lamp pole: present in bg as dark
    bgdark=bg.max(2)<90
    navy&=~bgdark
    # grey head disc: low saturation, mid grey, differs from bg
    diff=np.abs(im-bg).sum(2)
    sat=im.max(2)-im.min(2)
    n,lab,st,cen=cv2.connectedComponentsWithStats(navy.astype(np.uint8))
    # biggest component = jacket
    if n>1:
        k=1+np.argmax(st[1:,4]); m=lab==k
        ys,xs=np.nonzero(m)
        rows.append((i,xs.mean()+x0,ys.mean()+y0,ys.min()+y0,ys.max()+y0,m.sum()))
        if i in (60,70,80,90): dbg[i]=(im.astype(np.uint8),m)
for r in rows: print('%d cx=%.1f cy=%.1f ymin=%d ymax=%d area=%d'%r)
for i,(im,m) in dbg.items():
    o=im.copy(); o[m]=(0,0,255)
    cv2.imwrite('frames/mask%d.png'%i,cv2.resize(np.hstack([im,o]),None,fx=3,fy=3,interpolation=cv2.INTER_NEAREST))
