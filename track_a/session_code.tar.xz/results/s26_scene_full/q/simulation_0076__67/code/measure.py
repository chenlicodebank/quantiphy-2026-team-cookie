import csv,numpy as np
r={n:list(csv.DictReader(open('scene/tracks/%s.csv'%n))) for n in ['man_black_shirt','man_white_shirt']}
for col in [('head_x','head_y'),('cx','cy'),('pelvis_est_x','pelvis_est_y')]:
    v={}
    for n,rows in r.items():
        x=np.array([float(a[col[0]]) for a in rows]);y=np.array([float(a[col[1]]) for a in rows])
        v[n]=np.hypot(np.diff(x),np.diff(y))[1:].mean()
        v[n+'_net']=abs(x[71]-x[2])/69
    print(col,v,'ratio',v['man_white_shirt']/v['man_black_shirt'],v['man_white_shirt_net']/v['man_black_shirt_net'])
