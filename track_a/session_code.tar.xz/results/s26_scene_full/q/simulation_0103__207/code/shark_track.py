import av, numpy as np, cv2, csv
V = '/private/tmp/qp_blind/scene_full_a/simulation_0103/q_207/simulation_0103.mp4'
rows = list(csv.DictReader(open('/private/tmp/qp_blind/scene_full_a/simulation_0103/q_207/scene/tracks/shark.csv')))
frames = []
c = av.open(V)
for i, fr in enumerate(c.decode(video=0)):
    g = fr.to_ndarray(format='rgb24')[820:990].astype(np.float32)  # shark band only
    frames.append(g)
c.close()
# template: front body (nose to before tail) from frame 26
ref = 26
x0 = int(rows[ref]['x0'])
T = frames[ref][:, x0 - 5:x0 + 170]
xs = []
for i, g in enumerate(frames):
    r = cv2.matchTemplate(g, T, cv2.TM_SQDIFF_NORMED)
    _, _, mn, _ = cv2.minMaxLoc(r)
    y, x = mn[1], mn[0]
    # subpixel parabola in x
    if 0 < x < r.shape[1] - 1:
        a, b, cc = r[y, x - 1], r[y, x], r[y, x + 1]
        d = 0.5 * (a - cc) / (a - 2 * b + cc)
    else:
        d = 0
    xs.append(x + d)
xs = np.array(xs) - (x0 - 5)  # shift relative to frame ref
cx = np.array([float(r['cx']) for r in rows])
t = np.arange(len(xs)) / 24.0
print('frame  tmpl_shift  centroid  step_tmpl')
for i in range(len(xs)):
    print(i, round(xs[i], 2), cx[i], round(xs[i] - xs[i - 1], 2) if i else '')
for name, x in [('tmpl', xs), ('centroid', cx)]:
    for lo, hi in [(2, 54), (2, 28), (28, 54), (5, 50)]:
        p = np.polyfit(t[lo:hi], x[lo:hi], 2)
        print(name, lo, hi, 'acc px/s^2 =', round(2 * p[0], 2), 'v(t) coeff', np.round(p, 3))
np.save('/private/tmp/qp_blind/scene_full_a/simulation_0103/q_207/shark_tmpl.npy', xs)
