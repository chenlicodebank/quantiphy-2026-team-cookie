import av, numpy as np, cv2, csv
V = '/private/tmp/qp_blind/scene_full_a/simulation_0112/q_229/simulation_0112.mp4'
rows = {int(r['frame']): r for r in csv.DictReader(open('/private/tmp/qp_blind/scene_full_a/simulation_0112/q_229/scene/tracks/car.csv'))}
want = [18, 20, 22, 24, 26, 28, 30]
c = av.open(V)
for i, fr in enumerate(c.decode(video=0)):
    if i not in want: continue
    img = fr.to_ndarray(format='rgb24').astype(int)
    g = img.mean(axis=2)
    for key in ['rear_hub_x', 'front_hub_x']:
        hx = float(rows[i][key]); hy = 505.5
        # horizontal profile through hub row (avg rows 503-508)
        prof = g[503:509, int(hx) - 60:int(hx) + 61].mean(axis=0)
        dark = prof < 50
        xs = np.arange(int(hx) - 60, int(hx) + 61)
        # outermost dark run edges on each side
        left = xs[dark & (xs < hx)]; right = xs[dark & (xs > hx)]
        # vertical profile through hub column
        vp = g[440:560, int(hx) - 2:int(hx) + 3].mean(axis=1)
        ys = np.arange(440, 560)
        bot = ys[(vp < 50) & (ys > hy)]
        print(i, key, hx, 'L', left.min() if len(left) else None, 'R', right.max() if len(right) else None,
              'bot', bot.max() if len(bot) else None)
        if i == 24 and key == 'rear_hub_x':
            print(np.round(prof).astype(int).tolist())
            print(np.round(vp).astype(int).tolist())
    if i == 24:
        cr = img[440:560, 360:700].astype(np.uint8)
        cv2.imwrite('/private/tmp/qp_blind/scene_full_a/simulation_0112/q_229/frames/w24.png',
                    cv2.resize(cv2.cvtColor(cr, cv2.COLOR_RGB2BGR), None, fx=3, fy=3, interpolation=cv2.INTER_NEAREST))
