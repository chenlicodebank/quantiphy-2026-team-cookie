import av, numpy as np, cv2
D = '/private/tmp/qp_blind/scene_full_a/simulation_0112/q_229/'
V = D + 'simulation_0112.mp4'
# hub track: axle mid x = -148.14 + 28.227 f ; wheelbase 232 -> rear = mid-116, front = mid+116
def hub(f, which):
    m = -148.14 + 28.227 * f
    return m - 116 if which == 'rear' else m + 116
H = 60
stacks = {'rear': [], 'front': []}
c = av.open(V)
for i, fr in enumerate(c.decode(video=0)):
    if not (14 <= i <= 34): continue
    g = cv2.cvtColor(fr.to_ndarray(format='rgb24'), cv2.COLOR_RGB2GRAY).astype(np.float32)
    for w in stacks:
        hx = hub(i, w); hy = 505.5
        M = np.float32([[1, 0, -(hx - H)], [0, 1, -(hy - H)]])
        stacks[w].append(cv2.warpAffine(g, M, (2 * H + 1, 2 * H + 1), flags=cv2.INTER_LINEAR))
for w, s in stacks.items():
    s = np.array(s)
    mean = s.mean(0); std = s.std(0)
    cv2.imwrite(D + f'frames/stack_{w}.png', cv2.resize(np.clip(mean, 0, 255).astype(np.uint8), None, fx=4, fy=4, interpolation=cv2.INTER_NEAREST))
    # moving background -> high std; tyre (rigid w.r.t. hub except rotation) -> low std in tyre band
    # radial profile of std and mean
    res = []
    for ang in range(0, 360, 10):
        a = np.deg2rad(ang)
        rs = np.arange(20, 55, 0.25)
        xs = H + rs * np.cos(a); ys = H + rs * np.sin(a)  # ang 90 = down
        mv = cv2.remap(mean, xs.astype(np.float32)[None], ys.astype(np.float32)[None], cv2.INTER_LINEAR)[0]
        sv = cv2.remap(std, xs.astype(np.float32)[None], ys.astype(np.float32)[None], cv2.INTER_LINEAR)[0]
        grad = np.gradient(mv)
        # outer tyre edge: strongest positive gradient (dark->bright) beyond r=28
        k = np.argmax(np.where(rs > 28, grad, -1e9))
        res.append((ang, rs[k], grad[k]))
    print(w)
    for a, r, gr in res: print(f'  ang {a:3d} r {r:5.2f} grad {gr:6.1f}')
