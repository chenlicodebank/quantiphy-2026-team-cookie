import numpy as np, cv2
D = '/private/tmp/qp_blind/scene_full_a/simulation_0112/q_229/'
for w in ['rear', 'front']:
    big = cv2.imread(D + f'frames/stack_{w}.png', 0).astype(np.float32)
    m = cv2.resize(big, (121, 121), interpolation=cv2.INTER_AREA)
    print(w, 'row60 x15..105:', m[58:63, 15:106].mean(0).round().astype(int).tolist())
    print(w, 'col60 y15..105:', m[15:106, 58:63].mean(1).round().astype(int).tolist())
    # diagonals at 45 and 135 deg (lower half)
    for ang in [45, 135, 60, 120]:
        a = np.deg2rad(ang); rs = np.arange(20, 46, 1.0)
        v = [m[int(round(60 + r * np.sin(a))), int(round(60 + r * np.cos(a)))] for r in rs]
        print(w, ang, list(zip(rs.astype(int).tolist(), np.round(v).astype(int).tolist())))
