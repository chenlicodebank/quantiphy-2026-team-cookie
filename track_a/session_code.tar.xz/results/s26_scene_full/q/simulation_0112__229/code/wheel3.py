import numpy as np, cv2
D = '/private/tmp/qp_blind/scene_full_a/simulation_0112/q_229/'
for w in ['rear', 'front']:
    big = cv2.imread(D + f'frames/stack_{w}.png', 0).astype(np.float32)
    m = cv2.resize(big, (121, 121), interpolation=cv2.INTER_AREA)
    m = cv2.GaussianBlur(m, (0, 0), 0.8)
    gx = cv2.Sobel(m, cv2.CV_32F, 1, 0); gy = cv2.Sobel(m, cv2.CV_32F, 0, 1)
    pts = []
    for ang in np.arange(0, 360, 3):
        a = np.deg2rad(ang)
        rs = np.arange(26, 44, 0.1)
        xs = (60 + rs * np.cos(a)).astype(np.float32); ys = (60 + rs * np.sin(a)).astype(np.float32)
        gxv = cv2.remap(gx, xs[None], ys[None], cv2.INTER_LINEAR)[0]
        gyv = cv2.remap(gy, xs[None], ys[None], cv2.INTER_LINEAR)[0]
        radial = gxv * np.cos(a) + gyv * np.sin(a)  # dark inside -> bright outside positive
        k = np.argmax(radial)
        pts.append((ang, rs[k], radial[k]))
    pts = np.array(pts)
    for p in pts[::5]: print(w, p.round(2))
    # use lower arc and sides (exclude fender region at top, ang 200-340 where wheel arch shadow)
    sel = ((pts[:, 0] <= 180) | (pts[:, 0] >= 345)) & (pts[:, 2] > 20)
    a = np.deg2rad(pts[sel, 0]); r = pts[sel, 1]
    X = 60 + r * np.cos(a); Y = 60 + r * np.sin(a)
    keep = np.ones(len(X), bool)
    for it in range(3):
        A = np.c_[2 * X[keep], 2 * Y[keep], np.ones(keep.sum())]
        b = X[keep] ** 2 + Y[keep] ** 2
        cx, cy, c0 = np.linalg.lstsq(A, b, rcond=None)[0]
        R = np.sqrt(c0 + cx ** 2 + cy ** 2)
        res = np.hypot(X - cx, Y - cy) - R
        keep = np.abs(res) < max(1.0, 2.5 * np.median(np.abs(res[keep])))
    print(w, 'circle cx,cy,R', round(cx, 2), round(cy, 2), round(R, 2), 'n', keep.sum(), '/', len(X), 'resid', np.median(np.abs(res[keep])).round(2))
    print(w, 'median radius over selected angles', np.median(r).round(2))
