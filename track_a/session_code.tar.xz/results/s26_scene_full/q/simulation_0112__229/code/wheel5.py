import av, numpy as np, cv2, csv
D = '/private/tmp/qp_blind/scene_full_a/simulation_0112/q_229/'
rows = {int(r['frame']): r for r in csv.DictReader(open(D + 'scene/tracks/car.csv'))}
c = av.open(D + 'simulation_0112.mp4')
out = []
for i, fr in enumerate(c.decode(video=0)):
    if not (14 <= i <= 34) or i == 15: continue
    g = cv2.cvtColor(fr.to_ndarray(format='rgb24'), cv2.COLOR_RGB2GRAY).astype(np.float32)
    for key in ['rear_hub_x', 'front_hub_x']:
        hx = float(rows[i][key])
        res = {}
        for dx in [-6, -3, 0, 3, 6]:
            x = int(round(hx + dx))
            col = g[455:560, x - 1:x + 2].mean(1)
            ys = np.arange(455, 560)
            # bottom edge: dark tyre -> brighter deck, search y 530-548
            s = (ys >= 528) & (ys <= 548)
            d = np.diff(col)
            yb = ys[:-1][s[:-1]][np.argmax(d[s[:-1]])] + 0.5
            # top edge: tyre top vs arch gap; search y 462-482, largest |gradient|
            s2 = (ys >= 462) & (ys <= 482)
            res.setdefault('bot', []).append(yb)
        out.append((i, key, np.median(res['bot'])))
        if i in (24,) :
            x = int(round(hx))
            print(i, key, 'col y455..559', g[455:560, x - 1:x + 2].mean(1).round().astype(int).tolist())
b = np.array([o[2] for o in out])
print('bottom edge median', np.median(b), 'spread', b.min(), b.max())
