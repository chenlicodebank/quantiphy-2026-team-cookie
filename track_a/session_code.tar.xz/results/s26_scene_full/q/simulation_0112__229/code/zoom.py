import av, numpy as np, cv2
D = '/private/tmp/qp_blind/scene_full_a/simulation_0112/q_229/'
c = av.open(D + 'simulation_0112.mp4')
for i, fr in enumerate(c.decode(video=0)):
    if i != 24: continue
    img = cv2.cvtColor(fr.to_ndarray(format='rgb24'), cv2.COLOR_RGB2BGR)
    for (x0, name, hx) in [(365, 'rear', 413.5), (596, 'front', 644.5)]:
        cr = img[455:550, x0:x0 + 97].copy()
        S = 7
        z = cv2.resize(cr, None, fx=S, fy=S, interpolation=cv2.INTER_CUBIC)
        cx = (hx - x0 + 0.5) * S; cy = (505.5 - 455 + 0.5) * S
        for R, col in [(33.5, (0, 255, 0)), (35, (0, 0, 255))]:
            cv2.circle(z, (int(cx), int(cy)), int(R * S), col, 1)
        for y in [471.5, 539.5]:
            yy = int((y - 455 + 0.5) * S); cv2.line(z, (0, yy), (40, yy), (255, 255, 0), 2)
        cv2.imwrite(D + f'frames/zoom_{name}.png', z)
