import av, numpy as np, cv2, csv, os
os.makedirs('frames', exist_ok=True)
V = 'simulation_0101.mp4'
frames = []
c = av.open(V)
for i, fr in enumerate(c.decode(video=0)):
    frames.append(fr.to_ndarray(format='rgb24')[640:1080].astype(np.int16))  # underwater strip only
c.close()
# background: frame0 for x<1300 (shark starts at x>1500), last frame for x>=1300
bg = frames[0].copy(); bg[:, 1300:] = frames[-1][:, 1300:]
Y0 = 640
rows = []
for i, f in enumerate(frames):
    d = np.abs(f - bg).max(axis=2)
    m = (d > 22).astype(np.uint8)
    m[:676 - Y0] = 0
    m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    n, lab, st, cen = cv2.connectedComponentsWithStats(m)
    k = 1 + np.argmax(st[1:, cv2.CC_STAT_AREA])
    ys, xs = np.nonzero(lab == k)
    rows.append((i, xs.min(), xs.max(), xs.mean(), ys.mean() + Y0, ys.min() + Y0, ys.max() + Y0))
    if i in (10, 40, 70):
        vis = frames[i][:, :, ::-1].astype(np.uint8).copy()
        vis[lab == k] = (0, 0, 255)
        cv2.imwrite(f'frames/mask_{i}.png', vis[150:400, max(0, xs.min()-60):xs.max()+60])
r = np.array(rows, float)
np.savetxt('shark_track.csv', r, delimiter=',', fmt='%.2f', header='frame,xmin,xmax,cx,cy,ymin,ymax')
t = r[:, 0] / 24
for name, col in (('centroid', 3), ('xmin', 1), ('xmax', 2), ('bboxc', None)):
    x = (r[:, 1] + r[:, 2]) / 2 if col is None else r[:, col]
    sel = r[:, 0] >= 1
    p = np.polyfit(t[sel], x[sel], 2)
    res = x[sel] - np.polyval(p, t[sel])
    print(name, 'a=%.2f px/s^2' % (2 * p[0]), 'v(t=1/24)=%.1f' % np.polyval(np.polyder(p), 1/24), 'rms', res.std().round(2))
    # sub-windows
    for a, b in ((1, 36), (36, 72), (1, 72)):
        s = (r[:, 0] >= a) & (r[:, 0] <= b)
        pp = np.polyfit(t[s], x[s], 2)
        print('   win', a, b, 'a=%.2f' % (2 * pp[0]))
L = r[:, 2] - r[:, 1] + 1
print('length px mean %.1f median %.1f min %d max %d' % (L.mean(), np.median(L), L.min(), L.max()))
dx = np.diff(r[:, 3])
print('per-frame dx centroid', np.round(dx, 2))
