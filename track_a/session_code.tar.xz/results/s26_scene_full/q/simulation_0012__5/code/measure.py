import csv,numpy as np,av
r=list(csv.DictReader(open('scene/tracks/bird.csv')))
b=np.array([float(x['beak_x']) for x in r]); x=np.array([float(x['x']) for x in r])
# cruise window frames 19..42 (skip-free; steps 18->19 and 42->43 double)
for a,c in [(19,42),(20,41),(22,40)]:
    print(a,c,'beak px/frame',(b[c]-b[a])/(c-a),'body',(x[c]-x[a])/(c-a))
# roof edge profile along rows
c=av.open('simulation_0012.mp4'); f=next(c.decode(video=0)).to_ndarray(format='rgb24').astype(float)
for y in [450,520,600]:
    g=f[y,:,1]-f[y,:,2]
    idx=[i for i in range(350,1450) if (g[i]>25)!=(g[i-1]>25)]
    print(y,idx[:6],idx[-6:])
for y in [660,670,680]:
    g=f[y,:,1]-f[y,:,2]
    idx=[i for i in range(350,1450) if (g[i]>25)!=(g[i-1]>25)]
    print(y,idx[:6],idx[-6:])
