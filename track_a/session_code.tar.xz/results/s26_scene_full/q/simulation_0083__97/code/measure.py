import av, numpy as np, cv2
fr = []
c = av.open('simulation_0083.mp4')
for i, f in enumerate(c.decode(video=0)):
    if i % 6 == 0 or i in (24, 30, 36, 42):
        fr.append((i, f.to_ndarray(format='rgb24').astype(np.int16)))
c.close()
bg = np.median(np.stack([a for i, a in fr if i % 6 == 0]), axis=0).astype(np.int16)

def mask(a):
    d = a.astype(int) - bg
    g = a.mean(2) - bg.mean(2)
    yel = (a[..., 0] - a[..., 2]) > 30
    m = yel | (g < -34) | (g > 12)
    m = cv2.morphologyEx(m.astype(np.uint8), cv2.MORPH_CLOSE, np.ones((3, 3), np.uint8))
    return m

for i, a in fr:
    if i not in (24, 30, 36, 42):
        continue
    m = mask(a)
    for name, (y0, y1) in [('yellow', (330, 479)), ('black', (479, 640))]:
        sub = m[y0:y1]
        ys, xs = np.nonzero(sub)
        x0, x1 = xs.min(), xs.max()
        # per-column y extent
        ext = []
        for x in range(x0, x1 + 1):
            col = np.nonzero(sub[:, x])[0]
            ext.append(col.max() - col.min() + 1 if len(col) else 0)
        ext = np.array(ext)
        L = x1 - x0 + 1
        print(i, name, 'len', L, 'wmax', ext.max(), 'y', ys.min() + y0, ys.max() + y0,
              'pctl 50/90', np.percentile(ext, 50), np.percentile(ext, 90),
              'profile', ext[::10].tolist())
