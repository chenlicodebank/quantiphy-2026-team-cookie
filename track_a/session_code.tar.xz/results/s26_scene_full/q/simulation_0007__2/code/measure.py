import av, numpy as np, cv2
c = av.open('simulation_0007.mp4')
for i, fr in enumerate(c.decode(video=0)):
    if i == 0:
        img = fr.to_ndarray(format='bgr24'); break
hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
H, S, V = [hsv[..., k].astype(int) for k in range(3)]
# pier: greyish bright low-saturation in region
m = ((V > 110) & (S < 60)).astype(np.uint8)
roi = np.zeros_like(m); roi[340:700, 360:600] = 1
m = m * roi
m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8))
m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
n, lab, st, cen = cv2.connectedComponentsWithStats(m)
k = 1 + np.argmax(st[1:, 4])
pm = (lab == k).astype(np.uint8)
cnts, _ = cv2.findContours(pm, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
cnt = max(cnts, key=cv2.contourArea)
pm2 = np.zeros_like(pm); cv2.drawContours(pm2, [cnt], -1, 1, -1)
rect = cv2.minAreaRect(cnt)
print('pier rect', rect, 'bbox', cv2.boundingRect(cnt))
ys, xs = np.nonzero(pm2)
pts = np.c_[xs, ys].astype(float); mu = pts.mean(0)
w, v = np.linalg.eigh(np.cov((pts - mu).T)); ax = v[:, 1]
p = (pts - mu) @ ax; q = (pts - mu) @ v[:, 0]
print('pier axis', ax, 'along extent', p.max() - p.min(), 'across', q.max() - q.min())
# along extent using percentiles across slices of width
print('pier along 0.2-99.8 pct', np.percentile(p, 99.9) - np.percentile(p, 0.1))
# profile along axis: width at each along position
bins = np.arange(np.floor(p.min()), np.ceil(p.max()) + 1, 4)
hist = np.histogram(p, bins)[0]
print('width profile (px count per 4px slice / 4):', (hist / 4).astype(int).tolist())
# boat
bm = ((V > 100)).astype(np.uint8); r2 = np.zeros_like(bm); r2[640:770, 730:960] = 1; bm *= r2
bm = cv2.morphologyEx(bm, cv2.MORPH_CLOSE, np.ones((7, 7), np.uint8))
cn, _ = cv2.findContours(bm, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
cb = max(cn, key=cv2.contourArea)
print('boat rect', cv2.minAreaRect(cb), 'bbox', cv2.boundingRect(cb))
ov = img.copy()
cv2.drawContours(ov, [cnt], -1, (0, 0, 255), 1); cv2.drawContours(ov, [cb], -1, (255, 0, 0), 1)
box = cv2.boxPoints(rect).astype(int); cv2.polylines(ov, [box], True, (0, 255, 255), 1)
cv2.imwrite('frames/overlay.png', ov[320:780, 330:980])
