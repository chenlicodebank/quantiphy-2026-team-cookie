import av, numpy as np, cv2
c = av.open('simulation_0007.mp4')
for i, fr in enumerate(c.decode(video=0)):
    if i == 0:
        img = fr.to_ndarray(format='bgr24'); break
V = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)[..., 2].astype(int)
bm = (V > 100).astype(np.uint8); r2 = np.zeros_like(bm); r2[640:770, 730:960] = 1; bm *= r2
bm = cv2.morphologyEx(bm, cv2.MORPH_CLOSE, np.ones((7, 7), np.uint8))
cn, _ = cv2.findContours(bm, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
cb = max(cn, key=cv2.contourArea)
m = np.zeros_like(bm); cv2.drawContours(m, [cb], -1, 1, -1)
ys, xs = np.nonzero(m); pts = np.c_[xs, ys].astype(float); mu = pts.mean(0)
w, v = np.linalg.eigh(np.cov((pts - mu).T)); ax = v[:, 1]
p = (pts - mu) @ ax
print('axis', ax, 'extent', p.max() - p.min(), p.min(), p.max())
bins = np.arange(np.floor(p.min()), np.ceil(p.max()) + 1, 1)
h = np.histogram(p, bins)[0]
print('first 20 widths', h[:20].tolist())
print('last 20 widths', h[-20:].tolist())
for thr in (4, 6, 8):
    idx = np.nonzero(h >= thr)[0]
    print(thr, 'extent', bins[idx[-1] + 1] - bins[idx[0]])
