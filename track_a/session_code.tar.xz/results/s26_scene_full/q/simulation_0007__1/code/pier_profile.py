import av, numpy as np, cv2
c=av.open('simulation_0007.mp4')
for i,f in enumerate(c.decode(video=0)):
    img=f.to_ndarray(format='rgb24'); break
g=cv2.cvtColor(img,cv2.COLOR_RGB2HSV)[:,:,2].astype(float)
m=(g>110).astype(np.uint8)
m[:350]=0; m[700:]=0; m[:, :370]=0; m[:,620:]=0
m=cv2.morphologyEx(m,cv2.MORPH_OPEN,np.ones((5,5),np.uint8))
n,l,s,cen=cv2.connectedComponentsWithStats(m)
k=1+np.argmax(s[1:,4]); mk=(l==k).astype(np.uint8)
mk=cv2.morphologyEx(mk,cv2.MORPH_CLOSE,np.ones((9,9),np.uint8))
cnts,_=cv2.findContours(mk,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_NONE)
cnt=max(cnts,key=cv2.contourArea)
print('minAreaRect',cv2.minAreaRect(cnt), 'area',cv2.contourArea(cnt))
ys,xs=np.nonzero(mk); P=np.c_[xs,ys].astype(float); mu=P.mean(0)
ev,evec=np.linalg.eigh(np.cov((P-mu).T)); a=evec[:,1]; nrm=evec[:,0]
print('mu',mu,'axis',a,'normal',nrm)
s_ax=(P-mu)@a; s_n=(P-mu)@nrm
for t in np.arange(-160,161,20):
    sel=np.abs(s_ax-t)<2
    if sel.sum(): print(t, round(s_n[sel].max()-s_n[sel].min()+1,1), round(s_n[sel].min(),1), round(s_n[sel].max(),1))
for t in [-80,-40,0,40,80,120]:
    pts=[mu+t*a+u*nrm for u in range(-70,71)]
    vals=[g[int(round(p[1])),int(round(p[0]))] for p in pts]
    print(t,' '.join(str(int(v)) for v in vals[::2]))
cv2.imwrite('frames/piermask.png',cv2.cvtColor(img,cv2.COLOR_RGB2BGR)//2+mk[:,:,None]*np.array([0,120,0],np.uint8))
