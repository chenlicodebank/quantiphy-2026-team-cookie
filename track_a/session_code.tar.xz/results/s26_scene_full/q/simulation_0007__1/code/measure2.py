import av, numpy as np, cv2
def map_coordinates(A,yx,order=1):
    y=np.asarray(yx[0],np.float32).reshape(1,-1); x=np.asarray(yx[1],np.float32).reshape(1,-1)
    return cv2.remap(A.astype(np.float32),x,y,cv2.INTER_LINEAR).ravel()
c=av.open('simulation_0007.mp4')
frames={}
for i,f in enumerate(c.decode(video=0)):
    if i in (0,10,20): frames[i]=f.to_ndarray(format='rgb24')
    if i>20: break
img=frames[0]
V=cv2.cvtColor(img,cv2.COLOR_RGB2HSV)[:,:,2].astype(float)

# ---- pier width: sub-pixel edges on averaged cross profiles, refine angle
mu=np.array([478.886,521.811])
def prof(theta, trange):
    a=np.array([np.cos(theta),np.sin(theta)]); n=np.array([-a[1],a[0]])
    us=np.arange(-70,70.01,0.25)
    acc=[]
    for t in trange:
        p=mu[None,:]+t*a[None,:]+us[:,None]*n[None,:]
        acc.append(map_coordinates(V,[p[:,1],p[:,0]],order=1))
    return us,np.mean(acc,0)
def edges(us,pr):
    inside=np.median(pr[np.abs(us)<25]);
    lo_l=np.median(pr[us<-55]); lo_r=np.median(pr[us>55])
    hl=(inside+lo_l)/2; hr=(inside+lo_r)/2
    # left crossing: last index from left where below hl before rising
    i=np.where(pr[:len(us)//2]<hl)[0][-1]; ul=us[i]+(hl-pr[i])/(pr[i+1]-pr[i])*0.25
    j=len(us)//2+np.where(pr[len(us)//2:]<hr)[0][0]; ur=us[j-1]+(hr-pr[j-1])/(pr[j]-pr[j-1])*0.25
    return ul,ur
th0=np.arctan2(0.89788,0.44024)
best=None
for dth in np.deg2rad(np.arange(-2,2.01,0.1)):
    us,pr=prof(th0+dth,np.arange(-30,150,1.0))
    gmax=np.abs(np.diff(pr)).max()
    ul,ur=edges(us,pr)
    if best is None or gmax>best[0]: best=(gmax,np.rad2deg(th0+dth),ur-ul,ul,ur)
print('best angle',best)
th=np.deg2rad(best[1])
for seg in [(-30,30),(30,90),(90,150),(-80,-40)]:
    us,pr=prof(th,np.arange(seg[0],seg[1],1.0))
    ul,ur=edges(us,pr); print('pier seg',seg,'width px',round(ur-ul,2),round(ul,2),round(ur,2))
# pier length along axis (for info)
a=np.array([np.cos(th),np.sin(th)]); n=np.array([-a[1],a[0]])
ts=np.arange(-200,200.01,0.25)
p=mu[None,:]+ts[:,None]*a[None,:]
acc=np.mean([map_coordinates(V,[(p+u*n)[:,1],(p+u*n)[:,0]],order=1) for u in range(-25,26,5)],0)
print('water end, axial profile tail:', [(round(t,1),int(v)) for t,v in zip(ts[::20],acc[::20]) if t>120])

# ---- boat length along its axis
for fi,im in frames.items():
    hsv=cv2.cvtColor(im,cv2.COLOR_RGB2HSV); v=hsv[:,:,2]
    m=(v>100).astype(np.uint8); m[:600]=0
    m=cv2.morphologyEx(m,cv2.MORPH_CLOSE,np.ones((7,7),np.uint8))
    nlab,l,s,_=cv2.connectedComponentsWithStats(m); k=1+np.argmax(s[1:,4])
    mk=(l==k).astype(np.uint8)
    cnts,_=cv2.findContours(mk,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_NONE); cnt=max(cnts,key=cv2.contourArea)
    fill=np.zeros_like(mk); cv2.drawContours(fill,[cnt],-1,1,-1)
    ys,xs=np.nonzero(fill); P=np.c_[xs,ys].astype(float); m0=P.mean(0)
    ev,evec=np.linalg.eigh(np.cov((P-m0).T)); ax=evec[:,1]
    s_=(P-m0)@ax; q=(P-m0)@evec[:,0]
    print('frame',fi,'boat len',s_.max()-s_.min()+1,'width',q.max()-q.min()+1,'angle',np.rad2deg(np.arctan2(ax[1],ax[0])))
    if fi==0:
        o=im.copy(); o[fill>0]=o[fill>0]//2+np.array([0,120,0],np.uint8)
        cv2.imwrite('frames/boatmask.png',cv2.cvtColor(o[620:800,700:980],cv2.COLOR_RGB2BGR))
