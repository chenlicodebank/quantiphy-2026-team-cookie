import av, numpy as np, cv2
cont = av.open('simulation_0084.mp4')
for i, fr in enumerate(cont.decode(video=0)):
    if i != 24: continue
    img = fr.to_ndarray(format='rgb24')
    hsv = cv2.cvtColor(img, cv2.COLOR_RGB2HSV)
    g = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY).astype(int)
    m = (g < 113) | (g > 176) | (hsv[..., 1] > 40)
    for name, (x0, x1) in {'yellow': (1514, 1790), 'dark': (398, 668)}.items():
        sub = m[:, x0:x1]
        rows = np.where(sub.sum(1) > 3)[0]
        wide = np.where(sub.sum(1) > 0.5 * (x1 - x0))[0]
        print(name, rows.min(), rows.max(), (rows.min() + rows.max()) / 2,
              'wide', wide.min(), wide.max(), (wide.min() + wide.max()) / 2)
    break
