import av, numpy as np, cv2
cont = av.open('simulation_0084.mp4')
res = {}
for i, fr in enumerate(cont.decode(video=0)):
    if i > 40: break
    img = fr.to_ndarray(format='rgb24')
    hsv = cv2.cvtColor(img, cv2.COLOR_RGB2HSV)
    g = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY).astype(int)
    m = (g < 113) | (g > 176) | (hsv[..., 1] > 40)
    out = {}
    for name, (y0, y1) in {'yellow': (480, 570), 'dark': (600, 685)}.items():
        cols = np.where(m[y0:y1].sum(0) > 3)[0]
        rows = np.where(m[y0 - 40:y1 + 40].sum(1) > 3)[0] + y0 - 40
        out[name] = (cols.min(), cols.max(), rows.min(), rows.max())
    res[i] = out
for i in [12, 16, 20, 22, 23, 24, 25, 26, 30, 36, 40]:
    y = res[i]['yellow']; d = res[i]['dark']
    print(i, 'Y', y, (y[0] + y[1]) / 2, (y[2] + y[3]) / 2, 'D', d, (d[0] + d[1]) / 2, (d[2] + d[3]) / 2)
yc = np.array([(res[i]['yellow'][0] + res[i]['yellow'][1]) / 2 for i in range(12, 41)])
dc = np.array([(res[i]['dark'][0] + res[i]['dark'][1]) / 2 for i in range(2, 41)])
print('yellow step fit', np.polyfit(np.arange(12, 41), yc, 1))
print('dark step fit', np.polyfit(np.arange(2, 41), dc, 1))
