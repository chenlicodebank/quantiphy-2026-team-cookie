import csv, numpy as np
D='/private/tmp/qp_blind/scene_full_b/simulation_0102/q_197/'
r=list(csv.DictReader(open(D+'scene/tracks/shark.csv')))
f=np.array([int(x['frame']) for x in r])
def col(k): return np.array([float(x[k]) if x[k] else np.nan for x in r])
for k in ['mask_centroid_x','nose_x_sub','tail_x_sub']:
    y=col(k)
    for lo,hi in [(1,60),(1,30),(30,60),(1,72)]:
        m=(f>=lo)&(f<=hi)&~np.isnan(y)
        if m.sum()<5: continue
        p=np.polyfit(f[m],y[m],2); res=y[m]-np.polyval(p,f[m])
        print(k,lo,hi,'a px/fr2=%.5f'%(2*p[0]),'v@24=%.3f'%(2*p[0]*24+p[1]),'rms=%.2f'%res.std())
    m=(f>=1)&(f<=60)&~np.isnan(y)
    p=np.polyfit(f[m],y[m],3); print(' cubic coef',p[0])
b=list(csv.DictReader(open(D+'scene/tracks/boat.csv')))
bx=np.array([float(x['ref_x']) for x in b])
d=np.diff(bx); print('boat step f23->24',d[23],'mean 2-72',d[1:].mean(),'fit', np.polyfit(np.arange(1,73),bx[1:],1))
