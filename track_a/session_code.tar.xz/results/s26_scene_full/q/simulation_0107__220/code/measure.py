import csv, numpy as np
fps=24.0
def load(o):
    return list(csv.DictReader(open('scene/tracks/'+o+'.csv')))
res={}
for o,(a,b) in [('virus_small_left',(2,40)),('virus_large_right',(2,35))]:
    r=load(o)
    f=np.array([int(x['frame']) for x in r[a:b+1]]); x=np.array([float(q['cx_bodyfit']) for q in r[a:b+1]]); y=np.array([float(q['cy_bodyfit']) for q in r[a:b+1]])
    px=np.polyfit(f,x,1); py=np.polyfit(f,y,1)
    res[o]=(px,py)
    print(o,'step',px[0],py[0],'speed px/s',np.hypot(px[0],py[0])*fps,'resid',np.std(x-np.polyval(px,f)))
    print(' at48 fit',np.polyval(px,48),np.polyval(py,48),' record',r[48]['cx'],r[48]['cy'])
(pxl,pyl)=res['virus_large_right']; (pxs,pys)=res['virus_small_left']
v=np.hypot(pxl[0],pyl[0])*fps; s=1.7393/v
d=np.hypot(np.polyval(pxl,48)-np.polyval(pxs,48),np.polyval(pyl,48)-np.polyval(pys,48))
print('scale m/px',s,'dist px',d,'m',d*s)
r1=load('virus_small_left');r2=load('virus_large_right')
d2=np.hypot(float(r2[48]['cx'])-float(r1[48]['cx']),float(r2[48]['cy'])-float(r1[48]['cy']))
print('record dist px',d2,'m',d2*s)
