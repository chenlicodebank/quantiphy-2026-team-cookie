import av, numpy as np, cv2
bg = np.array([97,149,191])
c = av.open('simulation_0088.mp4')
res = {}
for i, fr in enumerate(c.decode(video=0)):
    a = fr.to_ndarray(format='rgb24').astype(int)
    m = (np.abs(a-bg).sum(2) > 40).astype(np.uint8)
    n, lab, st, _ = cv2.connectedComponentsWithStats(m)
    comps = [s for s in st[1:] if s[4] > 200]
    res[i] = [(s[0], s[0]+s[2]-1, s[2], s[3]) for s in comps]
    print(i, res[i])
