import csv,numpy as np
r=list(csv.DictReader(open('scene/tracks/virus_A.csv')))
f=np.array([int(x['frame']) for x in r[1:28]]);cx=np.array([float(x['cx']) for x in r[1:28]]);cy=np.array([float(x['cy']) for x in r[1:28]])
s=np.sqrt(np.array([float(x['mask_area_px']) for x in r[1:28]]))
invs=1/s
for name,y in [('1/s',invs),('(u-960)s',(cx-960)*s),('(v-540)s',(cy-540)*s)]:
    p1=np.polyfit(f,y,1);p2=np.polyfit(f,y,2)
    print(name,p1,'rms1',np.std(y-np.polyval(p1,f)),'quad/lin over 27f',p2[0]*27**2/(p1[0]*27))
d=np.hypot(np.diff(cx),np.diff(cy));print('pix speed fit',np.polyfit(f[1:],d,1))
print('speed/size',d[0]/s[1],d[-1]/s[-1])
