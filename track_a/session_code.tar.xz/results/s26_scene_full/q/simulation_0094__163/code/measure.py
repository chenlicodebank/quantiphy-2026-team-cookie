import csv, os, numpy as np, av
os.chdir(os.path.dirname(os.path.abspath(__file__)))
def load(n):
    return list(csv.DictReader(open(f'scene/tracks/{n}.csv')))
car = load('car')
rows = [r for r in car if r['clipped_by_frame_edge'] == '0']
f = np.array([int(r['frame']) for r in rows])
for col in ['bbox_x0', 'bbox_x1', 'ref_x']:
    x = np.array([float(r[col]) for r in rows])
    print('car', col, 'px/frame', np.polyfit(f, x, 1)[0])
bg = np.array([86, 79, 78])  # BGR
c = av.open('simulation_0094.mp4')
cx0 = []
for i, fr in enumerate(c.decode(video=0)):
    im = fr.to_ndarray(format='bgr24').astype(int)
    m = (np.abs(im - bg).sum(2) > 20)
    lo = m[590:]; lx = np.where(lo.any(0))[0]
    if 11 <= i and len(lx): cx0.append((i, lx[0], lx[-1]))
    if i < 22: continue
    up = m[:590]; ys = np.where(up.any(1))[0]; xs = np.where(up.any(0))[0]
    print(i, 'plane y0,y1,h', ys[0], ys[-1], ys[-1]-ys[0]+1, 'len', xs[-1]-xs[0]+1)
a = np.array(cx0, float)
print('car x0 slope', np.polyfit(a[:, 0], a[:, 1], 1)[0], 'x1 slope', np.polyfit(a[:, 0], a[:, 2], 1)[0])
