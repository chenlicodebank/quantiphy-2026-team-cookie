import os, numpy as np, av, cv2
os.chdir(os.path.dirname(os.path.abspath(__file__)))
c = av.open('simulation_0094.mp4')
for i, fr in enumerate(c.decode(video=0)):
    if i < 22: continue
    im = fr.to_ndarray(format='bgr24').astype(int)
    bg = np.median(im.reshape(-1, 3), axis=0)
    for th in (20, 30, 45):
        m = (np.abs(im - bg).sum(2) > th).astype(np.uint8)
        n, lab, st, _ = cv2.connectedComponentsWithStats(m)
        out = []
        for k in np.argsort(-st[1:, 4])[:2] + 1:
            x, y, w, h, a = st[k]
            out.append((x, y, w, h, a))
        out.sort(key=lambda o: o[1])
        p, car = out
        print(i, th, 'plane x,y,w,h', p[:4], 'car', car[:4])
