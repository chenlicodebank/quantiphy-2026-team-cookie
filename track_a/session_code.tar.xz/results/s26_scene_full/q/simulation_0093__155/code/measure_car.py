import av, numpy as np
bg = np.array([80, 81, 88], float)
c = av.open('simulation_0093.mp4')
for i, fr in enumerate(c.decode(video=0)):
    a = fr.to_ndarray(format='rgb24').astype(float)
    sub = a[580:660]
    d = np.abs(sub - bg).max(axis=2)
    for thr in (12, 25, 40):
        m = d > thr
        m[:, :700] = False
        ys, xs = np.nonzero(m)
        # restrict to largest blob region near car: columns with any mask
        if len(xs) == 0: continue
        cols = np.nonzero(m.any(0))[0]; rows = np.nonzero(m.any(1))[0]
        L = cols[-1] - cols[0] + 1; H = rows[-1] - rows[0] + 1
        if thr == 25:
            res = (i, L, H, cols[0], cols[-1], rows[0] + 580, rows[-1] + 580)
        if thr == 12: r12 = (L, H)
        if thr == 40: r40 = (L, H)
    # sub-pixel: column profile / row profile of soft coverage
    w = np.clip(d / np.percentile(d[d > 25], 50), 0, 1) if (d > 25).any() else d
    w[:, :700] = 0
    w[w < 0.08] = 0
    Lsoft = (w.max(0)).sum(); Hsoft = (w.max(1)).sum()
    print(*res, 'thr12', r12, 'thr40', r40, 'soft L %.1f H %.1f ratio %.4f' % (Lsoft, Hsoft, Hsoft / Lsoft), 'ratio25 %.4f' % (res[2] / res[1]))
