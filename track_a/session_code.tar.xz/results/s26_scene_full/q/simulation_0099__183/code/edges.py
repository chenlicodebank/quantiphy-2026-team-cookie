import av, numpy as np, cv2
V = '/private/tmp/qp_blind/scene_full_a/simulation_0099/q_183/simulation_0099.mp4'
fr = {}
with av.open(V) as c:
    for i, f in enumerate(c.decode(video=0)):
        if i <= 47 or i == 72:
            fr[i] = cv2.cvtColor(f.to_ndarray(format='rgb24'), cv2.COLOR_RGB2GRAY).astype(np.float32)
        if i > 72: break
ref0, ref72 = fr[0], fr[72]
def bg_for(i):
    # background: frame 72 left part (boat gone right of ~1150?), frame 0 right part
    b = ref72.copy(); b[:, 1100:] = ref0[:, 1100:]; return b
st, bw = [], []
for i in range(0, 48):
    d = np.abs(fr[i] - bg_for(i))
    # stern: hull rows 480-540 leftmost; bow tip rows 355-420 rightmost, subpixel by row-profile threshold
    def edge(rows, side):
        prof = d[rows[0]:rows[1]].max(0)
        idx = np.where(prof > 30)[0]
        if side == 'L':
            k = idx.min(); # subpixel interpolate across threshold
            return k - 1 + (30 - prof[k - 1]) / (prof[k] - prof[k - 1])
        k = idx.max(); return k + (prof[k] - 30) / (prof[k] - prof[k + 1])
    st.append(edge((480, 540), 'L')); bw.append(edge((355, 420), 'R'))
st, bw = np.array(st), np.array(bw)
print('len (bow-stern) frames 0..47:', np.round(bw - st, 1))
print('stern dx:', np.round(np.diff(st), 2))
print('bow dx:', np.round(np.diff(bw), 2))
print('stern mean dx 2..47:', (st[47] - st[1]) / 46, 'bow:', (bw[47] - bw[1]) / 46)
print('dx at frame 24 stern/bow:', st[24] - st[23], bw[24] - bw[23])
