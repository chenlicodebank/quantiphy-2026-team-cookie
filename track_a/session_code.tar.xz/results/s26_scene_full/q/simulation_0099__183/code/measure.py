import av, numpy as np, cv2
V = '/private/tmp/qp_blind/scene_full_a/simulation_0099/q_183/simulation_0099.mp4'
want = set(range(0, 40)) | {72}
fr = {}
with av.open(V) as c:
    for i, f in enumerate(c.decode(video=0)):
        if i in want:
            fr[i] = cv2.cvtColor(f.to_ndarray(format='rgb24'), cv2.COLOR_RGB2GRAY).astype(np.float32)
        if i > 72: break
bg = fr[72].copy()  # boat at x>... ; use right part of frame 0 sky and left of frame 72
bg[:, :1150] = fr[72][:, :1150]
# length at frame 0: columns in rows 360-610 differing from frame 72 (boat has moved far right by then)
d = np.abs(fr[0] - fr[72])[360:612, :1200]
cols = np.where((d > 18).sum(0) > 3)[0]
print('frame0 boat x-extent (rows 360-612):', cols.min(), cols.max(), cols.max() - cols.min() + 1)
# rows 360-560 only (above water, excludes reflection)
d2 = np.abs(fr[0] - fr[72])[340:565, :1200]
cols2 = np.where((d2 > 18).sum(0) > 2)[0]
print('frame0 extent rows 340-565:', cols2.min(), cols2.max())
# per-frame shift by phase correlation on band rows 230-560 (hull+cabin), window following boat
def shift(a, b):
    w = np.hanning(a.shape[1])[None, :] * np.hanning(a.shape[0])[:, None]
    (dx, dy), _ = cv2.phaseCorrelate(a * w, b * w)
    return dx, dy
for i in range(2, 40):
    x0 = int(200 + 17.88 * max(i - 2, 0))
    a = fr[i - 1][230:560, x0:x0 + 900]; b = fr[i][230:560, x0:x0 + 900]
    dx, dy = shift(a, b)
    print(i, round(dx, 3), round(dy, 3))
