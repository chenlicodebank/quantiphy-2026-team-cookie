import av, numpy as np
fn='/private/tmp/qp_blind/scene_full_b/simulation_0096/q_170/simulation_0096.mp4'
frames=[]
c=av.open(fn)
for f in c.decode(video=0):
    a=f.to_ndarray(format='rgb24').astype(float)
    frames.append(a[560:650].copy())  # car strip only
c.close()
bg=np.median(np.stack([frames[0],frames[-1]]),axis=0)
# background: use pixel far right column region as uniform grey
grey=np.median(frames[0][:, 1500:1900],axis=(0,1))
print('grey',grey)
L=[];X=[];LE=[];RE=[]
for i,a in enumerate(frames):
    d=np.abs(a-grey).max(axis=2)
    m=d>18
    rows=np.where(m.any(1))[0]
    # column profile: fraction-based subpixel edges using sum of diff per column
    prof=np.clip(d,0,60).max(axis=0)/60.0  # 0..1
    cols=np.where(prof>0.3)[0]
    cols=cols[(cols>300)&(cols<1400)]
    x0,x1=cols.min(),cols.max()
    # subpixel: edge at crossing of 0.5 level
    def cross(j0,j1):
        p0,p1=prof[j0],prof[j1]
        return j0+(0.5-p0)/(p1-p0) if p1!=p0 else j0
    j=x0
    while prof[j]>0.5: j-=1
    le=cross(j,j+1)
    j=x1
    while prof[j]>0.5: j+=1
    re=cross(j-1,j)
    LE.append(le);RE.append(re);L.append(re-le);X.append((le+re)/2)
    print(i,x0,x1,round(le,2),round(re,2),round(re-le,2),rows.min()+560,rows.max()+560)
X=np.array(X);t=np.arange(len(X))/24.
for s in [2,3,4]:
    sel=np.arange(s,41)
    for xx,name in [(X,'cen'),(np.array(LE),'le'),(np.array(RE),'re')]:
        p=np.polyfit(t[sel],xx[sel],2)
        res=xx[sel]-np.polyval(p,t[sel])
        print(s,name,'acc px/s2',2*p[0],'t0', -p[1]/(2*p[0]),'rms',res.std())
v=np.diff(X)*24
print('speeds',np.round(v,1))
np.save('/private/tmp/qp_blind/scene_full_b/simulation_0096/q_170/len.npy',np.array(L))
