import av, numpy as np, cv2
frames = {}
want = {0, 20, 22, 23, 24, 25, 26, 28}
c = av.open('simulation_0099.mp4')
for i, f in enumerate(c.decode(video=0)):
    if i in want:
        frames[i] = cv2.cvtColor(f.to_ndarray(format='rgb24'), cv2.COLOR_RGB2GRAY).astype(np.float32)
    if i > max(want): break
# boat length at frame 0: columns where non-sky/non-sea pixels exist in rows 360-560 (hull above waterline)
g = frames[0]
bg = np.median(g[360:560, 1300:1900], axis=1)[:, None]
diff = np.abs(g[360:560] - bg) > 20
cols = np.where(diff.sum(0) > 3)[0]
print('boat hull cols rows360-560:', cols.min(), cols.max(), 'len', cols.max() - cols.min() + 1)
# shark: template matching between frames
def shift(a, b):
    tpl = frames[a][840:970, 640:960] if a < 10 else None
    return tpl
def xs(i):
    s = frames[i][780:1030]
    m = np.abs(s - np.median(s, axis=1, keepdims=True)) > 18
    cs = np.where(m.sum(0) > 2)[0]
    w = m.sum(0).astype(float)
    return cs.min(), cs.max(), (w * np.arange(len(w))).sum() / w.sum()
for i in sorted(frames):
    if i: print(i, xs(i))
# phase correlation shark 23->24 and 20->28
def crop(i, x0):
    return frames[i][820:990, x0:x0 + 400]
for a, b in [(23, 24), (22, 26), (20, 28)]:
    x0 = 380
    tpl = frames[a][830:980, int(xs(a)[0]) - 5:int(xs(a)[1]) + 5]
    r = cv2.matchTemplate(frames[b][830:980], tpl, cv2.TM_CCOEFF_NORMED)
    _, _, _, loc = cv2.minMaxLoc(r)
    xi = loc[0]
    row = r[0]
    d = (row[xi - 1] - row[xi + 1]) / (2 * (row[xi - 1] - 2 * row[xi] + row[xi + 1]))
    print(a, b, 'dx/frame', (xi + d - (int(xs(a)[0]) - 5)) / (b - a))
