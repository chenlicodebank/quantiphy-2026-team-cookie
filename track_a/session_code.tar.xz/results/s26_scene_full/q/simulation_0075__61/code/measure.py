import csv, numpy as np, av
# cyclist speed from track: linear fit over frames 2..71 and local window
r = list(csv.DictReader(open('scene/tracks/pedestrian_road.csv')))
f = np.array([int(x['frame']) for x in r]); y = np.array([float(x['ref_y']) for x in r]); xx = np.array([float(x['ref_x']) for x in r])
cy = np.array([float(x['centroid_y']) for x in r])
m = f >= 2
p = np.polyfit(f[m], y[m], 1); print('global fit px/frame', p[0])
p2 = np.polyfit(f[m], cy[m], 1); print('global fit centroid', p2[0])
w = (f >= 14) & (f <= 34)
print('local fit f14-34', np.polyfit(f[w], y[w], 1)[0])
print('step at 24', np.hypot(xx[24]-xx[23], y[24]-y[23]))
# van body length measured independently: white pixels in van region
def frame(i):
    c = av.open('simulation_0075.mp4')
    for k, fr in enumerate(c.decode(video=0)):
        if k == i:
            a = fr.to_ndarray(format='rgb24'); c.close(); return a
for i in (0, 24, 50, 71):
    a = frame(i).astype(int)
    sub = a[:, 760:900]
    # van is bright white: min channel > 225
    mask = sub.min(axis=2) > 220
    rows = np.where(mask.sum(axis=1) > 30)[0]
    # largest contiguous run
    runs = np.split(rows, np.where(np.diff(rows) > 3)[0] + 1)
    run = max(runs, key=len)
    print('frame', i, 'van rows', run[0], run[-1], 'len', run[-1]-run[0]+1)
