import av,numpy as np,csv
# per-row extents of the van with lower threshold to catch mirrors; report widest rows
van=list(csv.DictReader(open('scene/tracks/van.csv')))
c=av.open('simulation_0073.mp4')
for i,f in enumerate(c.decode(video=0)):
    if i not in (20,30,40,50): continue
    a=f.to_ndarray(format='rgb24').astype(int)
    r=van[i]; y0,y1=int(float(r['bbox_y0'])),int(float(r['bbox_y1']))
    g=a.mean(2); bg=np.median(g[y0:y1,640:740])
    for th in (12,25,40):
        ws=[]
        for yy in range(y0-3,y1+3):
            xs=np.nonzero(np.abs(g[yy,740:930]-bg)>th)[0]
            if len(xs): ws.append((yy-y0,xs[0]+740,xs[-1]+740,xs[-1]-xs[0]+1))
        ws=np.array(ws); o=np.argsort(-ws[:,3])[:4]
        print(i,th,'median',np.median(ws[20:-20,3]),'widest rows',ws[o].tolist())
    # half-max edges on mean profile of middle rows
    prof=g[y0+60:y1-60,760:900].mean(0)-bg
    h=prof.max()/2; xs=np.nonzero(prof>h)[0]
    # subpixel
    def cross(k0,k1):
        return k0+(h-prof[k0])/(prof[k1]-prof[k0])
    L=cross(xs[0]-1,xs[0]); R=cross(xs[-1]+1,xs[-1])
    print(i,'half-max body width',R-L, 'L',L+760,'R',R+760)
