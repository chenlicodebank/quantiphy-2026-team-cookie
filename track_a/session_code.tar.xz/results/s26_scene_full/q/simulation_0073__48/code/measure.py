import av,numpy as np,csv
van=list(csv.DictReader(open('scene/tracks/van.csv')))
cyc=list(csv.DictReader(open('scene/tracks/cyclist.csv')))
y=np.array([float(x['cy_px']) for x in cyc])
p=np.polyfit(np.arange(2,72),y[2:],1); print('cyclist px/frame',p[0])
want={30,40,50}
c=av.open('simulation_0073.mp4')
for i,f in enumerate(c.decode(video=0)):
    if i not in want: continue
    a=f.to_ndarray(format='rgb24').astype(int)
    r=van[i]; y0,y1=int(float(r['bbox_y0'])),int(float(r['bbox_y1']))
    g=a.mean(2); bg=np.median(g[y0:y1,640:740])
    ws=[]
    for yy in range(y0+3,y1-3):
        row=np.abs(g[yy,740:930]-bg)>25
        xs=np.nonzero(row)[0]
        if len(xs): ws.append((yy,xs[0]+740,xs[-1]+740,xs[-1]-xs[0]+1))
    ws=np.array(ws)
    print(i,'bbox',r['bbox_x0'],r['bbox_x1'],y0,y1,'len',y1-y0,'bg',bg)
    print(' width per row pct10/50/90/max',np.percentile(ws[:,3],[10,50,90,100]))
    for k in range(0,len(ws),12): print('  ',ws[k])
