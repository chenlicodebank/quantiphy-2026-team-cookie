import av, numpy as np
import cv2
c = av.open('simulation_0100.mp4')
hs, ws, bl = [], [], []
for i, fr in enumerate(c.decode(video=0)):
    a = fr.to_ndarray(format='rgb24').astype(int)
    if i % 4 == 0 or i == 57:
        # shark: underwater panel, rows 700-1079; background is blue, measure deviation from row-median colour
        sub = a[700:1075]
        bg = np.median(sub, axis=1, keepdims=True)
        d = np.abs(sub - bg).sum(2)
        m = d > 40
        n, lab, st, _ = cv2.connectedComponentsWithStats(m.astype(np.uint8), 8)
        k = 1 + np.argmax(st[1:, cv2.CC_STAT_AREA])
        ys, xs = np.nonzero(lab == k)
        h = ys.max() - ys.min() + 1; w = xs.max() - xs.min() + 1
        hs.append(h); ws.append(w)
        # boat length: red hull rows 450-640, red/dark pixels; use row 480-560 extremes of non-grey pixels
        top = a[380:640]
        g = np.abs(top[..., 0] - top[..., 2])
        mb = g > 40
        cols = np.nonzero(mb.any(0))[0]
        bl.append((cols.min(), cols.max()))
        print(i, 'shark h', h, 'w', w, 'y', ys.min() + 700, ys.max() + 700, 'boat x', cols.min(), cols.max(), cols.max() - cols.min() + 1)
print('shark h median', np.median(hs), 'w median', np.median(ws))
