import csv,numpy as np
D='/private/tmp/qp_blind/scene_full_a/simulation_0085/q_109/'
r=list(csv.DictReader(open(D+'scene/tracks/car.csv')))
f=np.array([int(x['frame']) for x in r]);x0=np.array([float(x['bbox_x0']) for x in r]);x1=np.array([float(x['bbox_x1']) for x in r])
d0=-np.diff(x0[:64]); d1=-np.diff(x1[40:])
print('front dx',d0); print('rear dx',d1)
print('second diff front',np.diff(d0))
for a,b in [(3,63),(10,60),(20,63),(5,40),(3,30)]:
    m=(f>=a)&(f<=b); p=np.polyfit(f[m],x0[m],2); print(a,b,'acc px/f2',2*p[0], 'rest frame', -p[1]/(2*p[0]))
m=(f>=40)&(f<=71); p=np.polyfit(f[m],x1[m],2); print('rear 40-71',2*p[0])
m=(f>=40)&(f<=63); p=np.polyfit(f[m],x1[m],2); print('rear 40-63',2*p[0])
c=list(csv.DictReader(open(D+'scene/tracks/cyclist.csv')))
cx=np.array([float(x['centre_x_full']) for x in c]); cb0=np.array([float(x['bbox_x0']) for x in c])
print('cyc dx', -np.diff(cx))
p=np.polyfit(np.arange(72)[4:68],cx[4:68],1); print('cyc lin slope',p[0])
p=np.polyfit(np.arange(72)[2:68],cb0[2:68],1); print('cyc front slope',p[0])
