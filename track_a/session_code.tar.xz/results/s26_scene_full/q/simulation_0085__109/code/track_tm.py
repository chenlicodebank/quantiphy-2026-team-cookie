import av,numpy as np
D='/private/tmp/qp_blind/scene_full_a/simulation_0085/q_109/'
frames=[]
with av.open(D+'simulation_0085.mp4') as c:
    for fr in c.decode(video=0):
        g=fr.to_ndarray(format='gray').astype(np.float32)
        frames.append(g[540:920].copy())   # car lane rows only (keeps memory small)
T=frames[50][:, 737:1463]   # template: car bbox at frame 50
W=T.shape[1]
def ssd(img,s):
    # template left edge at integer s
    a=max(0,s); b=min(1920,s+W)
    if b-a<60: return np.inf
    d=img[:,a:b]-T[:,a-s:b-s]
    return np.mean(d*d)
pos=[]
prev=1839
for i,img in enumerate(frames):
    rng=range(prev-80,prev+5)
    v=np.array([ssd(img,s) for s in rng]); k=int(np.argmin(v)); s=rng[k]
    if 0<k<len(v)-1:
        y0,y1,y2=v[k-1],v[k],v[k+1]; off=0.5*(y0-y2)/(y0-2*y1+y2)
    else: off=0
    pos.append(s+off); prev=s
    print(i,round(s+off,2),round(v[k],1))
pos=np.array(pos); np.save(D+'car_pos.npy',pos)
d=-np.diff(pos); print('dx',np.round(d,2))
f=np.arange(len(pos))
for a,b in [(3,63),(3,30),(30,63),(3,71),(10,55)]:
    m=(f>=a)&(f<=b); p=np.polyfit(f[m],pos[m],2); print(a,b,'acc',-2*p[0],'rest',-p[1]/(2*p[0]))
