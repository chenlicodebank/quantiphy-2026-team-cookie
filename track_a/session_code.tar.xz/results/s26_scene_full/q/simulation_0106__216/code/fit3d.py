import csv, numpy as np
cx,cy=960,540
D0='/private/tmp/qp_blind/scene_full_b/simulation_0106/q_216/scene/tracks/'
def load(n):
    r=list(csv.DictReader(open(D0+n+'.csv')))
    a=np.array([[float(x['frame']),float(x['ref_x']),float(x['ref_y']),float(x['body_radius'])] for x in r])
    return a
L=load('virus_left_small'); R=load('virus_right_large')
def cam(a,f):
    return np.c_[(a[:,1]-cx)/a[:,3],(a[:,2]-cy)/a[:,3],f/a[:,3]]
for f in [1000,1500,2000,2667,3500,5000]:
    out=[]
    for name,a,rng in [('L',L,(1,36)),('R',R,(1,27))]:
        m=(a[:,0]>=rng[0])&(a[:,0]<=rng[1])
        P=cam(a[m],f); t=a[m,0]/24
        co=[np.polyfit(t,P[:,k],2) for k in range(3)]
        v1=np.array([np.polyfit(t,P[:,k],1)[0] for k in range(3)])
        v=np.array([2*c[0]*1+c[1] for c in co])
        p24=np.array([np.polyval(c,1.0) for c in co])
        out.append((name,v1,np.linalg.norm(v1),np.linalg.norm(v),p24))
    sR=out[1][2]
    D=np.linalg.norm(out[0][4]-out[1][4])
    Rm=1.5667/sR
    print(f, 'spdL %.3f spdR %.3f (quadR %.3f) dirR'%(out[0][2],out[1][2],out[1][3]), np.round(out[1][1]/out[1][2],3),'D_R %.3f'%D,'Rm %.4f'%Rm,'dist %.4f'%(D*Rm), 'dP', np.round(out[0][4]-out[1][4],3))
