import csv, numpy as np
cx,cy=960,540
D0='/private/tmp/qp_blind/scene_full_b/simulation_0106/q_216/scene/tracks/'
def load(n):
    r=list(csv.DictReader(open(D0+n+'.csv')))
    return np.array([[float(x['frame']),float(x['ref_x']),float(x['ref_y']),float(x['body_radius'])] for x in r])
L=load('virus_left_small'); R=load('virus_right_large')
def cam(a,f,s=1.0):
    return s*np.c_[(a[:,1]-cx)/a[:,3],(a[:,2]-cy)/a[:,3],f/a[:,3]]
def fitlin(a,f,rng,s=1.0):
    m=(a[:,0]>=rng[0])&(a[:,0]<=rng[1]); P=cam(a[m],f,s); t=a[m,0]/24
    c=[np.polyfit(t,P[:,k],1) for k in range(3)]
    return np.array([x[0] for x in c]), lambda tt: np.array([np.polyval(x,tt) for x in c])
for sL in [1.0, 0.87]:
  print('size ratio L/R =',sL)
  for f in np.arange(1800,3201,200):
    vL,pL=fitlin(L,f,(1,36),sL); vR,pR=fitlin(R,f,(1,27))
    dR=vR/np.linalg.norm(vR); dL=vL/np.linalg.norm(vL)
    up=-(dR-dL)/2; up/=np.linalg.norm(up)   # world up in camera coords
    h0=pL(1/24)@up - pR(1/24)@up            # height difference at start
    Rm=1.5667/np.linalg.norm(vR)
    D=np.linalg.norm(pL(1.0)-pR(1.0))*Rm
    print(' f %d dirL %s dirR %s  dh0(R) %.3f  |vL|/|vR| %.3f  R=%.4f m  dist %.4f'%(f,np.round(dL,3),np.round(dR,3),h0,np.linalg.norm(vL)/np.linalg.norm(vR),Rm,D))
# backward-difference speed check for right around frame 24 at f=2667
f=2667
P=cam(R,f); sp=np.linalg.norm(np.diff(P,axis=0),axis=1)*24
print('right per-frame speeds (R/s) f2..27 mean %.3f sd %.3f'%(sp[1:27].mean(),sp[1:27].std()))
# direct frame-24 distance using raw (unfitted) positions
for f in [2400,2667]:
    vR,_=fitlin(R,f,(1,27)); Rm=1.5667/np.linalg.norm(vR)
    pl=cam(L[L[:,0]==24],f)[0]; pr=cam(R[R[:,0]==24],f)[0]
    print('raw f24 f=%d dist %.4f'%(f,np.linalg.norm(pl-pr)*Rm))
