import av, numpy as np
c = av.open('simulation_0087.mp4')
car = []; cyc = []; cy = []; cary = []
for i, f in enumerate(c.decode(video=0)):
    a = f.to_ndarray(format='rgb24').astype(int)
    g = a.mean(2); ch = a.max(2) - a.min(2)
    m = (np.abs(g - 140) > 38) | (ch > 25)
    cb = m[560:820].sum(0); xs = np.where(cb > 20)[0]
    car.append((xs.min(), xs.max()))
    bb = m[300:540].sum(0); xs = np.where(bb > 5)[0]
    cyc.append((xs.min(), xs.max()))
car = np.array(car, float); cyc = np.array(cyc, float)
np.save('edges.npy', np.hstack([car, cyc]))
fr = np.arange(len(car))
for lo in (2, 5, 10, 20):
    for hi in (36, 53):
        s = slice(lo, hi + 1)
        p = np.polyfit(fr[s], car[s, 0], 2)
        print(lo, hi, 'acc px/f2 %.4f' % (2 * p[0]), 'resid %.2f' % np.std(car[s, 0] - np.polyval(p, fr[s])), 'x0(24)=%.1f' % np.polyval(p, 24))
print('car edges 20-28', car[20:29].tolist())
print('cyc edges 20-28', cyc[20:29].tolist())
print('car full len 37-53', (car[37:, 1] - car[37:, 0]).tolist())
print('cyc len 7-30', (cyc[7:31, 1] - cyc[7:31, 0]).tolist())
