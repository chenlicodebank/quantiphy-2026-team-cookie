import numpy as np
e = np.load('edges.npy'); x0 = e[:, 0]; fr = np.arange(len(x0))
for lo, hi in ((0, 53), (0, 36), (2, 53)):
    best = None
    for f0 in np.arange(0.0, 3.0, 0.01):
        f = fr[lo:hi + 1]; q = np.clip(f - f0, 0, None) ** 2
        M = np.vstack([np.ones_like(q), q]).T
        c, *_ = np.linalg.lstsq(M, x0[lo:hi + 1], rcond=None)
        r = np.std(x0[lo:hi + 1] - M @ c)
        if best is None or r < best[0]: best = (r, f0, c)
    r, f0, c = best
    print(lo, hi, 'f0=%.2f a=%.4f px/f2 resid %.2f' % (f0, -2 * c[1], r))
a = 0.715
scale = 4.03 / (a * 24 ** 2)
print('scale m/px', scale)
car24 = np.array([x0[24] + 583 / 2, 688.5]); cyc24 = np.array([(e[24, 2] + e[24, 3]) / 2, 429.0])
print('car24', car24, 'cyc (my mask)', cyc24, 'record cyc 460')
for cx in (cyc24[0], 460.0):
    d = np.hypot(car24[0] - cx, car24[1] - 429.0)
    print('d px %.1f -> %.3f m' % (d, d * scale))
