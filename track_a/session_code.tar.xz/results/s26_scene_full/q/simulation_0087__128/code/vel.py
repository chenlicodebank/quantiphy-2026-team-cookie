import numpy as np, csv
e = np.load('edges.npy')
x0 = e[:, 0]
v = -np.diff(x0)
print('front-edge steps', v.tolist())
# smoothed velocity via local quadratic fits on windows of 9 frames
fr = np.arange(len(x0))
for c in range(6, 50, 4):
    s = slice(c - 4, c + 5)
    p = np.polyfit(fr[s], x0[s], 2)
    print(c, 'v=%.2f a=%.3f' % (-(2 * p[0] * c + p[1]), -2 * p[0]))
r = list(csv.DictReader(open('scene/tracks/car.csv')))
mc = np.array([float(q['mask_cx']) for q in r]); bc = np.array([float(q['bbox_cx']) for q in r])
s = slice(37, 54)
for name, arr in (('mask_cx', mc), ('bbox_cx', bc), ('rear', e[:, 1])):
    p = np.polyfit(fr[s], arr[s], 2)
    print(name, 'acc 37-53 %.3f' % (2 * p[0]))
# fit of t with time origin free: x0 = A + B (f - f0)^2 starting from rest
from scipy.optimize import least_squares
def res(q, lo, hi):
    A, a, f0 = q
    f = fr[lo:hi + 1]
    return x0[lo:hi + 1] - (A - 0.5 * a * np.clip(f - f0, 0, None) ** 2)
for lo, hi in ((0, 36), (0, 53), (10, 53)):
    sol = least_squares(res, [1787, 0.7, 1.0], args=(lo, hi))
    print('rest-start fit', lo, hi, sol.x, np.std(sol.fun))
