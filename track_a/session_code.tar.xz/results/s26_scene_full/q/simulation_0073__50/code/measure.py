import csv, numpy as np, cv2, av
D = '/private/tmp/qp_blind/scene_full_b/simulation_0073/q_50/'
def load(n):
    r = list(csv.DictReader(open(D + 'scene/tracks/' + n + '.csv')))
    return np.array([[float(x['frame']), float(x['cx_px']), float(x['cy_px'])] for x in r])
van, cyc = load('van'), load('cyclist')
# cyclist constant speed: linear fit over frames 2..71
m = cyc[:, 0] >= 2
px = np.polyfit(cyc[m, 0], cyc[m, 1], 1); py = np.polyfit(cyc[m, 0], cyc[m, 2], 1)
v_pf = np.hypot(px[0], py[0])
print('cyclist px/frame', v_pf, 'resid rms', np.std(cyc[m, 2] - np.polyval(py, cyc[m, 0])))
# also bbox-centre based speed (top of bbox / bottom)
scale = 5.33 / (v_pf * 24)
print('m/px', scale)
i = 24
dv = van[i, 1:] - cyc[i, 1:]
print('centroid gap px', dv, np.hypot(*dv), 'm', np.hypot(*dv) * scale)
# smoothed positions at frame 24: local fits
for arr, deg, nm in [(van, 2, 'van'), (cyc, 1, 'cyc')]:
    w = (arr[:, 0] >= i - 5) & (arr[:, 0] <= i + 5)
    print(nm, 'smoothed y', np.polyval(np.polyfit(arr[w, 0], arr[w, 2], deg), i))

# independent mask at frame 24: diff vs clean background (frame 71 bottom region for van/cyc at frame 24)
c = av.open(D + 'simulation_0073.mp4')
fr = {}
for k, f in enumerate(c.decode(video=0)):
    if k in (0, 24, 71): fr[k] = cv2.cvtColor(f.to_ndarray(format='rgb24'), cv2.COLOR_RGB2GRAY).astype(int)
    if k > 71: break
bg = fr[71]  # at frame 71 both objects are at y~200, so y>400 is clean
d = np.abs(fr[24] - bg) > 22
d[:400] = False
d = cv2.morphologyEx(d.astype(np.uint8), cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8))
n, lab, st, cen = cv2.connectedComponentsWithStats(d)
for j in range(1, n):
    if st[j, 4] > 100: print('blob', st[j], cen[j])
