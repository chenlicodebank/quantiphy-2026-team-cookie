import os, av, numpy as np, cv2
os.makedirs('frames', exist_ok=True)
want = {0, 1, 17, 33, 49, 50, 20, 42}
frames = {}
bgs = []
c = av.open('simulation_0012.mp4')
for i, f in enumerate(c.decode(video=0)):
    img = f.to_ndarray(format='bgr24')
    if i % 6 == 0:
        bgs.append(img[850:1400].copy())
    if i in want:
        frames[i] = img[850:1400].copy()
bg = np.median(np.stack(bgs), axis=0).astype(np.int16)
for i in sorted(frames):
    im = frames[i].astype(np.int16)
    d = np.abs(im - bg).max(axis=2)
    gb = im[..., 1] - im[..., 0]
    m = ((d > 25) & (gb < 18)).astype(np.uint8)
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8))
    n, lab, st, cen = cv2.connectedComponentsWithStats(m)
    k = 1 + np.argmax(st[1:, 4])
    x, y, w, h, a = st[k]
    print(i, 'bbox x', x, x + w, 'y', y + 850, y + h + 850, 'w', w, 'h', h, 'area', a)
    vis = frames[i].copy()
    vis[lab == k] = (0, 0, 255)
    cv2.rectangle(vis, (x, y), (x + w, y + h), (255, 255, 0), 1)
    cx = x + w // 2
    crop = vis[max(0, y - 30):y + h + 30, max(0, cx - 200):cx + 200]
    cv2.imwrite(f'frames/m{i}.png', cv2.resize(crop, None, fx=2, fy=2))
