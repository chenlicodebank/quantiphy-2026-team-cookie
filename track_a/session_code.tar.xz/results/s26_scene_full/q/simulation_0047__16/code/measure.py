import av, numpy as np, csv
# pedestrian speed in px/s
rows = list(csv.DictReader(open('scene/tracks/pedestrian.csv')))
x = np.array([float(r['ref_x']) for r in rows]); y = np.array([float(r['ref_y']) for r in rows])
f = np.array([int(float(r['frame'])) for r in rows]) if 'frame' in rows[0] else np.arange(len(rows))
d = np.hypot(np.diff(x), np.diff(y))
print('n', len(x), 'mean step', d.mean(), 'net/frames', np.hypot(x[-1]-x[0], y[-1]-y[0])/(len(x)-1))
px = np.polyfit(np.arange(len(x)), x, 1)[0]; py = np.polyfit(np.arange(len(x)), y, 1)[0]
print('linear fit step', np.hypot(px, py))
# smoothed path (5-frame) mean step
k = 5; xs = np.convolve(x, np.ones(k)/k, 'valid'); ys = np.convolve(y, np.ones(k)/k, 'valid')
print('smoothed mean step', np.hypot(np.diff(xs), np.diff(ys)).mean())

# planter column profile: frame 0
c = av.open('simulation_0047.mp4')
for i, fr in enumerate(c.decode(video=0)):
    img = fr.to_ndarray(format='rgb24').astype(float); break
band = img[215:245, 1100:1430]
g = band[:, :, 1] - (band[:, :, 0] + band[:, :, 2]) / 2  # greenness
col = g.mean(0)
for xx in list(range(10, 60, 2)) + list(range(270, 330, 2)):
    print(1100+xx, round(col[xx], 1), round(band[:, xx].mean(), 1))
