import av, numpy as np, cv2
D = '/private/tmp/qp_blind/scene_full_b/simulation_0081/q_87/'
c = av.open(D + 'simulation_0081.mp4')
tiles = []
for i, f in enumerate(c.decode(video=0)):
    if i in (12, 14, 16, 18, 20, 22, 24, 26, 28):
        img = f.to_ndarray(format='bgr24')[360:520, 220:620].copy()
        img = cv2.resize(img, None, fx=2, fy=2, interpolation=cv2.INTER_NEAREST)
        for x in range(0, 400, 20):
            cv2.line(img, (2 * x, 0), (2 * x, 319), (0, 255, 255) if x % 100 else (0, 0, 255), 1)
        cv2.putText(img, str(i), (5, 25), 0, 0.8, (0, 0, 255), 2)
        tiles.append(img)
rows = [np.hstack(tiles[k:k + 3]) for k in range(0, 9, 3)]
cv2.imwrite(D + 'frames/pedsheet.png', np.vstack(rows))
