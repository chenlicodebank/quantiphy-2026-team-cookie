import av, numpy as np, cv2
c = av.open('/private/tmp/qp_blind/scene_full_b/simulation_0081/q_87/simulation_0081.mp4')
for i, f in enumerate(c.decode(video=0)):
    if i == 24:
        img = f.to_ndarray(format='rgb24'); break
hsv = cv2.cvtColor(img, cv2.COLOR_RGB2HSV)
cy = (hsv[..., 0] >= 80) & (hsv[..., 0] <= 105) & (hsv[..., 1] > 60)
cy[:545] = 0
ys, xs = np.nonzero(cy)
print('bike x', xs.min(), xs.max(), 'y', ys.min(), ys.max(), 'len', xs.max() - xs.min() + 1)
band = cy[630:650]; cols = np.nonzero(band.any(0))[0]; print('band cols', cols.min(), cols.max())
reg = img[350:540, 250:600].astype(int)
g = reg.mean(2); white = (g > 185) & (reg.std(2) < 12)
ys, xs = np.nonzero(white)
print('shirt centroid', xs.mean() + 250, ys.mean() + 350, 'bbox', xs.min() + 250, xs.max() + 250, ys.min() + 350, ys.max() + 350, len(xs))
