import csv, numpy as np, av
car = list(csv.DictReader(open('scene/tracks/car.csv')))
pl = list(csv.DictReader(open('scene/tracks/airplane.csv')))
f = np.array([float(r['frame']) for r in car]); x = np.array([float(r['cx_centroid']) for r in car])
xb = np.array([float(r['cx_bbox']) for r in car])
for name, xx in [('centroid', x), ('bbox', xb)]:
    for lo in [1, 5, 10]:
        m = f >= lo
        c = np.polyfit(f[m], xx[m], 2)
        print(name, 'from', lo, 'accel px/s^2', 2*c[0]*576, c)
d = np.diff(x); print('per-frame dx', np.round(d, 2))
# second-difference over long baselines
print('plane heights', [(r['frame'], r['height_px'], r['y0'], r['y1']) for r in pl][15:40])

# independent re-segmentation of plane height on a few frames
cont = av.open('simulation_0097.mp4')
for i, fr in enumerate(cont.decode(video=0)):
    if i in (20, 28, 35):
        a = fr.to_ndarray(format='rgb24').astype(int)
        bg = np.median(a.reshape(-1, 3), 0)
        diff = np.abs(a - bg).max(2)
        for thr in (4, 6, 10):
            ys = np.where((diff[:545] > thr).sum(1) > 2)[0]
            xs = np.where((diff[:545] > thr).sum(0) > 2)[0]
            print(i, thr, 'y', ys.min(), ys.max(), ys.max()-ys.min()+1, 'x', xs.min(), xs.max(), xs.max()-xs.min()+1)
        m = diff[545:] > 6
        ys = np.where(m.sum(1) > 2)[0] + 545; xs = np.where(m.sum(0) > 2)[0]
        print(' car', ys.min(), ys.max(), xs.min(), xs.max())
