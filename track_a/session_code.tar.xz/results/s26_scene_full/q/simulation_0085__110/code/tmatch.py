import av, numpy as np, cv2
V='/private/tmp/qp_blind/scene_full_a/simulation_0085/q_110/simulation_0085.mp4'
G=[]
c=av.open(V)
for fr in c.decode(video=0):
    G.append(cv2.cvtColor(fr.to_ndarray(format='rgb24'),cv2.COLOR_RGB2GRAY)[560:900].astype(np.float32))
G=np.array(G)  # 72x340x1920 floats ~ 190MB? reduce
# templates from frame 52 (bbox 646..1368): front patch and rear patch
ref=52
patches={'front':(690,960),'mid':(900,1150),'rear':(1100,1360)}
res={}
for name,(a,b) in patches.items():
    T=G[ref][:, a:b]
    xs=[]
    for i in range(72):
        R=cv2.matchTemplate(G[i],T,cv2.TM_CCOEFF_NORMED)[0]
        k=int(np.argmax(R)); s=R[k]
        if 0<k<len(R)-1:
            d=(R[k-1]-R[k+1])/(2*(R[k-1]-2*R[k]+R[k+1]))
        else: d=0
        xs.append((k+d+a*0, s))
    xs=np.array(xs); res[name]=xs
np.save('/private/tmp/qp_blind/scene_full_a/simulation_0085/q_110/tm.npy',np.stack([res[k] for k in patches]))
for i in range(72):
    print(i,' '.join('%8.2f(%.3f)'%(res[k][i,0],res[k][i,1]) for k in patches))
