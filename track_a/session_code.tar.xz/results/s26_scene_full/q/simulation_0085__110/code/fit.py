import csv, numpy as np
D='/private/tmp/qp_blind/scene_full_a/simulation_0085/q_110/scene/tracks/'
r=list(csv.DictReader(open(D+'car.csv')))
f=np.array([int(x['frame']) for x in r]); x0=np.array([float(x['bbox_x0']) for x in r]); x1=np.array([float(x['bbox_x1']) for x in r])
print('front dx', np.diff(x0)[:64])
print('rear dx', np.diff(x1)[39:])
for lo,hi in [(3,63),(10,63),(20,63),(3,40),(30,63)]:
    m=(f>=lo)&(f<=hi); p=np.polyfit(f[m],x0[m],2); print('front',lo,hi,'a px/f2',2*p[0], 'resid',np.std(x0[m]-np.polyval(p,f[m])))
for lo,hi in [(40,63),(40,66),(40,70)]:
    m=(f>=lo)&(f<=hi); p=np.polyfit(f[m],x1[m],2); print('rear',lo,hi,'a',2*p[0],'resid',np.std(x1[m]-np.polyval(p,f[m])))
m=(f>=40)&(f<=63); p=np.polyfit(f[m],(x0[m]+x1[m])/2,2); print('centre a',2*p[0])
c=list(csv.DictReader(open(D+'cyclist.csv'))); print(c[0].keys())
for x in c[4:68:6]: print(x['frame'],x['bbox_x0'],x['bbox_x1'],x['length_px'],x['width_px'])
pc=list(csv.DictReader(open(D+'cyclist_parts.csv'))); print(pc[0].keys())
for x in pc[4:68:6]: print({k:x[k] for k in list(x)[:10]})
