import csv, numpy as np
D='/private/tmp/qp_blind/scene_full_a/simulation_0085/q_110/scene/tracks/'
r=[x for x in csv.DictReader(open(D+'cyclist_parts.csv')) if 5<=int(x['frame'])<=66]
b=np.array([float(x['bike_cx']) for x in r]); rc=np.array([float(x['rider_cx']) for x in r])
by=np.array([float(x['bike_cy']) for x in r]); ry=np.array([float(x['rider_cy']) for x in r])
p=np.polyfit(b-960,rc-b,1); print('rider-bike dx vs u slope',p, 'dy',np.mean(ry-by))
