import av, numpy as np
V='/private/tmp/qp_blind/scene_full_a/simulation_0085/q_110/simulation_0085.mp4'
c=av.open(V)
for i,fr in enumerate(c.decode(video=0)):
    if i not in (40,52): continue
    im=fr.to_ndarray(format='rgb24')[360:410].astype(float)
    s=(im[:,:,1]+im[:,:,2])/2-im[:,:,0]
    g=im.mean(2)
    prof=s.max(0); r=np.argmax(s,0)
    lo=int(np.where(prof>20)[0][0]); hi=int(np.where(prof>20)[0][-1])
    print('frame',i)
    for x in list(range(lo-6,lo+10))+[None]+list(range(hi-10,hi+7)):
        if x is None: print('...'); continue
        col=im[:,x]; print(x,'sat %.0f row %d'%(prof[x],r[x]+360),'minGrey %.0f'%g[:,x].min(), 'rgb@row',col[r[x]].astype(int))
