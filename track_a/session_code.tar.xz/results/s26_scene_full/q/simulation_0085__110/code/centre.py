import numpy as np
A=np.loadtxt('/private/tmp/qp_blind/scene_full_a/simulation_0085/q_110/car_edges.txt')
f=np.arange(len(A)); c=(A[:,0]+A[:,1])/2
m=(f>=40)&(f<=63)
v=np.diff(c)
for i in range(40,64): print(i,'%.2f'%c[i],'%.2f'%v[i-1])
for lo,hi in [(40,63),(40,51),(52,63)]:
    mm=(f>=lo)&(f<=hi); p=np.polyfit(f[mm],c[mm],2); print(lo,hi,'a=%.4f'%(2*p[0]),'resid %.2f'%np.std(c[mm]-np.polyval(p,f[mm])))
p=np.polyfit(f[m],c[m],3); print('cubic',p)
# front edge early 3..30 fit
for lo,hi in [(2,20),(2,38),(20,38)]:
    mm=(f>=lo)&(f<=hi); p=np.polyfit(f[mm],A[mm,0],2); print('front',lo,hi,'a=%.4f'%(2*p[0]))
for lo,hi in [(64,71),(58,71)]:
    mm=(f>=lo)&(f<=hi); p=np.polyfit(f[mm],A[mm,1],2); print('rear',lo,hi,'a=%.4f'%(2*p[0]))
# cyclist
cc=(A[:,2]+A[:,3])/2; mm=(f>=5)&(f<=63); print('cyc v',np.polyfit(f[mm],cc[mm],1)[0], 'len',np.median(A[mm,3]-A[mm,2]))
