import numpy as np
T=np.load('/private/tmp/qp_blind/scene_full_a/simulation_0085/q_110/tm.npy')
names=['front','mid','rear']; rng={'front':(25,64),'mid':(33,67),'rear':(39,70)}
f=np.arange(72)
for k,n in enumerate(names):
    lo,hi=rng[n]; x=T[k,:,0]; m=(f>=lo)&(f<=hi)
    v=-np.diff(x)
    print(n,' '.join('%d:%.2f'%(i,v[i-1]) for i in range(lo+1,hi+1)))
    p=np.polyfit(f[m],x[m],2); print('  quad a=%.4f resid %.2f'%(-2*p[0],np.std(x[m]-np.polyval(p,f[m]))))
    for a,b in [(lo,52),(45,58),(52,hi)]:
        mm=(f>=a)&(f<=b); p=np.polyfit(f[mm],x[mm],2); print('   ',a,b,'a=%.4f'%(-2*p[0]))
