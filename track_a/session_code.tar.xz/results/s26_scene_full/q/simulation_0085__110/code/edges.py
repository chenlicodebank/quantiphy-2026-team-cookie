import av, numpy as np
V='/private/tmp/qp_blind/scene_full_a/simulation_0085/q_110/simulation_0085.mp4'
# subpixel front/rear edge of car along rows y 690..765 (body centre band), and of bike along y 375..390
def sub_edges(row, thr_dev=45, bg=140.0):
    d=np.abs(row-bg)
    idx=np.where(d>thr_dev)[0]
    if len(idx)==0: return np.nan,np.nan
    i0,i1=idx[0],idx[-1]
    # interpolate crossing at thr_dev
    def cross(a,b):  # a outside, b inside
        da,db=d[a],d[b]; return a+(thr_dev-da)/(db-da)*(b-a)
    x0=cross(i0-1,i0) if i0>0 else np.nan
    x1=cross(i1+1,i1) if i1<len(row)-1 else np.nan
    return x0,x1
F=[];C=[]
c=av.open(V)
for i,fr in enumerate(c.decode(video=0)):
    g=fr.to_ndarray(format='rgb24').astype(float).mean(2)
    band=g[700:756]
    e=[sub_edges(band[k]) for k in range(0,56,4)]
    e=np.array(e); F.append(np.nanmedian(e,0))
    bb=g[370:395]
    e=np.array([sub_edges(bb[k]) for k in range(25)]); C.append((np.nanmin(e[:,0]),np.nanmax(e[:,1])))
F=np.array(F);C=np.array(C)
np.savetxt('/private/tmp/qp_blind/scene_full_a/simulation_0085/q_110/car_edges.txt',np.c_[F,C],fmt='%.2f')
f=np.arange(len(F))
dx0=np.diff(F[:,0]); dx1=np.diff(F[:,1])
for i in range(1,len(F)): print(i,'%.2f %.2f'%(dx0[i-1],dx1[i-1]),'%.1f %.1f'%(F[i,0],F[i,1]),'len %.1f'%(F[i,1]-F[i,0]),'cyc %.1f %.1f'%tuple(C[i]))
