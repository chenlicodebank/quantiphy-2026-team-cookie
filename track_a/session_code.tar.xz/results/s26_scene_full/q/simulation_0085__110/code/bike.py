import av, numpy as np
V='/private/tmp/qp_blind/scene_full_a/simulation_0085/q_110/simulation_0085.mp4'
c=av.open(V)
out=[]
for i,fr in enumerate(c.decode(video=0)):
    if i<5 or i>66: continue
    im=fr.to_ndarray(format='rgb24')[360:410].astype(float)
    # saturation-like signal: (G+B)/2 - R  (teal); background ~0
    s=(im[:,:,1]+im[:,:,2])/2-im[:,:,0]
    prof=s.max(0)  # max over rows
    pk=np.percentile(prof[prof>20],90) if (prof>20).any() else 0
    res=[]
    for frac in (0.3,0.5):
        th=frac*pk
        idx=np.where(prof>th)[0]; a,b=idx[0],idx[-1]
        x0=a-1+(th-prof[a-1])/(prof[a]-prof[a-1]); x1=b+(prof[b]-th)/(prof[b]-prof[b+1])
        res+= [x0,x1,x1-x0]
    # also any-deviation from bg grey (dark tyres/rider) at 50% of 45
    g=np.abs(im.mean(2)-140).max(0); idx=np.where(g>25)[0]
    out.append((i,*res,idx[-1]-idx[0]+1,pk))
    print(i,'sat30: %.1f %.1f L=%.2f  sat50: %.1f %.1f L=%.2f  grey25 L=%d pk=%.0f'%tuple(out[-1][1:]))
o=np.array(out)
for lo,hi in [(5,66),(25,50)]:
    m=(o[:,0]>=lo)&(o[:,0]<=hi); print(lo,hi,'median L sat30 %.2f sat50 %.2f grey %.1f'%(np.median(o[m,3]),np.median(o[m,6]),np.median(o[m,7])))
