import csv, numpy as np
r = list(csv.DictReader(open('scene/tracks/car.csv')))
print(list(r[0].keys()))
for x in r[::6]:
    print({k: x[k] for k in ('frame', 'cy', 'bbox_h', 'mask_len', 'note') if k in x})
f = np.array([int(x['frame']) for x in r]); cy = np.array([float(x['cy']) for x in r])
t = f / 24
for a, b in [(3, 71), (6, 71), (3, 40), (40, 71), (20, 60), (5, 36)]:
    m = (f >= a) & (f <= b); p = np.polyfit(t[m], cy[m], 2); res = cy[m] - np.polyval(p, t[m])
    print(a, b, 'acc px/s2 %.2f' % (2 * p[0]), 'v0', p[1], 'rms %.2f' % res.std())
m = f >= 3; p = np.polyfit(t[m], cy[m], 3); print('cubic', p)
d = np.diff(cy) * 24
print('speeds', np.round(d, 1))
