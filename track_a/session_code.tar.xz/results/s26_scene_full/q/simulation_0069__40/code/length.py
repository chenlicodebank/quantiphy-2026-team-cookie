import av, numpy as np
c = av.open('simulation_0069.mp4')
want = {0, 30, 60}
for i, fr in enumerate(c.decode(video=0)):
    if i in want:
        g = fr.to_ndarray(format='gray').astype(float)
        road = np.median(g[100:1000, 700])  # road grey near car, check
        for x in (812, 832, 852):
            col = g[:, x]
            bright = np.where(col > 200)[0]
            # largest contiguous run
            runs = np.split(bright, np.where(np.diff(bright) > 3)[0] + 1)
            run = max(runs, key=len)
            # sub-pixel half-max edges
            lo, hi = run[0], run[-1]
            bg = np.median(col[max(lo - 40, 0):lo - 10])
            fg = np.median(col[lo:hi])
            h = (bg + fg) / 2
            def edge(a, b):
                return a + (h - col[a]) / (col[b] - col[a])
            top = edge(lo - 1, lo) if col[lo - 1] < h else lo
            bot = edge(hi, hi + 1) if col[hi + 1] < h else hi
            print(i, x, 'run', lo, hi, 'len %.1f' % (bot - top), 'bg', bg, 'fg', fg)
    if i > max(want):
        break
