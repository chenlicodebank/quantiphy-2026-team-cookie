import av, numpy as np
c = av.open('simulation_0069.mp4')
for i, fr in enumerate(c.decode(video=0)):
    if i == 0:
        g = fr.to_ndarray(format='gray').astype(float)
        for x in (812, 832, 852):
            print(x, 'top', g[800:825, x].astype(int).tolist())
            print(x, 'bot', g[1036:1056, x].astype(int).tolist())
        # front edge: first y where row-mean over x 800-865 exceeds half between road and car
        prof = g[780:1080, 800:866].mean(1)
        print('rowmean', np.round(prof[20:45]).astype(int).tolist(), np.round(prof[255:280]).astype(int).tolist())
        break
