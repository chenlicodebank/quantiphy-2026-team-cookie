import av, numpy as np, cv2
P = '/private/tmp/qp_blind/scene_full_b/simulation_0111/q_225/simulation_0111.mp4'
want = {5, 20, 24, 40, 60, 205, 210}
frames = {}
with av.open(P) as c:
    for i, f in enumerate(c.decode(video=0)):
        if i in want:
            frames[i] = cv2.cvtColor(f.to_ndarray(format='rgb24'), cv2.COLOR_RGB2GRAY).astype(float)
        if i > max(want): break

# width: per-row horizontal extent of bright hull, max over rows
for i in sorted(frames):
    g = frames[i]
    sub = g[:, 540:730]
    bright = sub > 90
    widths = []
    yc = int(5.4961 * i + 273.78)
    for r in range(yc - 110, yc + 110):
        xs = np.where(bright[r])[0]
        if len(xs) > 10 and xs[0] > 5 and xs[-1] < 184:
            widths.append((xs[-1] - xs[0] + 1, r))
    if widths:
        w = max(widths)
        # subpixel: half-max crossings on the widest row neighbourhood
        r = w[1]
        prof = sub[r-2:r+3].mean(0)
        bg = np.median(prof[:30]); pk = np.percentile(prof, 95)
        th = (bg + pk) / 2
        xs = np.where(prof > th)[0]
        a, b = xs[0], xs[-1]
        al = a - 1 + (th - prof[a-1]) / (prof[a] - prof[a-1])
        br = b + (prof[b] - th) / (prof[b] - prof[b+1])
        print(i, 'max row width', w, 'halfmax width %.2f' % (br - al), 'bg %.0f pk %.0f' % (bg, pk))

# speed: template match boat between frame 5 and 60, and 205 and 210
def shift(a, b, box):
    x0, y0, x1, y1 = box
    t = frames[a][y0:y1, x0:x1].astype(np.float32)
    res = cv2.matchTemplate(frames[b].astype(np.float32), t, cv2.TM_CCOEFF_NORMED)
    _, m, _, loc = cv2.minMaxLoc(res)
    yy, xx = loc[1], loc[0]
    # subpixel parabola in y
    if 0 < yy < res.shape[0]-1:
        c0, c1, c2 = res[yy-1, xx], res[yy, xx], res[yy+1, xx]
        yy = yy + 0.5 * (c0 - c2) / (c0 - 2*c1 + c2)
    return yy - y0, xx - x0, m
for a, b in [(5, 60), (20, 60), (5, 40), (205, 210)]:
    # boat bbox from track: y0 ~ 5.5*f+150
    yc = 5.4961 * a + 273.78
    box = (580, int(yc - 115), 685, int(yc + 115))
    dy, dx, m = shift(a, b, box)
    print(a, b, 'dy %.2f dx %d corr %.3f -> px/frame %.4f' % (dy, dx, m, dy / (b - a)))
