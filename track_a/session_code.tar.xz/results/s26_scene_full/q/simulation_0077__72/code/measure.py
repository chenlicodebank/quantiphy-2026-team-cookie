import csv, os, numpy as np
os.chdir(os.path.dirname(os.path.abspath(__file__)))
def load(n):
    r=list(csv.DictReader(open(f'scene/tracks/{n}.csv')))
    return {int(x['frame']):x for x in r}
B=load('person_black'); W=load('person_white')
def p(d,i,k): return np.array([float(d[i][k+'_x']),float(d[i][k+'_y'])])
for k in ['torso','mask','head']:
    try:
        sp=[np.linalg.norm(p(B,i,k)-p(B,i-1,k)) for i in range(3,72)]
        spw=[np.linalg.norm(p(W,i,k)-p(W,i-1,k)) for i in range(3,60)]
        d48=np.linalg.norm(p(B,48,k)-p(W,48,k))
        s=np.mean(sp); print(k,'black step',s,np.median(sp),'white step',np.mean(spw),'d48 px',d48,'m',d48/(s*24))
        print('  sp around 48', [round(x,2) for x in sp[40:50]])
    except Exception as e: print(k,e)
print(B[48]['torso_x'],B[48]['torso_y'],W[48]['torso_x'],W[48]['torso_y'])
