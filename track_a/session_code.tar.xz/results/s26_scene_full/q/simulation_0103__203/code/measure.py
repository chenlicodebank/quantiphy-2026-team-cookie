import csv, numpy as np, cv2, av
r = list(csv.DictReader(open('scene/tracks/shark.csv')))
f = np.array([int(x['frame']) for x in r]); cx = np.array([float(x['cx']) for x in r])
x0 = np.array([float(x['x0']) for x in r])
for lo in (1, 2, 5):
    m = f >= lo
    p = np.polyfit(f[m], cx[m], 2); q = np.polyfit(f[m], x0[m], 2)
    print('fit from', lo, 'centroid a px/fr2', 2*p[0], 'nose x0 a', 2*q[0])

# independent: template-match shark head region (nose + front body, rigid) per frame
cont = av.open('simulation_0103.mp4'); frames = []
for fr in cont.decode(video=0):
    g = fr.to_ndarray(format='bgr24')[820:990].copy(); frames.append(g)
cont.close()
# template: front 120 px of shark at frame 30
x0_30 = int(x0[30]); tpl = frames[30][:, x0_30-5:x0_30+120]
pos = []
for i, g in enumerate(frames):
    res = cv2.matchTemplate(g, tpl, cv2.TM_CCOEFF_NORMED)
    _, mv, _, ml = cv2.minMaxLoc(res)
    x, y = ml
    # subpixel parabola
    if 0 < x < res.shape[1]-1:
        a, b, c = res[y, x-1], res[y, x], res[y, x+1]; x = x + 0.5*(a-c)/(a-2*b+c)
    pos.append(x)
pos = np.array(pos)
print('tm steps', np.round(np.diff(pos), 2))
for lo in (1, 2, 5):
    m = f >= lo; p = np.polyfit(f[m], pos[m], 2)
    print('tm fit from', lo, 'a', 2*p[0], 'resid std', np.std(pos[m]-np.polyval(p, f[m])))

b = list(csv.DictReader(open('scene/tracks/boat.csv')))
bx = np.array([float(x['bow_x_sub']) for x in b])
print('boat steps', np.round(np.diff(bx), 2))
print('boat step 23->24', bx[24]-bx[23], 'mean 10..40', np.mean(np.diff(bx)[10:40]))
p = np.polyfit(f[2:], bx[2:], 2); print('boat quad a', 2*p[0], 'v24', 2*p[0]*23.5+p[1])
