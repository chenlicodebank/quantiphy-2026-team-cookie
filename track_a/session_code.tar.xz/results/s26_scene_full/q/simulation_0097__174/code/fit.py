import csv, numpy as np
def load(n):
    r=list(csv.DictReader(open(f'scene/tracks/{n}.csv')))
    return r
car=load('car'); pl=load('airplane')
f=np.array([float(r['frame']) for r in car]); x=np.array([float(r['cx_centroid']) for r in car]); xb=np.array([float(r['cx_bbox']) for r in car])
print(np.round(np.diff(x),2))
for lo in [0,1,2,5]:
    m=f>=lo
    for xx,nm in [(x,'cent'),(xb,'bbox')]:
        c=np.polyfit(f[m],xx[m],2); res=xx[m]-np.polyval(c,f[m])
        print(lo,nm,'a px/f2',2*c[0],'resid',res.std())
# second differences
d2=np.diff(x,2); print('mean d2 from f1',d2[1:].mean(), np.median(d2[1:]))
fp=np.array([float(r['frame']) for r in pl]);
for col in ['x1','x0','cx_est']:
    v=np.array([float(r[col]) for r in pl])
    for msk,nm in [((fp>=3)&(fp<=38),'nose-ok' ),((fp>=18)&(fp<=40),'tail-ok'),((fp>=18)&(fp<=38),'full')]:
        c=np.polyfit(fp[msk],v[msk],1); print(col,nm,c[0])
    print(col,'at f6-8',v[(fp>=6)&(fp<=8)])
