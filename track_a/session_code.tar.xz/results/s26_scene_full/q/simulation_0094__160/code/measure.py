import av, numpy as np
c = av.open('simulation_0094.mp4')
bg = np.array([78, 79, 86], float)
rows = []
for i, fr in enumerate(c.decode(video=0)):
    a = fr.to_ndarray(format='rgb24').astype(float)
    sub = a[590:, :, :]
    m = np.abs(sub - bg).sum(2) > 20
    xs = np.where(m.any(0))[0]
    ys = np.where(m.any(1))[0]
    if len(xs) == 0:
        continue
    # column-weighted centroid
    yy, xx = np.nonzero(m)
    rows.append((i, xs[0], xs[-1], ys[0] + 590, ys[-1] + 590, xx.mean()))
rows = np.array(rows, float)
for r in rows:
    print(int(r[0]), r[1:].tolist(), 'L', r[2] - r[1] + 1)
ok = (rows[:, 1] > 0) & (rows[:, 2] < 1919)
f = rows[ok, 0]
for k, n in [(1, 'x0'), (2, 'x1'), (5, 'centroid')]:
    print(n, 'slope px/frame', np.polyfit(f, rows[ok, k], 1)[0])
ctr = (rows[ok, 1] + rows[ok, 2]) / 2
print('ctr slope', np.polyfit(f, ctr, 1)[0])
# late frames slope (near centre)
s = f >= 25
print('ctr slope f>=25', np.polyfit(f[s], ctr[s], 1)[0], 'centroid', np.polyfit(f[s], rows[ok, 5][s], 1)[0])
L = rows[ok, 2] - rows[ok, 1] + 1
print('L late mean', L[s].mean())
