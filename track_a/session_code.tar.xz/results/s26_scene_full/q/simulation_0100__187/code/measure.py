import av, numpy as np
c = av.open('/private/tmp/qp_blind/scene_full_b/simulation_0100/q_187/simulation_0100.mp4')
fr = {}
for i, f in enumerate(c.decode(video=0)):
    if i in (2, 21, 22, 23, 24, 25, 30, 40, 57):
        fr[i] = f.to_ndarray(format='rgb24').astype(float)

def edges(img, rows):
    lo, hi = [], []
    for y in rows:
        r = img[y, :, 0]; g = img[y, :, 1]
        m = np.where((r - g) > 60)[0]
        if len(m):
            lo.append(m.min()); hi.append(m.max())
    return np.array(lo), np.array(hi)

for i in sorted(fr):
    lo, hi = edges(fr[i], range(460, 540))
    print(i, 'bow mean', hi.mean(), 'stern min', lo.min(), 'len', hi.max() - lo.min())
b = {i: edges(fr[i], range(460, 540))[1].mean() for i in fr}
print('step 23->24', b[24] - b[23], 'step 24->25', b[25] - b[24])
print('avg 2->57', (b[57] - b[2]) / 55, 'avg 21->57', (b[57] - b[21]) / 36)
