import av, numpy as np
# clean-plate difference: frame 25 vs frame 57 (shark regions do not overlap)
c = av.open('simulation_0100.mp4')
F = {}
for i, f in enumerate(c.decode(video=0)):
    if i in (25, 57):
        F[i] = f.to_ndarray(format='rgb24').astype(int)
d = np.abs(F[57] - F[25]).sum(2)[700:1075]
for name, xs in (('f57', slice(880, 1230)), ('f25', slice(1230, 1600))):
    sub = d[:, xs]
    off = xs.start
    print(name)
    for th in (8, 12, 16, 20, 30, 45, 60):
        cols = np.nonzero((sub > th).sum(0) >= 2)[0]
        # keep longest contiguous run
        runs = np.split(cols, np.nonzero(np.diff(cols) > 3)[0] + 1)
        r = max(runs, key=len)
        print(' th', th, 'x', r[0] + off, r[-1] + off, 'len', r[-1] - r[0] + 1)
    for y in (892, 898, 904, 910, 916, 922, 928):
        x0 = 915 if name == 'f57' else 1250
        print(y, ' '.join('%3d' % v for v in d[y - 700, x0:x0 + 30]))
