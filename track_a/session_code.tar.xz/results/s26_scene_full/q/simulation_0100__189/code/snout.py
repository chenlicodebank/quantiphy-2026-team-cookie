import av, numpy as np
c = av.open('simulation_0100.mp4')
for i, f in enumerate(c.decode(video=0)):
    if i in (25, 57):
        a = f.to_ndarray(format='rgb24').astype(int)
        x0 = 915 if i == 57 else 1250
        bg = np.median(a[700:1075], axis=1)
        print('frame', i)
        for y in range(880, 960, 6):
            d = np.abs(a[y, x0:x0 + 40] - bg[y - 700]).sum(1)
            print(y, ' '.join('%3d' % v for v in d))
        # tail side
        xt = 1185 if i == 57 else 1528
        for y in range(860, 915, 6):
            d = np.abs(a[y, xt:xt + 20] - bg[y - 700]).sum(1)
            print('tail', y, ' '.join('%3d' % v for v in d))
