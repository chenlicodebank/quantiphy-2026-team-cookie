import av, numpy as np
import cv2
c = av.open('simulation_0100.mp4')
frames = {}
for i, f in enumerate(c.decode(video=0)):
    if i in (0, 25, 40, 57):
        frames[i] = f.to_ndarray(format='rgb24').astype(int)
# shark: underwater panel rows 700-1079, deviation from per-row median background
for i in (25, 40, 57):
    a = frames[i][700:1075]
    bg = np.median(a, axis=1, keepdims=True)
    d = np.abs(a - bg).sum(2)
    for th in (30, 60, 100):
        m = d > th
        n, lab, st, _ = cv2.connectedComponentsWithStats(m.astype(np.uint8))
        k = 1 + np.argmax(st[1:, 4])
        ys, xs = np.nonzero(lab == k)
        print('shark f', i, 'th', th, 'x', xs.min(), xs.max(), 'len', xs.max() - xs.min() + 1, 'y', ys.min() + 700, ys.max() + 700)
# boat at frame 57: rows 230-560 (above water), deviation from column-0 sky per row
a = frames[57][230:565]
bg = np.median(a[:, :300], axis=1, keepdims=True)
d = np.abs(a - bg).sum(2)
for th in (30, 60, 100):
    m = d > th
    cols = np.nonzero(m.sum(0) > 2)[0]
    print('boat th', th, 'x', cols.min(), cols.max(), 'len', cols.max() - cols.min() + 1)
# hull per row extents
for y in (420, 470, 500, 530, 560, 600, 630):
    r = frames[57][y]
    bgc = np.median(frames[57][y, :300], axis=0)
    dd = np.abs(r - bgc).sum(1)
    xs = np.nonzero(dd > 60)[0]
    if len(xs):
        print('row', y, xs.min(), xs.max())
