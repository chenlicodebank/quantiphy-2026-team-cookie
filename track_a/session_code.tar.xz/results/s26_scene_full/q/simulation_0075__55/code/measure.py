import av, numpy as np
def frames(idx):
    out={}
    with av.open('simulation_0075.mp4') as c:
        for i,f in enumerate(c.decode(video=0)):
            if i in idx: out[i]=f.to_ndarray(format='rgb24').astype(int)
            if i>=max(idx): break
    return out
F=frames({0,71})
def extent(img,bg,x0,x1,y0,y1,axis,thr,frac=0.3):
    d=np.abs(img[y0:y1,x0:x1]-bg[y0:y1,x0:x1]).max(2)>thr
    prof=d.mean(axis=1 if axis=='y' else 0)
    idx=np.where(prof>frac)[0]
    return idx[-1]-idx[0]+1, idx[0]+(y0 if axis=='y' else x0)
cases={'van_f0':(0,71,770,900,760,1080,'y'),'tan_f0':(0,71,930,1050,700,1000,'y'),
       'van_f71':(71,0,770,900,40,360,'y'),'tan_f71':(71,0,1230,1520,580,690,'x')}
for thr in (12,20,25,35):
    for frac in (0.15,0.3,0.5):
        r={k:extent(F[a],F[b],x0,x1,y0,y1,ax,thr,frac) for k,(a,b,x0,x1,y0,y1,ax) in cases.items()}
        L={k:v[0] for k,v in r.items()}
        print(thr,frac,r, 'ratio f0 %.4f f71 %.4f'%(L['tan_f0']/L['van_f0'],L['tan_f71']/L['van_f71']))
