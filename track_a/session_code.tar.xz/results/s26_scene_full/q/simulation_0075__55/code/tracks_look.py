import csv
for name in ('white_van','tan_car'):
    rows=list(csv.DictReader(open(f'scene/tracks/{name}.csv')))
    print(name, list(rows[0].keys()))
    for r in rows[::4]:
        print(r['frame'], r['ref_x'], r['ref_y'], r['length_px'], r['width_px'], r['axis_angle_deg'])
