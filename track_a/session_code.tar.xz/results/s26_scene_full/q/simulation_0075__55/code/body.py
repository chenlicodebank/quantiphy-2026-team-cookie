import av, numpy as np, cv2, csv
# Shadow-free body masks: keep pixels brighter than the background or with changed chroma
# (shadows only darken grey asphalt), fill holes, min-area rect length per frame.
bgs=[]
with av.open('simulation_0075.mp4') as c:
    for i,f in enumerate(c.decode(video=0)):
        if i%3==0: bgs.append(cv2.resize(f.to_ndarray(format='rgb24'),(1080,540),interpolation=cv2.INTER_AREA))
# full-res median background, built in strips to limit memory
def median_bg():
    out=np.zeros((1080,2160,3),np.uint8)
    for y0 in range(0,1080,120):
        strip=[]
        with av.open('simulation_0075.mp4') as c:
            for i,f in enumerate(c.decode(video=0)):
                if i%2==0: strip.append(f.to_ndarray(format='rgb24')[y0:y0+120])
        out[y0:y0+120]=np.median(np.array(strip),0).astype(np.uint8)
    return out
bg=median_bg().astype(float)
tracks={n:{int(r['frame']):r for r in csv.DictReader(open(f'scene/tracks/{n}.csv'))} for n in ('white_van','tan_car')}
def chroma(a):
    s=a.sum(2,keepdims=True)+1e-6; return a/s*255
res={'white_van':[], 'tan_car':[]}
with av.open('simulation_0075.mp4') as c:
    for i,f in enumerate(c.decode(video=0)):
        img=f.to_ndarray(format='rgb24').astype(float)
        for n in res:
            r=tracks[n][i]
            x0,y0,x1,y1=[int(float(r[k])) for k in ('bbox_x0','bbox_y0','bbox_x1','bbox_y1')]
            x0-=15;y0-=15;x1+=15;y1+=15
            x0=max(x0,0);y0=max(y0,0);x1=min(x1,2159);y1=min(y1,1079)
            a=img[y0:y1,x0:x1]; b=bg[y0:y1,x0:x1]
            lum=a.mean(2)-b.mean(2)
            ch=np.abs(chroma(a)-chroma(b)).max(2)
            out={}
            for thr,cthr in ((20,6),(30,10)):
                m=((lum>thr)|(ch>cthr)).astype(np.uint8)
                m=cv2.morphologyEx(m,cv2.MORPH_OPEN,np.ones((3,3),np.uint8))
                m=cv2.morphologyEx(m,cv2.MORPH_CLOSE,np.ones((9,9),np.uint8))
                nlab,lab,st,_=cv2.connectedComponentsWithStats(m)
                k=1+np.argmax(st[1:,4]); m=(lab==k).astype(np.uint8)
                cnts,_=cv2.findContours(m,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_NONE)
                (cx,cy),(w,h),ang=cv2.minAreaRect(cnts[0])
                out[thr]=(max(w,h),min(w,h),cx+x0,cy+y0)
            res[n].append((i,out))
            if i in (0,36,71) and n=='white_van' or i in (0,30,71) and n=='tan_car':
                vis=a.astype(np.uint8).copy(); cnt=cnts[0]
                cv2.drawContours(vis,[cnt],-1,(255,0,0),1)
                cv2.imwrite(f'frames/mask_{n}_{i}.png',cv2.cvtColor(cv2.resize(vis,None,fx=2,fy=2,interpolation=cv2.INTER_NEAREST),cv2.COLOR_RGB2BGR))
for n in res:
    for thr in (20,30):
        L=np.array([o[thr][0] for _,o in res[n]]); W=np.array([o[thr][1] for _,o in res[n]])
        print(n,thr,'L median %.1f  p10 %.1f p90 %.1f  W median %.1f'%(np.median(L),np.percentile(L,10),np.percentile(L,90),np.median(W)))
        print('   ',' '.join('%d:%.0f'%(i,o[thr][0]) for i,o in res[n][::6]))
