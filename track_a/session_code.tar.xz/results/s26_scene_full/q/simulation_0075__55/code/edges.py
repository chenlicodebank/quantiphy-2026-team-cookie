import av, numpy as np
# Half-max edge positions of vehicle ends along the long axis, using the central band of the vehicle width
def frames(idx):
    out={}
    with av.open('simulation_0075.mp4') as c:
        for i,f in enumerate(c.decode(video=0)):
            if i in idx: out[i]=f.to_ndarray(format='rgb24').astype(float)
            if i>=max(idx): break
    return out
F=frames({0,36,71})
def prof(img,bg,band,rng,axis):
    d=np.abs(img-bg).max(2)
    if axis=='y': p=d[rng[0]:rng[1],band[0]:band[1]].mean(1)
    else: p=d[band[0]:band[1],rng[0]:rng[1]].mean(0)
    return p
def ends(p,off,level):
    m=np.median(p[p>np.percentile(p,40)])  # body level
    lv=level*m
    idx=np.where(p>lv)[0]; a,b=idx[0],idx[-1]
    # subpixel interpolation
    fa=a-1+(lv-p[a-1])/(p[a]-p[a-1]); fb=b+(p[b]-lv)/(p[b]-p[b+1])
    return fa+off,fb+off,fb-fa
cases={'van_f0':(0,71,(805,860),(770,1075),'y'),'tan_f0':(0,71,(970,1012),(710,990),'y'),
       'van_f71':(71,0,(805,860),(50,350),'y'),'tan_f71':(71,0,(615,656),(1230,1515),'x'),
       'van_f36':(36,71,(805,860),(590,880),'y')}
for lvl in (0.3,0.5):
    res={}
    for k,(a,b,band,rng,ax) in cases.items():
        p=prof(F[a],F[b],band,rng,ax); res[k]=ends(p,rng[0],lvl)
        print(lvl,k,'%.1f %.1f L=%.1f'%res[k])
        if lvl==0.5:
            a0=int(res[k][0])-rng[0]; b0=int(res[k][1])-rng[0]
            print('   start',np.round(p[max(a0-12,0):a0+8]).astype(int)); print('   end',np.round(p[b0-8:b0+12]).astype(int))
    vl=np.mean([res['van_f0'][2],res['van_f71'][2],res['van_f36'][2]]); tl=np.mean([res['tan_f0'][2],res['tan_f71'][2]])
    print('level',lvl,'van %.1f tan %.1f ratio %.4f -> %.3f m'%(vl,tl,tl/vl,6*tl/vl))
