import csv, numpy as np
car=list(csv.DictReader(open('scene/tracks/car.csv')))
cyc=list(csv.DictReader(open('scene/tracks/cyclist.csv')))
f=np.array([int(r['frame']) for r in car]); x0=np.array([float(r['bbox_x0']) for r in car]); x1=np.array([float(r['bbox_x1']) for r in car])
for lo,hi,arr,name in [(3,63,x0,'front'),(10,50,x0,'front'),(40,66,x1,'rear'),(20,63,x0,'front'),(3,40,x0,'front')]:
    m=(f>=lo)&(f<=hi); p=np.polyfit(f[m],arr[m],2); print(name,lo,hi,'a px/f2',2*p[0], 'resid',np.std(arr[m]-np.polyval(p,f[m])))
d=-np.diff(x0); print('dx',d[:66]); print('dd',np.diff(d[:64]))
for r in (car[48],cyc[48]): print(r['bbox_x0'],r['bbox_x1'],r['bbox_y0'],r['bbox_y1'],r['ref_x'],r['ref_y'],r['centroid_x'],r['centroid_y'])
