import csv, numpy as np
car=list(csv.DictReader(open('scene/tracks/car.csv')))
f=np.array([int(r['frame']) for r in car]); cx=np.array([float(r['centroid_x']) for r in car])
x0=np.array([float(r['bbox_x0']) for r in car]); x1=np.array([float(r['bbox_x1']) for r in car])
m=(f>=40)&(f<=63)
print('centroid dx', np.round(-np.diff(cx[m]),1))
for lo,hi in [(40,52),(52,63),(40,63)]:
    mm=(f>=lo)&(f<=hi)
    for nm,a in [('cx',cx),('x0',x0),('x1',x1),('mid',(x0+x1)/2)]:
        p=np.polyfit(f[mm],a[mm],2); print(lo,hi,nm,round(2*p[0],3))
# windowed accel of front edge
for lo in range(3,56,6):
    mm=(f>=lo)&(f<=lo+10); p=np.polyfit(f[mm],x0[mm],2); print('front win',lo,lo+10,round(2*p[0],3))
