import av, numpy as np, cv2
c = av.open('simulation_0083.mp4'); fr = []
for i, f in enumerate(c.decode(video=0)):
    if i % 6 == 0 or i in (47, 48, 49):
        fr.append((i, f.to_ndarray(format='rgb24').astype(np.int16)))
bg = np.median(np.stack([a for i, a in fr if i % 6 == 0]), 0)

def boxes(a):
    d = a.mean(2) - bg.mean(2); yel = (a[..., 0] - a[..., 2]) > 30
    m = (yel | (d < -34) | (d > 12)).astype(np.uint8)
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8))
    out = {}
    for name, (y0, y1) in {'yellow': (0, 479), 'black': (479, 1080)}.items():
        n, l, st, _ = cv2.connectedComponentsWithStats(m[y0:y1]); k = 1 + np.argmax(st[1:, 4])
        x, y, w, h, _ = st[k]
        out[name] = dict(x0=x, x1=x + w - 1, L=w, cx=x + (w - 1) / 2, cy=y0 + y + (h - 1) / 2)
    return out

for i, a in fr:
    if i in (24, 30, 36, 47, 48, 49):
        b = boxes(a); y, k = b['yellow'], b['black']
        dx = k['cx'] - y['cx']; dy = 124.0
        print(i, y, k, 'dx', dx, 'dist_px', np.hypot(dx, dy))
