import csv, numpy as np
r = list(csv.DictReader(open('/private/tmp/qp_blind/scene_full_a/simulation_0085/q_112/scene/tracks/car.csv')))
f = np.array([int(x['frame']) for x in r]); x0 = np.array([float(x['bbox_x0']) for x in r]); x1 = np.array([float(x['bbox_x1']) for x in r])
vf = -np.diff(x0); vr = -np.diff(x1)  # speed at frame i = index i-1 in diff
F = np.arange(1, 72)
# combined speed: front for frames <=63, rear for 64..71
v = np.where(F <= 63, vf, vr)
for lo, hi in [(3, 63), (3, 65), (5, 60), (3, 30), (30, 63)]:
    m = (F >= lo) & (F <= hi); p = np.polyfit(F[m], v[m], 1)
    print(lo, hi, 'slope px/f2 %.4f' % p[0], 'v0 frame %.2f' % (-p[1] / p[0]))
print('speeds', list(zip(F, v)))
# smoothed (5-frame) speed then slope
vs = np.convolve(v, np.ones(5) / 5, mode='same')
print('smoothed v', np.round(vs, 1))
# net: speed from ~0 at frame 2 to plateau mean frames 67..71
plateau = vr[66:71].mean(); print('plateau', plateau)
