import av, numpy as np
# subpixel front/rear edges of car along central rows (y 600..850), using anti-aliased profile
P = '/private/tmp/qp_blind/scene_full_a/simulation_0085/q_112/simulation_0085.mp4'
c = av.open(P)
out = []
for i, fr in enumerate(c.decode(video=0)):
    g = fr.to_ndarray(format='rgb24').astype(float)
    reg = g[560:900]
    dev = np.abs(reg - 140).max(axis=2)
    sat = reg.max(axis=2) - reg.min(axis=2)
    m = (dev > 45) | (sat > 35)
    cols = m.sum(axis=0)
    xs = np.where(cols > 20)[0]
    rows = m.sum(axis=1); ys = np.where(rows > 5)[0]
    # width per column profile: y extent at each column
    out.append((i, xs.min(), xs.max(), ys.min() + 560, ys.max() + 560, m.sum()))
    # column-mass based subpixel: cumulative mass position
    colmass = cols.astype(float)
    if i in (10, 30, 50):
        # y extent excluding mirrors: per-column y extent, take median over columns
        ext = []
        for x in xs:
            yy = np.where(m[:, x])[0]
            ext.append(yy.max() - yy.min() + 1)
        ext = np.array(ext)
        print('frame', i, 'col y-extent median', np.median(ext), 'p90', np.percentile(ext, 90), 'max', ext.max())
for o in out: print(*o)
