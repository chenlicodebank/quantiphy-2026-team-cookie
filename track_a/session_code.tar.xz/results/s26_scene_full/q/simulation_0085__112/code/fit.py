import csv, numpy as np
r = list(csv.DictReader(open('/private/tmp/qp_blind/scene_full_a/simulation_0085/q_112/scene/tracks/car.csv')))
f = np.array([int(x['frame']) for x in r]); x0 = np.array([float(x['bbox_x0']) for x in r]); x1 = np.array([float(x['bbox_x1']) for x in r])
for lo, hi, arr, name in [(3, 63, x0, 'front'), (10, 63, x0, 'front'), (40, 63, x0, 'front'), (40, 66, x1, 'rear'), (3, 40, x0, 'front early')]:
    m = (f >= lo) & (f <= hi); p = np.polyfit(f[m], arr[m], 2); res = arr[m] - np.polyval(p, f[m])
    print(name, lo, hi, 'a px/f2=%.4f' % (2 * p[0]), 'rms', res.std().round(2), 'start f', -p[1] / (2 * p[0]))
d = -np.diff(x0[:64]); print('front dx', d)
d = -np.diff(x1[40:72]); print('rear dx', d)
