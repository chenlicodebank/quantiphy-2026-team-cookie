import av, numpy as np
cont = av.open('simulation_0070.mp4')
frames = {}
for i, f in enumerate(cont.decode(video=0)):
    if i in (0, 1, 66, 68, 70, 71):
        frames[i] = f.to_ndarray(format='rgb24').astype(int)
    if i > 71: break

def extents(img, box, vertical):
    x0, y0, x1, y1 = box
    c = img[y0:y1, x0:x1]
    paint = (c[..., 0] - c[..., 2] > 22) & (c[..., 0] > 180)
    ys, xs = np.nonzero(paint)
    # use profile counts to ignore stray pixels
    colc = paint.sum(0); rowc = paint.sum(1)
    cols = np.nonzero(colc >= 3)[0]; rows = np.nonzero(rowc >= 3)[0]
    W = cols[-1] - cols[0] + 1; H = rows[-1] - rows[0] + 1
    return (W, H) if vertical else (H, W)

for i in (0, 1):
    L_w = extents(frames[i], (935, 700, 1080, 1000), True)
    print(i, 'width,length(paint)', L_w[0], L_w[1])
for i in (66, 68, 70, 71):
    img = frames[i]
    print(i, 'width,length(paint)', extents(img, (1200, 560, 1560, 720), False))
