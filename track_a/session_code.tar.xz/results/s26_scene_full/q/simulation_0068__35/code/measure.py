import numpy as np, av
V='/private/tmp/qp_blind/scene_full_a/simulation_0068/q_35/simulation_0068.mp4'
frames={}
want=set(range(72))
c=av.open(V)
vanfront=[];vanrear=[]
road=None
def edge(prof, thr, rising_from_start=True):
    # first index where prof crosses thr, with linear interpolation
    i=np.argmax(prof>thr)
    return i-1+(thr-prof[i-1])/(prof[i]-prof[i-1])
sed={}
for i,fr in enumerate(c.decode(video=0)):
    a=fr.to_ndarray(format='rgb24').astype(float)
    g=a.mean(2)
    # van: columns 800..860, along y, bright white vs road grey (~150)
    col=g[:,805:858].mean(1)
    roadv=np.median(g[300:700,700:760])
    whitev=np.percentile(col[col>0],99)
    thr=(roadv+235)/2
    # front edge: search from top within road N-S region going down, starting y=60
    seg=col[60:1075]
    idx=np.where(seg>thr)[0]
    y0=idx[0]+60; y1=idx[-1]+60
    f=y0-1+(thr-col[y0-1])/(col[y0]-col[y0-1])
    r=y1+(col[y1]-thr)/(col[y1]-col[y1+1])
    vanfront.append(f);vanrear.append(r)
    if i in (0,1,71,70,69):
        # sedan colour: saturation (R-B)
        s=a[:,:,0]-a[:,:,2]
        sed[i]=s
        np.save('/private/tmp/qp_blind/scene_full_a/simulation_0068/q_35/sat_%d.npy'%i, s[500:1100,850:1500].astype(np.float32))
vanfront=np.array(vanfront);vanrear=np.array(vanrear)
np.save('/private/tmp/qp_blind/scene_full_a/simulation_0068/q_35/van_edges.npy',np.c_[vanfront,vanrear])
fr=np.arange(72)
for name,y in [('front',vanfront),('rear',vanrear),('mid',(vanfront+vanrear)/2)]:
    for a_,b_ in [(4,71),(10,71),(4,38),(38,71),(20,60)]:
        m=(fr>=a_)&(fr<=b_);p=np.polyfit(fr[m],y[m],2)
        print(name,a_,b_,'acc %.4f px/f2'%(2*p[0]),'rest %.2f'%(-p[1]/2/p[0]),'rms %.3f'%(y[m]-np.polyval(p,fr[m])).std())
print('length',np.round(vanrear-vanfront,1)[::6])
print('front',np.round(vanfront[:8],2))
