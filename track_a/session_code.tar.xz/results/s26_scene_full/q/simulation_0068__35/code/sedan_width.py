import numpy as np
D='/private/tmp/qp_blind/scene_full_a/simulation_0068/q_35/'
# arrays are s[500:1100, 850:1500] with s = R-B
def cross(prof,thr):
    idx=np.where(prof>thr)[0]; a=idx[0]; b=idx[-1]
    l=a-1+(thr-prof[a-1])/(prof[a]-prof[a-1]); r=b+(prof[b]-thr)/(prof[b]-prof[b+1])
    return l,r
for i in (0,1):
    s=np.load(D+'sat_%d.npy'%i)
    print('road sat',np.median(s[0:50,0:50]))
    # car at x 950..1030 -> local 100..180 ; y 745..960 -> local 245..460
    for y in (290,330,380,420,450):
        prof=s[y-5:y+5,60:215].mean(0)
        hi=np.percentile(prof,90); lo=np.median(s[0:50,0:50])
        for frac in (0.5,):
            thr=lo+frac*(hi-lo)
            l,r=cross(prof,thr); print(i,'y',y+500,'x %.1f-%.1f width %.2f'%(l+910,r+910,r-l), 'hi',round(hi,1))
for i in (69,70,71):
    s=np.load(D+'sat_%d.npy'%i)
    m=s>np.percentile(s,99.5)*0.5
    ys,xs=np.where(m); print(i,'mask bbox',xs.min()+850,xs.max()+850,ys.min()+500,ys.max()+500)
    cx=1372-850
    for x in (cx-70,cx-30,cx,cx+30,cx+70):
        prof=s[60:250,x-5:x+5].mean(1)
        hi=np.percentile(prof,90); lo=np.median(s[0:50,0:50])
        l,r=cross(prof,lo+0.5*(hi-lo)); print(i,'x',x+850,'y %.1f-%.1f width %.2f'%(l+560,r+560,r-l))
