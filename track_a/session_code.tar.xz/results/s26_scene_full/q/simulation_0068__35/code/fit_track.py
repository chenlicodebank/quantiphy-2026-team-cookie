import numpy as np, csv
D='/private/tmp/qp_blind/scene_full_a/simulation_0068/q_35/'
r=list(csv.DictReader(open(D+'scene/tracks/van.csv')))
f=np.array([int(x['frame']) for x in r])
for col in ['ccy','cy','cbbox_y0','cbbox_y1','bbox_y0','bbox_y1']:
    y=np.array([float(x[col]) for x in r])
    for a,b in [(3,71),(10,71),(3,40),(40,71)]:
        m=(f>=a)&(f<=b); p=np.polyfit(f[m],y[m],2)
        res=y[m]-np.polyval(p,f[m])
        print(col,a,b,'acc px/f2 %.4f'%(2*p[0]),'rest frame %.2f'%(-p[1]/(2*p[0])),'rms %.2f'%res.std())
s=np.array([[float(x['clength']),float(x['cwidth'])] for x in r])
r2=list(csv.DictReader(open(D+'scene/tracks/sedan.csv')))
print('van len/wid median',np.median(s,0))
s2=np.array([[float(x['clength']),float(x['cwidth']),float(x['length']),float(x['width'])] for x in r2])
print('sedan c len/wid, diff len/wid median',np.median(s2,0)); print(s2[::6])
