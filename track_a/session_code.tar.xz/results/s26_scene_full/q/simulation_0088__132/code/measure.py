import av, numpy as np
bg = np.array([97, 149, 191], float)
c = av.open('simulation_0088.mp4')
res = []
for i, fr in enumerate(c.decode(video=0)):
    if i < 2 or i > 14: continue
    a = fr.to_ndarray(format='rgb24').astype(float)
    d = np.abs(a - bg).sum(2)
    band = d[540:575]  # body line rows
    out = []
    for th in (20, 40):
        cols = np.where((band > th).sum(0) >= 2)[0]
        # eagle: leftmost cluster region (eagle is left of crow after f2)
        cols = cols[cols < (cols.min() + 200)]
        # cut at first gap > 5 px
        gaps = np.where(np.diff(cols) > 5)[0]
        if len(gaps): cols = cols[:gaps[0] + 1]
        out.append((cols.min(), cols.max(), cols.max() - cols.min() + 1))
    res.append((i, out))
    print(i, out)
heads = np.array([r[1][0][0] for r in res]); tails = np.array([r[1][0][1] for r in res])
fr = np.array([r[0] for r in res])
ph = np.polyfit(fr, heads, 1); pt = np.polyfit(fr, tails, 1)
print('head step', ph[0], 'tail step', pt[0])
L20 = np.mean([r[1][0][2] for r in res]); L40 = np.mean([r[1][1][2] for r in res])
step = -(ph[0] + pt[0]) / 2
mpp = 17.98 / (step * 24)
print('step px/frame', step, 'm/px', mpp, 'L20', L20, L40, 'len m', L20 * mpp, L40 * mpp)
