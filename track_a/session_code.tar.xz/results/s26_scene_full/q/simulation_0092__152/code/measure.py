import av, numpy as np, cv2
frames = {}
c = av.open('simulation_0092.mp4')
bgs = []
for i, f in enumerate(c.decode(video=0)):
    a = f.to_ndarray(format='rgb24').astype(np.int16)
    if i % 4 == 0:
        bgs.append(a[::1, ::1])
    if i in (12, 16, 20, 22, 25, 28, 30, 35, 40):
        frames[i] = a
bg = np.median(np.stack(bgs), axis=0)
del bgs
for i, a in sorted(frames.items()):
    d = np.abs(a - bg).max(axis=2) > 12
    d = cv2.morphologyEx(d.astype(np.uint8), cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    n, lab, st, _ = cv2.connectedComponentsWithStats(d)
    for k in range(1, n):
        x, y, w, h, ar = st[k]
        if ar > 200:
            print(i, 'comp x0', x, 'y0', y, 'w', w, 'h', h, 'area', ar)
    # rows split
    up = d[:590]; lo = d[590:]
    for name, m, off in (('plane', up, 0), ('car', lo, 590)):
        ys, xs = np.nonzero(m)
        if len(xs):
            print(i, name, 'x', xs.min(), xs.max(), 'L', xs.max()-xs.min()+1, 'y', ys.min()+off, ys.max()+off, 'H', ys.max()-ys.min()+1)
