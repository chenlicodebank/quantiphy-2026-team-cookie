import csv, numpy as np, json
ld = lambda n: list(csv.DictReader(open('scene/tracks/' + n + '.csv')))
b, w = ld('person_black'), ld('person_white')
f = lambda r, k: np.array([float(x[k]) if x[k] else np.nan for x in r])
bx, by, wx, wy = f(b, 'torso_x'), f(b, 'torso_y'), f(w, 'torso_x'), f(w, 'torso_y')
sb = np.hypot(np.diff(bx), np.diff(by))
v = sb[1:].mean() * 24  # px/s, walking frames 2-71
s = 1 / v               # m/px from prior 1 m/s
d = np.hypot(bx[24] - wx[24], by[24] - wy[24])
print('black speed px/s', v, 'm/px', s, 'dist px', d, 'm', d * s, 'inst-step route', d / (sb[23] * 24))
json.dump({"71": round(d * s, 3)}, open('answers.json', 'w'))
