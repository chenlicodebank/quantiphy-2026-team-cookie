import av, numpy as np
import cv2
frames = {}
want = set(range(0, 73))
c = av.open('simulation_0092.mp4')
bgs = []
for i, f in enumerate(c.decode(video=0)):
    a = f.to_ndarray(format='rgb24').astype(np.int16)
    if i % 4 == 0: bgs.append(a[::1, ::1])
    if i in (12, 18, 21, 24, 27, 30, 33, 36, 40, 45): frames[i] = a
bg = np.median(np.stack(bgs), axis=0)
del bgs
for th in (12, 25):
    for i, a in sorted(frames.items()):
        m = np.abs(a - bg).max(axis=2) > th
        m = cv2.morphologyEx(m.astype(np.uint8), cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
        n, lab, st, _ = cv2.connectedComponentsWithStats(m)
        keep = np.isin(lab, [k for k in range(1, n) if st[k, 4] >= 30])
        out = []
        for name, rows in (('plane', slice(0, 590)), ('car', slice(590, 1080))):
            ys, xs = np.nonzero(keep[rows])
            out.append((name, xs.min(), xs.max(), xs.max() - xs.min() + 1, (xs.min() + xs.max()) / 2))
        print(th, i, out)
