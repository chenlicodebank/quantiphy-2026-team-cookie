import av, numpy as np, csv
rows=list(csv.DictReader(open('scene/tracks/person.csv')))
c=av.open('simulation_0041.mp4')
W=[]
for i,fr in enumerate(c.decode(video=0)):
    img=fr.to_ndarray(format='rgb24').astype(float)
    r=rows[i]; cx=int(float(r['ref_x'])); cy=int(float(r['ref_y']))
    cr=img[cy-40:cy+40, cx-25:cx+25]
    sand=np.median(cr[:6].reshape(-1,3),0)
    # brightness relative to sand along each row in the shirt band: half-max crossing widths
    lum=cr.mean(2); sl=sand.mean()
    mx=cr.max(2); mn=cr.min(2)
    white=(mn>175)&(mx-mn<45)
    rr=np.where(white.sum(1)>=4)[0]
    best=0
    for y in rr:
        row=lum[y]; pk=row.max(); thr=(pk+sl)/2
        xs=np.where(row>thr)[0]
        # contiguous run containing the white pixels
        wx=np.where(white[y])[0]; a=wx.min(); b=wx.max()
        while a>0 and row[a-1]>thr: a-=1
        while b<len(row)-1 and row[b+1]>thr: b+=1
        best=max(best,b-a+1)
    W.append(best)
W=np.array(W); print(W.tolist()); print('median',np.median(W),'p90',np.percentile(W,90))
