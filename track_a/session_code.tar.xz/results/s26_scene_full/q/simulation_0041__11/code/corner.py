import av, numpy as np, csv
rows=list(csv.DictReader(open('scene/tracks/boat.csv')))
c=av.open('simulation_0041.mp4')
for i,fr in enumerate(c.decode(video=0)):
    if i not in (10,20,30,40,50): continue
    g=fr.to_ndarray(format='rgb24').astype(float).mean(2)
    dx=float(rows[i]['tm_dx']); dy=float(rows[i]['tm_dy'])
    res=[]
    for y in range(912,952):
        yy=int(round(y+dy))
        x0=int(round(330+dx)); seg=g[yy,x0:x0+20]
        gr=np.diff(seg)  # white->grey = strong negative
        k=int(np.argmin(gr))
        # subpixel parabola
        if 0<k<len(gr)-1:
            a,b,cc=gr[k-1],gr[k],gr[k+1]; off=0.5*(a-cc)/(a-2*b+cc)
        else: off=0
        res.append((yy, x0+k+0.5+off, gr[k]))
    R=np.array(res); good=R[:,2]<-40
    p=np.polyfit(R[good,0],R[good,1],1)
    print(i, 'n',good.sum(),'slope dx/dy',round(p[0],4),'x at mid',round(np.polyval(p,R[good,0].mean()),2))
