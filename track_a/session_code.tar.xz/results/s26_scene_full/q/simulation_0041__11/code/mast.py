import av, numpy as np, cv2
c=av.open('simulation_0041.mp4')
for i,fr in enumerate(c.decode(video=0)):
    if i==30: img=fr.to_ndarray(format='rgb24').astype(float); break
g=img.mean(2)
# mast: brightest narrow column near x 315-335
pts=[]
for y in range(790,890,4):
    row=g[y,305:345]
    xs=np.arange(305,345)
    m=row>row.max()-25
    # take the connected run around argmax
    k=int(np.argmax(row)); a=k; b=k
    while a>0 and m[a-1]: a-=1
    while b<len(row)-1 and m[b+1]: b+=1
    w=row[a:b+1]-row.min()
    pts.append((y,(xs[a:b+1]*w).sum()/w.sum(),b-a+1, row.max()))
for p in pts: print(p)
P=np.array(pts)
sel=(P[:,0]>=812)&(P[:,0]<=884)
print(np.polyfit(P[sel,0],P[sel,1],1))
