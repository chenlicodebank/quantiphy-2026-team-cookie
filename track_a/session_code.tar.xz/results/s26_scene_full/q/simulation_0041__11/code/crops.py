import av, numpy as np, cv2, csv
rows=list(csv.DictReader(open('scene/tracks/person.csv')))
want=[3,12,24,27,39,48,57,66]
c=av.open('simulation_0041.mp4'); tiles=[]
for i,fr in enumerate(c.decode(video=0)):
    if i in want:
        img=fr.to_ndarray(format='bgr24'); r=rows[i]
        cx=int(float(r['ref_x'])); cy=int(float(r['ref_y']))
        crop=img[cy-35:cy+35, cx-20:cx+20].copy()
        crop=cv2.resize(crop,None,fx=6,fy=6,interpolation=cv2.INTER_NEAREST)
        for y in range(0,70,5):
            cv2.line(crop,(0,y*6),(239,y*6),(0,255,255) if y%10==0 else (0,120,120),1)
        cv2.putText(crop,f'{i} y0={cy-35}',(2,12),0,0.4,(0,0,255),1)
        tiles.append(crop)
cv2.imwrite('frames/ptiles.png',np.hstack(tiles))
