import av, numpy as np, csv
rows=list(csv.DictReader(open('scene/tracks/person.csv')))
c=av.open('simulation_0041.mp4')
# sand reference colour from an empty patch
out=[]
for i,fr in enumerate(c.decode(video=0)):
    img=fr.to_ndarray(format='rgb24').astype(float)
    r=rows[i]; cx=int(float(r['ref_x'])); cy=int(float(r['ref_y']))
    y0=cy-40; x0=cx-25
    cr=img[y0:cy+40, x0:cx+25]
    sand=np.median(np.concatenate([cr[:6].reshape(-1,3),cr[:, :5].reshape(-1,3)]),0)
    d=np.abs(cr-sand).sum(2)
    mx=cr.max(2); mn=cr.min(2)
    white=(mn>175)&(mx-mn<45)
    # shirt rows and width
    wr=white.sum(1)
    shirt_rows=np.where(wr>=4)[0]
    # per-row horizontal extent of white pixels
    widths=[]
    for yy in shirt_rows:
        xs=np.where(white[yy])[0]; widths.append(xs.max()-xs.min()+1)
    # body mask: differs from sand, restricted to columns of shirt +-3 (to drop shadow on the right)
    xs_sh=np.where(white.any(0))[0]
    xa,xb=xs_sh.min()-3, xs_sh.max()+3
    body=d>60
    colmask=np.zeros_like(body); colmask[:,xa:xb+1]=True
    b=body&colmask
    ys=np.where(b.sum(1)>=1)[0]
    # head top: first row with >=2 body px
    rr=np.where(b.sum(1)>=2)[0]
    out.append(dict(f=i,head=y0+rr.min(),feet=y0+rr.max(),shirt_top=y0+shirt_rows.min(),shirt_bot=y0+shirt_rows.max(),
                    shirt_w_med=float(np.median(widths)),shirt_w_max=int(max(widths)),
                    body_w=int(xs_sh.max()-xs_sh.min()+1)))
with open('person_meas.csv','w') as f:
    w=csv.DictWriter(f,fieldnames=list(out[0].keys())); w.writeheader(); w.writerows(out)
for o in out: print(o)
