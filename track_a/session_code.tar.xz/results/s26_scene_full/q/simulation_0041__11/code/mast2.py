import av, numpy as np, csv
rows=list(csv.DictReader(open('scene/tracks/boat.csv')))
c=av.open('simulation_0041.mp4')
for i,fr in enumerate(c.decode(video=0)):
    if i not in (5,15,30,45,60): continue
    g=fr.to_ndarray(format='rgb24').astype(float).mean(2)
    dx=float(rows[i]['tm_dx']); dy=float(rows[i]['tm_dy'])
    pts=[]
    for y in list(range(800,822))+list(range(864,888)):
        yy=int(round(y+dy)); x0=int(round(312+dx))
        row=g[yy,x0:x0+24]; k=int(np.argmax(row))
        if 0<k<23:
            a,b,cc=row[k-1],row[k],row[k+1]; off=0.5*(a-cc)/(a-2*b+cc)
        else: off=0
        pts.append((yy-dy, x0+k+off-dx, row[k]))
    P=np.array(pts); P=P[P[:,2]>180]
    p=np.polyfit(P[:,0],P[:,1],1)
    print(i,'mast x',round(312+dx+10,1),'slope',round(p[0],4),len(P))
