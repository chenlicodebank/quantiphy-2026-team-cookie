import av, numpy as np, cv2
c = av.open('simulation_0086.mp4')
frames = []
for i, fr in enumerate(c.decode(video=0)):
    g = fr.to_ndarray(format='gray').astype(np.float32)
    frames.append(g[550:760].copy())  # car band only
c.close()
T = frames[0][:, 860:1325]
xs = []
for i, g in enumerate(frames[:58]):
    res = cv2.matchTemplate(g, T, cv2.TM_CCOEFF_NORMED)[0] if False else cv2.matchTemplate(g, T, cv2.TM_CCOEFF_NORMED)
    res = res[:, :]
    y, x = np.unravel_index(np.argmax(res), res.shape)
    if 0 < x < res.shape[1] - 1:
        a, b, cc = res[y, x - 1], res[y, x], res[y, x + 1]
        dx = 0.5 * (a - cc) / (a - 2 * b + cc)
    else:
        dx = 0
    xs.append(x + dx)
    print(i, y, round(x + dx - 860, 2), round(float(res[y, x]), 3))
xs = np.array(xs) - 860
np.save('car_tm.npy', xs)
f = np.arange(len(xs))
for lo, hi in [(2, 57), (2, 30), (20, 57), (30, 57), (2, 20)]:
    m = (f >= lo) & (f <= hi); p = np.polyfit(f[m], xs[m], 2); r = xs[m] - np.polyval(p, f[m])
    print(lo, hi, 'acc %.4f rest %.2f rms %.3f' % (2 * p[0], -p[1] / (2 * p[0]), r.std()))
v = np.diff(xs)
print('steps', np.round(v, 2))
print('2nd diff', np.round(np.diff(v), 2))
