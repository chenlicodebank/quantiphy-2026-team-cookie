import csv, numpy as np
r = list(csv.DictReader(open('scene/tracks/car.csv')))
f = np.array([int(x['frame']) for x in r])
cols = {k: np.array([float(x[k]) for x in r]) for k in ['x0', 'x1', 'bbox_cx', 'mask_cx']}
for k, v in cols.items():
    for lo, hi in [(2, 56), (2, 30), (20, 56), (30, 56)]:
        if k == 'x1': hi = min(hi, 69)
        m = (f >= lo) & (f <= hi); p = np.polyfit(f[m], v[m], 2); res = v[m] - np.polyval(p, f[m])
        print(k, lo, hi, 'acc %.4f' % (2 * p[0]), 'rest frame %.2f' % (-p[1] / (2 * p[0])), 'rms %.2f' % res.std())
