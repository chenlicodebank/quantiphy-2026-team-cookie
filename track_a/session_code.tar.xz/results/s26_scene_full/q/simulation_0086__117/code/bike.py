import av, numpy as np
c = av.open('simulation_0086.mp4')
for i, fr in enumerate(c.decode(video=0)):
    if i == 0: g0 = fr.to_ndarray(format='gray').astype(float)
    if i == 71: g71 = fr.to_ndarray(format='gray').astype(float)
c.close()
d = np.abs(g0 - g71)[455:500, 860:1040]
colmax = d.max(axis=0)
xs = np.arange(860, 1040)
print('row of max per col near ends:')
for x in list(range(878, 892)) + list(range(1004, 1020)):
    col = d[:, x - 860]; print(x, int(col.max()), 455 + int(col.argmax()))
# half-max subpixel ends using column max profile, peak level ~ line darkness
def ends(th):
    idx = np.where(colmax > th)[0]
    l, r = idx[0], idx[-1]
    lf = l - 1 + (th - colmax[l - 1]) / (colmax[l] - colmax[l - 1])
    rf = r + (colmax[r] - th) / (colmax[r] - colmax[r + 1])
    return xs[0] + lf, xs[0] + rf
for th in [15, 30, 50, 70]:
    a, b = ends(th); print(th, round(a, 2), round(b, 2), 'len', round(b - a, 2))
