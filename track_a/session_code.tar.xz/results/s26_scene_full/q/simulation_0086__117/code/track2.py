import av, numpy as np, cv2
c = av.open('simulation_0086.mp4')
frames = []
for i, fr in enumerate(c.decode(video=0)):
    g = fr.to_ndarray(format='gray').astype(np.float32)
    frames.append(g[550:760].copy())
c.close()
x0t = 1150
T = frames[0][:, x0t:1325]
prev = None; xs = []
for i, g in enumerate(frames[:64]):
    # blur-matched template: box blur template with estimated per-frame step (shutter 0.5)
    step = abs(xs[-1] - xs[-2]) if len(xs) > 2 else 0
    k = max(1, int(round(step * 0.5)))
    Tb = cv2.blur(T, (k, 1)) if k > 1 else T
    res = cv2.matchTemplate(g, Tb, cv2.TM_CCOEFF_NORMED)
    y, x = np.unravel_index(np.argmax(res), res.shape)
    a, b, cc = res[y, x - 1], res[y, x], res[y, x + 1] if x + 1 < res.shape[1] else res[y, x]
    dx = 0.5 * (a - cc) / (a - 2 * b + cc)
    xs.append(x + dx - x0t)
    print(i, k, round(xs[-1], 2), round(float(res[y, x]), 3))
xs = np.array(xs); f = np.arange(len(xs))
np.save('car_tm_rear.npy', xs)
for lo, hi in [(2, 30), (2, 48), (25, 48), (30, 63), (45, 63), (2, 63)]:
    m = (f >= lo) & (f <= hi); p = np.polyfit(f[m], xs[m], 2)
    print(lo, hi, 'acc %.4f rms %.3f' % (2 * p[0], (xs[m] - np.polyval(p, f[m])).std()))
print('2nd diff', np.round(np.diff(xs, 2), 2))
