import csv, numpy as np
r = list(csv.DictReader(open('scene/tracks/car.csv')))
f = np.array([int(x['frame']) for x in r]); x0 = np.array([float(x['x0']) for x in r])
for lo, hi in [(1, 56), (5, 56), (10, 56), (1, 30), (30, 56)]:
    m = (f >= lo) & (f <= hi); p = np.polyfit(f[m], x0[m], 2); res = x0[m] - np.polyval(p, f[m])
    print(lo, hi, 'acc px/f2', 2 * p[0], 'v0', p[1], 't_rest', -p[1] / (2 * p[0]), 'rms', res.std())
    print('  cubic', np.polyfit(f[m], x0[m], 3))
