import csv, numpy as np
r = list(csv.DictReader(open('scene/tracks/car.csv')))
f = np.array([int(x['frame']) for x in r]); x1 = np.array([float(x['x1']) for x in r])
for lo, hi in [(2, 68), (20, 68), (40, 68), (48, 68)]:
    m = (f >= lo) & (f <= hi); p = np.polyfit(f[m], x1[m], 2)
    print('x1', lo, hi, 'acc %.4f rms %.2f' % (2 * p[0], (x1[m] - np.polyval(p, f[m])).std()))
xs = np.load('car_tm.npy'); ff = np.arange(len(xs))
for lo, hi in [(2, 48), (5, 45), (10, 48), (25, 48)]:
    m = (ff >= lo) & (ff <= hi); p = np.polyfit(ff[m], xs[m], 2)
    print('tm', lo, hi, 'acc %.4f rms %.3f' % (2 * p[0], (xs[m] - np.polyval(p, ff[m])).std()))
