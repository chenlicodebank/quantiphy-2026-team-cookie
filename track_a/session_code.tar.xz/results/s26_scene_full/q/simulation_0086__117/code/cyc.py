import av, numpy as np, cv2
c = av.open('simulation_0086.mp4')
frames = []
for i, fr in enumerate(c.decode(video=0)):
    g = fr.to_ndarray(format='gray').astype(np.float32)
    frames.append(g[440:515].copy())
c.close()
x0t = 878
T = frames[0][:, x0t:1018]
xs = []
for i, g in enumerate(frames[:56]):
    res = cv2.matchTemplate(g, T, cv2.TM_CCOEFF_NORMED)
    y, x = np.unravel_index(np.argmax(res), res.shape)
    a, b, cc = res[y, x - 1], res[y, x], res[y, x + 1]
    xs.append(x + 0.5 * (a - cc) / (a - 2 * b + cc) - x0t)
xs = np.array(xs); f = np.arange(len(xs))
print(np.round(np.diff(xs), 2))
for lo, hi in [(2, 20), (20, 40), (40, 55), (2, 55)]:
    m = (f >= lo) & (f <= hi); p = np.polyfit(f[m], xs[m], 2)
    print(lo, hi, 'v %.3f acc %.4f' % (np.polyfit(f[m], xs[m], 1)[0], 2 * p[0]))
