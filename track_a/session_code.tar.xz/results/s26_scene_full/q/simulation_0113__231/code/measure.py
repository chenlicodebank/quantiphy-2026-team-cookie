import av, numpy as np, cv2
c = av.open('simulation_0113.mp4'); cs = []; ds = []
for i, fr in enumerate(c.decode(video=0)):
    im = fr.to_ndarray(format='bgr24')[300:520, 300:520]
    hsv = cv2.cvtColor(im, cv2.COLOR_BGR2HSV)
    m = ((hsv[..., 1] > 110) & (hsv[..., 2] > 90)).astype(np.uint8)
    n, l, st, _ = cv2.connectedComponentsWithStats(m)
    k = 1 + np.argmax(st[1:, 4]); mk = (l == k).astype(np.uint8)
    cnts, _ = cv2.findContours(mk, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    cn = max(cnts, key=cv2.contourArea); f = np.zeros_like(mk); cv2.drawContours(f, [cn], -1, 1, -1)
    ys, xs = np.nonzero(f); cs.append((xs.mean() + 300, ys.mean() + 300))
    pts = cn[:, 0, :].astype(float); fer = []
    for a in np.linspace(0, np.pi, 36, endpoint=False):
        p = pts @ [np.cos(a), np.sin(a)]; fer.append(p.max() - p.min() + 1)
    ds.append((np.min(fer), np.max(fer), np.mean(fer), 2 * np.sqrt(f.sum() / np.pi)))
    if i == 24:
        ov = im.copy(); cv2.drawContours(ov, [cn], -1, (0, 255, 0), 1)
        cv2.imwrite('frames/ov24.png', cv2.resize(ov, None, fx=3, fy=3, interpolation=cv2.INTER_NEAREST))
cs = np.array(cs); ds = np.array(ds); t = np.arange(len(cs))
px = np.polyfit(t, cs[:, 0], 1); py = np.polyfit(t, cs[:, 1], 1)
v = np.hypot(px[0], py[0]); print('fit px/frame', px[0], py[0], v)
st = np.hypot(*np.diff(cs, axis=0).T); print('raw step at 24', st[23], 'mean 20-28', st[19:28].mean())
print('diam min/max/mean feret, equiv', ds.mean(0))
for fps in (24.0, 24.0048):
    print(fps, 'feret-mean', v * fps / ds[:, 2].mean(), 'feret-max', v * fps / ds[:, 1].mean(), 'equiv', v * fps / ds[:, 3].mean())
