import av, numpy as np
# front (left) edge of car per frame in rows 600-850 (car lane), plus subpixel estimate
c = av.open('simulation_0085.mp4'); xs = []
for i, fr in enumerate(c.decode(video=0)):
    a = fr.to_ndarray(format='rgb24').astype(float)[600:850]
    g = a.mean(2); sat = a.max(2) - a.min(2)
    m = (np.abs(g - 140) > 45) | (sat > 35)
    col = m.mean(0)
    idx = np.where(col > 0.05)[0]
    x0 = idx.min() if len(idx) else np.nan
    # subpixel: fractional coverage of the column just left of x0 relative to the next columns' coverage
    if len(idx) and x0 > 0:
        ref = col[x0 + 2:x0 + 6].max()
        x0s = x0 - col[x0 - 1] / ref + (1 - col[x0] / ref) if ref > 0 else x0
    else:
        x0s = np.nan
    xs.append((i, x0, x0s))
xs = np.array(xs, float); np.save('edges.npy', xs)
f = xs[:, 0]
for name, x in [('int', xs[:, 1]), ('sub', xs[:, 2])]:
    sel = (f >= 3) & (f <= 63)
    p = np.polyfit(f[sel], x[sel], 2)
    r = x[sel] - np.polyval(p, f[sel])
    print(name, 'a px/f^2', 2 * p[0], 't0', -p[1] / (2 * p[0]), 'rms', r.std(), 'max', abs(r).max())
    for lo, hi in [(3, 30), (20, 50), (30, 63), (25, 47)]:
        s = (f >= lo) & (f <= hi); q = np.polyfit(f[s], x[s], 2)
        print('  ', lo, hi, 'a', 2 * q[0], 't0', -q[1] / (2 * q[0]))
print('dx int', np.diff(xs[:, 1])[:66])
print('dx sub', np.round(np.diff(xs[:, 2])[:66], 2))
