import av, numpy as np
# frame-to-frame shift of the car (rows 590-860) by SSD over overlapping columns, subpixel parabola
c = av.open('simulation_0085.mp4'); prev = None; out = []
def ssd_shift(A, B, guess):
    # find s such that B(x) ~ A(x + s)  (car moves left => s ~ +dx magnitude), A,B: HxW gray
    W = A.shape[1]; best = []
    cands = range(max(0, guess - 8), guess + 9)
    for s in cands:
        # B[:, x] vs A[:, x+s], x in [0, W-1-s], restrict to columns < W-2 (exclude right edge entry)
        a = A[:, s:W - 2]; b = B[:, 0:W - 2 - s]
        w = (np.abs(a - 140) > 20) | (np.abs(b - 140) > 20)
        best.append(((a - b)[w] ** 2).mean())
    best = np.array(best); k = int(np.argmin(best)); s0 = list(cands)[k]
    if 0 < k < len(best) - 1:
        d = (best[k - 1] - best[k + 1]) / (2 * (best[k - 1] - 2 * best[k] + best[k + 1]))
    else:
        d = 0
    return s0 + d
guess = 0
for i, fr in enumerate(c.decode(video=0)):
    g = fr.to_ndarray(format='gray').astype(float)[590:860]
    if prev is not None:
        # restrict to the region of the car: columns where prev or cur differs from background
        s = ssd_shift(prev, g, guess)
        out.append((i, s)); guess = int(round(s)) + 1
    prev = g
out = np.array(out); np.save('shifts.npy', out)
f = out[:, 0]; v = out[:, 1]
print(np.round(v, 2))
for lo, hi in [(3, 63), (3, 30), (20, 50), (30, 63), (25, 47), (40, 71)]:
    s = (f >= lo) & (f <= hi); q = np.polyfit(f[s], v[s], 1)
    print(lo, hi, 'a px/f^2', q[0], 'v=0 at frame', -q[1] / q[0] + 0.5, 'v36', np.polyval(q, 36),
          'rms', np.std(v[s] - np.polyval(q, f[s])))
