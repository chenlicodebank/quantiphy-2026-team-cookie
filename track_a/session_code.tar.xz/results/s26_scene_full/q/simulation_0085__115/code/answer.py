import numpy as np
out = np.load('shifts.npy'); f = out[:, 0]; v = out[:, 1]   # v[f] = |x(f)-x(f-1)| px
edges = np.load('edges.npy'); vs = -np.diff(edges[:, 2])    # front-edge subpixel, frame k+1
A = 4.03; fps = 24
for name, ff, vv in [('ssd', f, v), ('edge', edges[1:, 0], vs)]:
    for lo, hi in [(3, 30), (3, 36), (5, 40), (10, 36)]:
        s = (ff >= lo) & (ff <= hi) & np.isfinite(vv); q = np.polyfit(ff[s], vv[s], 1)
        a_px = q[0] * fps * fps          # px/s^2
        v36_fit = np.polyval(q, 36) * fps
        v36_meas = vv[ff == 36][0] * fps
        m_per_px = A / a_px
        print(name, lo, hi, 'a_px/f2 %.4f' % q[0], 'scale m/px %.5f' % m_per_px,
              'speed36 fit %.3f meas %.3f' % (v36_fit * m_per_px, v36_meas * m_per_px))
