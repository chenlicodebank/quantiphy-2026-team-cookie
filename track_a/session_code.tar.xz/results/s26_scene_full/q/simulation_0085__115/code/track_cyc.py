import av, numpy as np, sys
sys.path.insert(0, '.')
# same SSD frame-to-frame shift for the cyclist rows (330-435) to check camera stability
c = av.open('simulation_0085.mp4'); prev = None; out = []
def ssd_shift(A, B, guess):
    W = A.shape[1]; best = []; cands = list(range(max(0, guess - 6), guess + 7))
    for s in cands:
        a = A[:, s + 2:W - 2]; b = B[:, 2:W - 2 - s]
        w = (np.abs(a - 140) > 20) | (np.abs(b - 140) > 20)
        best.append(((a - b)[w] ** 2).mean() if w.any() else 1e9)
    best = np.array(best); k = int(np.argmin(best))
    d = (best[k - 1] - best[k + 1]) / (2 * (best[k - 1] - 2 * best[k] + best[k + 1])) if 0 < k < len(best) - 1 else 0
    return cands[k] + d
for i, fr in enumerate(c.decode(video=0)):
    g = fr.to_ndarray(format='gray').astype(float)[330:435]
    if prev is not None:
        out.append((i, ssd_shift(prev, g, 27)))
    prev = g
out = np.array(out); print(np.round(out[:, 1], 2))
