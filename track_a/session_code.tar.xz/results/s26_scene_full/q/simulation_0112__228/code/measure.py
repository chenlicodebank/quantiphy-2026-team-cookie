import csv, numpy as np
fps = 24.006983
rows = [r for r in csv.DictReader(open('scene/tracks/car.csv')) if 13 <= int(r['frame']) <= 36]
f = np.array([int(r['frame']) for r in rows])
near = np.array([float(r['axle_mid_x']) for r in rows])
cp = np.array([float(r['centreplane_x_est']) for r in rows])
h = np.array([int(r['bbox_y1']) - int(r['bbox_y0']) + 0.5 for r in rows])  # inclusive rows, minus AA edge
for name, x in [('near-side hubs', near), ('centre plane', cp)]:
    v = np.polyfit(f, x, 1)[0]
    s = 6.66 / (v * fps)
    print(f'{name}: {v:.3f} px/frame, {s:.6f} m/px, height {np.median(h)*s:.3f} m')
print('median height px', np.median(h))
