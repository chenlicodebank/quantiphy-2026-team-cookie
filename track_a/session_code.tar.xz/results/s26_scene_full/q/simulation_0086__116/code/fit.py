import csv, numpy as np
r=list(csv.DictReader(open('scene/tracks/car.csv')))
f=np.array([int(x['frame']) for x in r]); x0=np.array([float(x['x0']) for x in r]); x1=np.array([float(x['x1']) for x in r])
for name,arr,lo,hi in [('front',x0,2,56),('front',x0,10,56),('rear',x1,2,56),('rear',x1,2,68),('mid',(x0+x1)/2,2,56)]:
    m=(f>=lo)&(f<=hi)
    p=np.polyfit(f[m],arr[m],2); print(name,lo,hi,'a px/f^2=',2*p[0],'t0 vertex=',-p[1]/(2*p[0]), 'res', np.std(arr[m]-np.polyval(p,f[m])))
c=list(csv.DictReader(open('scene/tracks/cyclist.csv')))
cf=np.array([int(x['frame']) for x in c]); cx=np.array([float(x['bbox_cx']) for x in c]); X0=np.array([float(x['x0']) for x in c])
m=(cf>=2)&(cf<=57)
print('bike v cx', np.polyfit(cf[m],cx[m],1), 'x0', np.polyfit(cf[(cf>=2)],X0[cf>=2],1))
