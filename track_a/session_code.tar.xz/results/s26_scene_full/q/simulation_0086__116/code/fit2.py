import numpy as np
r = np.load('car_shift.npy')[:, 0]
st = -np.diff(r)  # step into frame i+1
fr = np.arange(1, 70)
for lo, hi in [(2, 30), (2, 55), (10, 50), (30, 55), (2, 69)]:
    m = (fr >= lo) & (fr <= hi)
    p = np.polyfit(fr[m], st[m], 1)
    q = np.polyfit(np.arange(lo, hi + 1), -r[lo:hi + 1], 2)
    print(lo, hi, 'step slope', round(p[0], 4), 'zero at', round(-p[1] / p[0], 2), 'quad a', round(2 * q[0], 4))
