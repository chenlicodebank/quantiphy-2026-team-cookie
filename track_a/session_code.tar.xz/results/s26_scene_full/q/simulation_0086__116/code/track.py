import av, numpy as np
cont = av.open('simulation_0086.mp4')
frames = []
for fr in cont.decode(video=0):
    g = fr.to_ndarray(format='gray').astype(np.float32)
    frames.append((g[545:760].copy(), g[400:545].copy()))
bg_car = frames[71][0]; bg_bike = frames[71][1]

def prof(a, bg):
    return np.abs(a - bg).sum(0)

def track(idx, bg, ref_frame, lo, hi, guess):
    P0 = prof(frames[ref_frame][idx], bg)
    xs = np.arange(len(P0))
    out = {}
    for i in range(lo, hi + 1):
        P = prof(frames[i][idx], bg)
        # centroid
        c = (P * xs).sum() / P.sum()
        out[i] = c
    return out

car = track(0, bg_car, 0, 0, 56, None)
bike = track(1, bg_bike, 0, 0, 57, None)
# cross-correlation shift for car
def xcorr_track(idx, bg, lo, hi):
    P0 = prof(frames[0][idx], bg); P0 = P0 - P0.mean()
    res = {}
    for i in range(lo, hi + 1):
        P = prof(frames[i][idx], bg); P = P - P.mean()
        cc = np.correlate(P, P0, mode='full')
        k = np.argmax(cc)
        y0, y1, y2 = cc[k-1], cc[k], cc[k+1]
        d = 0.5 * (y0 - y2) / (y0 - 2*y1 + y2)
        res[i] = k + d - (len(P0) - 1)
    return res
carx = xcorr_track(0, bg_car, 0, 56)
bikex = xcorr_track(1, bg_bike, 0, 57)
f = np.arange(2, 57)
for name, d in [('car centroid', car), ('car xcorr', carx)]:
    y = np.array([d[i] for i in f])
    p = np.polyfit(f, y, 2)
    print(name, 'a=', 2*p[0], 'vertex', -p[1]/(2*p[0]), 'res', np.std(y - np.polyval(p, f)))
    for lo in (5, 15):
        m = f >= lo
        p = np.polyfit(f[m], y[m], 2); print('   from', lo, 'a=', 2*p[0])
    # second differences
    yy = np.array([d[i] for i in range(0, 57)])
    print('   steps', np.round(np.diff(yy), 2))
fb = np.arange(2, 58)
for name, d in [('bike centroid', bike), ('bike xcorr', bikex)]:
    y = np.array([d[i] for i in fb])
    print(name, np.polyfit(fb, y, 1), 'step 23->24', d[24]-d[23], 'res', np.std(y-np.polyval(np.polyfit(fb,y,1),fb)))
    yy = np.array([d[i] for i in range(0, 58)])
    print('   steps', np.round(np.diff(yy), 2))
