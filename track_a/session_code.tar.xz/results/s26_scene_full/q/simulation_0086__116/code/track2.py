import av, numpy as np
cont = av.open('simulation_0086.mp4')
P = []
for fr in cont.decode(video=0):
    g = fr.to_ndarray(format='gray').astype(np.float32)
    P.append(g[560:745])
bg = P[71]
prof = [np.abs(p - bg).sum(0) for p in P]
W = len(prof[0]); xs = np.arange(W, dtype=float)
P0 = prof[0]

def model(s, w):
    # shift P0 by s and box-blur with width w (sampled)
    n = max(1, int(np.ceil(w)) * 4 + 1)
    offs = np.linspace(-w/2, w/2, n) if w > 0 else np.array([0.0])
    acc = np.zeros(W)
    for o in offs:
        acc += np.interp(xs - s - o, xs, P0, left=0, right=0)
    return acc / len(offs)

res = {}
prev = 0.0; prevstep = 0.0
for i in range(0, 70):
    obs = prof[i]
    guess = prev + prevstep - 0.55
    best = None
    for w in np.arange(0, 40, 1.0):
        for s in np.arange(guess - 4, guess + 4, 0.25):
            m = model(s, w)
            mask = np.ones(W, bool)
            e = ((m - obs)**2).sum()
            if best is None or e < best[0]: best = (e, s, w)
    # refine
    e0, s0, w0 = best
    for w in np.arange(max(0, w0 - 1), w0 + 1.01, 0.2):
        for s in np.arange(s0 - 0.3, s0 + 0.31, 0.05):
            e = ((model(s, w) - obs)**2).sum()
            if e < best[0]: best = (e, s, w)
    res[i] = best[1:]
    prevstep = best[1] - prev; prev = best[1]
    print(i, round(best[1], 2), round(best[2], 1), round(prevstep, 2), flush=True)
np.save('car_shift.npy', np.array([res[i] for i in range(70)]))
