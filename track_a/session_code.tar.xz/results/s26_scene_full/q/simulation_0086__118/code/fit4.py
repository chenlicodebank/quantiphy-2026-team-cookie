import numpy as np
d=np.loadtxt('edges.csv',delimiter=',');F,X0,X1=d.T
M=(X0+X1)/2
for lo,hi in [(2,57),(2,30),(15,45),(30,57),(2,20),(20,40),(40,57)]:
    m=(F>=lo)&(F<=hi)&np.isfinite(M); p=np.polyfit(F[m],M[m],2)
    print(lo,hi,'mid acc',round(-2*p[0],4),'rms',round((M[m]-np.polyval(p,F[m])).std(),3),'v=0 at',round(-p[1]/(2*p[0]),2))
# constrained: rest until t0, then 0.5 a (t-t0)^2 ; grid over t0
from scipy.optimize import least_squares
m=(F>=0)&(F<=57)
def res(q):
    x0,a,t0=q; tt=np.clip(F[m]-t0,0,None); return M[m]-(x0-0.5*a*tt**2)
r=least_squares(res,[1095,0.55,1.5]);print('constrained', r.x, np.std(r.fun))
def res3(q):
    x0,a,j,t0=q; tt=np.clip(F[m]-t0,0,None); return M[m]-(x0-0.5*a*tt**2-j*tt**3/6)
r=least_squares(res3,[1095,0.5,0.001,1.5]);print('with jerk', r.x, np.std(r.fun))
