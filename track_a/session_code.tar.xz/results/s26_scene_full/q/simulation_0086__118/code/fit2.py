import numpy as np, csv
d=np.loadtxt('edges.csv',delimiter=',');F,X0,X1=d.T
def fit(arr,lo,hi):
    m=(F>=lo)&(F<=hi)&np.isfinite(arr); p=np.polyfit(F[m],arr[m],2); return round(2*p[0],4),round((arr[m]-np.polyval(p,F[m])).std(),3)
for lo,hi in [(2,12),(12,24),(24,36),(36,48),(44,56),(48,57)]:
    print(lo,hi,'front',fit(X0,lo,hi),'rear',fit(X1,lo,hi))
for lo,hi in [(56,68),(58,69)]: print(lo,hi,'rear',fit(X1,lo,hi))
# cyclist steps vs x
r=list(csv.DictReader(open('scene/tracks/cyclist.csv')))
f=np.array([int(x['frame']) for x in r]);x0=np.array([float(x['x0']) for x in r]);x1=np.array([float(x['x1']) for x in r])
print('cyc x0',x0[:60:4]);print('cyc x1',x1[:60:4])
m=(f>=2)&(f<=57);print('cyc lin fit resid', np.polyfit(f[m],x0[m],2))
