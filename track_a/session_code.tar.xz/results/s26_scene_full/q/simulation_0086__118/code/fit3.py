import numpy as np
d=np.loadtxt('edges.csv',delimiter=',');F,X0,X1=d.T
s0=-np.diff(X0);s1=-np.diff(X1);G=F[1:]
for nm,s,lo,hi in [('front',s0,3,57),('rear',s1,3,57),('rear',s1,3,69),('front',s0,3,30),('front',s0,30,57)]:
    m=(G>=lo)&(G<=hi)&np.isfinite(s); p=np.polyfit(G[m],s[m],1); p2=np.polyfit(G[m],s[m],2)
    print(nm,lo,hi,'slope',round(p[0],4),'zero at',round(-p[1]/p[0],2),'quad',np.round(p2,5))
# cubic position fit
for nm,X,lo,hi in [('front',X0,2,57),('rear',X1,2,69)]:
    m=(F>=lo)&(F<=hi)&np.isfinite(X); p=np.polyfit(F[m],X[m],3)
    print(nm,'cubic',p, 'acc at 10,30,50', [round(-(6*p[0]*t+2*p[1]),3) for t in (10,30,50)])
