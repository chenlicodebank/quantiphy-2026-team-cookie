import av,numpy as np
c=av.open('simulation_0086.mp4')
fr=[f.to_ndarray(format='gray').astype(float)[540:760] for f in c.decode(video=0)]
bg=fr[71]
F=[];X0=[];X1=[]
for i in range(0,70):
    d=np.abs(fr[i]-bg)>30
    prof=d[:, :].mean(axis=0)  # fraction of rows in band per column
    # use body core rows only (exclude mirrors): rows of car centre band
    core=d[652-540-60:652-540+60].mean(axis=0)
    cols=np.where(core>0.5)[0]
    if len(cols)==0: continue
    # subpixel left edge: first crossing of 0.5
    j=cols[0]
    xl=j-1+(0.5-core[j-1])/(core[j]-core[j-1]) if j>0 else np.nan
    k=cols[-1]
    xr=k+(core[k]-0.5)/(core[k]-core[k+1]) if k<1919 else np.nan
    F.append(i);X0.append(xl);X1.append(xr)
F=np.array(F);X0=np.array(X0);X1=np.array(X1)
np.savetxt('edges.csv',np.c_[F,X0,X1],delimiter=',',fmt='%.3f',header='frame,front,rear')
for i in range(len(F)): print(F[i],round(X0[i],2),round(X1[i],2),round(X1[i]-X0[i],2))
def fit(arr,lo,hi):
    m=(F>=lo)&(F<=hi)&np.isfinite(arr); p=np.polyfit(F[m],arr[m],2); return 2*p[0],(arr[m]-np.polyval(p,F[m])).std()
for lo,hi in [(2,56),(2,20),(10,30),(20,40),(30,56),(40,56)]:
    print('front',lo,hi,fit(X0,lo,hi))
for lo,hi in [(2,68),(2,40),(40,68),(50,68)]:
    print('rear',lo,hi,fit(X1,lo,hi))
# per-frame step and second differences
s=np.diff(X0); print('front steps',np.round(s,2))
