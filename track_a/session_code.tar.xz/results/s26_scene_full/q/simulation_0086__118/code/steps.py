import numpy as np
d=np.loadtxt('edges.csv',delimiter=',');F,X0,X1=d.T
s0=-np.diff(X0);s1=-np.diff(X1)
for i in range(1,len(F)):
    print(int(F[i]),round(s0[i-1],2),round(s1[i-1],2), 'model0.53:',round(0.53*(F[i]-1.5),2))
