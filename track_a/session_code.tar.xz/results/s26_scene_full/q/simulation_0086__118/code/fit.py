import csv,numpy as np
r=list(csv.DictReader(open('scene/tracks/car.csv')))
f=np.array([int(x['frame']) for x in r]);x0=np.array([float(x['x0']) for x in r]);x1=np.array([float(x['x1']) for x in r])
for name,arr,lo,hi in [('x0',x0,2,56),('x0',x0,2,30),('x0',x0,30,56),('x1',x1,2,68),('x1',x1,2,40),('x1',x1,40,68)]:
    m=(f>=lo)&(f<=hi); p=np.polyfit(f[m],arr[m],2); res=arr[m]-np.polyval(p,f[m])
    print(name,lo,hi,'acc px/f2',2*p[0],'rms',res.std(), 'v at f1', np.polyval(np.polyder(p),1))
