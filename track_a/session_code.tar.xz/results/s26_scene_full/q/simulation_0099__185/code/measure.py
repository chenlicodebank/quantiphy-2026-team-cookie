import av, numpy as np
c = av.open('simulation_0099.mp4')
for i, fr in enumerate(c.decode(video=0)):
    if i not in (0, 10, 30, 47): continue
    a = fr.to_ndarray(format='rgb24').astype(int)
    # shark: underwater band, differs from flat blue
    sub = a[680:1080]
    bg = np.median(sub.reshape(-1, 3), axis=0)
    m = np.abs(sub - bg).sum(2) > 40
    ys, xs = np.nonzero(m)
    print(i, 'shark x', xs.min(), xs.max(), xs.max() - xs.min() + 1, 'y', ys.min() + 680, ys.max() + 680)
    # boat: above y=610, differs from sky (column-wise sky estimated at far right x>1800 when free)
    top = a[300:612]
    sky = np.median(a[300:612, 1850:1920], axis=1)  # per-row sky colour
    mb = np.abs(top - sky[:, None, :]).sum(2) > 40
    cols = np.nonzero(mb.sum(0) > 2)[0]
    print(i, 'boat x', cols.min(), cols.max(), cols.max() - cols.min() + 1)
