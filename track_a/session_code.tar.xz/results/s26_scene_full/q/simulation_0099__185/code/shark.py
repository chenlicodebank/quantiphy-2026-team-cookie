import av, numpy as np
c = av.open('simulation_0099.mp4')
for i, fr in enumerate(c.decode(video=0)):
    if i not in (0, 10, 30, 47, 60): continue
    a = fr.to_ndarray(format='rgb24').astype(int)
    sub = a[830:1000]
    bg = np.median(sub, axis=1)  # per-row background colour
    for th in (30, 60):
        m = np.abs(sub - bg[:, None, :]).sum(2) > th
        cols = np.nonzero(m.sum(0) > 0)[0]
        print(i, th, 'shark x', cols.min(), cols.max(), cols.max() - cols.min() + 1)
