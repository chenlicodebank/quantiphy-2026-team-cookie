import av, numpy as np, cv2
c = av.open('simulation_0080.mp4')
for i, f in enumerate(c.decode(video=0)):
    if i == 12:
        img = f.to_ndarray(format='rgb24').astype(int)
        break
g = img.mean(2); bg = np.median(g)
# bike: cyan pixels
cy = (img[:, :, 2] - img[:, :, 0] > 40)
ys, xs = np.nonzero(cy)
print('bike x', xs.min(), xs.max(), 'len', xs.max() - xs.min() + 1, 'y', ys.min(), ys.max())
bx = (xs.min() + xs.max()) / 2
byc = np.median(ys[(xs > xs.min() + 5) & (xs < xs.min() + 60)])
byr = np.median(ys[(xs < xs.max() - 5) & (xs > xs.max() - 30)])
print('bike centre x', bx, 'front-wheel y', byc, 'rear y', byr)
# walker region
x0, y0 = 900, 300
sub = img[y0:600, x0:1300]
d = np.abs(sub - np.median(sub.reshape(-1, 3), 0)).sum(2)
m = (d > 30).astype(np.uint8)
m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((7, 7), np.uint8))
n, l, st, cen = cv2.connectedComponentsWithStats(m)
k = 1 + np.argmax(st[1:, 4])
print('walker bbox', st[k, 0] + x0, st[k, 1] + y0, st[k, 0] + st[k, 2] + x0, st[k, 1] + st[k, 3] + y0, 'centroid', cen[k] + [x0, y0])
sh = (sub.mean(2) > bg + 12) & (np.abs(sub[:, :, 0] - sub[:, :, 2]) < 25)
ys2, xs2 = np.nonzero(sh)
print('shirt', xs2.min() + x0, xs2.max() + x0, ys2.min() + y0, ys2.max() + y0, 'mean', xs2.mean() + x0, ys2.mean() + y0)
dark = (sub.mean(2) < 80)
ys3, xs3 = np.nonzero(dark)
print('dark (hair/shoes)', xs3.mean() + x0, ys3.mean() + y0)
