import av, numpy as np, cv2
# Yellow truck: mask by saturation/dark within rows 375-430 (core band), measure front/rear x per frame,
# and x-shift by cross-correlating column profiles.
c = av.open('simulation_0082.mp4')
prof = {}; ext = {}
for i, fr in enumerate(c.decode(video=0)):
    img = fr.to_ndarray(format='rgb24')
    band = img[375:431].astype(np.int16)
    hsv = cv2.cvtColor(img[375:431], cv2.COLOR_RGB2HSV)
    m = (hsv[..., 1] > 50) | (band.min(2) < 100)
    cols = np.where(m.mean(0) > 0.3)[0]
    ext[i] = (cols.min(), cols.max())
    prof[i] = img[360:445].astype(float).mean(axis=(0, 2))
c.close()
def shift(a, b):
    a = a - a.mean(); b = b - b.mean()
    cc = np.correlate(b, a, 'full'); k = np.argmax(cc)
    y0, y1, y2 = cc[k-1], cc[k], cc[k+1]
    return k - (len(a) - 1) + 0.5 * (y0 - y2) / (y0 - 2*y1 + y2)
for i in range(20, 29):
    print(i, ext[i], ext[i][1]-ext[i][0]+1, round(shift(prof[i-1], prof[i]), 2))
s = [shift(prof[i-1], prof[i]) for i in range(2, 72)]
print('mean shift 2-71', np.mean(s), 'frames 20-28', np.mean(s[18:27]))
L = [ext[i][1]-ext[i][0]+1 for i in range(72)]
print('length f24', L[24], 'median', np.median(L), 'min', min(L))
