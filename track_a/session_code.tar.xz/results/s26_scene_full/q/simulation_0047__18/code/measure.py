import av, numpy as np, cv2, csv
V = '/private/tmp/qp_blind/scene_full_b/simulation_0047/q_18/simulation_0047.mp4'
frames = []
with av.open(V) as c:
    for fr in c.decode(video=0):
        g = fr.to_ndarray(format='gray')
        # keep only the strip containing both movers (y 250-540)
        frames.append(g[250:540].astype(np.float32))
print(len(frames))

def track(ref_f, box, search_pad, flist):
    x0, y0, x1, y1 = box
    tmpl = frames[ref_f][y0-250:y1-250, x0:x1]
    out = {}
    for f in flist:
        res = cv2.matchTemplate(frames[f], tmpl, cv2.TM_CCOEFF_NORMED)
        _, mv, _, ml = cv2.minMaxLoc(res)
        x, y = ml
        dx = dy = 0
        if 0 < x < res.shape[1]-1:
            a, b, cc = res[y, x-1], res[y, x], res[y, x+1]
            dx = 0.5*(a-cc)/(a-2*b+cc)
        if 0 < y < res.shape[0]-1:
            a, b, cc = res[y-1, x], res[y, x], res[y+1, x]
            dy = 0.5*(a-cc)/(a-2*b+cc)
        out[f] = (x+dx+(x1-x0)/2, y+dy+250+(y1-y0)/2, mv)
    return out

# cyclist at f33: box around bike+rider
cyc = track(33, (1110, 445, 1265, 500), 0, range(20, 50))
xs = np.array([cyc[f][0] for f in range(20, 50)]); ys = np.array([cyc[f][1] for f in range(20, 50)])
st = np.hypot(np.diff(xs), np.diff(ys))
print('cyc steps', np.round(st, 2), 'scores', np.round([cyc[f][2] for f in range(20,50)],2))
fs = np.arange(20, 50)
px = np.polyfit(fs, xs, 1); py = np.polyfit(fs, ys, 1)
print('cyc fit px/frame', np.hypot(px[0], py[0]), 'step at f33', st[33-21])

# pedestrian: templates at several frames, full clip
for rf in (10, 33, 60, 85):
    # locate ped at rf from scene track
    r = {int(float(a['frame'])): a for a in csv.DictReader(open('scene/tracks/pedestrian.csv'))}
    cx, cy = float(r[rf]['ref_x']), float(r[rf]['ref_y'])
    box = (int(cx-28), int(cy-28), int(cx+28), int(cy+28))
    ped = track(rf, box, 0, range(99))
    xs = np.array([ped[f][0] for f in range(99)]); ys = np.array([ped[f][1] for f in range(99)])
    st = np.hypot(np.diff(xs), np.diff(ys))
    # per-gait-cycle (~34 frames = 2 steps) windows
    print('ped tmpl', rf, 'mean step', st.mean(), 'net/98', np.hypot(xs[-1]-xs[0], ys[-1]-ys[0])/98,
          'f3-71', np.hypot(xs[71]-xs[3], ys[71]-ys[3])/68, 'minscore', min(ped[f][2] for f in range(99)))
