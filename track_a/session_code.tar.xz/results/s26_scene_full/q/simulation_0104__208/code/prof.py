import av, numpy as np
c = av.open('simulation_0104.mp4'); fr = []
for i, f in enumerate(c.decode(video=0)):
    if i in (27, 28, 29, 30): fr.append(f.to_ndarray(format='rgb24').astype(float))
im = np.mean(fr, 0)
np.save('stillA.npy', im[280:420, 650:1300].astype(np.float32))
bg = im[100:200, 100:300].reshape(-1, 3).mean(0)
d = np.abs(im - bg).sum(2)
print('bg', bg)
xs = list(range(684, 800, 4)) + list(range(800, 1240, 20)) + list(range(1240, 1262, 2))
for x in xs:
    col = d[300:400, x]; m = col > 40
    ys = np.where(m)[0]
    if len(ys) == 0: print(x, 'none'); continue
    print(x, ys.min() + 300, ys.max() + 300, len(ys), np.round(im[ys.min() + 300 + 3, x]).astype(int))
