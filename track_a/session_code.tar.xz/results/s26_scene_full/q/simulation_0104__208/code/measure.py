import av, numpy as np
c = av.open('simulation_0104.mp4')
bg = None
top = {}; ext = {}; mid = {}
for i, f in enumerate(c.decode(video=0)):
    im = f.to_ndarray(format='rgb24').astype(float)
    if bg is None: bg = im[100:200, 100:300].reshape(-1, 3).mean(0)
    d = np.abs(im - bg).sum(2)
    # top edge: strip x 700-780 (end face) and 900-1050 (side face), sub-pixel via fraction of column
    full = np.median(d[:, 700:780][d[:, 700:780] > 60]) if i == 0 else full
    col = d[:, 700:780].mean(1)
    rows = np.where(col > 40)[0]
    r0 = rows.min()
    # sub-pixel top: r0 - fraction of the row above
    t = r0 - np.clip(col[r0 - 1] / col[r0 + 3], 0, 1)
    top[i] = t
    # horizontal extent on rows through the phone middle (top+6 .. top+16)
    rr = slice(int(r0) + 6, int(r0) + 17)
    prof = d[rr, :].mean(0)
    xs = np.where(prof > 40)[0]
    # restrict to the phone run containing x=973
    lev = np.median(prof[700:780])
    lev2 = np.median(prof[900:1050])
    xl = xs.min(); xr = xs.max()
    fl = xl - np.clip(prof[xl - 1] / lev, 0, 1)
    fr = xr + np.clip(prof[xr + 1] / lev2, 0, 1)
    # boundary end-face / side-face: largest brightness jump between 770 and 810
    g = im[rr, :, :].mean(2).mean(0)
    j = 770 + np.argmax(np.abs(np.diff(g[770:810])))
    ext[i] = (fl, fr, fr - fl + 1 - 1, j + 0.5)
for i in range(31):
    print(i, round(top[i], 2), [round(v, 2) for v in ext[i]])
t = np.array([top[i] for i in range(31)])
v = -np.diff(t)
print('per-frame dy', np.round(v, 2))
mv = v[1:27]
print('moving frames 1..27 mean px/frame', mv.mean(), 'std', mv.std(), 'total', t[1] - t[27], (t[1] - t[27]) / 26)
