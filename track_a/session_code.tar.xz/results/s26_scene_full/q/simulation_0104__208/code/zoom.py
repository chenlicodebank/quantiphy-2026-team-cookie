import numpy as np
from PIL import Image
im = np.load('stillA.npy')  # rows 280:420, cols 650:1300
def save(x0, x1, y0, y1, s, name, stretch=True):
    a = im[y0 - 280:y1 - 280, x0 - 650:x1 - 650]
    if stretch:
        lo, hi = np.percentile(a, 1), np.percentile(a, 99)
        a = np.clip((a - lo) / (hi - lo) * 255, 0, 255)
    img = Image.fromarray(a.astype(np.uint8)).resize(((x1 - x0) * s, (y1 - y0) * s), Image.NEAREST)
    img.save(name)
save(680, 800, 325, 365, 8, 'frames/zl.png')
save(1040, 1260, 325, 365, 5, 'frames/zr.png')
