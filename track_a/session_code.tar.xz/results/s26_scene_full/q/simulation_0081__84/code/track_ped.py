import av, numpy as np, cv2, csv
V = '/private/tmp/qp_blind/scene_full_b/simulation_0081/q_84/simulation_0081.mp4'
head = {int(r['frame']): (float(r['ref_x']), float(r['ref_y'])) for r in csv.DictReader(open('/private/tmp/qp_blind/scene_full_b/simulation_0081/q_84/scene/tracks/pedestrian.csv'))}
c = av.open(V)
rows = []
for i, fr in enumerate(c.decode(video=0)):
    img = fr.to_ndarray(format='rgb24').astype(np.int32)
    sub = img[330:560, 0:700]
    r, g, b = sub[..., 0], sub[..., 1], sub[..., 2]
    mx = sub.max(-1); mn = sub.min(-1)
    # white shirt: bright, low saturation
    shirt = (b - r >= 6) & (mn > 135) & (b - g >= 3)
    shirt = cv2.morphologyEx(shirt.astype(np.uint8), cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    n, lab, st, cen = cv2.connectedComponentsWithStats(shirt)
    k = 1 + np.argmax(st[1:, 4])
    ys, xs = np.nonzero(lab == k)
    sx, sy = xs.mean(), ys.mean() + 330
    # whole figure mask (dark or bright vs bg 151)
    gray = sub.mean(-1)
    fg = (np.abs(gray - 151) > 25) | (mx - mn > 40)
    fg = cv2.morphologyEx(fg.astype(np.uint8), cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    n2, lab2, st2, _ = cv2.connectedComponentsWithStats(fg)
    k2 = 1 + np.argmax(st2[1:, 4])
    ys2, xs2 = np.nonzero(lab2 == k2)
    rows.append((i, sx, sy, len(xs), xs.min(), xs.max(), xs2.mean(), head[i][0]))
    if i == 12:
        vis = img[330:560, 0:700].astype(np.uint8).copy()
        vis[lab == k] = (vis[lab == k] * 0.5 + np.array([255, 0, 0]) * 0.5).astype(np.uint8)
        cv2.circle(vis, (int(sx), int(sy - 330)), 4, (0, 255, 0), -1)
        cv2.circle(vis, (int(head[i][0]), int(head[i][1] - 330)), 4, (0, 0, 255), -1)
        cv2.imwrite('/private/tmp/qp_blind/scene_full_b/simulation_0081/q_84/frames/shirt12.png', cv2.resize(vis[:, :, ::-1], None, fx=2, fy=2))
prev = None
for r in rows:
    d = '' if prev is None else '%6.1f %6.1f %6.1f' % (r[1] - prev[1], r[6] - prev[6], r[7] - prev[7])
    print('%2d shirt=(%.1f,%.1f) n=%d x[%d,%d] fgcx=%.1f head=%.1f  steps shirt/fg/head: %s' % (*r, d))
    prev = r
