import av, numpy as np
V = '/private/tmp/qp_blind/scene_full_b/simulation_0081/q_84/simulation_0081.mp4'
c = av.open(V)
for i, fr in enumerate(c.decode(video=0)):
    if i == 12:
        img = fr.to_ndarray(format='rgb24')
        print(img.shape)
        for y in (410, 470, 490):
            print(y, [tuple(img[y, x]) for x in range(150, 320, 10)])
        break
