import av, numpy as np, cv2
# Independent check: car body mask (peach paint) bbox in horizontal frames, plus centroid steps near f60
want = set(range(54, 72))
res = {}
c = av.open('simulation_0070.mp4')
for i, fr in enumerate(c.decode(video=0)):
    if i in want:
        a = fr.to_ndarray(format='rgb24').astype(int)
        R, G, B = a[..., 0], a[..., 1], a[..., 2]
        m = ((R - B > 22) & (R > 180)).astype(np.uint8)
        m[:, :1050] = 0; m[:450] = 0; m[750:] = 0  # region around the car on the horizontal road
        n, lab, st, cen = cv2.connectedComponentsWithStats(m)
        k = 1 + np.argmax(st[1:, cv2.CC_STAT_AREA])
        ys, xs = np.nonzero(lab == k)
        res[i] = (xs.min(), xs.max(), ys.min(), ys.max(), (xs.min() + xs.max()) / 2, (ys.min() + ys.max()) / 2)
        print(i, res[i])
    if i >= 71:
        break
for i in range(55, 72):
    print(i, 'bbox-centre step', round(np.hypot(res[i][4] - res[i-1][4], res[i][5] - res[i-1][5]), 2))
L = np.mean([res[i][1] - res[i][0] + 1 for i in range(66, 72)])
print('length px (f66-71)', L)
step = np.hypot(res[64][4] - res[56][4], res[64][5] - res[56][5]) / 8
print('mean step f56-64', step, 'speed', step / L * 5.44 * 24)
