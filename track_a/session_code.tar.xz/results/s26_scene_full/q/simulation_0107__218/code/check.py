# Independent check: centroid of the non-background (body+spike) pixels per object, frames 4..22
# (all spikes fully in frame until frame 24), split by image column midline between objects.
import av, numpy as np, cv2
p='/private/tmp/qp_blind/scene_full_b/simulation_0107/q_218/simulation_0107.mp4'
c=av.open(p); res={}
for i,fr in enumerate(c.decode(video=0)):
    if i>22: break
    if i<3: continue
    a=fr.to_ndarray(format='rgb24').astype(int)
    m=(np.abs(a-206).sum(-1)>40).astype(np.uint8)
    n,lab,st,cen=cv2.connectedComponentsWithStats(m)
    order=np.argsort(st[1:,cv2.CC_STAT_AREA])[-2:]+1
    cs=sorted([tuple(cen[k]) for k in order])  # (x,y), sorted by x
    res[i]=cs
fs=np.array(sorted(res)); L=np.array([res[i][0] for i in fs]); R=np.array([res[i][1] for i in fs])
out={}
for nm,P in [('left',L),('right',R)]:
    vx=np.polyfit(fs,P[:,0],1)[0]; vy=np.polyfit(fs,P[:,1],1)[0]
    out[nm]=np.hypot(vx,vy); print(nm,vx,vy,out[nm])
print('ratio',out['left']/out['right'],'answer',1.7393*out['left']/out['right'])
