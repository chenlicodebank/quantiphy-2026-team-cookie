import csv, numpy as np
import os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
def f(x):
    try: return float(x)
    except: return np.nan
for n in ['virus_small_left','virus_large_right']:
    r=list(csv.DictReader(open(f'scene/tracks/{n}.csv')))
    cx=np.array([f(x['cx']) for x in r]); cy=np.array([f(x['cy']) for x in r])
    bx=np.array([f(x['cx_bodyfit']) for x in r]); by=np.array([f(x['cy_bodyfit']) for x in r])
    tx=np.array([f(x['cx_template']) for x in r]); ty=np.array([f(x['cy_template']) for x in r])
    s=np.hypot(np.diff(cx),np.diff(cy)); sb=np.hypot(np.diff(bx),np.diff(by)); st=np.hypot(np.diff(tx),np.diff(ty))
    print(n,'speed i=24',s[23],'bodyfit',sb[23],'tmpl',st[23])
    print(' mean cx 2..30',s[1:30].mean(),' lin fit 1..30:',np.polyfit(np.arange(1,31),cx[1:31],1)[0],np.polyfit(np.arange(1,31),cy[1:31],1)[0])
    print(' steps 18-30',np.round(s[17:30],2))
