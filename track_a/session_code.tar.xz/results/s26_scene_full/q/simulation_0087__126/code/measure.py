import av, numpy as np
c = av.open('/private/tmp/qp_blind/scene_full_a/simulation_0087/q_126/simulation_0087.mp4')
fr = []
for i, f in enumerate(c.decode(video=0)):
    g = f.to_ndarray(format='gray').astype(float)
    band = g[560:820]
    m = np.abs(band - 140) > 38
    cols = m.sum(0)
    idx = np.where(cols >= 20)[0]
    x0 = idx[0]; x1 = idx[-1]
    # subpixel front edge: column-mean profile over body rows 620-750
    prof = np.abs(g[620:750] - 140).mean(0)
    # find crossing of half level between bg (~0) and body plateau near x0
    lvl = 0.5 * np.median(prof[x0 + 5:x0 + 40])
    j = x0 - 5
    while prof[j] < lvl: j += 1
    sx0 = j - 1 + (lvl - prof[j - 1]) / (prof[j] - prof[j - 1])
    rows = m[:, x0:x1 + 1].sum(1)
    ry = np.where(rows >= 5)[0]
    # body-only width: rows profile over columns where mirrors absent (front hood region)
    fr.append((i, x0, x1, sx0, ry[0] + 560, ry[-1] + 560))
    print(i, x0, x1, round(sx0, 2), ry[0] + 560, ry[-1] + 560)
np.save('/private/tmp/qp_blind/scene_full_a/simulation_0087/q_126/edges.npy', np.array(fr))
