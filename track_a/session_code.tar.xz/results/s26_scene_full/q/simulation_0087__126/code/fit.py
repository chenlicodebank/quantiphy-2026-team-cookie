import numpy as np
e = np.load('/private/tmp/qp_blind/scene_full_a/simulation_0087/q_126/edges.npy')
f = e[:, 0]; x0 = e[:, 1]; x1 = e[:, 2]; sx0 = e[:, 3]
for name, s, a, b in [('x0', x0, 2, 54), ('x0 10-53', x0, 10, 54), ('x0 2-30', x0, 2, 31), ('sx0', sx0, 2, 54), ('x1', x1, 37, 54)]:
    p = np.polyfit(f[a:b], s[a:b], 2)
    r = s[a:b] - np.polyval(p, f[a:b])
    print(name, 'acc px/fr^2 =', 2 * p[0], 'rms', r.std(), 'v0 at f1', np.polyval(np.polyder(p), 1))
# piecewise check: speed differences
v = -np.diff(x0)
print(v)
# start-at-rest fit: x = x(1) - 0.5 a (f-1)^2 with t0 free
from scipy.optimize import curve_fit
fn = lambda t, X, a, t0: X - 0.5 * a * np.clip(t - t0, 0, None) ** 2
p, _ = curve_fit(fn, f, x0, p0=[1789, 0.7, 1])
print('rest fit', p)
p, _ = curve_fit(fn, f[37:], x1[37:], p0=[2370, 0.7, 1])
print('rest fit x1', p)
