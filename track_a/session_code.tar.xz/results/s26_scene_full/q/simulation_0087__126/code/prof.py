import av, numpy as np
D = '/private/tmp/qp_blind/scene_full_a/simulation_0087/q_126/'
c = av.open(D + 'simulation_0087.mp4')
for i, f in enumerate(c.decode(video=0)):
    if i == 53:
        g = f.to_ndarray(format='gray').astype(int); break
for x in (880, 1000, 1100, 1250, 1350):
    print(x, 'top', list(g[560:600, x]))
    print(x, 'bot', list(g[780:820, x]))
