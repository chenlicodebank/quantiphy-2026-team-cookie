import av, numpy as np
D = '/private/tmp/qp_blind/scene_full_a/simulation_0087/q_126/'
e = np.load(D + 'edges.npy')
c = av.open(D + 'simulation_0087.mp4')
res = []
for i, f in enumerate(c.decode(video=0)):
    if i < 37: continue
    g = f.to_ndarray(format='gray').astype(float)
    x0, x1 = int(e[i, 1]), int(e[i, 2])
    m = np.abs(g[540:840, x0:x1 + 1] - 140) > 30
    # per-column top and bottom extents
    top = []; bot = []
    for j in range(m.shape[1]):
        ys = np.where(m[:, j])[0]
        if len(ys): top.append(ys[0]); bot.append(ys[-1])
    top = np.array(top) + 540; bot = np.array(bot) + 540
    # body-only: exclude mirror columns (mirrors are thin protrusions near x0+~110..170)
    L = x1 - x0
    sel = np.r_[0:int(0.15 * L), int(0.35 * L):len(top)]
    res.append((i, top.min(), bot.max(), np.percentile(top[sel], 1), np.percentile(bot[sel], 99), bot.max() - top.min() + 1, np.percentile(bot[sel], 99) - np.percentile(top[sel], 1) + 1))
for r in res: print(r)
r = np.array(res); print('mirror width', np.median(r[:, 5]), 'body width', np.median(r[:, 6]))
