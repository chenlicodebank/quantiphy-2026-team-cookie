import av, numpy as np, cv2
D = '/private/tmp/qp_blind/scene_full_a/simulation_0087/q_126/'
c = av.open(D + 'simulation_0087.mp4')
G = [f.to_ndarray(format='gray').astype(np.float32)[540:840] for f in c.decode(video=0)]
e = np.load(D + 'edges.npy')
x0 = e[:, 1].astype(int)

def sub(r, k):
    a, b, cc = r[k - 1], r[k], r[k + 1]
    return k + 0.5 * (a - cc) / (a - 2 * b + cc)

# frame-to-frame shift of the front 120 px of the car (template from frame i, searched in i+1)
d = [0.0]
for i in range(1, 53):
    L = x0[i] - 5
    tpl = G[i][:, L:L + 130]
    lo = L - 60
    srch = G[i + 1][:, lo:L + 135]
    r = cv2.matchTemplate(srch, tpl, cv2.TM_CCOEFF_NORMED)[0]
    k = int(np.argmax(r))
    d.append(sub(r, k) + lo - L)
d = np.array(d)  # d[i-1] = shift from frame i to i+1 ... index: d[j] for j=1..52 is shift i=j -> j+1
pos = np.concatenate([[0], np.cumsum(d[1:])])  # position relative to frame1, at frames 1..53
fr = np.arange(1, 54)
print('steps', np.round(-d[1:], 2))
for a, b in [(1, 53), (5, 53), (1, 30), (25, 53)]:
    m = (fr >= a) & (fr <= b)
    p = np.polyfit(fr[m], pos[m], 2)
    print(a, b, 'acc', 2 * p[0], 'rms', (pos[m] - np.polyval(p, fr[m])).std())
# speed linear fit
v = -d[1:]; tv = np.arange(1.5, 53, 1.0)
p = np.polyfit(tv, v, 1); print('speed slope', p)
np.save(D + 'tm_pos.npy', pos)
