import av, numpy as np, cv2, csv
D = '/private/tmp/qp_blind/scene_full_a/simulation_0087/q_126/'
r = list(csv.DictReader(open(D + 'scene/tracks/cyclist.csv')))
c = av.open(D + 'simulation_0087.mp4')
G = [f.to_ndarray(format='gray').astype(np.float32)[330:530] for f in c.decode(video=0)]
def sub(rr, k):
    a, b, cc = rr[k - 1], rr[k], rr[k + 1]
    return k + 0.5 * (a - cc) / (a - 2 * b + cc)
st = []
for i in range(8, 53):
    x0 = int(float(r[i]['x0'])); x1 = int(float(r[i]['x1']))
    tpl = G[i][:, x0 - 5:x1 + 5]
    lo = x0 - 5 - 10
    srch = G[i + 1][:, lo:x1 + 5 + 40]
    rr = cv2.matchTemplate(srch, tpl, cv2.TM_CCOEFF_NORMED)[0]
    k = int(np.argmax(rr))
    st.append(sub(rr, k) + lo - (x0 - 5))
st = np.array(st)
print(np.round(st, 2))
print('first half mean', st[:22].mean(), 'second half', st[22:].mean())
