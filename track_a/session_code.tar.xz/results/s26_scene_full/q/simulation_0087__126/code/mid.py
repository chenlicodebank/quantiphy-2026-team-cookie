import numpy as np
D = '/private/tmp/qp_blind/scene_full_a/simulation_0087/q_126/'
e = np.load(D + 'edges.npy'); pos = np.load(D + 'tm_pos.npy')
f = e[37:, 0]; mid = (e[37:, 1] + e[37:, 2]) / 2
p = np.polyfit(f, mid, 2); print('midpoint acc 37-53', 2 * p[0], 'rms', (mid - np.polyval(p, f)).std())
print('len', e[37:, 2] - e[37:, 1])
# constrained: known motion start; fit tm pos with model a*(t-t0)^2/2 over 1-40
fr = np.arange(1, 54)
for b in (30, 40, 53):
    m = fr <= b
    best = None
    for t0 in np.arange(-1, 2, 0.01):
        X = np.clip(fr[m] - t0, 0, None) ** 2 / 2
        A = np.vstack([X, np.ones_like(X)]).T
        s, res, *_ = np.linalg.lstsq(A, pos[m], rcond=None)
        r = ((A @ s - pos[m]) ** 2).sum()
        if best is None or r < best[0]: best = (r, t0, s)
    print('to', b, 'start', best[1], 'acc', -best[2][0], 'rms', np.sqrt(best[0] / m.sum()))
