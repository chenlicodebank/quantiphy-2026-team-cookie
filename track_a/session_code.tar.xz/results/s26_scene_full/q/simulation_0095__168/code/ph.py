import av, numpy as np
c = av.open('simulation_0095.mp4')
for i, fr in enumerate(c.decode(video=0)):
    if i in (8, 10, 12, 14):
        a = fr.to_ndarray(format='rgb24').astype(int)
        d = np.abs(a - np.array([132, 126, 135])).max(2)
        for th in (6, 15, 30):
            m = d[:545] > th
            ys = np.where(m.any(1))[0]; xs = np.where(m.any(0))[0]
            print(i, th, ys.min(), ys.max(), ys.max() - ys.min() + 1, xs.min(), xs.max())
    if i > 14:
        break
