import av, numpy as np, cv2
cont = av.open('simulation_0113.mp4')
for i, f in enumerate(cont.decode(video=0)):
    if i == 48:
        im = f.to_ndarray(format='bgr24'); break
g = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY).astype(float)
# horizontal profile averaged over rows 450-700 (away from ring), vertical over cols 480-720
ph = g[450:700, :].mean(0)
pv = g[:, 480:720].mean(1)
print('horiz x295..330', np.round(ph[295:330]).astype(int))
print('horiz x755..790', np.round(ph[755:790]).astype(int))
print('vert y290..330', np.round(pv[290:330]).astype(int))
print('vert y750..790', np.round(pv[750:790]).astype(int))
def cross(p, a, b, lvl):
    # subpixel crossing of level lvl between indices a..b (monotonic segment)
    for k in range(a, b):
        if (p[k]-lvl)*(p[k+1]-lvl) <= 0 and p[k] != p[k+1]:
            return k + (lvl-p[k])/(p[k+1]-p[k])
deck = np.median(ph[200:290]); print('deck level', deck, 'water', np.median(ph[400:700]))
