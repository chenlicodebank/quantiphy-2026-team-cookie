import av, numpy as np, cv2
# Radial half-level edge of the ring (saturation*value contrast vs water) over many angles and frames
cont = av.open('simulation_0113.mp4')
res = []
for i, f in enumerate(cont.decode(video=0)):
    if i % 10: continue
    im = f.to_ndarray(format='bgr24')
    hsv = cv2.cvtColor(im, cv2.COLOR_BGR2HSV).astype(float)
    sig = hsv[..., 1] * hsv[..., 2] / 255.0  # saturated & bright -> ring
    m = (sig > 60).astype(np.uint8); m[:300] = 0; m[600:] = 0; m[:, :300] = 0; m[:, 600:] = 0
    n, lab, st, cen = cv2.connectedComponentsWithStats(m)
    k = 1 + np.argmax(st[1:, 4]); cx, cy = cen[k]
    water = np.median(sig[(lab == 0)][:50000]) if False else np.median(sig[cy.astype(int)+60:cy.astype(int)+90, int(cx)-30:int(cx)+30])
    radii = []
    for th in np.linspace(0, 2*np.pi, 72, endpoint=False):
        r = np.arange(22, 50, 0.25)
        xs = cx + r*np.cos(th); ys = cy + r*np.sin(th)
        p = cv2.remap(sig.astype(np.float32), xs.astype(np.float32)[None], ys.astype(np.float32)[None], cv2.INTER_LINEAR)[0]
        top = np.percentile(p[:40], 80)
        lvl = (top + water) / 2
        idx = np.where(p > lvl)[0]
        if len(idx) == 0: continue
        j = idx[-1]
        if j+1 >= len(r): continue
        radii.append(r[j] + 0.25*(p[j]-lvl)/(p[j]-p[j+1]))
    radii = np.array(radii)
    res.append(2*np.median(radii))
    print(i, 'centre', round(cx,1), round(cy,1), 'diam median', round(2*np.median(radii),2), 'mean', round(2*radii.mean(),2))
print('overall', np.mean(res))
