import av, numpy as np, cv2
cont = av.open('simulation_0113.mp4')
frames = {}
for i, f in enumerate(cont.decode(video=0)):
    if i in (0, 60, 119):
        frames[i] = f.to_ndarray(format='bgr24')
    if i > 119: break

# ring diameter: saturated mask
for i, im in frames.items():
    hsv = cv2.cvtColor(im, cv2.COLOR_BGR2HSV)
    m = ((hsv[..., 1] > 90) & (hsv[..., 2] > 90)).astype(np.uint8)
    m[:300] = 0; m[780:] = 0; m[:, :300] = 0; m[:, 780:] = 0
    n, lab, st, cen = cv2.connectedComponentsWithStats(m)
    k = 1 + np.argmax(st[1:, 4])
    x, y, w, h, a = st[k]
    comp = (lab == k).astype(np.uint8)
    cs, _ = cv2.findContours(comp, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    c = max(cs, key=cv2.contourArea)
    filled = np.zeros_like(comp); cv2.drawContours(filled, [c], -1, 1, -1)
    A = filled.sum()
    print(i, 'bbox w,h', w, h, 'equiv diam', 2*np.sqrt(A/np.pi), 'ellipse', cv2.fitEllipse(c)[1])
    # half-max profile along rows/cols through centre using saturation
    s = hsv[..., 1].astype(float)
    cy, cx = int(round(y+h/2)), int(round(x+w/2))
    for name, prof, off in () and (('row', s[cy-2:cy+3, x-10:x+w+10].mean(0), x-10), ('col', s[y-10:y+h+10, cx-2:cx+3].mean(1), y-10)):
        bg = np.median(np.r_[prof[:6], prof[-6:]]); pk = np.percentile(prof, 90); half = (bg+pk)/2
        idx = np.where(prof > half)[0]
        # subpixel edges
        l = idx[0]; r = idx[-1]
        le = l-1 + (half-prof[l-1])/(prof[l]-prof[l-1]); re = r + (prof[r]-half)/(prof[r]-prof[r+1])
        print('  ', name, 'halfmax width', re-le)

# pool edges: grey profiles across the pool
im = frames[0]
g = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY).astype(float)
for y0 in (450, 550, 650):
    p = g[y0-3:y0+4, 280:810].mean(0)
    d = np.diff(p)
    print('row', y0, 'left edge cands', 280+np.argsort(d)[:3], 'right', 280+np.argsort(-d)[:3])
for x0 in (450, 550, 650):
    p = g[280:810, x0-3:x0+4].mean(1)
    d = np.diff(p)
    print('col', x0, 'top edge cands', 280+np.argsort(d)[:3], 'bottom', 280+np.argsort(-d)[:3])
print(np.round(g[540, 295:330]).astype(int))
print(np.round(g[540, 755:790]).astype(int))
print(np.round(g[295:330, 540]).astype(int))
print(np.round(g[750:785, 540]).astype(int))
