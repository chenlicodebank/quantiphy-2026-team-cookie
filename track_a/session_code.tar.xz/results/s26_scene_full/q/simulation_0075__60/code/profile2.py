import av, numpy as np, os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
def frames(ids):
    out={}
    c=av.open('simulation_0075.mp4')
    for k,f in enumerate(c.decode(video=0)):
        if k in ids: out[k]=f.to_ndarray(format='rgb24').astype(int)
        if k>=max(ids): break
    c.close(); return out
F=frames([0,36,71])
def edges(p, lo, hi):
    # p: brightness profile; find first/last crossing of 0.5*(lo+hi) with subpixel interp
    th=0.5*(lo+hi); idx=np.where(p>th)[0]; a,b=idx[0],idx[-1]
    ea=a-1+(th-p[a-1])/(p[a]-p[a-1]); eb=b+(p[b]-th)/(p[b]-p[b+1])
    return ea,eb
for k in (0,36,71):
    p=F[k][:,805:861].mean(axis=(1,2))
    # restrict to van region
    yc={0:929,36:735,71:199}[k]
    sub=p.copy(); sub[:max(0,yc-170)]=0; sub[yc+170:]=0
    ea,eb=edges(sub,163,242)
    print('van f%d'%k, round(ea,1), round(eb,1), 'len', round(eb-ea,1))
# purple rear: print per-row b-g and brightness across x 1425-1450 for several rows
img=F[0]
print('purple rear, rows; value = B-G (purple tint)')
for y in range(405,481,5):
    print(y, [int(img[y,x,2]-img[y,x,1]) for x in range(1428,1448)])
print('purple rear brightness rows')
for y in range(405,481,5):
    print(y, [int(img[y,x].mean()) for x in range(1428,1448)])
print('purple front brightness rows')
for y in range(405,481,5):
    print(y, [int(img[y,x].mean()) for x in range(1234,1252)])
