import av, numpy as np
import os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
def frame(i):
    c=av.open('simulation_0075.mp4')
    for k,f in enumerate(c.decode(video=0)):
        if k==i:
            a=f.to_ndarray(format='rgb24').astype(float); c.close(); return a
f0=frame(0); f36=frame(36); f71=frame(71)
road=np.median(f0[300:380,1500:1700].reshape(-1,3),axis=0); print('road',road)
# ax=1: car horizontal (length along x); ax=0: vertical (length along y)
for name,img,(y0,y1,x0,x1),ax in [('purple',f0,(405,480,1200,1480),1),('green',f0,(565,640,300,560),1),
                                   ('van36',f36,(560,900,795,870),0),('van71',f71,(40,360,795,870),0),('van0',f0,(760,1075,795,870),0)]:
    d=np.abs(img[y0:y1,x0:x1]-road).max(axis=2)
    if ax==1: p=np.percentile(d,80,axis=0); off=x0
    else: p=np.percentile(d,80,axis=1); off=y0
    for thr in (6,10,15,25):
        idx=np.where(p>thr)[0]
        print(name,thr,idx[0]+off,idx[-1]+off,idx[-1]-idx[0]+1)
