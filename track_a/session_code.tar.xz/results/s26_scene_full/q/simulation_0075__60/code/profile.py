import av, numpy as np, os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
def frame(i):
    c=av.open('simulation_0075.mp4')
    for k,f in enumerate(c.decode(video=0)):
        if k==i:
            a=f.to_ndarray(format='rgb24').astype(int); c.close(); return a
f0=frame(0); f36=frame(36)
# purple: mean RGB over rows 425-460 (central band), columns 1225-1460
print('purple ends (x: rgb)')
band=f0[425:461].mean(axis=0)
for x in list(range(1225,1255))+list(range(1425,1460)):
    print(x, band[x].round(0))
print('van36 ends (y: rgb), columns 805-860')
band=f36[:,805:861].mean(axis=1)
for y in list(range(590,625))+list(range(835,880)):
    print(y, band[y].round(0))
