# track car sub-regions (rear, roof, nose) separately: features at different heights move at different image rates
import av, numpy as np, cv2
fr = {}
c = av.open('simulation_0054.mp4')
for i, f in enumerate(c.decode(video=0)):
    if i > 90: break
    if i >= 20:
        fr[i] = cv2.cvtColor(f.to_ndarray(format='bgr24'), cv2.COLOR_BGR2GRAY).astype(np.float32)
ref = fr[60]
parts = {'rear': (576, 626), 'roof': (690, 760), 'nose': (820, 870), 'whole': (576, 868)}
res = {}
for name, (ya, yb) in parts.items():
    T = ref[ya:yb, 284:412].copy()
    ys = []
    fs = list(range(30, 91))
    for i in fs:
        r = cv2.matchTemplate(fr[i][:, 250:450], T, cv2.TM_CCOEFF_NORMED)
        _, mx, _, (x, y) = cv2.minMaxLoc(r)
        a, b, cc = r[y-1, x], r[y, x], r[y+1, x]
        ys.append(y + 0.5 * (a - cc) / (a - 2*b + cc) - ya)
    ys = np.array(ys); fs = np.array(fs)
    p = np.polyfit(fs, ys, 2)
    res[name] = p
    print(name, 'acc %.4f' % (2*p[0]), 'v@60 %.4f' % (2*p[0]*60 + p[1]), 'disp30-90 %.2f' % (ys[-1]-ys[0]), 'rms %.3f' % (ys - np.polyval(p, fs)).std())
