import numpy as np, cv2
bg = cv2.imread('scene/bg.png'); g = cv2.cvtColor(bg, cv2.COLOR_BGR2GRAY).astype(np.float32)
c = np.array([540., 540.])  # assumed principal point
outs = []
for name, (x0, y0) in {'upper': (205, 425), 'lower': (205, 880)}.items():
    roi = g[y0:y0+70, x0:x0+70]
    m = (roi < 60).astype(np.uint8)
    dt = cv2.distanceTransform(m, cv2.DIST_L2, 5)
    # local maxima of dt = centres of round lumps
    mx = cv2.dilate(dt, np.ones((7, 7), np.uint8))
    pk = np.argwhere((dt == mx) & (dt > 6))
    print(name, [(int(x + x0), int(y + y0), round(float(dt[y, x]), 1)) for y, x in pk])
    im = cv2.resize(bg[y0:y0+70, x0:x0+70], None, fx=8, fy=8, interpolation=cv2.INTER_CUBIC)
    for k in range(0, 70, 10):
        cv2.line(im, (k*8, 0), (k*8, 559), (0, 255, 255), 1); cv2.line(im, (0, k*8), (559, k*8), (0, 255, 255), 1)
    for y, x in pk:
        cv2.circle(im, (int(x*8+4), int(y*8+4)), 5, (0, 0, 255), -1)
    outs.append(im)
cv2.imwrite('frames/bases.png', np.hstack(outs))
