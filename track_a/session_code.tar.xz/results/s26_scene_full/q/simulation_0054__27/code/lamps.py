import numpy as np, cv2
bg = cv2.imread('scene/bg.png')
g = cv2.cvtColor(bg, cv2.COLOR_BGR2GRAY)
out = bg.copy()
for name, (x0, y0, x1, y1) in {'upper': (150, 400, 290, 520), 'lower': (150, 870, 290, 1020)}.items():
    roi = g[y0:y1, x0:x1]
    m = (roi < 60).astype(np.uint8)
    m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    n, lab, st, cen = cv2.connectedComponentsWithStats(m)
    print(name)
    for k in range(1, n):
        if st[k, 4] > 30:
            print('  comp', k, 'bbox', st[k, :4] + [x0, y0, 0, 0], 'area', st[k, 4], 'cent', np.round(cen[k] + [x0, y0], 1))
    # distance transform: thick parts (head and pole cap) vs thin arm
    dt = cv2.distanceTransform(m, cv2.DIST_L2, 5)
    thick = (dt > 5).astype(np.uint8)
    n2, lab2, st2, cen2 = cv2.connectedComponentsWithStats(thick)
    for k in range(1, n2):
        print('  thick', k, 'area', st2[k, 4], 'cent', np.round(cen2[k] + [x0, y0], 1), 'maxdt', dt[lab2 == k].max())
    cnt, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    cv2.drawContours(out[y0:y1, x0:x1], cnt, -1, (0, 0, 255), 1)
cv2.imwrite('frames/lamps_chk.png', cv2.resize(np.vstack([out[400:520, 150:290], out[880:1020, 150:290]]), None, fx=4, fy=4, interpolation=cv2.INTER_NEAREST))
