import av, numpy as np, cv2, json
fr = {}
c = av.open('simulation_0054.mp4')
for i, f in enumerate(c.decode(video=0)):
    if i > 90: break
    fr[i] = cv2.cvtColor(f.to_ndarray(format='bgr24'), cv2.COLOR_BGR2GRAY).astype(np.float32)
# template: orange car at frame 60, bbox 285..410 x, 576..867 y
T = fr[60][576:868, 284:412].copy()
ys = {}
for i in range(16, 91):
    img = fr[i][:, 250:450]
    r = cv2.matchTemplate(img, T, cv2.TM_CCOEFF_NORMED)
    _, mx, _, loc = cv2.minMaxLoc(r)
    x, y = loc
    def sub(a, b, cc):
        d = a - 2 * b + cc
        return 0.0 if d == 0 else 0.5 * (a - cc) / d
    dy = sub(r[y-1, x], r[y, x], r[y+1, x]) if 0 < y < r.shape[0]-1 else 0
    dx = sub(r[y, x-1], r[y, x], r[y, x+1]) if 0 < x < r.shape[1]-1 else 0
    ys[i] = (y + dy + 146, x + dx + 250 + 64, mx)
fs = np.array(sorted(ys)); y = np.array([ys[i][0] for i in fs]); s = np.array([ys[i][2] for i in fs])
for i in fs: print(i, '%.2f %.2f %.3f' % ys[i])
v = np.diff(y)
print('steps', np.round(v, 2))
for a, b in [(16, 90), (25, 90), (30, 90), (16, 55), (50, 90), (35, 75)]:
    m = (fs >= a) & (fs <= b)
    p = np.polyfit(fs[m], y[m], 2)
    res = y[m] - np.polyval(p, fs[m])
    print(a, b, 'acc px/f2 %.4f' % (2 * p[0]), 'rms %.2f' % res.std())
p3 = np.polyfit(fs, y, 3); print('cubic', p3)
json.dump({int(i): ys[i][0] for i in fs}, open('y_tm.json', 'w'))
