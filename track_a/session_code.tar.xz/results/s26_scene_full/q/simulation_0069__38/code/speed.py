import json, numpy as np
d = json.load(open('/private/tmp/qp_blind/scene_full_b/simulation_0069/q_38/meas.json'))
fps = 24.0
a_px = 162.15  # car accel px/s^2 (quadratic fit of front edge)
s = 4.0 / a_px
print('m/px', s)
for key in ('ped_white_x', 'ped_x'):
    x = np.array(d[key])
    for h in (4, 6, 8, 12):
        f = np.arange(24 - h, 24 + h + 1)
        v = np.polyfit(f, x[f], 1)[0]
        print(key, 'half-window', h, 'px/frame', round(v, 3), 'm/s', round(v * fps * s, 4))
    print(key, 'whole clip px/frame', np.polyfit(np.arange(72), x, 1)[0])
    print(key, 'backdiff at 24', x[24] - x[23])
