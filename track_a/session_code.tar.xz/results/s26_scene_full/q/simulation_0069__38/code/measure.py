import av, numpy as np, json
V = '/private/tmp/qp_blind/scene_full_b/simulation_0069/q_38/simulation_0069.mp4'
fps = 24.0
# collect crops: car column and pedestrian strip
carc, pedc = [], []
c = av.open(V)
for i, fr in enumerate(c.decode(video=0)):
    a = fr.to_ndarray(format='rgb24').astype(np.int16)
    carc.append(a[:, 760:910].copy())
    pedc.append(a[800:900, 1280:1520].copy())
c.close()
carc = np.array(carc); pedc = np.array(pedc)
n = len(carc)
# car: white pixels (all channels > 225, low saturation) in column crop
front, rear = [], []
for i in range(n):
    a = carc[i]
    m = (a.min(axis=2) > 215) & ((a.max(axis=2) - a.min(axis=2)) < 25)
    rows = np.where(m.sum(axis=1) > 25)[0]
    front.append(rows.min()); rear.append(rows.max())
front = np.array(front, float); rear = np.array(rear, float)
print('front', front.tolist())
print('len', (rear - front + 1).tolist())
t = np.arange(n) / fps
for lo in (3, 5, 10):
    sel = np.arange(lo, n)
    p = np.polyfit(t[sel], front[sel], 2)
    res = front[sel] - np.polyval(p, t[sel])
    print('car fit from', lo, 'a px/s^2 =', 2 * p[0], 'rms', res.std())
# also second-difference of speeds
v = np.diff(front) * fps
print('mean accel from speeds 10..70:', np.polyfit(t[11:], v[10:], 1)[0])
# pedestrian: background median subtraction
bg = np.median(pedc, axis=0)
xs, cxs = [], []
for i in range(n):
    d = np.abs(pedc[i] - bg).sum(axis=2)
    m = d > 60
    ys, xx = np.where(m)
    if len(xx) == 0:
        xs.append(np.nan); cxs.append(np.nan); continue
    # bright (white top) pixels for torso
    a = pedc[i]
    w = m & (a.min(axis=2) > 200)
    yw, xw = np.where(w)
    xs.append(xx.mean() + 1280)
    cxs.append(xw.mean() + 1280 if len(xw) else np.nan)
xs = np.array(xs); cxs = np.array(cxs)
print('ped mask centroid x', np.round(xs, 1).tolist())
print('ped white centroid x', np.round(cxs, 1).tolist())
json.dump({'front': front.tolist(), 'ped_x': xs.tolist(), 'ped_white_x': cxs.tolist()},
          open('/private/tmp/qp_blind/scene_full_b/simulation_0069/q_38/meas.json', 'w'))
