import av, numpy as np, cv2
P='/private/tmp/qp_blind/scene_full_b/simulation_0082/q_94/simulation_0082.mp4'
bg=cv2.imread('/private/tmp/qp_blind/scene_full_b/simulation_0082/q_94/scene/scripts/bg.png')[:,:,::-1]
bg=cv2.resize(bg,(1920,1080),interpolation=cv2.INTER_LINEAR).astype(int)
c=av.open(P)
for i,f in enumerate(c.decode(video=0)):
    if i not in (0,12,24,36,40,48,55,60,71): continue
    a=f.to_ndarray(format='rgb24').astype(int)
    d=np.abs(a-bg).max(2)
    res=[]
    for (y0,y1) in [(375,430),(515,580)]:
        colfrac=(d[y0:y1]>30).mean(0)
        cols=np.where(colfrac>0.5)[0]
        runs=np.split(cols,np.where(np.diff(cols)>3)[0]+1)
        r=max(runs,key=len)
        res.append((int(r[0]),int(r[-1]),int(r[-1]-r[0]+1)))
    print(i,res)
c.close()
