import av, numpy as np
P='/private/tmp/qp_blind/scene_full_b/simulation_0082/q_94/simulation_0082.mp4'
c=av.open(P)
for i,f in enumerate(c.decode(video=0)):
    if i!=24: continue
    a=f.to_ndarray(format='rgb24').astype(int)
    for y in (400,545):
        print('row',y)
        for x in range(1140,1500,6):
            print(x,a[y-3:y+4,x].mean(0).round().astype(int).tolist())
    break
c.close()
