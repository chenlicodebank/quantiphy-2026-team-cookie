import av, numpy as np
import cv2
def binary_opening(m,iterations=2):
    return cv2.morphologyEx(m.astype(np.uint8),cv2.MORPH_OPEN,np.ones((3,3),np.uint8),iterations=iterations)>0
P='/private/tmp/qp_blind/scene_full_b/simulation_0082/q_94/simulation_0082.mp4'
frames={}
want=set(range(0,72))
c=av.open(P)
for i,f in enumerate(c.decode(video=0)):
    a=f.to_ndarray(format='rgb24').astype(int)
    mn=a.min(2); mx=a.max(2)
    sat=mx-mn
    mask=(mn<100)|(mx>172)|(sat>50)
    mask=binary_opening(mask,iterations=2)
    out=[]
    for (y0,y1) in [(375,430),(515,580)]:
        cols=np.where(mask[y0:y1].sum(0)>(y1-y0)*0.3)[0]
        # largest contiguous run
        runs=np.split(cols,np.where(np.diff(cols)>3)[0]+1)
        r=max(runs,key=len)
        out.append((r[0],r[-1]))
    # column profile of white truck for xcorr
    prof=(a[515:580].mean(axis=(0,2)))
    frames[i]=(out,prof)
c.close()
for i in [0,1,2,12,23,24,25,36,48,60,71]:
    (y,w),_=frames[i]
    print(i,'yellow',y,y[1]-y[0]+1,'white',w,w[1]-w[0]+1,(w[0]+w[1])/2)
# xcorr shift white
def shift(p0,p1):
    p0=p0-p0.mean(); p1=p1-p1.mean()
    best=None
    cc=np.correlate(p1,p0,'full'); k=np.argmax(cc)
    y0,y1,y2=cc[k-1],cc[k],cc[k+1]
    return k-(len(p0)-1)+0.5*(y0-y2)/(y0-2*y1+y2)
for i in range(20,29):
    print('white shift',i,shift(frames[i-1][1],frames[i][1]))
ylen=[frames[i][0][0][1]-frames[i][0][0][0]+1 for i in range(72)]
print('yellow len median',np.median(ylen),'f24',ylen[24])
wc=np.array([(frames[i][0][1][0]+frames[i][0][1][1])/2 for i in range(72)])
print('white centre fit 2-71 slope',np.polyfit(np.arange(2,72),wc[2:],1)[0])
