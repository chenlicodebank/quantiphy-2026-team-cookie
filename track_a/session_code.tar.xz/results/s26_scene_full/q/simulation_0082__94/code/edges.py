import av, numpy as np
P='/private/tmp/qp_blind/scene_full_b/simulation_0082/q_94/simulation_0082.mp4'
def cross(p,thr,start,step):
    x=start
    while p[x]<thr: x+=step
    # interpolate between x-step and x
    a,b=p[x-step],p[x]
    return x-step+step*(thr-a)/(b-a)
c=av.open(P)
rows=[]
for i,f in enumerate(c.decode(video=0)):
    a=f.to_ndarray(format='rgb24').astype(float)
    sat=(a[375:430,:,0]-a[375:430,:,2])   # yellow: R-B ~ 90, ground ~5
    p=np.median(sat,0)
    # body band: yellow paint at front (hood) and rear (bed) ends
    xs=np.where(p>45)[0]
    x0=cross(p,45,xs[0]-5,1); x1=cross(p,45,xs[-1]+5,-1)
    rows.append((i,x0,x1,x1-x0,(x0+x1)/2))
c.close()
for r in rows:
    if r[0]%3==0: print('%d front %.1f rear %.1f len %.1f cx %.1f'%r)
np.savetxt('/private/tmp/qp_blind/scene_full_b/simulation_0082/q_94/yellow_edges.csv',np.array(rows),delimiter=',',fmt='%.2f',header='frame,front,rear,len,cx')
