import numpy as np
res = np.load('edges.npy', allow_pickle=True).item()
yc = lambda i: (res[i]['orange'][0] + res[i]['orange'][1]) / 2
for a, b in ((16, 90), (25, 90), (30, 90), (16, 60), (40, 90)):
    f = np.arange(a, b + 1); y = np.array([yc(i) for i in f])
    p = np.polyfit(f, y, 2); print(a, b, 2 * p[0], (y - np.polyval(p, f)).std())
# speed from 5-frame differences
f = np.arange(16, 91); y = np.array([yc(i) for i in f])
v = (y[5:] - y[:-5]) / 5; print(np.round(v[::5], 2))
