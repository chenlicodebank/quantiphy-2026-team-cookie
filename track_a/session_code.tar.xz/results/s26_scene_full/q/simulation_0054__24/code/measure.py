import av, numpy as np, cv2
V = 'simulation_0054.mp4'
FPS = 30.003
def gen():
    c = av.open(V)
    for i, f in enumerate(c.decode(video=0)):
        if i > 90: break
        yield i, f.to_ndarray(format='rgb24')
    c.close()
# background: median over subsampled frames (cars move)
bg = np.median(np.stack([fr for i, fr in gen() if i % 6 == 0]), axis=0).astype(np.int16)
res = {}
for i, fr in gen():
    d = np.abs(fr.astype(np.int16) - bg).max(2) > 40
    d = cv2.morphologyEx(d.astype(np.uint8), cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
    d = cv2.morphologyEx(d, cv2.MORPH_CLOSE, np.ones((15, 15), np.uint8))
    out = {}
    for name, xs in (('orange', slice(300, 570)), ('green', slice(570, 845))):
        m = np.zeros_like(d); m[:, xs] = d[:, xs]
        n, lab, st, _ = cv2.connectedComponentsWithStats(m, connectivity=8)
        if n <= 1: continue
        k = 1 + np.argmax(st[1:, cv2.CC_STAT_AREA])
        if st[k, cv2.CC_STAT_AREA] < 2000: continue
        ys, xx = np.nonzero(lab == k)
        out[name] = (ys.min(), ys.max(), xx.min(), xx.max())
    res[i] = out
np.save('edges.npy', res, allow_pickle=True)
for i in range(91):
    print(i, res[i])
