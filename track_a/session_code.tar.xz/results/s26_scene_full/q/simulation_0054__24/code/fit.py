import numpy as np
FPS = 30.003
res = np.load('edges.npy', allow_pickle=True).item()
f = np.arange(16, 91)
for k, nm in ((0, 'top'), (1, 'bot')):
    y = np.array([res[i]['orange'][k] for i in f], float)
    p = np.polyfit(f, y, 2)
    r = y - np.polyval(p, f)
    print('orange', nm, 'acc px/f^2', 2 * p[0], 'rms', r.std())
    # piecewise windows to test constancy
    for a, b in ((16, 40), (30, 60), (50, 75), (65, 90)):
        m = (f >= a) & (f <= b)
        q = np.polyfit(f[m], y[m], 2)
        print('   win', a, b, 2 * q[0])
    # cubic check
    c = np.polyfit(f, y, 3); print('   cubic acc at f30,60,90', [2*c[1]+6*c[0]*x for x in (30,60,90)])
yc = np.array([(res[i]['orange'][0] + res[i]['orange'][1]) / 2 for i in f])
p = np.polyfit(f, yc, 2); print('orange centre acc', 2 * p[0])
acc_px = 2 * p[0]
g = np.arange(37, 71)
for k, nm in ((0, 'top'), (1, 'bot')):
    y = np.array([res[i]['green'][k] for i in g], float)
    print('green', nm, 'lin slope', np.polyfit(g, y, 1)[0], 'quad acc', 2 * np.polyfit(g, y, 2)[0])
gc = np.array([(res[i]['green'][0] + res[i]['green'][1]) / 2 for i in g])
vg = np.polyfit(g, gc, 1)[0]
print('green centre px/frame', vg, 'step at 60', gc[60 - 37] - gc[59 - 37])
# also front edge over a wider window (bottom edge visible 24..70, top edge visible 37..83)
gt = np.arange(37, 84); yt = np.array([res[i]['green'][0] for i in gt], float)
print('green top 37-83 slope', np.polyfit(gt, yt, 1)[0])
gb = np.arange(24, 71); yb = np.array([res[i]['green'][1] for i in gb], float)
print('green bot 24-70 slope', np.polyfit(gb, yb, 1)[0])
# scale: px/frame^2 -> m/s^2 ; a_px_s2 = acc_px*FPS^2
mpp = 2.86 / (abs(acc_px) * FPS ** 2)
print('m per px', mpp, 'green speed m/s', vg * FPS * mpp)
