import numpy as np, csv, cv2, os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
r=list(csv.DictReader(open('scene/tracks/pedestrian_sidewalk.csv')))
f=np.array([int(x['frame']) for x in r]); tx=np.array([float(x['torso_x']) for x in r]); ty=np.array([float(x['torso_y']) for x in r])
cx=np.array([float(x['centroid_x']) for x in r])
for a,b in [(14,34),(18,30),(20,28),(2,27),(10,38),(2,71)]:
    s=slice(a,b+1); p=np.polyfit(f[s],tx[s],1); q=np.polyfit(f[s],cx[s],1)
    print(a,b,'torso px/f %.3f centroid %.3f y %.3f'%(p[0],q[0],np.polyfit(f[s],ty[s],1)[0]))
print(np.round(np.diff(tx)[15:35],2))
cap=cv2.VideoCapture('simulation_0075.mp4')
vr=list(csv.DictReader(open('scene/tracks/white_van.csv')))
for i in [0,24,36,60,71]:
    cap.set(cv2.CAP_PROP_POS_FRAMES,i); ok,fr=cap.read()
    rr=vr[i]; x=int(float(rr['ref_x'])); y=int(float(rr['ref_y']))
    strip=fr[:, x-20:x+20].astype(float)
    w=strip.min(axis=2).mean(axis=1)
    idx=np.where(w>200)[0]; idx=idx[(idx>y-170)&(idx<y+170)]
    # horizontal width
    row=fr[y-40:y+40,:].astype(float).min(axis=2).mean(axis=0)
    jdx=np.where(row>200)[0]; jdx=jdx[(jdx>x-80)&(jdx<x+80)]
    print(i,x,y,'len rows',idx.min(),idx.max(),idx.max()-idx.min()+1,'width',jdx.max()-jdx.min()+1,'track len',rr['length_px'])
