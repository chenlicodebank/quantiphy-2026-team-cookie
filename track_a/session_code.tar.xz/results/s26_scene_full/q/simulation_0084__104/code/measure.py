import av, numpy as np, cv2
c = av.open('simulation_0084.mp4')
res = []
for i, f in enumerate(c.decode(video=0)):
    a = f.to_ndarray(format='rgb24')
    hsv = cv2.cvtColor(a, cv2.COLOR_RGB2HSV); g = cv2.cvtColor(a, cv2.COLOR_RGB2GRAY)
    m = (g < 113) | (g > 176) | (hsv[..., 1] > 40)
    def ext(r0, r1):
        cols = np.where(m[r0:r1].sum(0) > 3)[0]
        return (cols.min(), cols.max()) if len(cols) else (-1, -1)
    y = ext(480, 570); d = ext(600, 685)
    res.append((i, *y, *d))
res = np.array(res, float)
np.savetxt('ext.csv', res, fmt='%g', delimiter=',')
y0, y1, d0, d1 = res[:, 1], res[:, 2], res[:, 3], res[:, 4]
print('yellow len', (y1 - y0)[12:].round(0))
print('dark len', (d1 - d0).round(0))
yc = (y0 + y1) / 2; dc = (d0 + d1) / 2
print('yellow front mean 1..71', (y0[71] - y0[1]) / 70, 'center 12..71', (yc[71] - yc[12]) / 59)
print('yellow rear 12..71', (y1[71] - y1[12]) / 59)
print('yellow per-frame center steps', np.diff(yc[12:]))
print('dark center', (dc[71] - dc[1]) / 70)
