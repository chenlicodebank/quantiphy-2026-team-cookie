import csv, numpy as np
r = list(csv.DictReader(open('scene/tracks/orange_car.csv')))
g = lambda k: np.array([float(x[k]) if x[k] else np.nan for x in r])
f = g('frame').astype(int); cy = g('cy_best_px'); cx = g('cx_best_px'); L = g('length_px_vertical')
fps = 30.003297
for a, b in [(7, 90), (17, 90), (7, 48), (48, 90), (30, 90), (60, 90)]:
    m = (f >= a) & (f <= b)
    t = f[m] / fps
    p = np.polyfit(t, cy[m], 2); res = cy[m] - np.polyval(p, t)
    p3 = np.polyfit(t, cy[m], 3)
    print(a, b, 'acc px/s2 %.2f v0 %.2f rms %.3f cubic coef %.2f' % (2 * p[0], p[1], res.std(), p3[0]))
sp = np.hypot(np.diff(cx), np.diff(cy)) * fps
print(np.round(sp[6:], 1))
acc = np.diff(sp) * fps
print('mean acc 8-90', np.nanmean(acc[7:]))
print('len median 17-90', np.nanmedian(L[17:]), 'len 60-90', np.nanmedian(L[60:]))
print(L[17:])
