import av, numpy as np, cv2
# independent length: orange-ness profile along the car axis, half-max edges with subpixel interpolation
c = av.open('simulation_0057.mp4')
for i, fr in enumerate(c.decode(video=0)):
    if i not in (40, 60, 75, 87, 90): continue
    im = fr.to_ndarray(format='rgb24').astype(float)
    R, G, B = im[..., 0], im[..., 1], im[..., 2]
    o = R - B  # orange: high R, low B; road gray ~0
    ys = np.arange(im.shape[0])
    for xc in (320, 340, 350, 360):
        prof = o[:, xc - 3:xc + 4].mean(1)
        on = prof > 60
        idx = np.where(on)[0]
        if len(idx) == 0: continue
        # take the longest run with small gaps filled
        y0, y1 = idx.min(), idx.max()
        thr = 0.5 * (np.median(prof[on]) + np.median(prof[~on]))
        def edge(a, b):
            return a + (thr - prof[a]) / (prof[b] - prof[a]) * (b - a)
        top = edge(y0 - 1, y0) if prof[y0] > thr else y0
        bot = edge(y1, y1 + 1) if y1 + 1 < len(prof) else y1
        print(i, xc, y0, y1, 'len %.1f' % (bot - top))
