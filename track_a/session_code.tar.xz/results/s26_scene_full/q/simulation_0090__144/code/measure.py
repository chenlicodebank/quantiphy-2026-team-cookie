import av, numpy as np, cv2
frames = []
c = av.open('simulation_0090.mp4')
for f in c.decode(video=0):
    frames.append(f.to_ndarray(format='bgr24').astype(np.int16))
bg = np.median(np.stack(frames[24:30]), axis=0)
res = {}
for i in range(0, 20):
    d = np.abs(frames[i] - bg).sum(2) > 20
    d = cv2.morphologyEx(d.astype(np.uint8), cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8))
    n, lab, st, _ = cv2.connectedComponentsWithStats(d)
    comps = sorted([s for s in st[1:] if s[4] > 200], key=lambda s: -s[4])
    print(i, [(s[0], s[0] + s[2] - 1, s[2], s[3], s[4]) for s in comps])
    if i == 6:
        im = frames[i].astype(np.uint8).copy()
        for s in comps:
            cv2.rectangle(im, (s[0], s[1]), (s[0] + s[2] - 1, s[1] + s[3] - 1), (0, 0, 255), 1)
        cv2.imwrite('frames_f6.png', im[450:750, 600:1500])
