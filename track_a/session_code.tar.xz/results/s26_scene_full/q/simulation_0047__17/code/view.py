import av, numpy as np, cv2, sys
# usage: view.py frame x0 y0 x1 y1 scale out
fr, x0, y0, x1, y1, sc = [int(a) for a in sys.argv[1:7]]
out = sys.argv[7]
c = av.open('simulation_0047.mp4')
for i, f in enumerate(c.decode(video=0)):
    if i == fr:
        img = f.to_ndarray(format='bgr24')[y0:y1, x0:x1].copy()
        break
c.close()
img = cv2.resize(img, None, fx=sc, fy=sc, interpolation=cv2.INTER_NEAREST)
for x in range((x0 // 10 + 1) * 10, x1, 10):
    col = (0, 255, 255) if x % 50 == 0 else (0, 120, 120)
    cv2.line(img, ((x - x0) * sc, 0), ((x - x0) * sc, 8 if x % 50 else 20), col, 1)
    if x % 50 == 0:
        cv2.putText(img, str(x), ((x - x0) * sc + 2, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255), 1)
for y in range((y0 // 10 + 1) * 10, y1, 10):
    col = (0, 255, 255) if y % 50 == 0 else (0, 120, 120)
    cv2.line(img, (0, (y - y0) * sc), (8 if y % 50 else 20, (y - y0) * sc), col, 1)
    if y % 50 == 0:
        cv2.putText(img, str(y), (22, (y - y0) * sc + 5), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255), 1)
cv2.imwrite(out, img)
