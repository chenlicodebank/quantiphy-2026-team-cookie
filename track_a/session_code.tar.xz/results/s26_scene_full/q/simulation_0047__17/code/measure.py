import av, numpy as np, cv2, csv
V = 'simulation_0047.mp4'
frames = {}
want = set(range(0, 99, 3)) | {20, 30, 40, 50, 60, 70, 80, 90}
c = av.open(V)
for i, f in enumerate(c.decode(video=0)):
    if i in want:
        frames[i] = f.to_ndarray(format='rgb24')[380:580].astype(np.float32)  # road band
c.close()
ks = sorted(frames)
bg = np.median(np.stack([frames[k] for k in ks]), axis=0)
cyc = {int(r['frame']): (float(r['ref_x']), float(r['ref_y'])) for r in csv.DictReader(open('scene/tracks/cyclist.csv'))}
res = []
for k in [20, 30, 40, 50, 60, 70, 80, 90]:
    d = np.abs(frames[k] - bg).sum(2)
    rx, ry = cyc[k]
    ry -= 380
    x0, x1 = int(rx - 110), int(rx + 110)
    band = d[int(ry) - 12:int(ry) + 12, x0:x1]   # rows near bike axis (y~465-490)
    colmax = band.max(0)
    on = np.where(colmax > 60)[0]
    # longest run with gaps < 6 px
    runs = []; s = on[0]; p = on[0]
    for q in on[1:]:
        if q - p > 6:
            runs.append((s, p)); s = q
        p = q
    runs.append((s, p))
    best = max(runs, key=lambda r: r[1] - r[0])
    res.append(best[1] - best[0] + 1)
    print(k, 'ref', round(rx, 1), 'extent x', x0 + best[0], x0 + best[1], 'len', best[1] - best[0] + 1, runs)
print('median len', np.median(res))
