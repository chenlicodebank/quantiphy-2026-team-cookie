import av, numpy as np, csv
# Bike end-to-end along the axis: brightness of diff vs background restricted to rows near the axis,
# using a positive-brightness criterion (tyres/frame/rack appear bright; shadow is dark -> excluded).
frames = {}
bgset = set(range(0, 99, 3))
want = bgset | set(range(15, 99))
c = av.open('simulation_0047.mp4')
for i, f in enumerate(c.decode(video=0)):
    if i in want:
        frames[i] = f.to_ndarray(format='rgb24')[400:560].astype(np.float32)
c.close()
bg = np.median(np.stack([frames[k] for k in sorted(bgset)]), axis=0)
out = []
for k in range(15, 99):
    fx = 1619.23 - 12.849 * k
    x0 = int(fx - 100); x1 = int(fx + 100)
    img = frames[k][:, x0:x1].mean(2); b = bg[:, x0:x1].mean(2)
    br = img - b
    # axis row: row with most bright (+40) pixels
    cnt = (br > 40).sum(1)
    ya = int(np.argmax(cnt))
    prof = br[ya - 3:ya + 4].max(0)
    on = np.where(prof > 40)[0]
    runs = []; s = p = on[0]
    for q in on[1:]:
        if q - p > 25:
            runs.append((s, p)); s = q
        p = q
    runs.append((s, p))
    bst = max(runs, key=lambda r: r[1] - r[0])
    xf, xr = x0 + bst[0], x0 + bst[1]
    out.append((k, ya + 400, xf, xr, xr - xf + 1, round(fx, 1)))
    print(k, 'axis y', ya + 400, 'front', xf, 'rear', xr, 'len', xr - xf + 1, 'fitx', round(fx, 1), 'front-fit', round(fx - xf, 1), 'rear-fit', round(xr - fx, 1))
L = np.array([o[4] for o in out])
print('median all', np.median(L), 'f15-35', np.median(L[:21]), 'f40-60', np.median(L[25:46]), 'f75-98', np.median(L[60:]))
