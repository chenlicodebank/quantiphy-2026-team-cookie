import av, numpy as np, cv2, csv
# Independent pedestrian speed: chained template matching (head+shoulders), templates refreshed every 17 frames.
gray = {}
c = av.open('simulation_0047.mp4')
for i, f in enumerate(c.decode(video=0)):
    gray[i] = cv2.cvtColor(f.to_ndarray(format='rgb24')[200:420], cv2.COLOR_RGB2GRAY).astype(np.float32)
c.close()
rec = {int(r['frame']): (float(r['ref_x']), float(r['ref_y'])) for r in csv.DictReader(open('scene/tracks/pedestrian.csv'))}
def match(tmpl, img, guess, rad=25):
    gx, gy = guess; h, w = tmpl.shape
    x0 = int(gx - w / 2 - rad); y0 = int(gy - h / 2 - rad)
    win = img[y0:y0 + h + 2 * rad, x0:x0 + w + 2 * rad]
    r = cv2.matchTemplate(win, tmpl, cv2.TM_CCOEFF_NORMED)
    _, mv, _, ml = cv2.minMaxLoc(r)
    px, py = ml
    def sub(a, b, cc):
        d = a - 2 * cc + b
        return 0 if d == 0 else 0.5 * (a - b) / d
    dx = sub(r[py, px - 1], r[py, px + 1], r[py, px]) if 0 < px < r.shape[1] - 1 else 0
    dy = sub(r[py - 1, px], r[py + 1, px], r[py, px]) if 0 < py < r.shape[0] - 1 else 0
    return x0 + px + dx + w / 2, y0 + py + dy + h / 2, mv
# chain: frame a -> a+17 using template cut at frame a (same gait phase)
pos = {2: rec[2]}
pos[2] = (rec[2][0], rec[2][1] - 200)
k = 2
total = 0
while k + 17 <= 98:
    x, y = pos[k]
    t = gray[k][int(y) - 22:int(y) + 22, int(x) - 22:int(x) + 22]
    # template centre in absolute coords
    cx, cy = int(x) - 22 + 22, int(y) - 22 + 22
    nx, ny, mv = match(t, gray[k + 17], (cx - 17 * 3.33, cy))
    shift = (nx - cx, ny - cy)
    pos[k + 17] = (x + shift[0], y + shift[1])
    print(k, '->', k + 17, 'shift', np.round(shift, 2), 'score', round(mv, 3), 'px/s', round(-shift[0] / 17 * 33, 2))
    k += 17
x2 = pos[2][0]; xe = pos[k][0]
print('chain', 2, k, 'speed px/s', (x2 - xe) / (k - 2) * 33)
print('record same frames', (rec[2][0] - rec[k][0]) / (k - 2) * 33)
