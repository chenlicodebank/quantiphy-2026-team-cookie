import av, numpy as np, csv
# Bike length along x in a narrow band around the bike axis, using diff vs median background.
frames = {}
bgset = set(range(0, 99, 3))
want = bgset | set(range(20, 99, 5))
c = av.open('simulation_0047.mp4')
for i, f in enumerate(c.decode(video=0)):
    if i in want:
        frames[i] = f.to_ndarray(format='rgb24')[380:580].astype(np.float32)
c.close()
bg = np.median(np.stack([frames[k] for k in sorted(bgset)]), axis=0)
cyc = {int(r['frame']): (float(r['ref_x']), float(r['ref_y'])) for r in csv.DictReader(open('scene/tracks/cyclist.csv'))}
for thr in (60, 90, 120):
    L = []
    for k in range(20, 99, 5):
        d = np.abs(frames[k] - bg).sum(2)
        rx, ry = cyc[k]
        x0 = int(rx - 110)
        yy = int(round(ry)) - 380 - 7  # axis row ~ ref_y - 7
        prof = d[yy - 5:yy + 6, x0:x0 + 220].max(0)
        on = np.where(prof > thr)[0]
        runs = []; s = p = on[0]
        for q in on[1:]:
            if q - p > 8:
                runs.append((s, p)); s = q
            p = q
        runs.append((s, p)); b = max(runs, key=lambda r: r[1] - r[0])
        L.append(b[1] - b[0] + 1)
        if thr == 90:
            print(k, 'x', x0 + b[0], x0 + b[1], 'len', b[1] - b[0] + 1, 'front-ref', round(rx - x0 - b[0], 1), 'rear-ref', round(x0 + b[1] - rx, 1))
    print('thr', thr, 'lens', L, 'median', np.median(L))
