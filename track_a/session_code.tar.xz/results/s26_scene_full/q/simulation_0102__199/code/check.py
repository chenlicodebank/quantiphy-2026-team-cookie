import numpy as np
r = np.loadtxt('len2.csv', delimiter=',')
f = r[:, 0]
for name, j in (('nose th10', 4), ('tail th10', 5), ('nose th15', 7), ('mid th15', None)):
    v = r[:, j] if j is not None else 0.5 * (r[:, 7] + r[:, 8])
    k = f <= 54
    c = np.polyfit(f[k] / 24, v[k], 2)
    print(name, 'acc', round(2 * c[0], 2), 'rms', round((v[k] - np.polyval(c, f[k] / 24)).std(), 2))
t = np.loadtxt('track2.csv', delimiter=',')
x = t[1:59, 1]
s = np.abs(np.diff(x)) * 24  # per-frame speeds, frames 2..58
a = np.polyfit(np.arange(len(s)) / 24, s, 1)[0]
print('template: slope of per-frame speed', round(a, 2), 'px/s^2')
L = 280.5
for acc in (87.0, 86.4, 85.0, 88.0):
    print('acc', acc, 'length m', round(L / acc, 3))
