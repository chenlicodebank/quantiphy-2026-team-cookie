import csv, numpy as np
r = list(csv.DictReader(open('scene/tracks/shark.csv')))
f = np.array([int(x['frame']) for x in r])
for key in ['ref_x', 'nose_x_sub', 'tail_x_sub', 'mask_centroid_x']:
    v = np.array([float(x[key]) if x[key] else np.nan for x in r])
    for lo, hi in [(1, 59), (1, 30), (30, 59), (2, 59), (1, 72)]:
        m = (f >= lo) & (f <= hi) & np.isfinite(v)
        if m.sum() < 5: continue
        c = np.polyfit(f[m] / 24, v[m], 2); res = v[m] - np.polyval(c, f[m] / 24)
        print(key, lo, hi, 'acc px/s2', round(2 * c[0], 2), 'v(t) lin', round(c[1], 1), 'rms', round(res.std(), 2))
v = np.array([float(x['ref_x']) for x in r])
print('steps', np.round(np.diff(v), 2))
