import av, numpy as np, cv2
bg = cv2.imread('scene/scripts/bg.png')[:, :, ::-1].astype(np.float32)
c = av.open('simulation_0102.mp4')
for i, fr in enumerate(c.decode(video=0)):
    if i not in (20, 40): continue
    im = fr.to_ndarray(format='rgb24').astype(np.float32)
    d = np.abs(im - bg).max(2)
    # noise level in empty region
    print('frame', i, 'noise p99 in empty water', np.percentile(d[1000:1070, 1200:1800], 99))
    m = d > 12
    m = cv2.morphologyEx(m.astype(np.uint8), cv2.MORPH_OPEN, np.ones((2, 2), np.uint8))
    sub = m[840:970]
    n, lab, st, _ = cv2.connectedComponentsWithStats(sub)
    k = 1 + np.argmax(st[1:, 4])
    print(' th12 bbox', st[k], 'x0,x1', st[k, 0], st[k, 0] + st[k, 2] - 1)
    x0 = st[k, 0]
    for x in range(x0 - 3, x0 + 20, 2):
        col = d[880:950, x]
        print('  col', x, 'max', int(col.max()), 'at y', 880 + int(col.argmax()))
    x1 = st[k, 0] + st[k, 2] - 1
    for x in range(x1 - 10, x1 + 4, 2):
        col = d[850:960, x]
        print('  col', x, 'max', int(col.max()), 'at y', 850 + int(col.argmax()))
c.close()
