import av, numpy as np, cv2
bg = cv2.imread('scene/scripts/bg.png')[:, :, ::-1].astype(np.float32)
want = [5, 10, 20, 30, 40, 50]
c = av.open('simulation_0102.mp4')
for i, fr in enumerate(c.decode(video=0)):
    if i not in want: continue
    im = fr.to_ndarray(format='rgb24').astype(np.float32)
    d = np.abs(im - bg).max(2)[700:1080]
    out = [i]
    for th in [10, 20, 40, 60]:
        m = (d > th).astype(np.uint8)
        m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
        n, lab, st, _ = cv2.connectedComponentsWithStats(m)
        k = 1 + np.argmax(st[1:, 4])
        x0, y0, w, h = st[k, :4]
        out.append((th, x0, x0 + w - 1, w, h, y0 + 700))
    print(out)
    if i == 20:
        # column profile of max diff
        prof = d.max(0)
        print('cols 490-530', np.round(prof[490:530]).astype(int))
        print('cols 760-800', np.round(prof[760:800]).astype(int))
c.close()
