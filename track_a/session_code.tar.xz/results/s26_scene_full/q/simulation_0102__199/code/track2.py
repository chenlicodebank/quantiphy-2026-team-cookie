import av, numpy as np, cv2
# independent track: template match on the front half (nose -> dorsal fin) of the shark, sub-pixel peak
frames = {}
c = av.open('simulation_0102.mp4')
for i, fr in enumerate(c.decode(video=0)):
    g = fr.to_ndarray(format='rgb24')[820:1000].astype(np.float32)
    frames[i] = cv2.cvtColor(g, cv2.COLOR_RGB2GRAY)
c.close()
ref = 20
# shark at frame 20 roughly: find dark pixels
g = frames[ref]
bgrow = np.median(g, axis=1, keepdims=True)
m = np.abs(g - bgrow) > 25
xs = np.where(m.any(0))[0]; ys = np.where(m.any(1))[0]
print('frame20 bbox x', xs.min(), xs.max(), 'y', ys.min() + 820, ys.max() + 820)
x0 = xs.min() - 5; x1 = xs.min() + 130  # front ~half
y0 = ys.min() - 3; y1 = ys.max() + 3
tpl = g[y0:y1, x0:x1]
pos = []
for i in range(73):
    r = cv2.matchTemplate(frames[i], tpl, cv2.TM_CCOEFF_NORMED)
    _, mv, _, ml = cv2.minMaxLoc(r)
    x, y = ml
    if 0 < x < r.shape[1] - 1:
        a, b, cc = r[y, x - 1], r[y, x], r[y, x + 1]
        dx = 0.5 * (a - cc) / (a - 2 * b + cc)
    else:
        dx = 0
    # nose edge: leftmost dark column, subpixel via fraction
    gi = frames[i]; d = np.abs(gi - np.median(gi, axis=1, keepdims=True)) > 25
    cols = np.where(d.any(0))[0]
    nose = cols.min() if len(cols) else np.nan
    pos.append((i, x + dx, mv, nose))
pos = np.array(pos)
np.savetxt('track2.csv', pos, delimiter=',', header='frame,tpl_x,score,nose_px', fmt='%.3f')
f = pos[:, 0]; x = pos[:, 1]
for lo, hi in [(1, 58), (1, 30), (30, 58), (10, 58)]:
    k = (f >= lo) & (f <= hi) & (pos[:, 2] > 0.8)
    cf = np.polyfit(f[k] / 24, x[k], 2)
    print('tpl', lo, hi, 'acc', round(2 * cf[0], 2), 'rms', round((x[k] - np.polyval(cf, f[k] / 24)).std(), 3))
    k2 = (f >= lo) & (f <= hi) & (pos[:, 3] > 2)
    cf = np.polyfit(f[k2] / 24, pos[k2, 3], 2)
    print('nose', lo, hi, 'acc', round(2 * cf[0], 2))
print('scores', np.round(pos[:, 2], 3))
print('steps', np.round(np.diff(x), 2))
