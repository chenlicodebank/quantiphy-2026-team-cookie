import av, numpy as np, cv2
bg = cv2.imread('scene/scripts/bg.png')[:, :, ::-1].astype(np.float32)
c = av.open('simulation_0102.mp4')
rows = []
for i, fr in enumerate(c.decode(video=0)):
    if i < 2 or i > 56: continue
    im = fr.to_ndarray(format='rgb24')[840:975].astype(np.float32)
    d = np.abs(im - bg[840:975]).max(2)
    d = cv2.GaussianBlur(d, (3, 3), 0)
    prof = d.max(0)
    res = [i]
    for th in (6, 10, 15):
        on = np.where(prof > th)[0]
        # largest contiguous run
        runs = np.split(on, np.where(np.diff(on) > 3)[0] + 1)
        r = max(runs, key=len)
        a, b = r[0], r[-1]
        # sub-pixel crossings
        xa = a - 1 + (th - prof[a - 1]) / (prof[a] - prof[a - 1])
        xb = b + (prof[b] - th) / (prof[b] - prof[b + 1])
        res += [xa, xb, xb - xa]
    rows.append(res)
c.close()
rows = np.array(rows)
np.savetxt('len2.csv', rows, delimiter=',', fmt='%.2f', header='frame,l6,r6,L6,l10,r10,L10,l15,r15,L15')
for j, th in zip((3, 6, 9), (6, 10, 15)):
    L = rows[:, j]
    print('th', th, 'length median', round(np.median(L), 2), 'mean', round(L.mean(), 2), 'min', round(L.min(), 1), 'max', round(L.max(), 1))
print(np.round(rows[::6], 1))
