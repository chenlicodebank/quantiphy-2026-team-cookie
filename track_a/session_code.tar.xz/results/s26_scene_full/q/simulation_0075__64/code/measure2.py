import csv, numpy as np, av
D = '/private/tmp/qp_blind/scene_full_b/simulation_0075/q_64/'
r = list(csv.DictReader(open(D + 'scene/tracks/white_van.csv')))
f = np.array([int(x['frame']) for x in r]); y = np.array([float(x['ref_y']) for x in r])
y0 = np.array([float(x['bbox_y0']) for x in r]); y1 = np.array([float(x['bbox_y1']) for x in r])
fps = 24.0

# body length from a vertical brightness profile down the van's centre strip (x 800-860)
want = {0, 20, 36, 50, 71}
L = []
c = av.open(D + 'simulation_0075.mp4')
for i, fr in enumerate(c.decode(video=0)):
    if i in want:
        g = fr.to_ndarray(format='rgb24').astype(float)
        bg = np.median(g[:, 700:740], axis=1)  # road strip left of van (same rows)
        prof = g[:, 805:860].mean(axis=1)
        diff = np.abs(prof - bg).max(axis=1)
        rows = np.where(diff > 30)[0]
        # largest contiguous run
        runs = np.split(rows, np.where(np.diff(rows) > 60)[0] + 1)
        run = max(runs, key=len)
        L.append(run[-1] - run[0] + 1)
        print('frame', i, 'body rows', run[0], run[-1], 'len', run[-1] - run[0] + 1)
c.close()
Lpx = float(np.median(L)); mpp = 6.0 / Lpx
print('length px', Lpx, 'm/px', mpp)

for name, s in [('ref', y), ('front', y0), ('rear', y1)]:
    for lo, hi in [(0, 71), (10, 38), (0, 48), (24, 71)]:
        m = (f >= lo) & (f <= hi) & (f != 34) & (f != 35)
        p = np.polyfit(f[m] / fps, s[m], 2)
        print(name, lo, hi, 'a px/s^2 = %.1f' % (2 * p[0]), 'a m/s^2 = %.3f' % (abs(2 * p[0]) * mpp),
              'v0 px/s %.1f' % p[1])

# local finite difference convention around t=1.0 (frame 24) from smoothed track
m = (f >= 12) & (f <= 36) & (f != 34) & (f != 35)
p = np.polyfit(f[m], y[m], 2)
sp = lambda i: abs(np.polyval(p, i) - np.polyval(p, i - 1)) * fps
print('speed(24) %.1f speed(23) %.1f -> a %.1f px/s^2 = %.3f m/s^2' % (sp(24), sp(23), (sp(24) - sp(23)) * fps, (sp(24) - sp(23)) * fps * mpp))
