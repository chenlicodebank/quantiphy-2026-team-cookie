import av, numpy as np, cv2
want = {0, 71, 20, 25, 30, 35, 40, 60, 65, 68}
fr = {}
c = av.open('simulation_0073.mp4')
for i, f in enumerate(c.decode(video=0)):
    if i in want:
        fr[i] = f.to_ndarray(format='rgb24')[:, 760:910].astype(np.float32)
c.close()
scale = 5.33 / (8.9804 * 24)
for i, bgi in [(20, 71), (25, 71), (30, 71), (35, 71), (40, 71), (60, 0), (65, 0), (68, 0)]:
    d = np.abs(fr[i] - fr[bgi]).max(axis=2)
    for thr in (15, 25, 40):
        m = d > thr
        rows = m[:, 40:110].sum(axis=1)  # body columns ~800-870
        idx = np.where(rows > 20)[0]
        runs = np.split(idx, np.where(np.diff(idx) > 2)[0] + 1)
        rr = max(runs, key=len)
        L = rr[-1] - rr[0] + 1
        print(i, thr, 'y', rr[0], rr[-1], 'L', L, 'm', round(L * scale, 3))
