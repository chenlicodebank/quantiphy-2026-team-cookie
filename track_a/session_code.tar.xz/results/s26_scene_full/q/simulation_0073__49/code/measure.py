import av, numpy as np, csv, cv2
# frames as grayscale
fr = []
c = av.open('simulation_0073.mp4')
for f in c.decode(video=0):
    fr.append(cv2.cvtColor(f.to_ndarray(format='rgb24'), cv2.COLOR_RGB2GRAY)[150:1080, 600:1100].astype(np.float32))
c.close()
OX, OY = 600, 150

# cyclist: template matching of a patch from frame 30 across frames (sub-pixel via parabola)
r = list(csv.DictReader(open('scene/tracks/cyclist.csv')))
cy30 = float(r[30]['cy_px']); cx30 = float(r[30]['cx_px'])
y0 = int(cy30 - 40) - OY; x0 = int(cx30 - 20) - OX
T = fr[30][y0:y0 + 80, x0:x0 + 40]
ys = []
for i in range(72):
    res = cv2.matchTemplate(fr[i][:, x0 - 10:x0 + 50], T, cv2.TM_SQDIFF_NORMED)
    j = np.unravel_index(np.argmin(res), res.shape)
    a, b, cc = (res[j[0] - 1, j[1]], res[j], res[j[0] + 1, j[1]]) if 0 < j[0] < res.shape[0] - 1 else (0, 0, 0)
    d = 0.5 * (a - cc) / (a - 2 * b + cc) if (a - 2 * b + cc) != 0 else 0
    ys.append(j[0] + d)
ys = np.array(ys)
st = np.diff(ys)
print('cyclist steps', np.round(st, 2))
p = np.polyfit(np.arange(2, 72), ys[2:], 1)
print('cyclist fit slope px/frame', p[0], 'mean step 2..71', st[1:].mean(), 'median', np.median(st[1:]))
v = abs(p[0]) * 24
scale = 5.33 / v
print('px/s', v, 'm/px', scale)

# van length: column-profile brightness along x=790..875 in frame 0 and several frames
for i in [0, 10, 20, 30, 40, 50]:
    col = fr[i][:, 800 - OX:866 - OX].mean(axis=1)
    bg = np.median(fr[i][:, 700 - OX:760 - OX])
    m = np.where(col > bg + 40)[0]
    # longest run
    runs = np.split(m, np.where(np.diff(m) > 3)[0] + 1)
    rr = max(runs, key=len)
    L = rr[-1] - rr[0] + 1
    print('frame', i, 'van y', rr[0] + OY, rr[-1] + OY, 'len px', L, '->', L * scale, 'm')
np.save('cyc_y.npy', ys)
