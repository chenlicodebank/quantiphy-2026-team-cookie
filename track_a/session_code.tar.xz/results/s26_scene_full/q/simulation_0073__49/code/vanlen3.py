import av, numpy as np
want = {0, 5, 10, 71}
fr = {}
c = av.open('simulation_0073.mp4')
for i, f in enumerate(c.decode(video=0)):
    if i in want:
        fr[i] = f.to_ndarray(format='rgb24')[:, 760:910].astype(np.float32)
    if i > 71: break
c.close()
scale = 5.33 / (8.9804 * 24)
for i in (0, 5, 10):
    d = np.abs(fr[i] - fr[71]).max(axis=2)
    pmax = d[:, 30:120].max(axis=1)     # x 790-880
    pmid = d[:, 65:80].mean(axis=1)     # centre columns x 825-840
    print('frame', i)
    for y in list(range(785, 815)) + list(range(1030, 1060)):
        print(y, int(pmax[y]), int(pmid[y]), fr[i][y, 73].astype(int), fr[71][y, 73].astype(int))
    for thr in (20, 40):
        idx = np.where(pmax[400:] > thr)[0] + 400
        runs = np.split(idx, np.where(np.diff(idx) > 2)[0] + 1)
        rr = max(runs, key=len)
        print('thr', thr, rr[0], rr[-1], rr[-1] - rr[0] + 1, (rr[-1] - rr[0] + 1) * scale)
