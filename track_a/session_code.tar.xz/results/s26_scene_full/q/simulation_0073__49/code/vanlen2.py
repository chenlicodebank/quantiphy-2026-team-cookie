import av, numpy as np
want = {0, 71, 20, 25, 30, 35, 40, 50, 55, 60}
fr = {}
c = av.open('simulation_0073.mp4')
for i, f in enumerate(c.decode(video=0)):
    if i in want:
        fr[i] = f.to_ndarray(format='rgb24')[:, 760:910].astype(np.float32)
c.close()
scale = 5.33 / (8.9804 * 24)
Ls = []
for i, bgi, lo, hi in [(20, 71, 400, 1080), (25, 71, 400, 1080), (30, 71, 400, 1080), (35, 71, 400, 1080), (40, 71, 380, 1080),
                       (50, 0, 0, 790), (55, 0, 0, 790), (60, 0, 0, 790)]:
    d = np.abs(fr[i] - fr[bgi]).max(axis=2)[lo:hi]
    # body columns ~800-866 -> 40..106
    prof = d[:, 40:106].mean(axis=1)
    out = []
    for thr in (10, 20, 30):
        idx = np.where(prof > thr)[0]
        runs = np.split(idx, np.where(np.diff(idx) > 2)[0] + 1)
        rr = max(runs, key=len)
        out.append((rr[0] + lo, rr[-1] + lo, rr[-1] - rr[0] + 1))
    print(i, out)
    Ls.append(out[1][2])
print('median L', np.median(Ls), 'm', np.median(Ls) * scale)
