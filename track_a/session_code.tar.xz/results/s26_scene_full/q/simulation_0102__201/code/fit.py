import numpy as np, csv
def load(f):
    return list(csv.DictReader(open(f)))
def col(rows,k):
    return np.array([float(r[k]) if r[k]!='' else np.nan for r in rows])
s=load('scene/tracks/shark.csv'); b=load('scene/tracks/boat.csv')
fr=np.array([int(r['frame']) for r in s])
for key in ['ref_x','nose_x_sub','tail_x_sub']:
    x=col(s,key)
    for lo,hi in [(1,60),(1,30),(30,60),(2,58)]:
        m=(fr>=lo)&(fr<=hi)&np.isfinite(x)
        p=np.polyfit(fr[m],x[m],2); res=x[m]-np.polyval(p,fr[m])
        print(key,lo,hi,'acc px/f^2 %.4f px/s^2 %.2f v@f1 %.2f rms %.2f'%(2*p[0],2*p[0]*576,np.polyval(np.polyder(p),1),res.std()))
bx=col(b,'ref_x'); print('boat ref_x f12',bx[12],'step',np.round(np.diff(bx)[:15],2))
p=np.polyfit(fr[2:72],bx[2:72],2); print('boat quad acc px/f2',2*p[0])
sx=col(s,'ref_x'); print('shark ref f12',sx[12])
