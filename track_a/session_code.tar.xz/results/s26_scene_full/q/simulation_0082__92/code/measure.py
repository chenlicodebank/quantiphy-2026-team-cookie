import av, numpy as np, cv2
FR = [0, 47, 48, 49]
c = av.open('simulation_0082.mp4')
frames = {}
for i, f in enumerate(c.decode(video=0)):
    if i in FR:
        frames[i] = f.to_ndarray(format='rgb24').astype(int)
    if i > max(FR):
        break
for i in FR:
    im = frames[i]
    mn, mx = im.min(2), im.max(2)
    hsv = cv2.cvtColor(im.astype(np.uint8), cv2.COLOR_RGB2HSV)
    m = (mn < 100) | (mx > 172) | (hsv[..., 1] > 50)
    out = {}
    for name, (y0, y1, core) in {'yellow': (300, 468, (375, 430)), 'white': (468, 640, (515, 580))}.items():
        sub = m[core[0]:core[1]]
        cols = np.where(sub.sum(0) > 0.3 * (core[1] - core[0]))[0]
        x0, x1 = cols.min(), cols.max()
        band = m[y0:y1, x0:x1 + 1]
        rows = np.where(band.sum(1) > 0.5 * (x1 - x0))[0] + y0
        ya, yb = rows.min(), rows.max()
        out[name] = ((x0 + x1) / 2, (ya + yb) / 2, x1 - x0 + 1, yb - ya + 1)
        # mask centroid
        ys, xs = np.nonzero(m[ya:yb + 1, x0:x1 + 1])
        out[name] += (xs.mean() + x0, ys.mean() + ya)
    print(i, out)
    Y, W = out['yellow'], out['white']
    d = np.hypot(Y[0] - W[0], Y[1] - W[1])
    for L in (Y[2], 304, 308):
        print('  dpx %.1f  L %d -> %.3f m' % (d, L, d * 5.67 / L))
    print('  centroid dpx %.1f -> %.3f m' % (np.hypot(Y[4] - W[4], Y[5] - W[5]), np.hypot(Y[4] - W[4], Y[5] - W[5]) * 5.67 / Y[2]))
