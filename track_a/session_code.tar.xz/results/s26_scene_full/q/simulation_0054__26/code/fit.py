import numpy as np
r = np.load('edges.npy')
f = r[:, 0]
glen = np.median(r[37:71, 5] - r[37:71, 4] + 1)
print('green len px median f37-70:', glen, 'mean', np.mean(r[37:71, 5] - r[37:71, 4] + 1))
for name, y, a, b in [('front f16-90', r[:, 2], 16, 91), ('front f37-90', r[:, 2], 37, 91),
                      ('rear f30-90', r[:, 1], 30, 91), ('centre f30-90', (r[:, 1] + r[:, 2]) / 2, 30, 91),
                      ('centre f16-60', (r[:, 1] + r[:, 2]) / 2, 16, 61), ('centre f45-90', (r[:, 1] + r[:, 2]) / 2, 45, 91),
                      ('front f0-90', r[:, 2], 0, 91)]:
    c = np.polyfit(f[a:b], y[a:b], 2)
    res = y[a:b] - np.polyval(c, f[a:b])
    acc = 2 * c[0]  # px/frame^2
    print(name, 'acc px/frame^2 %.4f' % acc, 'rms %.2f' % res.std())
