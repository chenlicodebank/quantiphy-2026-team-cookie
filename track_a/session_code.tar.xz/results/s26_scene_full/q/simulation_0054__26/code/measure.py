import av, numpy as np, cv2
bg = cv2.imread('scene/bg.png')[:, :, ::-1].astype(np.int16)  # RGB
cont = av.open('simulation_0054.mp4')
rows = []
for i, fr in enumerate(cont.decode(video=0)):
    if i > 90: break
    img = fr.to_ndarray(format='rgb24').astype(np.int16)
    d = np.abs(img - bg).max(2) > 40
    d = cv2.morphologyEx(d.astype(np.uint8), cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
    d = cv2.morphologyEx(d, cv2.MORPH_CLOSE, np.ones((15, 15), np.uint8))
    res = [i]
    for xa, xb in [(290, 570), (570, 850)]:
        sub = d[:, xa:xb]
        n, lab, st, _ = cv2.connectedComponentsWithStats(np.ascontiguousarray(sub).astype(np.uint8))
        if n <= 1:
            res += [np.nan] * 3; continue
        sizes = st[1:, cv2.CC_STAT_AREA]
        k = np.argmax(sizes) + 1
        ys, xs = np.nonzero(lab == k)
        # length along y using central columns (avoid mirrors irrelevant for y anyway)
        res += [ys.min(), ys.max(), sizes[k - 1]]
    rows.append(res)
rows = np.array(rows, float)
np.save('edges.npy', rows)
fps = 30.003
o = rows[:, 1:4]; g = rows[:, 4:7]
print('frame oy0 oy1 olen | gy0 gy1 glen')
for r in rows:
    print(int(r[0]), r[1], r[2], r[2] - r[1] + 1, '|', r[4], r[5], r[5] - r[4] + 1)
