import csv, numpy as np
r = list(csv.DictReader(open('scene/tracks/shark.csv')))
f = np.array([int(x['frame']) for x in r]); t = f / 24.0
for key in ['cx', 'x0', 'x1', 'bbox_cx']:
    y = np.array([float(x[key]) for x in r])
    for lo in [1, 2, 10]:
        m = f >= lo
        c = np.polyfit(t[m], y[m], 2)
        res = y[m] - np.polyval(c, t[m])
        print(key, lo, 'a_px=%.2f' % (2 * c[0]), 'v(t)=', '%.1f' % c[1], 'rms %.2f' % res.std())
    # cubic check
    m = f >= 2
    c3 = np.polyfit(t[m], y[m], 3)
    print('  cubic coeffs', c3)
h = np.array([float(x['bbox_h']) for x in r]); print('h median', np.median(h), h.mean())
