import csv,numpy as np
r=list(csv.DictReader(open('scene/tracks/shark.csv')))
f=np.array([int(x['frame']) for x in r]);
for k in ['centroid_x','bbox_cx','nose_x','tail_x']:
    x=np.array([float(q[k]) for q in r])
    for lo,hi in [(1,72),(2,72),(1,36),(36,72),(10,72)]:
        m=(f>=lo)&(f<=hi); t=f[m]/24
        p=np.polyfit(t,x[m],2); res=x[m]-np.polyval(p,t)
        print(k,lo,hi,'a=%.2f px/s2 v0=%.1f rms=%.2f'%(2*p[0],p[1],res.std()))
x=np.array([float(q['centroid_x']) for q in r]);print(np.round(np.diff(x),1))
