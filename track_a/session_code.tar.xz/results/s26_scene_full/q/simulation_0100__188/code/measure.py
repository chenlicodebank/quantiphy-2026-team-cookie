import av, numpy as np, cv2
cont = av.open('simulation_0100.mp4')
want = {0, 1, 18, 20, 24, 28, 30, 57}
fr = {}
for i, f in enumerate(cont.decode(video=0)):
    if i in want:
        fr[i] = cv2.cvtColor(f.to_ndarray(format='rgb24'), cv2.COLOR_RGB2GRAY).astype(np.float32)
    if i > max(want): break

# Boat length at frame 57: difference vs frame 0 is confounded; use colour-free approach: diff vs a frame where boat is elsewhere
# Use frame 20 as background for right part and frame 57 itself; simpler: rows 380-640 column profile of |f57 - f0| where boat not present in f0 region
d = np.abs(fr[57] - fr[0])
for rows in [(380, 560), (450, 560), (300, 640)]:
    band = d[rows[0]:rows[1]]
    cols = np.where((band > 25).sum(0) > 3)[0]
    print('boat diff cols rows', rows, cols.min(), cols.max())
# bow edge detail per row at frame 57 (red hull vs grey sky)
img = fr[57]
for y in range(360, 640, 20):
    row = img[y, 1300:1600]
    g = np.abs(np.diff(row))
    print(y, 1300 + int(np.argmax(g)))
# stern: rows 470-560 leftmost strong edge in 600-720
for y in range(460, 600, 10):
    row = img[y, 600:760]
    g = np.abs(np.diff(row))
    print('stern', y, 600 + int(np.argmax(g)), g.max())

# Shark speed: template match underwater panel around frame 24 window
def shark_x(i, ref):
    tpl = ref[840:970, :]
    return tpl
ref = fr[24][840:975]
bg = np.median(np.stack([fr[0][840:975], fr[57][840:975]]), 0)
# locate shark in frame 24 via difference to frame 57 (shark elsewhere far)
m = np.abs(fr[24][840:975] - fr[57][840:975]) > 20
xs = np.where(m.sum(0) > 2)[0]
print('shark24 cols approx', xs.min(), xs.max())
x0, x1 = 1230, 1560
tpl = fr[24][845:970, x0:x1]
for i in [18, 20, 28, 30]:
    res = cv2.matchTemplate(fr[i][845:970], tpl, cv2.TM_CCOEFF_NORMED)
    _, mx, _, loc = cv2.minMaxLoc(res)
    r = res[0]; k = loc[0]
    sub = k + 0.5 * (r[k-1] - r[k+1]) / (r[k-1] - 2*r[k] + r[k+1])
    print(i, 'shift', sub - x0, 'per frame', (sub - x0) / (i - 24), mx)
