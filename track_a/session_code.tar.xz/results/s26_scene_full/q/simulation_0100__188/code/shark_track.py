import av, numpy as np, cv2
cont = av.open('simulation_0100.mp4')
F = []
for i, f in enumerate(cont.decode(video=0)):
    g = cv2.cvtColor(f.to_ndarray(format='rgb24'), cv2.COLOR_RGB2GRAY).astype(np.float32)
    F.append(g[845:970].copy())
F = np.stack(F)
x0, x1 = 1245, 1535
tpl = F[24][:, x0:x1]
xs = []
for i in range(len(F)):
    res = cv2.matchTemplate(F[i], tpl, cv2.TM_CCOEFF_NORMED)[0]
    k = int(np.argmax(res))
    sub = k + 0.5 * (res[k-1] - res[k+1]) / (res[k-1] - 2*res[k] + res[k+1]) if 0 < k < len(res)-1 else k
    xs.append(sub - x0)
xs = np.array(xs)
d = np.diff(xs)
print('steps', np.round(d, 2))
for a, b in [(2, 57), (12, 36), (18, 30), (20, 28), (1, 57)]:
    print(a, b, (xs[b] - xs[a]) / (b - a))
fr = np.arange(2, 58)
p = np.polyfit(fr, xs[2:], 1); print('fit slope', p[0], 'resid', np.std(xs[2:] - np.polyval(p, fr)))
print('step at 24:', d[23])
