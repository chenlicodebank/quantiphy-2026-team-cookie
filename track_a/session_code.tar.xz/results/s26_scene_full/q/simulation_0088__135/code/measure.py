import av, numpy as np, cv2
bg = np.array([97,149,191.])
res = {}
c = av.open('simulation_0088.mp4')
for i, fr in enumerate(c.decode(video=0)):
    a = fr.to_ndarray(format='rgb24').astype(float)
    d = np.abs(a - bg).sum(2)
    out = {}
    for th in (25, 40, 60):
        m = (d > th).astype(np.uint8)
        n, lab, st, cen = cv2.connectedComponentsWithStats(m)
        comps = [(st[k], k) for k in range(1, n) if st[k][4] > 300]
        out[th] = comps
    res[i] = out
    if i < 26:
        line = f'{i:2d}'
        for th in (25, 40, 60):
            for s, k in sorted(out[th], key=lambda z: z[0][0]):
                x, y, w, h, A = s
                line += f' | th{th} x{x}-{x+w-1} y{y}-{y+h-1} w{w} h{h}'
        print(line)
