import av, numpy as np
c = av.open('simulation_0091.mp4')
fr = [f.to_ndarray(format='rgb24').astype(np.int16) for f in c.decode(video=0)]
bg = np.median(np.stack([fr[i] for i in (14, 20, 26, 29)]), 0)
for i in range(12):
    m = np.abs(fr[i] - bg).sum(2) > 30
    xs = np.where(m.any(0))[0]
    L = xs[xs < 950] if i < 8 else np.array([])
    R = xs[xs >= 950] if i < 2 else xs[xs >= 1000]
    print(i, (L.min(), L.max()) if len(L) else None, (R.min(), R.max()) if len(R) else None)
