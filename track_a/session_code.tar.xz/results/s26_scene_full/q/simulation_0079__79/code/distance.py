import numpy as np
# Frame 12 (t=0.5 s). Top-down pinhole camera, principal point assumed at image centre.
cx, cy = 960.0, 540.0
head = np.array([1756.7, 437.0])     # walker hair-blob centroid (scene/tracks/walker.csv)
bike = np.array([1262.5, 649.0])     # midpoint of bike front/rear tips (cyclist.csv)
k_bar = 0.0356                       # handlebar-minus-front-tip parallax slope (handlebar.py)
L_px_centre = 404.2 + 0.0065 * 960   # tip-to-tip length when bike is centred (handlebar.py fit)
for h_bar, h_tip, h_head, h_pel in [(1.0, 0.34, 1.68, 0.98), (1.05, 0.34, 1.70, 1.0),
                                     (0.95, 0.34, 1.65, 0.95), (1.1, 0.34, 1.72, 1.02)]:
    D = h_bar + (h_bar - h_tip) / k_bar          # camera height above floor
    f = L_px_centre / 1.7 * (D - h_tip)          # px focal length (bike length 1.7 m at tip height)
    Xp = (head - [cx, cy]) * (D - h_head) / f    # pelvis assumed vertically below the head
    Xb = (bike - [cx, cy]) * (D - h_tip) / f
    dh = np.linalg.norm(Xp - Xb)
    print('D=%.2f f=%.0f hfov=%.1f  horiz=%.3f  3D(bike root at ground)=%.3f  3D(root at %.2f)=%.3f' % (
        D, f, np.degrees(2 * np.arctan(960 / f)), dh, np.hypot(dh, h_pel), h_tip, np.hypot(dh, h_pel - h_tip)))
naive = np.linalg.norm(head - bike) / 412 * 1.7
print('naive single scale, head point: %.3f' % naive)
