import av, numpy as np, csv
# Track the handlebar (transverse cyan bar) x vs bike front/rear tips, to measure perspective parallax.
P = '/private/tmp/qp_blind/scene_full_b/simulation_0079/q_79/'
B = {int(r['frame']): r for r in csv.DictReader(open(P + 'scene/tracks/cyclist.csv'))}
c = av.open(P + 'simulation_0079.mp4')
out = []
for i, fr in enumerate(c.decode(video=0)):
    if i < 4 or i > 32:
        continue
    a = fr.to_ndarray(format='rgb24').astype(int)
    r, g, b = a[..., 0], a[..., 1], a[..., 2]
    cyan = (b - r > 25) & (g - r > 20)
    ft, rt = float(B[i]['bike_front_tip_x']), float(B[i]['bike_rear_tip_x'])
    x0, x1 = int(ft), int(rt)
    # grips: cyan pixels in y bands far from axis (y<615 or y>685)
    res = {}
    for name, ys in (('top', slice(585, 615)), ('bot', slice(683, 715))):
        m = cyan[ys, x0:x1 + 1]
        yy, xx = np.nonzero(m)
        res[name] = (xx.mean() + x0, len(xx)) if len(xx) else (np.nan, 0)
    # axis-band cyan extents
    m = cyan[640:658, :]
    cols = np.nonzero(m.sum(0) > 0)[0]
    out.append((i, ft, rt, res['top'][0], res['top'][1], res['bot'][0], res['bot'][1], cols.min(), cols.max()))
    print(i, ft, rt, '%.1f %d %.1f %d' % (res['top'][0], res['top'][1], res['bot'][0], res['bot'][1]), cols.min(), cols.max())
o = np.array(out, float)
bar = (o[:, 3] + o[:, 5]) / 2
cen = (o[:, 1] + o[:, 2]) / 2
d = bar - o[:, 1]
p = np.polyfit(cen, d, 1)
print('bar - fronttip vs centre: slope %.4f intercept %.1f' % tuple(p))
p2 = np.polyfit(cen, o[:, 2] - o[:, 1], 1)
print('length vs centre: slope %.4f intercept %.1f' % tuple(p2))
