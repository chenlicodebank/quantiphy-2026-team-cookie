import av, numpy as np, csv, cv2, sys
P = '/private/tmp/qp_blind/scene_full_b/simulation_0079/q_79/'
W = {int(r['frame']): r for r in csv.DictReader(open(P + 'scene/tracks/walker.csv'))}
want = set(int(a) for a in sys.argv[1:]) if len(sys.argv) > 1 else set(range(72))
c = av.open(P + 'simulation_0079.mp4')
for i, fr in enumerate(c.decode(video=0)):
    if i not in want:
        continue
    img = fr.to_ndarray(format='rgb24').astype(int)
    r = W[i]
    x0, x1 = int(r['bbox_x0']) - 10, min(1920, int(r['bbox_x1']) + 10)
    y0, y1 = int(r['bbox_y0']) - 10, int(r['bbox_y1']) + 10
    sub = img[y0:y1, x0:x1]
    v = sub.max(2); s = v - sub.min(2)
    hx, hy = float(r['head_x']), float(r['head_y'])
    dark = (v < 45)
    yy, xx = np.mgrid[y0:y1, x0:x1]
    dist = np.hypot(xx - hx, yy - hy)
    shoe = dark & (dist > 32)
    n, lab, st, cen = cv2.connectedComponentsWithStats(shoe.astype(np.uint8))
    blobs = [(st[k, 4], cen[k, 0] + x0, cen[k, 1] + y0) for k in range(1, n) if st[k, 4] > 30]
    blobs.sort(reverse=True)
    # also: hair blob stats
    hair = dark & (dist <= 32)
    print(i, 'head', hx, hy, 'shoes', [(a, round(b, 1), round(cc, 1)) for a, b, cc in blobs[:3]])
