import av, numpy as np, cv2, os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
os.makedirs('frames', exist_ok=True)
bg = np.array([80, 81, 88])
c = av.open('simulation_0093.mp4')
for i, fr in enumerate(c.decode(video=0)):
    if i not in (0, 2, 5, 10, 15, 18):
        continue
    img = fr.to_ndarray(format='rgb24').astype(int)
    for th in (12, 18, 30):
        m = (np.abs(img - bg).max(2) > th).astype(np.uint8)
        m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
        n, lab, st, _ = cv2.connectedComponentsWithStats(m)
        for k in range(1, n):
            x, y, w, h, a = st[k]
            if a < 30: continue
            print(i, th, 'comp', x, y, x + w - 1, y + h - 1, 'w', w, 'h', h, 'area', a)
        # also union bbox per half
        for name, ys in (('plane', slice(0, 580)), ('car', slice(580, 1080))):
            mm = m[ys]
            yy, xx = np.nonzero(mm)
            if len(xx):
                print(i, th, name, 'union w', xx.max() - xx.min() + 1, 'h', yy.max() - yy.min() + 1,
                      'x', xx.min(), xx.max(), 'y', yy.min() + ys.start, yy.max() + ys.start)
    if i == 0:
        im = cv2.cvtColor(img.astype(np.uint8), cv2.COLOR_RGB2BGR)
        cv2.imwrite('frames/plane0.png', cv2.resize(im[340:580, 700:1360], None, fx=2, fy=2, interpolation=cv2.INTER_NEAREST))
        cv2.imwrite('frames/car0.png', cv2.resize(im[590:650, 840:960], None, fx=8, fy=8, interpolation=cv2.INTER_NEAREST))
