import av, numpy as np, cv2
D = '/private/tmp/qp_blind/scene_full_b/simulation_0054/q_28/'
bg = cv2.imread(D + 'scene/bg.png').astype(np.int16)
c = av.open(D + 'simulation_0054.mp4')
for i, f in enumerate(c.decode(video=0)):
    if i not in (60, 75, 87, 90): continue
    a = f.to_ndarray(format='bgr24').astype(np.int16)
    d = np.abs(a - bg).max(2)
    print('frame', i)
    for th in (25, 40, 60):
        ext = []
        for y in range(0, 1080):
            xx = np.nonzero(d[y, 250:470] > th)[0] + 250
            if len(xx) > 30: ext.append((y, xx.min(), xx.max()))
        ext = np.array(ext)
        w = ext[:, 2] - ext[:, 1] + 1
        k = np.argsort(-w)[:5]
        print(' th', th, 'rows', ext[0, 0], ext[-1, 0], 'max widths', [(int(ext[j, 0]), int(ext[j, 1]), int(ext[j, 2])) for j in k])
    if i == 87:
        for y in (800, 850, 900, 935, 940, 1000):
            print(y, ' '.join(f'{v}' for v in d[y, 278:305]), '|', ' '.join(f'{v}' for v in d[y, 395:420]))
