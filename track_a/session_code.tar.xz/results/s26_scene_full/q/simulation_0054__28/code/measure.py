import av, numpy as np, cv2
D = '/private/tmp/qp_blind/scene_full_b/simulation_0054/q_28/'
bg = cv2.imread(D + 'scene/bg.png').astype(np.int16)
k5 = np.ones((5, 5), np.uint8)
rows = []
c = av.open(D + 'simulation_0054.mp4')
for i, f in enumerate(c.decode(video=0)):
    a = f.to_ndarray(format='bgr24')
    if a.mean() < 5:
        continue
    d = np.abs(a.astype(np.int16) - bg).max(2)
    m = (d > 40).astype(np.uint8)
    m[:, 570:] = 0
    m = cv2.morphologyEx(m, cv2.MORPH_OPEN, k5)
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((15, 15), np.uint8))
    n, lab, st, cen = cv2.connectedComponentsWithStats(m)
    if n < 2: continue
    j = 1 + np.argmax(st[1:, 4])
    mm = (lab == j)
    ys, xs = np.nonzero(mm)
    y0, y1, x0, x1 = ys.min(), ys.max(), xs.min(), xs.max()
    # orange-ness mask: R high, B low
    A = a.astype(int)
    orng = (A[:, :, 2] > 150) & (A[:, :, 2] - A[:, :, 0] > 80) & mm
    oy, ox = np.nonzero(orng)
    # width per row from orange mask
    wrow = []
    for y in range(y0, y1 + 1):
        xx = np.nonzero(orng[y])[0]
        if len(xx): wrow.append(xx.max() - xx.min() + 1)
    wrow = np.array(wrow)
    rows.append((i, y0, y1, x0, x1, ox.min(), ox.max(), np.percentile(wrow, 95), np.median(wrow)))
    if i in (60, 87):
        v = a.copy(); v[orng] = (0, 255, 0)
        cv2.rectangle(v, (x0, y0), (x1, y1), (255, 0, 255), 1)
        cv2.imwrite(D + f'frames/ov_{i}.png', v[max(0,y0-20):y1+20, 250:470])
np.save(D + 'rows.npy', np.array(rows, float))
for r in rows: print(*[round(float(x), 1) for x in r])
