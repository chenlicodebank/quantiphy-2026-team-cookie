import numpy as np
D = '/private/tmp/qp_blind/scene_full_b/simulation_0054/q_28/'
r = np.load(D + 'rows.npy')
f = r[:, 0]; y0 = r[:, 1]; y1 = r[:, 2]; cy = (y0 + y1) / 2
for name, y, lo in (('centre', cy, 16), ('front', y1, 3), ('rear', y0, 16)):
    for a, b in ((lo, 90), (lo, 50), (50, 90), (30, 90)):
        k = (f >= a) & (f <= b)
        p = np.polyfit(f[k], y[k], 2)
        res = y[k] - np.polyval(p, f[k])
        print(name, a, b, 'acc px/f^2 %.4f' % (2 * p[0]), 'v@f50 %.2f' % np.polyval(np.polyder(p), 50), 'rms %.2f' % res.std())
# speed per frame (5-frame differences) to check constancy
k = f >= 16
v = np.diff(cy[k]); print(np.round(np.convolve(v, np.ones(5) / 5, 'valid')[::5], 2))
# cubic test
k = (f >= 16)
print('cubic', np.polyfit(f[k], cy[k], 3))
