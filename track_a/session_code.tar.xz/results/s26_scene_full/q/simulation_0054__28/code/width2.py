import av, numpy as np, cv2
D = '/private/tmp/qp_blind/scene_full_b/simulation_0054/q_28/'
bg = cv2.imread(D + 'scene/bg.png').astype(np.int16)
rows = np.load(D + 'rows.npy')
c = av.open(D + 'simulation_0054.mp4')
for i, f in enumerate(c.decode(video=0)):
    if i not in (45, 60, 75, 87, 90): continue
    r = rows[rows[:, 0] == i][0]; y0, y1 = int(r[1]), int(r[2])
    a = f.to_ndarray(format='bgr24').astype(np.int16)
    d = np.abs(a - bg).max(2)[y0:y1 + 1, 270:430]
    for th in (50, 80):
        frac = (d > th).mean(0)
        cols = np.arange(270, 430)
        s = ' '.join(f'{x}:{v:.2f}' for x, v in zip(cols, frac) if 0.01 < v)
        on = cols[frac > 0.02]; body = cols[frac > 0.3]
        print(i, th, 'any', on.min(), on.max(), on.max() - on.min() + 1, 'body', body.min(), body.max(), body.max() - body.min() + 1)
        if i == 87 and th == 50: print(s)
