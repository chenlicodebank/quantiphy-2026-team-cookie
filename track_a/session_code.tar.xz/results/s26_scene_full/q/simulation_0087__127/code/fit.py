import csv, numpy as np
D='/private/tmp/qp_blind/scene_full_a/simulation_0087/q_127/'
car=list(csv.DictReader(open(D+'scene/tracks/car.csv')))
cyc=list(csv.DictReader(open(D+'scene/tracks/cyclist.csv')))
f=np.array([int(r['frame']) for r in car]); x0=np.array([float(r['x0']) for r in car]); x1=np.array([float(r['x1']) for r in car])
for lo,hi in [(2,53),(2,36),(10,53),(20,53),(37,53)]:
    m=(f>=lo)&(f<=hi); p=np.polyfit(f[m],x0[m],2); r=x0[m]-np.polyval(p,f[m])
    print('x0',lo,hi,'a px/f2=',2*p[0],'rms',r.std(), 'vertex frame',-p[1]/(2*p[0]))
m=f>=37; p=np.polyfit(f[m],x1[m],2); print('x1 a',2*p[0])
m=f>=37; p=np.polyfit(f[m],(x0[m]+x1[m])/2,2); print('cx a',2*p[0])
# cubic check for jerk
m=(f>=2); p=np.polyfit(f[m],x0[m],3); print('cubic',p)
