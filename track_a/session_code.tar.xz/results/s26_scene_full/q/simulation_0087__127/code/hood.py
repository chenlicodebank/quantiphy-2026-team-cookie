import av, numpy as np
D='/private/tmp/qp_blind/scene_full_a/simulation_0087/q_127/'
E=np.load(D+'edges.npy')
c=av.open(D+'simulation_0087.mp4')
for i,fr in enumerate(c.decode(video=0)):
    if i not in (12,20,30,37,45,53): continue
    g=fr.to_ndarray(format='gray').astype(float)
    p=g[660:720].mean(0)
    xf=int(E[i,1])
    seg=p[xf-15:xf+130]
    print(i, xf, ' '.join('%d'%v for v in seg[::3]))
    # hood->windshield: first big drop after front edge + 20
    d=np.diff(p[xf+20:xf+200]); k=np.argmin(d)+xf+20
    # top bright end
    print('   windshield drop at',k,'hood len',k-E[i,1])
