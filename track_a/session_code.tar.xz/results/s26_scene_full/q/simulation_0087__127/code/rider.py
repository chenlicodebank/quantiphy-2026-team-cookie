import numpy as np, csv
D='/private/tmp/qp_blind/scene_full_a/simulation_0087/q_127/'
cyc=list(csv.DictReader(open(D+'scene/tracks/cyclist.csv')))
for r in cyc[7::3]:
    print(r['frame'], r['ref_x'], r['rider_cx'], round(float(r['rider_cx'])-float(r['ref_x']),1), r['len_x'], r['rider_x0'], r['rider_x1'], r['rider_y0'], r['rider_y1'], r['y0'], r['y1'])
