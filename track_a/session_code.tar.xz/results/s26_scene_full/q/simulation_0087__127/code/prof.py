import numpy as np
D='/private/tmp/qp_blind/scene_full_a/simulation_0087/q_127/'
o=np.load(D+'tm.npy'); f=o[:,0]; v=-o[:,1]
for a in range(3,48,4):
    m=(f>=a)&(f<a+8); p=np.polyfit(f[m],v[m],1); print('frames %d-%d accel %.3f'%(a,a+7,p[0]))
# fit v = c*(i-i0)^n
from scipy.optimize import curve_fit
fn=lambda i,c,i0,n: c*np.clip(i-i0,1e-6,None)**n
p,_=curve_fit(fn,f,v,p0=[0.7,0.5,1]); print('power fit',p, 'rms',(v-fn(f,*p)).std())
fq=lambda i,a,b,c: a+b*i+c*i*i
p2,_=curve_fit(fq,f,v); print('quad v',p2,'rms',(v-fq(f,*p2)).std())
