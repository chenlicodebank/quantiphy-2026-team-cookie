import av, numpy as np
D='/private/tmp/qp_blind/scene_full_a/simulation_0087/q_127/'
c=av.open(D+'simulation_0087.mp4')
rows=[]
for i,fr in enumerate(c.decode(video=0)):
    g=fr.to_ndarray(format='gray').astype(float)
    # car front edge: band rows 640-740 averaged
    prof=g[640:740].mean(0)
    dev=np.abs(prof-np.median(prof))
    thr=25
    idx=np.where(dev[600:]>thr)[0]
    xf=None
    if len(idx):
        k=idx[0]+600
        # subpixel crossing
        xf=k-1+(thr-dev[k-1])/(dev[k]-dev[k-1])
    # car rear edge (only when not truncated)
    idx2=np.where(dev>thr)[0]
    xr=None
    if len(idx2) and idx2[-1]<1915:
        k=idx2[-1]; xr=k+(dev[k]-thr)/(dev[k]-dev[k+1])
    # mirrors: dark blobs in rows 560-580 (top mirror)
    pm=g[562:578].mean(0); dm=np.where(pm<80)[0]
    mx=dm.mean() if len(dm)>3 else None
    rows.append((i,xf,xr,mx))
    print(i,xf,xr,mx)
np.save(D+'edges.npy',np.array([[r[0]]+[np.nan if v is None else v for v in r[1:]] for r in rows]))
