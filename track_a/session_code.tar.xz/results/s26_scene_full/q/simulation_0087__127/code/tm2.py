import av, numpy as np, cv2
D='/private/tmp/qp_blind/scene_full_a/simulation_0087/q_127/'
c=av.open(D+'simulation_0087.mp4')
E=np.load(D+'edges.npy')
def match(prev,g,x0,x1,y0=575,y1=800):
    T=prev[y0:y1, x0:x1]; S=g[y0:y1, x0-50:x1+5]
    R=cv2.matchTemplate(S,T,cv2.TM_SQDIFF)[0]; k=int(np.argmin(R))
    dk=0.5*(R[k-1]-R[k+1])/(R[k-1]-2*R[k]+R[k+1]) if 0<k<len(R)-1 else 0
    return (k+dk)-50
prev=None; out=[]
for i,fr in enumerate(c.decode(video=0)):
    g=fr.to_ndarray(format='gray').astype(np.float32)
    if prev is not None and i>=38:
        xf=int(E[i-1,1]); xr=int(E[i-1,2])
        a=match(prev,g,xf-8,xf+200)           # front
        b=match(prev,g,xr-200,min(xr+8,1919-5)) # rear
        cc=match(prev,g,xf+200,xr-200)        # middle
        d=match(prev,g,xf-8,xr+8 if xr+8<1914 else 1914,640,740) # whole, central rows
        out.append((i,a,b,cc,d)); print(i,*np.round([a,b,cc,d],2))
    prev=g
o=np.array(out); f=o[:,0]
for j,n in enumerate(['front','rear','mid','whole']):
    p=np.polyfit(f,o[:,j+1],1); print(n,'a=%.4f rms %.2f'%(p[0],(o[:,j+1]-np.polyval(p,f)).std()))
