import av, numpy as np
D='/private/tmp/qp_blind/scene_full_a/simulation_0087/q_127/'
c=av.open(D+'simulation_0087.mp4')
R=np.load(D+'mirror.npy'); o=np.load(D+'tm.npy')
res=[]
def cross(p,k,thr):  # subpixel crossing between k-1,k
    return k-1+(thr-p[k-1])/(p[k]-p[k-1])
for i,fr in enumerate(c.decode(video=0)):
    g=fr.to_ndarray(format='gray').astype(float)
    p=g[660:720].mean(0)
    k=np.where(p<70)[0]; k=k[k>600]
    front=cross(p,k[0],70)
    rear=np.nan
    if i>=37:
        kk=k[-1]; rear=kk+(p[kk]-80)/(p[kk]-p[kk+1]) if p[kk+1]>80 else np.nan
        # rear: last px below 80
        k2=np.where(p<80)[0]; kk=k2[-1]; rear=kk+(80-p[kk])/(p[kk+1]-p[kk])
    res.append((i,front,rear))
    if i%4==1 or i>=37: print(i,round(front,1),round(rear,1) if rear==rear else '', 'len',round(rear-front,1) if rear==rear else '', 'mirror',np.round(np.nanmean(R[i,1:]),1))
res=np.array(res); np.save(D+'outline.npy',res)
f=res[:,0]; x=res[:,1]
for lo,hi in [(3,30),(10,53),(37,53)]:
    s=(f>=lo)&(f<=hi); p=np.polyfit(f[s],x[s],2); print('front',lo,hi,'a=%.4f'%(2*p[0]),'rms %.2f'%(x[s]-np.polyval(p,f[s])).std())
