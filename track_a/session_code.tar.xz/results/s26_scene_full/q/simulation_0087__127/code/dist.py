import numpy as np, csv
D='/private/tmp/qp_blind/scene_full_a/simulation_0087/q_127/'
o=np.load(D+'tm.npy'); f=o[:,0]; s=o[:,1]
E=np.load(D+'edges.npy')
cyc=list(csv.DictReader(open(D+'scene/tracks/cyclist.csv')))
for ref in range(45,54):
    cen=(E[ref,1]+E[ref,2])/2
    c12=cen-s[(f>12)&(f<=ref)].sum()
    print('ref frame',ref,'centre',round(cen,1),'-> car centre f12',round(c12,1))
# second route: front-edge at f12 + mean front-to-centre offset in fully visible frames
off=np.mean([(E[k,2]-E[k,1])/2 for k in range(45,54)])
print('front edge f12',E[12,1],'offset',off,'centre',E[12,1]+off)
scale=4.03/(0.7*576)
cx=float(cyc[12]['ref_x']); cy=float(cyc[12]['ref_y'])
for carx in [2030.5]:
    pass
