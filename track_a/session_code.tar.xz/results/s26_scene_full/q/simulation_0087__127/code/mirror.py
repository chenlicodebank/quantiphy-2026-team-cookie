import av, numpy as np
D='/private/tmp/qp_blind/scene_full_a/simulation_0087/q_127/'
c=av.open(D+'simulation_0087.mp4')
res=[]
for i,fr in enumerate(c.decode(video=0)):
    g=fr.to_ndarray(format='gray').astype(float)
    out=[i]
    for (y0,y1) in [(560,580),(797,817)]:   # top and bottom mirror rows
        p=g[y0:y1].mean(0)
        w=np.clip(90-p,0,None); w[:600]=0
        out.append((w*np.arange(1920)).sum()/w.sum() if w.sum()>50 and w[1905:].sum()==0 else np.nan)
    res.append(out)
R=np.array(res); f=R[:,0]; m=np.nanmean(R[:,1:],1)
for i in range(12,54,4): print(i,np.round(R[i,1:],1))
ok=~np.isnan(m)
for lo,hi in [(16,30),(16,36),(16,53),(37,53)]:
    s=ok&(f>=lo)&(f<=hi); p=np.polyfit(f[s],m[s],2); print(lo,hi,'a=%.4f'%(2*p[0]),'rms %.2f'%(m[s]-np.polyval(p,f[s])).std(),'x(12)=%.1f'%np.polyval(p,12),'vertex %.2f'%(-p[1]/2/p[0]))
np.save(D+'mirror.npy',R)
