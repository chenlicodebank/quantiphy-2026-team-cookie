import numpy as np
D='/private/tmp/qp_blind/scene_full_a/simulation_0087/q_127/'
E=np.load(D+'edges.npy'); f=E[:,0]
for name,col in [('front',1),('rear',2),('mirror',3)]:
    x=E[:,col]; ok=~np.isnan(x)
    for lo,hi in [(2,53),(5,53),(15,53),(2,30),(30,53),(37,53)]:
        m=ok&(f>=lo)&(f<=hi)
        if m.sum()<5: continue
        p=np.polyfit(f[m],x[m],2); r=x[m]-np.polyval(p,f[m])
        print(name,lo,hi,'a=%.4f rms=%.2f vertex=%.2f'%(2*p[0],r.std(),-p[1]/(2*p[0])))
x=E[:,1]; v=np.diff(x); print('front steps',np.round(v,1))
print('2nd diff of steps (avg over windows):',[(np.diff(x[a:a+12],2).mean()).round(3) for a in range(2,50,8)])
