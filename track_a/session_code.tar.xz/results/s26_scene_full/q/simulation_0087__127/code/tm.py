import av, numpy as np, cv2
D='/private/tmp/qp_blind/scene_full_a/simulation_0087/q_127/'
c=av.open(D+'simulation_0087.mp4')
E=np.load(D+'edges.npy')
prev=None; out=[]
for i,fr in enumerate(c.decode(video=0)):
    g=fr.to_ndarray(format='gray').astype(np.float32)
    if prev is not None and i>=3:
        x0=int(E[i-1,1])-8
        x1=min(x0+420, 1919-45)
        if x1-x0>60:
            T=prev[575:800, x0:x1]
            # search in current frame shifted left by 0..45
            S=g[575:800, x0-50:x1+5]
            R=cv2.matchTemplate(S,T,cv2.TM_SQDIFF)[0]
            k=int(np.argmin(R))
            if 0<k<len(R)-1:
                dk=0.5*(R[k-1]-R[k+1])/(R[k-1]-2*R[k]+R[k+1])
            else: dk=0
            shift=(k+dk)-50
            out.append((i,shift,x1-x0))
            print(i,round(shift,2),x1-x0)
    prev=g
np.save(D+'tm.npy',np.array(out))
o=np.array(out); f=o[:,0]; v=o[:,1]
for lo,hi in [(3,53),(3,25),(25,53),(10,53)]:
    m=(f>=lo)&(f<=hi); p=np.polyfit(f[m],v[m],1); print(lo,hi,'a=%.4f'%p[0],'v0 zero at frame %.2f'%(-p[1]/p[0]+0), 'rms %.2f'%(v[m]-np.polyval(p,f[m])).std())
