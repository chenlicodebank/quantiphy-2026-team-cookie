import av, numpy as np, cv2
C = np.array([540.0, 540.0])
frames = {}
c = av.open('simulation_0057.mp4')
for i, fr in enumerate(c.decode(video=0)):
    if i in (0, 45, 90):
        frames[i] = cv2.cvtColor(fr.to_ndarray(format='bgr24'), cv2.COLOR_BGR2GRAY)
heads = {'A': np.array([194.14, 449.84]), 'B': np.array([193.93, 980.05])}
guess = {'A': np.array([247.0, 465.0]), 'B': np.array([247.0, 910.0])}

def fit_circle(x, y):
    A = np.c_[2 * x, 2 * y, np.ones_like(x)]
    b = x ** 2 + y ** 2
    s = np.linalg.lstsq(A, b, rcond=None)[0]
    return s[0], s[1], np.sqrt(s[2] + s[0] ** 2 + s[1] ** 2)

out = {}
for fi in (0, 45, 90):
    g = cv2.GaussianBlur(frames[fi].astype(np.float32), (0, 0), 1.0)
    gx = cv2.Sobel(g, cv2.CV_32F, 1, 0); gy = cv2.Sobel(g, cv2.CV_32F, 0, 1)
    mag = np.hypot(gx, gy)
    for name in 'AB':
        c0 = guess[name].copy()
        for it in range(5):
            # radial profile search: for angles facing image centre (away from pole), find max gradient
            pole_dir = heads[name] - c0; pole_dir /= np.linalg.norm(pole_dir)
            xs, ys = [], []
            for ang in np.radians(np.arange(0, 360, 4)):
                d = np.array([np.cos(ang), np.sin(ang)])
                if d @ pole_dir > np.cos(np.radians(80)):  # skip pole / knob side
                    continue
                rr = np.arange(8, 22, 0.25)
                px = c0[0] + rr * d[0]; py = c0[1] + rr * d[1]
                m = cv2.remap(mag, px.astype(np.float32)[None], py.astype(np.float32)[None], cv2.INTER_LINEAR)[0]
                # outward edge: dark inside -> bright outside, gradient along d positive
                gd = cv2.remap(gx, px.astype(np.float32)[None], py.astype(np.float32)[None], cv2.INTER_LINEAR)[0] * d[0] + \
                     cv2.remap(gy, px.astype(np.float32)[None], py.astype(np.float32)[None], cv2.INTER_LINEAR)[0] * d[1]
                k = np.argmax(gd)
                xs.append(px[k]); ys.append(py[k])
            cx, cy, r = fit_circle(np.array(xs), np.array(ys))
            c0 = np.array([cx, cy])
        out[(fi, name)] = (c0, r)
        print(fi, name, 'centre (%.2f, %.2f) r %.2f n %d' % (cx, cy, r, len(xs)))
    a, b = out[(fi, 'A')][0], out[(fi, 'B')][0]
    print(' base dist px %.2f' % np.linalg.norm(a - b))
    for name in 'AB':
        bb = out[(fi, name)][0]
        k = np.linalg.norm(heads[name] - C) / np.linalg.norm(bb - C) - 1
        ang = np.degrees(np.arctan2(*(heads[name] - bb)[::-1]) - np.arctan2(*(bb - C)[::-1]))
        print('  %s k=%.3f radial-angle mismatch %.1f deg' % (name, k, ang))
