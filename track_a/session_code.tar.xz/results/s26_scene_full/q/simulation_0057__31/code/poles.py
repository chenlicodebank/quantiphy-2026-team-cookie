import av, numpy as np, cv2
c = av.open('simulation_0057.mp4')
for i, fr in enumerate(c.decode(video=0)):
    if i == 45:
        img = fr.to_ndarray(format='bgr24'); break
g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
pts = {}
for name, (x0, y0, x1, y1) in {'A': (225, 445, 270, 485), 'B': (225, 885, 270, 930)}.items():
    roi = g[y0:y1, x0:x1]
    for thr in (40, 50, 60):
        m = (roi < thr).astype(np.uint8)
        d = cv2.distanceTransform(m, cv2.DIST_L2, 5)
        yy, xx = np.unravel_index(np.argmax(d), d.shape)
        # refine: centroid of pixels with d >= 0.6*max (core of disc)
        core = d >= 0.6 * d.max()
        n, lab = cv2.connectedComponents(core.astype(np.uint8))
        k = lab[yy, xx]; ys, xs = np.nonzero(lab == k)
        # circle fit to edge of disc: pixels of mask within r_max+2 of center
        r = d.max()
        Y, X = np.mgrid[:m.shape[0], :m.shape[1]]
        cx, cy = xs.mean(), ys.mean()
        sel = m.astype(bool) & ((X - cx) ** 2 + (Y - cy) ** 2 <= (r + 1.5) ** 2)
        cx2, cy2 = X[sel].mean(), Y[sel].mean()
        print(name, thr, 'r %.1f' % r, 'core (%.1f,%.1f)' % (cx + x0, cy + y0), 'disc (%.1f,%.1f)' % (cx2 + x0, cy2 + y0))
        pts[(name, thr)] = np.array([cx2 + x0, cy2 + y0])
    cv2.imwrite('frames/pole_%s.png' % name, cv2.resize(np.dstack([roi] * 3), None, fx=6, fy=6, interpolation=cv2.INTER_NEAREST))
for thr in (40, 50, 60):
    print(thr, 'pole dist %.2f' % np.linalg.norm(pts[('A', thr)] - pts[('B', thr)]))
