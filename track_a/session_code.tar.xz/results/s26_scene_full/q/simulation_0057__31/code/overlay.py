import av, numpy as np, cv2
c = av.open('simulation_0057.mp4')
for i, fr in enumerate(c.decode(video=0)):
    if i == 45: img = fr.to_ndarray(format='bgr24'); break
S = 6
for (cx, cy, r, y0) in ((251.64, 465.10, 11.71, 440), (251.85, 908.99, 11.61, 885)):
    crop = cv2.resize(img[y0:y0 + 50, 225:280], None, fx=S, fy=S, interpolation=cv2.INTER_NEAREST)
    cv2.circle(crop, (int((cx - 225) * S), int((cy - y0) * S)), int(r * S), (0, 0, 255), 1)
    cv2.circle(crop, (int((cx - 225) * S), int((cy - y0) * S)), 3, (0, 255, 0), -1)
    cv2.imwrite('frames/ov_%d.png' % y0, crop)
