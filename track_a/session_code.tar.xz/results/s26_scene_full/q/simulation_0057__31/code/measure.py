import av, numpy as np, cv2, csv
c = av.open('simulation_0057.mp4')
for i, fr in enumerate(c.decode(video=0)):
    if i == 45:
        img = fr.to_ndarray(format='bgr24'); break
g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
out = img.copy()
res = {}
for name, (x0, y0, x1, y1) in {'A': (140, 400, 300, 520), 'B': (140, 870, 300, 1030)}.items():
    roi = g[y0:y1, x0:x1]
    m = (roi < 45).astype(np.uint8)
    me = cv2.erode(m, np.ones((7, 7), np.uint8))  # break thin arm
    n, lab, st, cen = cv2.connectedComponentsWithStats(me)
    comps = []
    for k in range(1, n):
        if st[k, 4] < 30: continue
        # centroid on the un-eroded blob restricted to dilated component
        comp = cv2.dilate((lab == k).astype(np.uint8), np.ones((7, 7), np.uint8)) & m
        ys, xs = np.nonzero(comp)
        comps.append((xs.mean() + x0, ys.mean() + y0, comp.sum(), xs.min() + x0, xs.max() + x0, ys.min() + y0, ys.max() + y0))
    comps.sort(key=lambda r: -r[2])
    res[name] = comps
    for cpt in comps:
        print(name, ['%.1f' % v for v in cpt])
        cv2.circle(out, (int(round(cpt[0])), int(round(cpt[1]))), 3, (0, 0, 255), -1)
cv2.imwrite('frames/lamps_mask.png', out[380:1050, 120:320])
# pole discs = smaller round blob, heads = largest
A = res['A']; B = res['B']
for label, ia in (('head', 0), ('pole', 1)):
    pa, pb = np.array(A[ia][:2]), np.array(B[ia][:2])
    print(label, pa, pb, 'dist px %.2f' % np.linalg.norm(pa - pb))

# car acceleration in px/s^2
rows = list(csv.DictReader(open('scene/tracks/orange_car.csv')))
f = np.array([int(r['frame']) for r in rows]); fps = 30.003297
cy = np.array([float(r['cy_best_px']) if r['cy_best_px'] else np.nan for r in rows])
cx = np.array([float(r['cx_best_px']) if r['cx_best_px'] else np.nan for r in rows])
sel = f >= 7
for fp in (fps, 30.0):
    t = f[sel] / fp
    p = np.polyfit(t, cy[sel], 2); print('fps', fp, 'quad fit accel px/s^2 %.2f' % (2 * p[0]))
    sp = np.hypot(np.diff(cx[sel]), np.diff(cy[sel])) * fp
    a = np.diff(sp) * fp
    print(' mean per-frame accel %.2f, median %.2f' % (a.mean(), np.median(a)))
    pl = np.polyfit(t[1:], sp, 1); print(' linear fit of speed slope %.2f' % pl[0])
    for lo, hi in ((7, 48), (48, 90)):
        s2 = (f >= lo) & (f <= hi)
        p = np.polyfit(f[s2] / fp, cy[s2], 2); print('  window', lo, hi, '%.2f' % (2 * p[0]))
