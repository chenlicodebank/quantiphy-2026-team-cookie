import av, numpy as np, csv
rows = np.arange(650, 731)
res = []
c = av.open('simulation_0087.mp4')
for i, fr in enumerate(c.decode(video=0)):
    g = fr.to_ndarray(format='gray').astype(float)
    band = g[rows].mean(0)  # mean over rows
    # front edge: first crossing from background (~140) to bright (>200) going left->right; level 170
    xs = np.where(band > 175)[0]
    x = xs[0]
    fe = (x - 1) + (175 - band[x - 1]) / (band[x] - band[x - 1])
    # windshield: first crossing bright->dark (<110) after fe+20
    j = x + 20
    while band[j] > 120 and j < 1919: j += 1
    ws = (j - 1) + (band[j - 1] - 120) / (band[j - 1] - band[j]) if j < 1919 else np.nan
    res.append((i, fe, ws))
c.close()
with open('edges.csv', 'w') as f:
    w = csv.writer(f); w.writerow(['frame', 'front', 'windshield']); w.writerows(res)
r = np.array(res)
for a in r: print('%d %.2f %.2f %.2f' % (a[0], a[1], a[2], a[2] - a[1]))
f = r[:, 0]
for col, name in [(1, 'front'), (2, 'ws')]:
    for a, b in [(2, 54), (2, 30), (12, 37), (14, 35), (20, 54), (30, 54)]:
        m = slice(a, b); y = r[m, col]; ok = ~np.isnan(y)
        p = np.polyfit(f[m][ok], y[ok], 2)
        print(name, a, b, 'acc px/f2 %.4f rms %.3f' % (2 * p[0], (y[ok] - np.polyval(p, f[m][ok])).std()))
