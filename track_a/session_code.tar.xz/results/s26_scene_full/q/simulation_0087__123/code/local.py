import numpy as np, csv
r = np.array([[float(v) for v in row] for row in list(csv.reader(open('edges.csv')))[1:]])
f = r[:, 0]
for col, name in [(1, 'front'), (2, 'ws')]:
    out = []
    for c in range(7, 48, 2):
        m = (f >= c - 5) & (f <= c + 5)
        p = np.polyfit(f[m], r[m, col], 2)
        out.append('%d:%.3f' % (c, 2 * p[0]))
    print(name, ' '.join(out))
# speed (central px/frame) from front
v = np.diff(r[:, 1])
print('per-frame steps', np.round(v, 2))
# cubic fit
for col in (1, 2):
    p = np.polyfit(f[2:], r[2:, col], 3)
    print('cubic acc at 24: %.4f, jerk %.5f' % (np.polyval(np.polyder(p, 2), 24), 6 * p[0]))
    p = np.polyfit(f[2:], r[2:, col], 4)
    print('quartic acc at 24: %.4f' % np.polyval(np.polyder(p, 2), 24))
# window around 24
for h in (4, 6, 8, 10):
    m = (f >= 24 - h) & (f <= 24 + h)
    print(h, ['%.4f' % (2 * np.polyfit(f[m], r[m, col], 2)[0]) for col in (1, 2)])
