import csv, numpy as np
car=list(csv.DictReader(open('scene/tracks/car.csv')))
cy=list(csv.DictReader(open('scene/tracks/cyclist.csv')))
f=np.array([int(r['frame']) for r in car]); x0=np.array([float(r['x0']) for r in car])
cx=np.array([float(r['ref_x']) for r in cy])
v=np.polyfit(f[7:],cx[7:],1)[0]; print('cyc px/frame',v)
c1=np.array([float(r['x1']) for r in cy]); print('cyc x1 slope',np.polyfit(f[2:],c1[2:],1)[0])
for a,b in [(2,54),(2,30),(10,40),(14,34),(20,53),(30,53)]:
    p=np.polyfit(f[a:b],x0[a:b],2); res=x0[a:b]-np.polyval(p,f[a:b])
    print(a,b,'acc px/f2',2*p[0],'rms',res.std())
p3=np.polyfit(f[2:],x0[2:],3); print('cubic acc at 24', np.polyval(np.polyder(p3,2),24), 'at 10,40',np.polyval(np.polyder(p3,2),[10,40]))
d=np.diff(x0); print(d)
