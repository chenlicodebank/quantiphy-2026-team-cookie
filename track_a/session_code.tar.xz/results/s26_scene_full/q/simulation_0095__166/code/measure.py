import av, numpy as np
bg = np.array([132, 126, 135])
rows = []
c = av.open('simulation_0095.mp4')
for i, fr in enumerate(c.decode(video=0)):
    a = fr.to_ndarray(format='rgb24').astype(int)
    sub = a[545:]
    m = np.abs(sub - bg).max(axis=2) > 6
    ys, xs = np.nonzero(m)
    rows.append((i, xs.min(), xs.max(), ys.min() + 545, ys.max() + 545, xs.mean(), ys.mean() + 545,
                 # thresholded at 20 for height check
                 ))
    if i in (0, 24, 48, 71):
        m2 = np.abs(sub - bg).max(axis=2) > 20
        y2 = np.nonzero(m2.any(1))[0]
        print('frame', i, 'h thr6', ys.max() - ys.min() + 1, 'h thr20', y2.max() - y2.min() + 1)
r = np.array(rows, float)
f = r[:, 0]; x0, x1 = r[:, 1], r[:, 2]; cx = (x0 + x1) / 2; mcx = r[:, 5]
h = r[:, 4] - r[:, 3] + 1
print('height px mean', h.mean(), 'min/max', h.min(), h.max())
for name, x in [('bbox', cx), ('mask', mcx), ('front', x0), ('rear', x1)]:
    for lo in (2, 10, 20):
        s = (f >= lo)
        p = np.polyfit(f[s], x[s], 2)
        res = x[s] - np.polyval(p, f[s])
        print(name, lo, 'acc px/frame^2', 2 * p[0], 't0 frame', -p[1] / (2 * p[0]), 'rms', res.std())
# speed difference convention
sp = np.abs(np.diff(mcx))
acc = np.diff(sp)
print('mean diff acc 10-71', acc[9:].mean())
np.savetxt('car_meas.csv', r, delimiter=',', fmt='%.2f')
