import av, numpy as np, cv2
def frame(i):
    c=av.open('simulation_0082.mp4')
    for k,f in enumerate(c.decode(video=0)):
        if k==i:
            a=f.to_ndarray(format='rgb24'); c.close(); return a
def mask(a):
    a=a.astype(int); mn=a.min(2); mx=a.max(2)
    hsv=cv2.cvtColor(a.astype(np.uint8),cv2.COLOR_RGB2HSV)
    return (mn<100)|(mx>172)|(hsv[:,:,1]>50)
for fi in [36,40,44,48,60]:
    a=frame(fi); m=mask(a)
    sub=m[470:620]
    cols=np.where(sub.sum(0)>20)[0]
    x0,x1=cols.min(),cols.max()
    ext=[]
    for x in range(x0,x1+1):
        ys=np.where(sub[:,x])[0]
        ext.append((x,ys.min()+470,ys.max()+470))
    ext=np.array(ext)
    w=ext[:,2]-ext[:,1]+1
    print('white f',fi,'x',x0,x1,'len',x1-x0+1,'width pct',np.percentile(w,[50,75,90,95,100]))
    print(' top modes',np.bincount(ext[:,1]-470).argsort()[-5:]+470,' bottom',np.bincount(ext[:,2]-470).argsort()[-5:]+470)
    # profile of width along x in steps
    print(' ', [(int(x),int(t),int(b)) for x,t,b in ext[::15]])
for fi in [50,55,60]:
    a=frame(fi); m=mask(a)
    sub=m[375:430]
    cols=np.where(sub.sum(0)>5)[0]
    print('yellow f',fi,cols.min(),cols.max(),cols.max()-cols.min()+1)
    sub2=m[330:470]
    rows=np.where(sub2[:,cols.min():cols.max()].sum(1)>5)[0]
    print('  yellow rows',rows.min()+330,rows.max()+330)
