import csv,numpy as np
r=list(csv.DictReader(open('scene/tracks/car.csv')))
f=np.array([int(x['frame']) for x in r]);y0=np.array([float(x['bbox_y0']) for x in r]);cy=np.array([float(x['cy']) for x in r])
for lo,hi in [(3,71),(10,71),(20,71),(3,40),(40,71)]:
    m=(f>=lo)&(f<=hi)
    for nm,y in [('y0',y0),('cy',cy)]:
        p=np.polyfit(f[m],y[m],2); res=y[m]-np.polyval(p,f[m])
        print(lo,hi,nm,'a px/s2=%.2f'%(2*p[0]*576),'t_start %.2f'%(-p[1]/(2*p[0])),'rms %.2f'%res.std())
