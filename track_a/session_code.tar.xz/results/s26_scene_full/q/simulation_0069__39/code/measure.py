import av, numpy as np, cv2
frames={}
c=av.open('simulation_0069.mp4')
for i,fr in enumerate(c.decode(video=0)):
    g=fr.to_ndarray(format='rgb24')[:, 700:960].copy()  # strip around the vertical road
    frames[i]=g
N=len(frames)
# background: per-pixel median over all frames (car moves its own length several times)
stack=np.stack([frames[i] for i in range(0,N,2)])
bg=np.median(stack,axis=0).astype(np.float32)
del stack
X0=700
widths=[];fronts=[]
for i in range(N):
    d=np.abs(frames[i].astype(np.float32)-bg).sum(2)
    m=d>40
    m=cv2.morphologyEx(m.astype(np.uint8),cv2.MORPH_OPEN,np.ones((3,3),np.uint8))
    n,lab,st,cen=cv2.connectedComponentsWithStats(m)
    k=1+np.argmax(st[1:,4])
    x,y,w,h,a=st[k]
    mk=lab==k
    # width: median over rows of per-row extents in the middle of the body
    rows=range(y+30,y+h-30)
    ext=[ (np.where(mk[r])[0].max()-np.where(mk[r])[0].min()+1) for r in rows if mk[r].any()]
    # sub-pixel front edge: column-mean diff profile over car centre columns
    cols=slice(x+15,x+w-15)
    prof=d[:,cols].mean(1)
    yy=y
    # find crossing of half of body level near the top
    lvl=0.5*np.median(prof[y+20:y+60])
    j=y-5
    while prof[j]<lvl: j+=1
    fy=j-1+(lvl-prof[j-1])/(prof[j]-prof[j-1])
    fronts.append(fy); widths.append((w,np.median(ext),np.percentile(ext,95),h))
    if i in (0,20,40,60,71): print(i,'bbox x',x+X0,x+w-1+X0,'w',w,'h',h,'row ext med',np.median(ext),'p95',np.percentile(ext,95),'front',round(fy,2))
f=np.arange(N);fy=np.array(fronts)
np.save('fronts.npy',fy)
for lo,hi in [(3,71),(10,71),(3,40),(40,71)]:
    mm=(f>=lo)&(f<=hi); p=np.polyfit(f[mm],fy[mm],2); r=fy[mm]-np.polyval(p,f[mm])
    print(lo,hi,'a px/s2 %.2f vertex %.2f rms %.3f'%(2*p[0]*576,-p[1]/(2*p[0]),r.std()))
sp=np.abs(np.diff(fy))*24; ac=np.diff(sp)*24
print('per-frame speed px/s', np.round(sp,1))
print('mean accel from speed diffs (frames 5-71):', ac[4:].mean(), 'median', np.median(ac[4:]))
print('(v71-v5)/dt', (sp[-1]-sp[4])/(66/24))
w=np.array(widths); print('width bbox median',np.median(w[:,0]),'rowext med',np.median(w[:,1]),'len med',np.median(w[:,3]))
