import av, numpy as np
# per-row extent of the car at frame 0 (background = frame 71, car long gone from y>800)
c=av.open('simulation_0069.mp4')
for i,fr in enumerate(c.decode(video=0)):
    if i==0: f0=fr.to_ndarray(format='rgb24').astype(int)
    if i==71: f71=fr.to_ndarray(format='rgb24').astype(int); break
d=np.abs(f0-f71).sum(2)[:,700:960]
ext=[]
for r in range(800,1060):
    xs=np.where(d[r]>90)[0]
    if len(xs): ext.append((r,xs.min()+700,xs.max()+700,xs.max()-xs.min()+1))
e=np.array(ext)
print('rows',e[0,0],e[-1,0],'len',e[-1,0]-e[0,0]+1)
for row in e[::6]: print(row)
for row in e:
    if 860<=row[0]<=880 or row[3]>=87: print('detail',row)
print('median width',np.median(e[:,3]),'max',e[:,3].max(),'p90',np.percentile(e[:,3],90))
# subpixel half-level edges on mean column profile over body rows
prof=d[850:1030].mean(0)
lvl=prof.max()/2
xs=np.where(prof>lvl)[0]
a=xs[0];b=xs[-1]
L=a-1+(lvl-prof[a-1])/(prof[a]-prof[a-1]); R=b+(prof[b]-lvl)/(prof[b]-prof[b+1])
print('subpixel L R width',L+700,R+700,R-L)
