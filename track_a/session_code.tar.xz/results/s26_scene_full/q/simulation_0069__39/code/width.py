import av, numpy as np
c=av.open('simulation_0069.mp4')
for i,fr in enumerate(c.decode(video=0)):
    if i==0: f0=fr.to_ndarray(format='rgb24').astype(int)
    if i==71: f71=fr.to_ndarray(format='rgb24').astype(int); break
for r in (900,1000):
    print('row',r)
    print(' '.join('%d:%s/%d'%(x,','.join(map(str,f0[r,x])),np.abs(f0[r,x]-f71[r,x]).sum()) for x in range(772,898)))
