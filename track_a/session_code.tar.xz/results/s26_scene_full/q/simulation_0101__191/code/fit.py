import numpy as np, csv
r = list(csv.DictReader(open('scene/tracks/shark.csv')))
f = np.array([int(x['frame']) for x in r])
for col in ['centroid_x', 'bbox_cx', 'nose_x', 'tail_x']:
    x = np.array([float(q[col]) for q in r])
    for f0 in [1, 2]:
        m = f >= f0
        p = np.polyfit(f[m], x[m], 2)
        res = x[m] - np.polyval(p, f[m])
        a = 2 * p[0]  # px/frame^2
        s = 1 / (abs(a) * 576)  # m/px from a = 1 m/s^2
        v0 = p[1]
        v1 = a * 1 + p[1]
        print(f'{col} from fr{f0}: a={a:.4f} px/fr2 ({abs(a)*576:.1f} px/s2) v(fr0)={v0:.3f} v(fr1)={v1:.3f} rms={res.std():.2f}'
              f' | v0={abs(v0)*24*s:.3f} m/s, v(fr1)={abs(v1)*24*s:.3f}, v(fr1.5)={abs(a*1.5+p[1])*24*s:.3f}')
x = np.array([float(q['centroid_x']) for q in r])
print(np.round(np.diff(x)[:12], 2))
