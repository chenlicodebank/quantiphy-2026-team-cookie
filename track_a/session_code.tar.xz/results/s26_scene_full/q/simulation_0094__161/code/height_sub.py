import av, numpy as np
cont = av.open('simulation_0094.mp4')
bg = np.array([78, 79, 86], float)
for i, fr in enumerate(cont.decode(video=0)):
    if i not in (20, 30, 37):
        continue
    img = fr.to_ndarray(format='rgb24').astype(float)
    sub = img[620:685]
    d = np.abs(sub - bg).max(axis=2)
    # per-row max difference across the car columns
    rowmax = d.max(axis=1)
    print('frame', i)
    for k, v in enumerate(rowmax):
        if 625 <= 620 + k <= 680:
            print(620 + k, round(v, 1), int((d[k] > 20).sum()))
