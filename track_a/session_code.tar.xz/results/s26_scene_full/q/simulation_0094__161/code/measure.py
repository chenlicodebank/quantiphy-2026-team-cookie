import av, numpy as np
cont = av.open('simulation_0094.mp4')
bg = np.array([78, 79, 86], float)
rows = []
for i, fr in enumerate(cont.decode(video=0)):
    img = fr.to_ndarray(format='rgb24').astype(float)
    sub = img[590:800]
    d = np.abs(sub - bg).max(axis=2)
    for th in (20,):
        m = d > th
        ys, xs = np.nonzero(m)
        if len(xs) < 50:
            continue
        cols = np.nonzero(m.sum(0) > 0)[0]
        rws = np.nonzero(m.sum(1) > 0)[0]
        x0, x1 = cols.min(), cols.max()
        y0, y1 = rws.min() + 590, rws.max() + 590
        # subpixel edges via column profile of weighted mask
        w = np.clip((d - 10) / 30, 0, 1)
        colw = w.sum(0)
        cx = (colw * np.arange(len(colw))).sum() / colw.sum()
        rows.append((i, x0, x1, y0, y1, x1 - x0 + 1, y1 - y0 + 1, cx))
for r in rows:
    print(r)
r = np.array(rows, float)
sel = (r[:, 1] > 0)  # unclipped
r2 = r[sel]
for name, col in (('x0', 1), ('x1', 2), ('ctr', None), ('centroid', 7)):
    v = r2[:, col] if col is not None else (r2[:, 1] + r2[:, 2]) / 2
    p = np.polyfit(r2[:, 0], v, 1)
    print(name, 'slope px/frame', p[0])
print('height px mean', r2[:, 6].mean(), 'min', r2[:, 6].min(), 'max', r2[:, 6].max())
