import av, numpy as np, cv2
P='/private/tmp/qp_blind/scene_full_a/simulation_0007/q_4/'
with av.open(P+'simulation_0007.mp4') as c:
    for i,f in enumerate(c.decode(video=0)):
        if i==0: img=f.to_ndarray(format='bgr24'); break
x0,y0=725,700
sub=img[y0:y0+60,x0:x0+80]
big=cv2.resize(sub,None,fx=10,fy=10,interpolation=cv2.INTER_NEAREST)
for k in range(0,80,5):
    cv2.line(big,(k*10,0),(k*10,599),(0,255,255) if k%10==0 else (0,120,120),1)
for k in range(0,60,5):
    cv2.line(big,(0,k*10),(799,k*10),(0,255,255) if k%10==0 else (0,120,120),1)
cv2.imwrite(P+'frames/fL2.png',big)
v=cv2.cvtColor(img,cv2.COLOR_BGR2HSV)[:,:,2]
np.set_printoptions(linewidth=250)
print(v[730:750,740:770])
