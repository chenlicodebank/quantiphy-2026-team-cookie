import av, numpy as np, cv2, csv
P='/private/tmp/qp_blind/scene_full_a/simulation_0007/q_4/'
want={0,12,24,36,60}
frames={}
with av.open(P+'simulation_0007.mp4') as c:
    for i,f in enumerate(c.decode(video=0)):
        if i in want: frames[i]=f.to_ndarray(format='bgr24')
rows=list(csv.DictReader(open(P+'scene/tracks/boat.csv')))
for i in sorted(frames):
    img=frames[i]; r=rows[i]
    cx,cy=float(r['cx']),float(r['cy'])
    hsv=cv2.cvtColor(img,cv2.COLOR_BGR2HSV)
    # profile along the boat axis through the centroid: brightness
    ang=np.deg2rad(float(r['axis_angle_deg']))
    u=np.array([np.cos(ang),np.sin(ang)])
    n=np.array([-u[1],u[0]])
    out=[]
    for off in [-6,-3,0,3,6]:
        s=np.arange(-130,130,0.5)
        pts=np.array([cx,cy])+np.outer(s,u)+off*n
        v=cv2.remap(hsv[:,:,2].astype(np.float32),pts[:,0].astype(np.float32).reshape(1,-1),pts[:,1].astype(np.float32).reshape(1,-1),cv2.INTER_LINEAR)[0]
        m=v>100
        idx=np.where(m)[0]
        out.append((off,s[idx[0]],s[idx[-1]]))
    # also mask-based extent: threshold around boat
    x0,y0,x1,y1=[int(r[k]) for k in ['bbox_x0','bbox_y0','bbox_x1','bbox_y1']]
    sub=hsv[y0-10:y1+10,x0-10:x1+10,2]>100
    ys,xs=np.nonzero(sub); xs=xs+x0-10; ys=ys+y0-10
    pr=(xs-cx)*u[0]+(ys-cy)*u[1]; pn=(xs-cx)*n[0]+(ys-cy)*n[1]
    sel=np.abs(pn)<40
    print(i,'axisdeg',r['axis_angle_deg'],'lines',out,'mask extent',pr[sel].min(),pr[sel].max(),pr[sel].max()-pr[sel].min())
