import numpy as np, csv
P='/private/tmp/qp_blind/scene_full_a/simulation_0007/q_4/'
r=list(csv.DictReader(open(P+'scene/tracks/boat.csv')))
f=np.array([int(x['frame']) for x in r]); x=np.array([float(a['cx']) for a in r]); y=np.array([float(a['cy']) for a in r])
print('raw backward step at 24:', np.hypot(x[24]-x[23],y[24]-y[23]))
for lo,hi in [(14,34),(10,38),(0,73)]:
    s=slice(lo,hi+1)
    px=np.polyfit(f[s],x[s],2); py=np.polyfit(f[s],y[s],2)
    vx=np.polyval(np.polyder(px),23.5); vy=np.polyval(np.polyder(py),23.5)
    print(lo,hi,'speed px/frame at 23.5:',np.hypot(vx,vy))
v=np.hypot(np.polyval(np.polyder(np.polyfit(f[14:35],x[14:35],1)),0),np.polyval(np.polyder(np.polyfit(f[14:35],y[14:35],1)),0))
print('linear 14-34',v)
for L in (203.2,207.0,209.7):
    print(L, v*24*3.62/L)
