import av, numpy as np, cv2
fr = []
c = av.open('simulation_0070.mp4')
for f in c.decode(video=0):
    fr.append(f.to_ndarray(format='rgb24')[:, 880:960].astype(np.int16))  # cyclist strip only
c.close()
fr = np.array(fr)
bg = np.median(fr[::3], axis=0)
rows = []
for i, a in enumerate(fr):
    d = np.sqrt(((a - bg) ** 2).sum(-1)) > 30
    d[:, 55:] = False  # cut car side (x>=935)
    n, lab, st, _ = cv2.connectedComponentsWithStats(d.astype(np.uint8))
    k = 1 + np.argmax(st[1:, 4])
    ys, xs = np.nonzero(lab == k)
    rows.append((i, xs.mean() + 880, ys.mean(), ys.min(), ys.max()))
r = np.array(rows)
np.savetxt('cyc_track.csv', r, delimiter=',', fmt='%.2f', header='f,cx,cy,ytop,ybot')
f = r[:, 0]
for name, col in [('cy', 2), ('ytop', 3), ('ybot', 4)]:
    for lo, hi in [(12, 36), (18, 30), (2, 71), (40, 71)]:
        m = (f >= lo) & (f <= hi)
        p = np.polyfit(f[m], r[m, col], 2); p1 = np.polyfit(f[m], r[m, col], 1)
        print(name, lo, hi, 'lin slope %.3f' % p1[0], 'quad slope@24 %.3f' % (2 * p[0] * 24 + p[1]))
print('steps 20-28', np.diff(r[19:29, 2]))
