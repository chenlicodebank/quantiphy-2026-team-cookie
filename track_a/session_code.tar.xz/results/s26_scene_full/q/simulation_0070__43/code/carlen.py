import av, numpy as np, cv2
# car body length from frames where it points straight up (f0-1) or right (f66-71)
X0, Y0, X1, Y1 = 900, 500, 1500, 1000
fr = {}
bgs = []
c = av.open('simulation_0070.mp4')
for i, f in enumerate(c.decode(video=0)):
    a = f.to_ndarray(format='rgb24')[Y0:Y1, X0:X1].astype(np.int16)
    if i % 4 == 0: bgs.append(a)
    if i in (0, 1, 66, 68, 71): fr[i] = a
c.close()
bg = np.median(np.array(bgs), axis=0)
for i, a in fr.items():
    d = np.sqrt(((a - bg) ** 2).sum(-1)) > 30
    peach = (a[..., 0] - a[..., 2] > 22) & (a[..., 0] > 180)
    m = (d & peach).astype(np.uint8)
    n, lab, st, cen = cv2.connectedComponentsWithStats(m)
    k = 1 + np.argmax(st[1:, 4])
    ys, xs = np.nonzero(lab == k)
    hull = cv2.convexHull(np.c_[xs, ys].astype(np.int32))
    hm = np.zeros_like(m); cv2.fillPoly(hm, [hull], 1)
    ys, xs = np.nonzero(hm)
    print(i, 'x', xs.min() + X0, xs.max() + X0, 'w', xs.max() - xs.min() + 1,
          'y', ys.min() + Y0, ys.max() + Y0, 'h', ys.max() - ys.min() + 1,
          'centroid', round(xs.mean() + X0, 1), round(ys.mean() + Y0, 1))
    if i == 0:
        o = cv2.cvtColor(a.astype(np.uint8), cv2.COLOR_RGB2BGR)
        cv2.rectangle(o, (int(xs.min()), int(ys.min())), (int(xs.max()), int(ys.max())), (0, 0, 255), 1)
        cv2.imwrite('frames/car0.png', cv2.resize(o[250:500, 0:200], None, fx=3, fy=3, interpolation=cv2.INTER_NEAREST))
