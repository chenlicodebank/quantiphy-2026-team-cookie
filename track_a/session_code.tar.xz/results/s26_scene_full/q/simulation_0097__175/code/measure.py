import av, numpy as np, csv
# 1) car acceleration from scene track centroid (quadratic fit), 2) subpixel car length per frame
r = list(csv.DictReader(open('scene/tracks/car.csv')))
f = np.array([float(x['frame']) for x in r]); c = np.array([float(x['cx_centroid']) for x in r])
m = f >= 1
p = np.polyfit(f[m], c[m], 2)
a_pf = 2 * abs(p[0]); a_ps = a_pf * 24**2
v = np.diff(c) * 24
acc_lin = np.polyfit(f[2:], v[1:], 1)[0] * 24  # slope of per-frame speed vs frame
print('a px/frame2', a_pf, 'px/s2', a_ps, 'speed-slope px/s2', abs(acc_lin))

cont = av.open('simulation_0097.mp4'); res = []
for i, fr in enumerate(cont.decode(video=0)):
    if i % 4: continue
    a = fr.to_ndarray(format='rgb24').astype(float)
    bg = np.median(a.reshape(-1, 3), axis=0)
    roi = a[560:660, 1050:1600]
    d = np.abs(roi - bg).max(2)
    mk = d > 6
    cols = np.where(mk.any(0))[0]; x0, x1 = cols.min(), cols.max()
    prof = d.max(0)
    fr0 = min(prof[x0] / max(prof[x0 + 1], 1), 1); fr1 = min(prof[x1] / max(prof[x1 - 1], 1), 1)
    Lsub = (x1 - x0 - 1) + fr0 + fr1
    rows = np.where(mk.any(1))[0]
    res.append((i, x1 - x0 + 1, round(Lsub, 2), rows.max() - rows.min() + 1))
for q in res: print(q)
Ls = np.array([q[2] for q in res]); Li = np.array([q[1] for q in res])
print('mean int', Li.mean(), 'mean sub', Ls.mean())
s = 10 / a_ps
print('m/px', s, 'L int', Li.mean() * s, 'L sub', Ls.mean() * s)
