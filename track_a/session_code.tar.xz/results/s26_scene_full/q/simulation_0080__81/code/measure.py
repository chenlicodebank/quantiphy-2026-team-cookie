import av, numpy as np, cv2, os
os.makedirs('frames', exist_ok=True)
c = av.open('simulation_0080.mp4')
res = {}
for i, fr in enumerate(c.decode(video=0)):
    if i > 18: break
    img = fr.to_ndarray(format='rgb24').astype(int)
    # cyan bike pixels: high G,B relative to R
    r, g, b = img[..., 0], img[..., 1], img[..., 2]
    bike = ((g - r) > 40) & ((b - r) > 40)
    bike[:500] = False; bike[800:] = False
    ys, xs = np.nonzero(bike)
    # non-floor mask (dark/colour deviation) in lane
    grey = np.abs(img - 151).max(axis=2) > 28
    grey[:540] = False; grey[760:] = False
    cols = np.nonzero(grey.sum(0) > 2)[0]
    res[i] = (xs.min(), xs.max(), (xs.min() + xs.max()) / 2, xs.mean(), cols.min(), cols.max())
    if i == 12:
        o = img.astype(np.uint8).copy()
        o[bike] = [255, 0, 0]
        cv2.imwrite('frames/f12_mask.png', cv2.cvtColor(o[500:800, 150:700], cv2.COLOR_RGB2BGR))
for i, v in res.items():
    print(i, v)
for i in range(2, 17):
    print(i, 'step bbox-centre', res[i - 1][2] - res[i][2], 'step mean', res[i - 1][3] - res[i][3])
