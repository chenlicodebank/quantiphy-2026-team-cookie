import av, numpy as np, cv2
# independent: dark-hair/shirt blobs per person; track centroid of non-floor pixels per half of image row band
c = av.open('simulation_0078.mp4')
res = {}
for i, fr in enumerate(c.decode(video=0)):
    img = fr.to_ndarray(format='rgb24').astype(int)
    m = (np.abs(img - 136).max(2) > 28).astype(np.uint8)
    n, lab, st, cen = cv2.connectedComponentsWithStats(m)
    blobs = [(st[k, 4], cen[k], k) for k in range(1, n) if st[k, 4] > 2000]
    # identify by mean brightness of top pixels: shirt colour
    out = []
    for a, cc, k in blobs:
        px = img[lab == k]
        bright = (px.mean(1) > 200).sum(); dark = (px.mean(1) < 50).sum()
        out.append(('B' if bright > dark else 'A', cc[0], cc[1], a))
    res[i] = out
c.close()
A = {i: [o for o in v if o[0] == 'A'] for i, v in res.items()}
B = {i: [o for o in v if o[0] == 'B'] for i, v in res.items()}
fa = [i for i in range(6, 72) if len(A[i]) == 1]; fb = [i for i in range(17, 72) if len(B[i]) == 1]
ax = np.array([A[i][0][1] for i in fa]); bx = np.array([B[i][0][1] for i in fb])
pA = np.polyfit(fa, ax, 1); pB = np.polyfit(fb, bx, 1)
print('vA', pA[0], 'vB', pB[0], len(fa), len(fb))
print('48:', A[48], B[48])
d = abs(np.polyval(pA, 48) - np.polyval(pB, 48))
print('fit dx48', d, 'ans', d / (abs(pB[0]) * 24) * 1.3)
d2 = abs(A[48][0][1] - B[48][0][1]); print('raw', d2, d2 / (abs(pB[0]) * 24) * 1.3)
