import csv, numpy as np
def load(n):
    r = list(csv.DictReader(open(f'scene/tracks/{n}.csv')))
    d = {}
    for row in r:
        d[int(row['frame'])] = {k: (float(v) if v not in ('', None) else np.nan) for k, v in row.items()}
    return d
A = load('person_A_dark_shirt'); B = load('person_B_white_shirt')
for key in ['pelvis_est', 'head', 'shirt']:
    fr = [f for f in range(17, 72) if f in B and not np.isnan(B[f][key + '_x'])]
    bx = np.array([B[f][key + '_x'] for f in fr]); by = np.array([B[f][key + '_y'] for f in fr])
    pB = np.polyfit(fr, bx, 1)
    frA = [f for f in range(6, 72) if f in A and not np.isnan(A[f][key + '_x'])]
    ax = np.array([A[f][key + '_x'] for f in frA])
    pA = np.polyfit(frA, ax, 1)
    vB = abs(pB[0]) * 24
    a48 = np.array([A[48][key + '_x'], A[48][key + '_y']]); b48 = np.array([B[48][key + '_x'], B[48][key + '_y']])
    dpx = np.linalg.norm(a48 - b48)
    # fitted positions at 48
    dfit = abs(np.polyval(pA, 48) - np.polyval(pB, 48))
    print(key, 'vB px/frame', pB[0], 'vA', pA[0], 'raw dist48', dpx, 'fit dx48', dfit,
          'ans raw', dpx / vB * 1.3, 'ans fit', np.hypot(dfit, a48[1]-b48[1]) / vB * 1.3)
    print('  A48', a48, 'B48', b48)
