import numpy as np
# frame 12 (t=0.5 s). Bike: cyan bbox x 1047..1427, y centre 643.5 (scene/tracks/cyclist.csv, checked on frame)
# Pedestrian: shirt centroid (230.1, 443.8) from torso.py; head occludes rear of shirt -> torso centre ~228
uf, ur, vb = 1047.0, 1427.0, 643.5
up, vp = 228.0, 444.0
cx, cy = 960.0, 540.0

# route 1: plain 2D, one scale from bike length
L = ur - uf
s = 1.7 / L
d1 = np.hypot(0.5 * (uf + ur) - up, vb - vp) * s
print('2D: bike len px', L, 'm/px', s, 'dist px', np.hypot(0.5 * (uf + ur) - up, vb - vp), 'd', d1)

# route 2: nadir pinhole with parallax; rider-head parallax 0.040 px/px for ~0.95 m height diff
for hr, hb in [(1.5, 0.6), (1.55, 0.6), (1.65, 0.6)]:
    H = (hr - hb) / 0.040 + hr
    hf, hrk = 0.35, 0.8          # front wheel tip / rear rack heights
    f = ((ur - cx) * (H - hrk) - (uf - cx) * (H - hf)) / 1.7
    Xb = 0.5 * ((uf - cx) * (H - hf) + (ur - cx) * (H - hrk)) / f
    Yb = (vb - cy) * (H - hb) / f
    for hp in [1.0, 1.3]:
        Xp = (up - cx) * (H - hp) / f
        Yp = (vp - cy) * (H - hp) / f
        print(f'H={H:.1f} f={f:.0f} hp={hp}: d={np.hypot(Xb - Xp, Yb - Yp):.3f}')
