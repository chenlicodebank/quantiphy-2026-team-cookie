import av, numpy as np, cv2, sys
# white-shirt centroid of the pedestrian (proxy for pelvis plan position) per frame
want = set(range(8, 17))
c = av.open('/private/tmp/qp_blind/scene_full_b/simulation_0081/q_86/simulation_0081.mp4')
for i, fr in enumerate(c.decode(video=0)):
    if i not in want: continue
    im = fr.to_ndarray(format='rgb24').astype(int)
    sub = im[360:545, 0:700]
    hsv = cv2.cvtColor(sub.astype(np.uint8), cv2.COLOR_RGB2HSV)
    white = ((sub[...,2]-sub[...,0]) >= 5) & (hsv[..., 2] >= 128) & (hsv[...,0]>100)&(hsv[...,0]<130)
    white = cv2.morphologyEx(white.astype(np.uint8), cv2.MORPH_OPEN, np.ones((3, 3), np.uint8)) > 0
    n, lab, st, cen = cv2.connectedComponentsWithStats(white.astype(np.uint8))
    k = 1 + np.argmax(st[1:, 4])
    ys, xs = np.nonzero(lab == k)
    print(i, 'shirt centroid', round(xs.mean(), 1), round(ys.mean() + 360, 1),
          'bbox x', xs.min(), xs.max(), 'y', ys.min() + 360, ys.max() + 360, 'area', len(xs))
    if i == 12:
        o = sub.astype(np.uint8).copy(); o[lab == k] = [255, 0, 0]
        cv2.circle(o, (int(xs.mean()), int(ys.mean())), 4, (0, 255, 0), -1)
        cv2.imwrite('/private/tmp/qp_blind/scene_full_b/simulation_0081/q_86/frames/shirt12.png',
                    cv2.resize(o[:, 100:420], None, fx=2, fy=2)[:, :, ::-1])
