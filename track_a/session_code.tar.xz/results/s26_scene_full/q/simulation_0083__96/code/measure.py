import csv, os, cv2, numpy as np
D = os.path.dirname(os.path.abspath(__file__))
def rd(n): return list(csv.DictReader(open(f'{D}/scene/tracks/{n}.csv')))
y = rd('yellow_car'); b = rd('black_car')
for r1, r2 in zip(y, b):
    f = int(r1['frame'])
    if f % 4 == 0:
        print(f, r1['ref_x'], r1['length_px'], r1['width_px'], r2['ref_x'], r2['length_px'], r2['width_px'])

# independent re-measure: background difference using frame 71 vs frame 0 as mutual backgrounds
cap = cv2.VideoCapture(f'{D}/simulation_0083.mp4')
frames = {}
i = 0
while True:
    ok, fr = cap.read()
    if not ok: break
    if i in (0, 20, 30, 40, 71): frames[i] = fr.astype(int)
    i += 1
bg = np.median(np.stack([frames[0], frames[40], frames[71]]), axis=0)
for k in (20, 30):
    fr = frames[k]
    d = np.abs(fr - bg).sum(2)
    for name, (ya, yb) in (('yellow', (340, 479)), ('black', (479, 620))):
        m = d[ya:yb] > 40
        cols = np.where(m.sum(0) > 3)[0]
        rows = np.where(m.sum(1) > 3)[0]
        print(k, name, 'x', cols.min(), cols.max(), cols.max() - cols.min() + 1, 'y', rows.min() + ya, rows.max() + ya)
