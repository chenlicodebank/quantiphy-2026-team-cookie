import numpy as np, csv
def load(n):
    r=list(csv.DictReader(open(f'scene/tracks/{n}.csv')))
    return {k:np.array([float(x[k]) for x in r]) for k in r[0].keys()}
v=load('van'); s=load('sedan')
f=v['frame']
for key in ['ccy','cy','cbbox_y0','cbbox_y1']:
    y=v[key]
    for a,b in [(3,71),(10,71),(20,71),(3,40),(40,71)]:
        m=(f>=a)&(f<=b)
        p=np.polyfit(f[m],y[m],2); r=y[m]-np.polyval(p,f[m])
        print(key,a,b,'acc px/fr2 %.4f'%(2*p[0]),'rms %.2f'%r.std())
    print('steps',np.round(np.abs(np.diff(y)),1))
for key in [('ccx','ccy'),('cx','cy')]:
    x,y=s[key[0]],s[key[1]]
    d=np.hypot(np.diff(x),np.diff(y))
    print(key,'steps',np.round(d,2))
    print('step into frame60 %.3f'%d[59],'mean 55-65 %.3f'%d[54:65].mean(),'mean 2-71 %.3f'%d[2:].mean())
    print('chord 56-64/8 %.3f'%(np.hypot(x[64]-x[56],y[64]-y[56])/8))
    print('chord 59-61/2 %.3f'%(np.hypot(x[61]-x[59],y[61]-y[59])/2))
