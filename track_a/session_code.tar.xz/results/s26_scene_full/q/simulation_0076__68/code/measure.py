import csv,numpy as np
def ld(n):
  r=list(csv.DictReader(open('scene/tracks/'+n+'.csv')));return {k:np.array([float(x[k]) for x in r]) for k in r[0]}
b=ld('man_black_shirt');w=ld('man_white_shirt')
f=np.arange(72)
for kx,ky in [('head_x','head_y'),('cx','cy'),('pelvis_est_x','pelvis_est_y')]:
  for lo,hi in [(12,36),(6,42),(2,71)]:
    s=slice(lo,hi+1)
    pb=np.polyfit(f[s],b[kx][s],1); pw=np.polyfit(f[s],w[kx][s],1)
    pby=np.polyfit(f[s],b[ky][s],1); pwy=np.polyfit(f[s],w[ky][s],1)
    vb=np.hypot(pb[0],pby[0])
    dx=np.polyval(pb,24)-np.polyval(pw,24); dy=np.polyval(pby,24)-np.polyval(pwy,24)
    d=np.hypot(dx,dy)
    print(kx,lo,hi,'vb %.2f vw %.2f dx %.1f dy %.1f d %.1f -> %.4f m'%(vb,np.hypot(pw[0],pwy[0]),dx,dy,d,d/(vb*24)))
