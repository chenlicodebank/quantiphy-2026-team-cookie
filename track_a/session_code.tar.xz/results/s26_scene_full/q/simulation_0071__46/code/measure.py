import av, numpy as np, cv2, os
D = os.path.dirname(os.path.abspath(__file__))
V = os.path.join(D, 'simulation_0071.mp4')

frames = {}
want = set(range(0, 72))
c = av.open(V)
bg_samples = []
for i, f in enumerate(c.decode(video=0)):
    img = f.to_ndarray(format='bgr24')
    if i in (0, 71, 35):
        bg_samples.append(img)
    # keep only crops: car region and ped region
    frames[i] = (img[500:1000, 900:1400].copy(), img[790:900, 1300:1520].copy())
c.close()

# background: median over sampled frames for ped crop (ped moves ~140px over clip)
pc = np.median(np.stack([frames[i][1] for i in range(0, 72, 3)]), axis=0).astype(np.float32)
cc_bg = np.median(np.stack([frames[i][0] for i in range(0, 72, 3)]), axis=0).astype(np.float32)

# car: frame 2 heading ~ vertical; measure mask extents
def car_mask(i):
    d = np.abs(frames[i][0].astype(np.float32) - cc_bg).sum(2)
    m = (d > 40).astype(np.uint8)
    n, lab, st, cen = cv2.connectedComponentsWithStats(m)
    k = 1 + np.argmax(st[1:, 4])
    return lab == k, st[k]
for i in (0, 2, 5):
    m, s = car_mask(i)
    ys, xs = np.nonzero(m)
    print('car frame', i, 'bbox w,h', s[2], s[3], 'area', s[4])

# pedestrian centroid by bg subtraction
xs_all = []
for i in range(72):
    d = np.abs(frames[i][1].astype(np.float32) - pc).sum(2)
    m = (d > 45).astype(np.uint8)
    m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((2, 2), np.uint8))
    n, lab, st, cen = cv2.connectedComponentsWithStats(m)
    if n < 2:
        xs_all.append((np.nan, np.nan)); continue
    k = 1 + np.argmax(st[1:, 4])
    xs_all.append((cen[k][0] + 1300, cen[k][1] + 790))
xs_all = np.array(xs_all)
for i in range(16, 34):
    print(i, xs_all[i])
t = np.arange(72)
for a, b in [(14, 34), (16, 32), (18, 30), (10, 40), (2, 71)]:
    sel = (t >= a) & (t <= b) & ~np.isnan(xs_all[:, 0])
    px = np.polyfit(t[sel], xs_all[sel, 0], 1)[0]
    py = np.polyfit(t[sel], xs_all[sel, 1], 1)[0]
    print('fit', a, b, 'px/frame', np.hypot(px, py))
