import av, numpy as np
c = av.open('simulation_0075.mp4')
for i, f in enumerate(c.decode(video=0)):
    if i not in (0, 10, 20, 36, 50, 60, 71):
        continue
    im = f.to_ndarray(format='rgb24').astype(int)
    road = np.median(im[:, 650:700], axis=(0, 1))
    d = np.abs(im[:, 800:862] - road).max(axis=2)
    p = (d > 25).mean(axis=1)
    on = np.where(p > 0.5)[0]
    runs = np.split(on, np.where(np.diff(on) > 40)[0] + 1)
    r = max(runs, key=len)
    # half-max sub-pixel edges on mean |diff| profile
    q = d.mean(axis=1)
    lvl = np.median(q[r[0]+20:r[-1]-20]) / 2
    print(i, r[0], r[-1], r[-1] - r[0] + 1, 'lvl', round(lvl, 1))
c.close()
