import av, numpy as np, cv2
fr = {}
c = av.open('simulation_0075.mp4')
for i, f in enumerate(c.decode(video=0)):
    if i in (0, 20, 36, 50, 71):
        fr[i] = f.to_ndarray(format='rgb24').astype(int)
c.close()
img = fr[36]
road = np.array([166, 166, 166])
# brown squares: profile through centres, find extent where colour differs from sidewalk
for name, (cx, cy) in {'NW': (411, 222), 'SW': (410, 849), 'SE': (1217, 845)}.items():
    win = img[cy-70:cy+71, cx-70:cx+71]
    side = np.median(np.concatenate([img[cy-70:cy+71, cx-70], img[cy-70:cy+71, cx+70]]), axis=0)
    d = np.abs(win - side).max(axis=2)
    m = (d > 20).astype(np.uint8)
    n, lab, st, _ = cv2.connectedComponentsWithStats(m)
    k = lab[70, 70]
    x, y, w, h, a = st[k]
    # also half-max profile along central rows/cols
    rowp = d[60:81].mean(axis=0); colp = d[:, 60:81].mean(axis=1)
    def fw(p):
        thr = p.max() / 2; idx = np.where(p > thr)[0]; return idx[-1] - idx[0] + 1
    print(name, 'side', side, 'bbox w,h', w, h, 'area', a, 'sqrt', np.sqrt(a), 'fwhm', fw(rowp), fw(colp))
# van length per frame via column profile at x~831
for i, im in fr.items():
    col = im[:, 800:862]
    d = np.abs(col - road).max(axis=2)
    bright = (im[:, 800:862].min(axis=2) > 200).mean(axis=1)
    p = d.mean(axis=1)
    idx = np.where(p > 40)[0]
    # longest contiguous run
    runs = np.split(idx, np.where(np.diff(idx) > 3)[0] + 1)
    r = max(runs, key=len)
    print('van f', i, r[0], r[-1], r[-1] - r[0] + 1)
