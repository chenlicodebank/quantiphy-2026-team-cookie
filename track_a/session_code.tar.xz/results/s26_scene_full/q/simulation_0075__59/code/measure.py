import av, numpy as np, cv2, os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
def frame(i):
    c=av.open('simulation_0075.mp4')
    for k,f in enumerate(c.decode(video=0)):
        if k==i: a=f.to_ndarray(format='rgb24'); c.close(); return a
def meas(img, box, name, thr):
    x0,y0,x1,y1=box
    crop=img[y0:y1,x0:x1].astype(int)
    border=np.concatenate([crop[:5].reshape(-1,3),crop[-5:].reshape(-1,3),crop[:,:5].reshape(-1,3),crop[:,-5:].reshape(-1,3)])
    road=np.median(border,0)
    d=np.abs(crop-road).max(2)
    m=(d>thr).astype(np.uint8)
    m=cv2.morphologyEx(m,cv2.MORPH_CLOSE,np.ones((5,5),np.uint8))
    n,lab,st,_=cv2.connectedComponentsWithStats(m)
    k=1+np.argmax(st[1:,4])
    mm=lab==k
    ys,xs=np.nonzero(mm)
    rect=cv2.minAreaRect(np.column_stack([xs,ys]).astype(np.float32))
    print(name,thr,'road',road,'bbox x',xs.min()+x0,xs.max()+x0,'y',ys.min()+y0,ys.max()+y0,
          'w',xs.max()-xs.min()+1,'h',ys.max()-ys.min()+1,'rect',np.round(rect[1],1))
    return mm
for fi in [0,36,71]:
    img=frame(fi)
    for thr in [12,18,25]:
        meas(img,(1220,380,1460,500),f'purple f{fi}',thr)
    vb={0:(760,780,900,1075),36:(760,590,900,880),71:(760,60,900,345)}[fi]
    for thr in [12,18,25]:
        meas(img,vb,f'van f{fi}',thr)
