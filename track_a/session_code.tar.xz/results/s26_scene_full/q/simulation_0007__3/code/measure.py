import av, numpy as np, cv2

def frame(i):
    c = av.open('simulation_0007.mp4')
    for k, f in enumerate(c.decode(video=0)):
        if k == i:
            a = f.to_ndarray(format='rgb24'); c.close(); return a

I = 72
img = frame(I)
hsv = cv2.cvtColor(img, cv2.COLOR_RGB2HSV)
V = hsv[..., 2].astype(int); S = hsv[..., 1].astype(int)
bright = ((V > 100) & (S < 90)).astype(np.uint8)

def comp_near(mask, pt, close=7):
    m = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((close, close), np.uint8))
    n, lab = cv2.connectedComponents(m)
    l = lab[pt[1], pt[0]]
    out = (lab == l).astype(np.uint8)
    cs, _ = cv2.findContours(out, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    filled = np.zeros_like(out); cv2.drawContours(filled, cs, -1, 1, -1)
    return filled

# region restrict
boat_reg = np.zeros_like(bright); boat_reg[720:880, 480:760] = 1
pier_reg = np.zeros_like(bright); pier_reg[380:700, 370:600] = 1
boat = comp_near(bright * boat_reg, (650, 790))
pier = comp_near(bright * pier_reg, (520, 620))
print('boat area', boat.sum(), 'pier area', pier.sum())
ys, xs = np.nonzero(boat); print('boat centroid', xs.mean(), ys.mean(), 'bbox', xs.min(), xs.max(), ys.min(), ys.max())
# boat length via PCA
P = np.c_[xs, ys].astype(float); P0 = P - P.mean(0)
w, v = np.linalg.eigh(np.cov(P0.T)); ax = v[:, 1]
pr = P0 @ ax; print('boat length along axis', pr.max() - pr.min() + 1, 'width', np.ptp(P0 @ v[:, 0]) + 1)
# pier rect
pc, _ = cv2.findContours(pier, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
rect = cv2.minAreaRect(max(pc, key=cv2.contourArea)); box = cv2.boxPoints(rect)
print('pier rect', rect); print('box', box)
# outer end = two corners with largest y
b = box[np.argsort(box[:, 1])]
end = b[2:]; endmid = end.mean(0)
print('pier end corners', end, 'mid', endmid)
# min gap between masks
dt = cv2.distanceTransform((1 - boat).astype(np.uint8), cv2.DIST_L2, 5)
pys, pxs = np.nonzero(pier)
d = dt[pys, pxs]; k = d.argmin()
print('min gap pier-mask to boat-mask', d.min(), 'at pier pt', pxs[k], pys[k])
# gap from end-edge segment to boat
seg = np.linspace(end[0], end[1], 200)
bys, bxs = np.nonzero(boat); B = np.c_[bxs, bys]
dd = np.sqrt(((seg[:, None, :] - B[None]) ** 2).sum(-1))
print('min gap end-edge to boat', dd.min())
print('end mid to boat centroid', np.hypot(xs.mean() - endmid[0], ys.mean() - endmid[1]))
print('end mid to nearest boat pixel', np.sqrt(((B - endmid) ** 2).sum(1)).min())
ov = img.copy()
ov[boat > 0] = (0.5 * ov[boat > 0] + [127, 0, 0]).astype(np.uint8)
ov[pier > 0] = (0.5 * ov[pier > 0] + [0, 0, 127]).astype(np.uint8)
cv2.polylines(ov, [box.astype(int)], True, (255, 255, 0), 1)
cv2.circle(ov, (int(pxs[k]), int(pys[k])), 4, (255, 0, 0), -1)
cv2.imwrite('frames/ov72.png', cv2.cvtColor(ov[350:900, 350:800], cv2.COLOR_RGB2BGR))
