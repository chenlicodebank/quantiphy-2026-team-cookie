import av, numpy as np, cv2

def frames(idx):
    out = {}
    c = av.open('simulation_0007.mp4')
    for k, f in enumerate(c.decode(video=0)):
        if k in idx: out[k] = f.to_ndarray(format='rgb24')
        if k >= max(idx): break
    c.close(); return out

F = frames([0, 36, 72])

def masks(img, bpt):
    hsv = cv2.cvtColor(img, cv2.COLOR_RGB2HSV)
    br = ((hsv[..., 2] > 100) & (hsv[..., 1] < 90)).astype(np.uint8)
    def comp(reg, pt):
        m = cv2.morphologyEx(br * reg, cv2.MORPH_CLOSE, np.ones((7, 7), np.uint8))
        n, lab = cv2.connectedComponents(m); o = (lab == lab[pt[1], pt[0]]).astype(np.uint8)
        cs, _ = cv2.findContours(o, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
        fl = np.zeros_like(o); cv2.drawContours(fl, cs, -1, 1, -1); return fl
    r = np.zeros_like(br); r[bpt[1]-90:bpt[1]+90, bpt[0]-150:bpt[0]+150] = 1
    boat = comp(r, bpt)
    r2 = np.zeros_like(br); r2[520:700, 400:620] = 1   # water part of pier only
    pier = comp(r2, (520, 620))
    return boat, pier

# pier from frame 72 (water part)
boat, pier = masks(F[72], (625, 788))
pc, _ = cv2.findContours(pier, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
cnt = max(pc, key=cv2.contourArea)
rect = cv2.minAreaRect(cnt); box = cv2.boxPoints(rect)
print('pier water-part rect', rect)
b = box[np.argsort(box[:, 1])]; end = b[2:]
# outer end: the two corners farthest along pier axis toward water; use largest y
print('box', box)
# edge points of the pier contour near the outer end
pts = cnt[:, 0, :]
print('max-y pier pixel', pts[pts[:, 1].argmax()], 'max-x', pts[pts[:, 0].argmax()])
ys, xs = np.nonzero(boat); B = np.c_[xs, ys].astype(float)
cen = B.mean(0)
pys, pxs = np.nonzero(pier); P = np.c_[pxs, pys].astype(float)
# min gap by brute force on contours
bc, _ = cv2.findContours(boat, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE); bc = max(bc, key=cv2.contourArea)[:, 0, :].astype(float)
D = np.sqrt(((pts[:, None, :].astype(float) - bc[None]) ** 2).sum(-1))
i, j = np.unravel_index(D.argmin(), D.shape)
print('min contour gap', D.min(), 'pier pt', pts[i], 'boat pt', bc[j])
print('boat centroid', cen)
for nm, e in [('endmid', end.mean(0)), ('corner0', end[0]), ('corner1', end[1])]:
    print(nm, e, 'to centroid', np.hypot(*(cen - e)), 'to nearest hull', np.sqrt(((bc - e) ** 2).sum(1)).min())

# boat length at frames 0,36,72 via PCA, plus with looser threshold to include stick
for k, c0 in [(0, None), (36, None), (72, None)]:
    img = F[k]
    hsv = cv2.cvtColor(img, cv2.COLOR_RGB2HSV)
    import csv
    rows = list(csv.DictReader(open('scene/tracks/boat.csv')))
    cx, cy = int(float(rows[k]['cx'])), int(float(rows[k]['cy']))
    bm, _ = masks(img, (cx, cy))
    ys, xs = np.nonzero(bm); Q = np.c_[xs, ys].astype(float); Q0 = Q - Q.mean(0)
    w, v = np.linalg.eigh(np.cov(Q0.T)); pr = Q0 @ v[:, 1]
    print('frame', k, 'len', np.ptp(pr) + 1, 'wid', np.ptp(Q0 @ v[:, 0]) + 1, 'cen', Q.mean(0))

ov = F[72].copy()
cv2.drawContours(ov, [cnt], -1, (0, 0, 255), 1)
cv2.polylines(ov, [box.astype(int)], True, (255, 255, 0), 1)
cv2.line(ov, tuple(pts[i].astype(int)), tuple(bc[j].astype(int)), (255, 0, 0), 1)
cv2.imwrite('frames/ov72b.png', cv2.cvtColor(cv2.resize(ov[600:820, 480:720], None, fx=3, fy=3, interpolation=cv2.INTER_NEAREST), cv2.COLOR_RGB2BGR))
