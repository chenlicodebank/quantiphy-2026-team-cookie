import numpy as np, cv2, av, csv
# 1) fit record centroid track
rows = list(csv.DictReader(open('scene/tracks/shark.csv')))
f = np.array([int(r['frame']) for r in rows]); cx = np.array([float(r['cx']) for r in rows])
x0 = np.array([float(r['x0']) for r in rows])
for name, x in [('centroid', cx), ('nose x0', x0)]:
    for a, b in [(2, 53), (2, 27), (27, 53)]:
        m = (f >= a) & (f <= b)
        t = f[m] / 24.0
        p = np.polyfit(t, x[m], 2)
        print(name, a, b, 'a_px/s2 =', 2 * p[0])

# 2) independent: template-match the shark head/front body (rigid part)
cont = av.open('simulation_0103.mp4')
frames = []
for fr in cont.decode(video=0):
    g = fr.to_ndarray(format='gray').astype(np.float32)
    frames.append(g[820:990, :])  # underwater strip around shark
cont.close()
# template from frame 27: front half of shark
r27 = rows[27]
X0 = int(r27['x0']); W = 120
tpl = frames[27][:, X0 - 5:X0 + W]
xs = []
for i, g in enumerate(frames):
    res = cv2.matchTemplate(g, tpl, cv2.TM_CCOEFF_NORMED)
    _, mv, _, ml = cv2.minMaxLoc(res)
    x = ml[0]; y = ml[1]
    row = res[y]
    if 0 < x < len(row) - 1:
        d = (row[x - 1] - row[x + 1]) / (2 * (row[x - 1] - 2 * row[x] + row[x + 1]))
    else:
        d = 0
    xs.append(x + d)
xs = np.array(xs)
print('steps', np.round(np.diff(xs), 2))
for a, b in [(2, 53), (2, 27), (27, 53), (5, 50)]:
    m = (f >= a) & (f <= b)
    p = np.polyfit(f[m] / 24.0, xs[m], 2)
    res = xs[m] - np.polyval(p, f[m] / 24.0)
    print('template', a, b, 'a =', 2 * p[0], 'rms', res.std())
np.save('shark_tpl_x.npy', xs)
