import av, numpy as np, cv2
c = av.open('/private/tmp/qp_blind/scene_full_b/simulation_0088/q_131/simulation_0088.mp4')
for i, fr in enumerate(c.decode(video=0)):
    if i > 14:
        break
    a = fr.to_ndarray(format='rgb24').astype(int)
    m = (np.abs(a - [97, 149, 191]).sum(2) > 40).astype(np.uint8)
    n, l, st, cen = cv2.connectedComponentsWithStats(m)
    out = []
    for k in range(1, n):
        s = st[k]
        if s[4] < 300:
            continue
        x0, x1 = s[0], s[0] + s[2] - 1
        out.append((x0, x1, s[1], s[1] + s[3] - 1, (x0 + x1) / 2, round(cen[k][0], 1), s[4]))
    print(i, out)
