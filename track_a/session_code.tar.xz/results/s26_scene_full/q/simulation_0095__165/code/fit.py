import numpy as np, csv, av
r = list(csv.DictReader(open('scene/tracks/car.csv')))
f = np.array([float(x['frame']) for x in r])
for k in ['mask_cx', 'ref_x', 'bbox_x0', 'bbox_x1']:
    x = np.array([float(a[k]) for a in r])
    for lo, hi in [(2, 71), (10, 71), (2, 40), (40, 71)]:
        m = (f >= lo) & (f <= hi)
        p = np.polyfit(f[m], x[m], 2)
        print(k, lo, hi, 'a_px/f2 %.4f' % (2 * p[0]), 'resid %.3f' % np.std(x[m] - np.polyval(p, f[m])), 't0 %.2f' % (-p[1] / (2 * p[0])))
L = np.array([float(a['len_px']) for a in r])
print('len_px', L[:3], L.min(), L.max(), L.mean())

# independent length measurement from video, frames 0 and others
c = av.open('simulation_0095.mp4')
bg = np.array([132, 126, 135])
for i, fr in enumerate(c.decode(video=0)):
    if i in (0, 1, 24, 48, 71):
        a = fr.to_ndarray(format='rgb24').astype(int)[560:700]
        d = np.abs(a - bg).max(axis=2)
        for th in (6, 15, 30):
            ys, xs = np.nonzero(d > th)
            cols = np.nonzero((d > th).sum(0) >= 2)[0]
            print(i, th, 'x', cols.min(), cols.max(), 'len', cols.max() - cols.min() + 1, 'y', ys.min() + 560, ys.max() + 560)
