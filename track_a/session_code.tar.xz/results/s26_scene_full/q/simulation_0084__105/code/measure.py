import av, numpy as np, cv2
c = av.open('simulation_0084.mp4')
yel = {}; dark = {}
for i, fr in enumerate(c.decode(video=0)):
    img = fr.to_ndarray(format='rgb24')
    hsv = cv2.cvtColor(img, cv2.COLOR_RGB2HSV)
    g = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY).astype(int)
    m = (g < 113) | (g > 176) | (hsv[..., 1] > 40)
    # yellow car rows 480-570
    cols = np.where(m[480:571].sum(0) > 3)[0]
    yel[i] = (cols.min(), cols.max())
    if i in (24, 36, 48):
        sub = m[540:740]
        colsd = np.where(m[600:686].sum(0) > 3)[0]
        x0, x1 = colsd.min(), colsd.max()
        print('frame', i, 'dark x', x0, x1, 'len', x1 - x0 + 1)
        # per-column vertical extent within the dark car's x range
        for x in range(x0, x1 + 1, 6):
            ys = np.where(m[540:740, x])[0] + 540
            print(x - x0, ys.min(), ys.max(), ys.max() - ys.min() + 1)
        cv2.imwrite(f'frames/mask{i}.png', (m[540:740, x0 - 10:x1 + 10] * 255).astype(np.uint8))
yf = np.array([yel[i][0] for i in range(len(yel))]); yr = np.array([yel[i][1] for i in range(len(yel))])
print('yellow front', yf[:15], yf[-5:])
print('yellow rear', yr[10:20], yr[-5:])
print('front step mean 2..71', (yf[71] - yf[1]) / 70, 'rear 12..71', (yr[71] - yr[12]) / 59)
