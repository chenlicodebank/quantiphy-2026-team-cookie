import av, numpy as np
P = '/private/tmp/qp_blind/scene_full_b/simulation_0096/q_171/simulation_0096.mp4'
frames = {}
c = av.open(P)
for i, f in enumerate(c.decode(video=0)):
    a = f.to_ndarray(format='rgb24').astype(float)
    frames[i] = a[560:650, 450:1000].copy()  # car region only
c.close()
# background: column-wise from frame 40 right part and frame 0 left part
bg = frames[40].copy()
bg[:, 450:] = frames[0][:, 450:]  # x >= 900 in frame0 region... car at 842-954 in frame 0 -> abs 842-954 -> local 392-504
bg = np.where(np.arange(550)[None, :, None] < 380, frames[0], frames[40])  # frame0 car at local>=392; frame40 car at local 97-213
# simpler: background = median grey
gval = np.median(frames[0][:, :300], axis=(0, 1))
print('bg grey', gval)
xs = []
for i in range(41):
    d = np.abs(frames[i] - gval).max(axis=2)
    m = d > 18
    rows = np.where(m.any(1))[0]; cols = np.where(m.any(0))[0]
    # subpixel vertical extent: in central columns, profile of fraction
    # use column profile: per row, max diff over car columns
    rp = d[:, cols[0]:cols[-1] + 1].max(axis=1)
    cp = d[rows[0]:rows[-1] + 1].max(axis=0)
    # half-max crossing estimates
    def extent(p, thr):
        idx = np.where(p > thr)[0]
        a, b = idx[0], idx[-1]
        fa = (p[a] - thr) / (p[a] - p[a - 1]) if p[a] != p[a - 1] else 0
        fb = (p[b] - thr) / (p[b] - p[b + 1]) if p[b] != p[b + 1] else 0
        return a - fa, b + fb
    t1, b1 = extent(rp, 0.5 * np.percentile(rp, 90))
    l1, r1 = extent(cp, 0.5 * np.percentile(cp, 90))
    w = d * m
    cx = (w.sum(0) * np.arange(d.shape[1])).sum() / w.sum() + 450
    xs.append(cx)
    print(i, 'rows', rows[0] + 560, rows[-1] + 560, 'h_sub %.2f' % (b1 - t1), 'L_sub %.2f' % (r1 - l1),
          'top %.2f bot %.2f' % (t1 + 560, b1 + 560), 'cx %.2f' % cx)
xs = np.array(xs)
t = np.arange(41) / 24
for s in (1, 2, 3):
    sel = np.arange(s, 41)
    p = np.polyfit(t[sel], xs[sel], 2)
    res = xs[sel] - np.polyval(p, t[sel])
    print('start', s, 'a_px', 2 * p[0], 'vertex t', -p[1] / (2 * p[0]), 'rms', res.std())
sp = np.abs(np.diff(xs)) * 24
print('speeds', np.round(sp, 1))
