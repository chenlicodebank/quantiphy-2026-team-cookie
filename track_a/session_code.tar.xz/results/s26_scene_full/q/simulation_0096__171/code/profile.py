import av, numpy as np
P = '/private/tmp/qp_blind/scene_full_b/simulation_0096/q_171/simulation_0096.mp4'
c = av.open(P)
for i, f in enumerate(c.decode(video=0)):
    if i in (0, 12, 30):
        a = f.to_ndarray(format='rgb24').astype(float)[575:630, 820:980]
        g = np.median(a[:, :15], axis=(0, 1))
        d = np.abs(a - g).max(axis=2)
        print('frame', i)
        for r in range(0, 55):
            row = d[r]
            idx = np.where(row > 10)[0]
            print(575 + r, 'max %.0f' % row.max(), 'n>10', len(idx), (idx[0] + 820, idx[-1] + 820) if len(idx) else '')
        if i == 30:
            break
c.close()
