import av, numpy as np, cv2, csv
# per-frame car and cyclist displacement by template matching (sub-pixel), using the scene track bboxes
def rows(p):
    return {int(r['frame']):r for r in csv.DictReader(open(p))}
car=rows('scene/tracks/car.csv'); cyc=rows('scene/tracks/cyclist.csv')
frames=[]
c=av.open('simulation_0085.mp4')
for fr in c.decode(video=0):
    g=cv2.cvtColor(fr.to_ndarray(format='rgb24'),cv2.COLOR_RGB2GRAY).astype(np.float32)
    frames.append(g[300:900].copy())  # keep strip only (y 300..900)
c.close()
Y0=300
def shift(prev,cur,x0,x1,y0,y1,vguess):
    # template from prev [x0:x1], search in cur around x0+vguess
    tpl=prev[y0-Y0:y1-Y0,x0:x1]
    s0=max(0,int(x0+vguess-40)); s1=min(1920,int(x1+vguess+40))
    srch=cur[y0-Y0-5:y1-Y0+5,s0:s1]
    res=cv2.matchTemplate(srch,tpl,cv2.TM_CCOEFF_NORMED)
    _,mx,_,loc=cv2.minMaxLoc(res)
    i=loc[0]; dx=0.0
    if 0<i<res.shape[1]-1:
        a,b,cc=res[loc[1],i-1],res[loc[1],i],res[loc[1],i+1]
        dx=0.5*(a-cc)/(a-2*b+cc)
    return s0+i+dx-x0, mx
out=[]
for i in range(1,len(frames)):
    r=car[i-1]; bx0=int(r['bbox_x0']); bx1=int(r['bbox_x1'])
    v=int(car[i]['bbox_x0'])-bx0 if int(car[i]['bbox_x0'])>0 else int(car[i]['bbox_x1'])-bx1
    # use a window of the car visible in both frames
    lo=max(bx0,0)+5; hi=min(bx1,1919)-5
    lo2=max(lo, -v+5 if v<0 else lo)  # ensure shifted window inside image
    lo=max(lo, int(-v)+45)
    hi=min(hi, 1919-45)
    if hi-lo<60: out.append((i,np.nan,np.nan,np.nan)); continue
    dcar,q=shift(frames[i-1],frames[i],lo,hi,590,860,v)
    rc=cyc[i-1]; cx0=max(int(rc['bbox_x0']),40)+3; cx1=min(int(rc['bbox_x1']),1919)-3
    if cx1-cx0>60:
        dcy,qc=shift(frames[i-1],frames[i],cx0,cx1,350,414,-26.6)
    else: dcy=np.nan
    out.append((i,dcar,q,dcy))
with open('tm.csv','w') as f:
    f.write('frame,dcar,q,dcyc\n')
    for o in out: f.write('%d,%.3f,%.4f,%.3f\n'%o)
for o in out: print('%d %.2f %.3f %.2f'%o)
