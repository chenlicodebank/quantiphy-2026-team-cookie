import numpy as np, csv
r=list(csv.DictReader(open('scene/tracks/car.csv')))
f=np.array([int(x['frame']) for x in r]); x0=np.array([float(x['bbox_x0']) for x in r]); x1=np.array([float(x['bbox_x1']) for x in r])
for a,b in [(3,60),(5,55),(10,63),(2,40),(20,63),(3,30)]:
    m=(f>=a)&(f<=b)&(x0>0)
    p=np.polyfit(f[m],x0[m],2); res=x0[m]-np.polyval(p,f[m])
    print('front',a,b,'acc px/f2',2*p[0],'rms',res.std(),'rest frame',-p[1]/(2*p[0]))
for a,b in [(40,66),(40,62)]:
    m=(f>=a)&(f<=b)
    p=np.polyfit(f[m],x1[m],2); print('rear',a,b,2*p[0], (x1[m]-np.polyval(p,f[m])).std())
d=np.diff(x0); print(list(zip(f[1:].tolist(),d.tolist())))
d=np.diff(x1); print(list(zip(f[1:].tolist(),d.tolist())))
