import numpy as np, csv
d=np.genfromtxt('tm.csv',delimiter=',',names=True)
f=d['frame']; v=-d['dcar']
for a,b in [(10,49),(10,40),(20,49),(10,30),(30,49)]:
    m=(f>=a)&(f<=b); p=np.polyfit(f[m],v[m],1)
    print(a,b,'acc px/f2 %.4f  v=0 at frame %.2f'%(p[0],-p[1]/p[0]))
m=(f>=10)&(f<=49); acc=np.polyfit(f[m],v[m],1)[0]
s=4.03/(acc*24*24)
print('scale m/px',s,'car len m',726*s,'cyc speed m/s',27.2*24*s)
# positions at frame 24
car={int(r['frame']):r for r in csv.DictReader(open('scene/tracks/car.csv'))}
cyc={int(r['frame']):r for r in csv.DictReader(open('scene/tracks/cyclist.csv'))}
L=727  # car length px (median 726-728 when fully visible)
cx_car=float(car[24]['bbox_x0'])+(L-1)/2; cy_car=727.5
cx_cyc=float(cyc[24]['ref_x']); cy_cyc=381.5
dpx=np.hypot(cx_car-cx_cyc,cy_car-cy_cyc)
print('frame24 car',cx_car,'cyc',cx_cyc,'dx',cx_car-cx_cyc,'dpx',dpx,'dist m',dpx*s)
# route 2: back-extrapolate car centre from fully visible frames 40-49 using template displacements
cen40=float(car[40]['ref_x'])
pos=cen40+np.sum(d['dcar'][(f>=25)&(f<=40)])  # x(24)=x(40)-sum dx(25..40)
pos24=cen40-np.sum(d['dcar'][(f>=25)&(f<=40)])
dpx2=np.hypot(pos24-cx_cyc,cy_car-cy_cyc)
print('route2 car x24',pos24,'dpx',dpx2,'dist m',dpx2*s)
