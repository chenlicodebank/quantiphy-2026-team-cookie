import csv, numpy as np, json
v = list(csv.DictReader(open("scene/tracks/van.csv")))
c = list(csv.DictReader(open("scene/tracks/cyclist.csv")))
g = lambda r, k: np.array([float(x[k]) for x in r])
i = np.arange(72)
cy, cx, vy, vx = g(c, "cy_px"), g(c, "cx_px"), g(v, "cy_px"), g(v, "cx_px")
# cyclist constant speed (moves from frame 1->2 on)
pc = np.polyfit(i[2:], cy[2:], 1)
spd = abs(pc[0]) * 24
s = 5.33 / spd
pv = np.polyfit(i, vy, 2)
dx = np.median(cx[40:57]) - np.median(vx[40:57])
dy = np.polyval(pv, 48) - np.polyval(pc, 48)
d_s = np.hypot(dx, dy)
d_raw = np.hypot(cx[48] - vx[48], cy[48] - vy[48])
print("px/s", spd, "m/px", s, "smoothed px", d_s, "raw px", d_raw, "m", d_s * s, d_raw * s)
json.dump({"51": round(float(d_s * s), 3)}, open("answers.json", "w"))
