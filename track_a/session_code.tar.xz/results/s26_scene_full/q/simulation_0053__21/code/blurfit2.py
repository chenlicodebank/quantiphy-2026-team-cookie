import numpy as np
exec(open('blurfit.py').read().split('for col,name')[0])
# per-car fit of length vs y (linear + quadratic): separates a camera tilt / perspective trend from speed (blur)
for nm,arr in [('orange',o),('black',b)]:
    y=arr[:,1]-1024; L=arr[:,3]
    X=np.c_[np.ones_like(y),y/1e3,(y/1e3)**2]
    p,*_=np.linalg.lstsq(X,L,rcond=None); print(nm,'L0 %.1f lin %.2f quad %.2f'%tuple(p),'resid %.2f'%np.std(L-X@p))
    X=np.c_[np.ones_like(y),y/1e3,(y/1e3)**2,arr[:,2]]
    if nm=='orange':
        p,*_=np.linalg.lstsq(X,L,rcond=None); print(nm,'+speed: L0 %.1f lin %.2f quad %.2f a %.3f'%tuple(p),'resid %.2f'%np.std(L-X@p))
