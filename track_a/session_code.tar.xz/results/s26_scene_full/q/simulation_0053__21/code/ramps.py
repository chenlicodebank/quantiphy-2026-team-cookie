import av, numpy as np, csv
# Width of the leading/trailing edge ramps (10%..90% of diff level) along several columns, for both cars.
tr={n:{int(r['frame']):r for r in csv.DictReader(open(f'scene/tracks/{n}.csv'))} for n in ['orange_car','black_car']}
F={'orange_car':[50,60,70],'black_car':[60,65,70]}
c=av.open('simulation_0053.mp4')
for i,fr in enumerate(c.decode(video=0)):
    img=fr.to_ndarray(format='rgb24').astype(np.float32)
    if i==0: bg=img; continue
    for n,fs in F.items():
        if i not in fs: continue
        r=tr[n][i]; cx=int(float(r['ref_x'])); y0=int(r['bbox_y0']); y1=int(r['bbox_y1'])
        d=np.abs(img-bg).sum(2)
        out=[]
        for o in range(-80,81,20):
            col=np.median(d[:,cx+o-3:cx+o+4],1)
            # rear (top) edge: scan from y0-30 downward
            seg=col[y0-30:y0+40]; mx=np.percentile(seg,95)
            a10=np.argmax(seg>0.1*mx); a50=np.argmax(seg>0.5*mx); a90=np.argmax(seg>0.9*mx)
            segb=col[y1-40:y1+30][::-1]; mxb=np.percentile(segb,95)
            b10=np.argmax(segb>0.1*mxb); b50=np.argmax(segb>0.5*mxb); b90=np.argmax(segb>0.9*mxb)
            top10=y0-30+a10; top50=y0-30+a50; bot10=y1+30-b10; bot50=y1+30-b50
            out.append((o,top10,top50,a90-a10,bot50,bot10,b90-b10,bot10-top10,bot50-top50))
        print(n,i,'bbox',y0,y1,y1-y0)
        for row in out: print('   off %4d top10 %5d top50 %5d rampT %3d | bot50 %5d bot10 %5d rampB %3d | L10 %4d L50 %4d'%row)
c.close()
