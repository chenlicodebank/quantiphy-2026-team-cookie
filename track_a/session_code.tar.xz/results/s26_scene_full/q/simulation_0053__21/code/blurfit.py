import csv, numpy as np
# Fit length_px = L0 + a*speed + b*(y-yc)^2 ; black car (constant speed) pins b, orange (varying speed) pins a.
def load(n):
    r={int(x['frame']):x for x in csv.DictReader(open(f'scene/tracks/{n}.csv'))}
    out=[]
    for f,x in r.items():
        if f-1 not in r or x['truncated_by_frame_edge']=='1' or float(x['visible_fraction'])<0.999: continue
        s=np.hypot(float(x['ref_x'])-float(r[f-1]['ref_x']),float(x['ref_y'])-float(r[f-1]['ref_y']))
        out.append((f,float(x['ref_y']),s,float(x['length_px']),float(x['bbox_h'])))
    return np.array(out)
o=load('orange_car'); b=load('black_car')
for col,name in [(3,'minAreaRect len'),(4,'bbox_h')]:
    for yc in (1024,):
        X=[];Y=[]
        for arr,isb in [(o,0),(b,1)]:
            for f,y,s,L,h in arr:
                X.append([1-isb,isb,s,(y-yc)**2/1e4]); Y.append(arr[arr[:,0]==f][0,col])
        X=np.array(X);Y=np.array(Y)
        p,*_=np.linalg.lstsq(X,Y,rcond=None)
        print(name,'L0_orange %.1f L0_black %.1f a(px per px/frame) %.3f b %.3f'%tuple(p),'resid',np.std(Y-X@p))
print('black rows f y speed len bboxh');print(np.round(b,1))
