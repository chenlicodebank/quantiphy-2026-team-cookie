import av, numpy as np, csv
# Along-road length of each car from row profiles of |frame - frame0| in a central column band.
# Edges found at fractional thresholds of the plateau level (50% = blur-corrected edge estimate).
tr={n:{int(r['frame']):r for r in csv.DictReader(open(f'scene/tracks/{n}.csv'))} for n in ['orange_car','black_car']}
want={'black_car':range(47,82),'orange_car':range(22,91)}
c=av.open('simulation_0053.mp4'); bg=None
res={n:[] for n in want}
for i,fr in enumerate(c.decode(video=0)):
    img=fr.to_ndarray(format='rgb24').astype(np.float32)
    if i==0: bg=img; continue
    for n,rg in want.items():
        if i not in rg or i not in tr[n]: continue
        r=tr[n][i]
        if r['truncated_by_frame_edge']=='1': continue
        cx=float(r['ref_x']); cy=float(r['ref_y'])
        out=[]
        for hw in (25,50,80):
            x0,x1=int(cx-hw),int(cx+hw)
            d=np.abs(img[:,x0:x1]-bg[:,x0:x1]).sum(2)
            prof=np.median(d,1)
            y0=int(max(0,cy-420)); y1=int(min(2048,cy+420))
            p=prof[y0:y1]
            plat=np.percentile(prof[int(cy-200):int(cy+200)],50)
            noise=np.percentile(np.r_[prof[max(0,y0-80):y0],prof[y1:y1+80]],50) if True else 0
            row=[]
            for fr_ in (0.2,0.5):
                th=noise+fr_*(plat-noise)
                above=np.where(p>th)[0]
                if len(above)==0: row.append(np.nan); continue
                # contiguous run containing centre
                ci=int(cy)-y0
                a=ci
                while a>0 and p[a-1]>th: a-=1
                b=ci
                while b<len(p)-1 and p[b+1]>th: b+=1
                # subpixel interpolation
                ya=a-1+(th-p[a-1])/(p[a]-p[a-1]) if a>0 else a
                yb=b+(p[b]-th)/(p[b]-p[b+1]) if b<len(p)-1 else b
                row.append(yb-ya)
            out+=row
        spd=np.hypot(float(r['ref_x'])-float(tr[n][i-1]['ref_x']),float(r['ref_y'])-float(tr[n][i-1]['ref_y'])) if i-1 in tr[n] else np.nan
        res[n].append((i,cy,spd,*out))
c.close()
for n in res:
    a=np.array(res[n]); np.save(f'len_{n}.npy',a)
    print(n,'frame cy speed | hw25: L20 L50 | hw50: L20 L50 | hw80: L20 L50')
    for row in a[::3]: print(' '.join(f'{v:7.1f}' for v in row))
