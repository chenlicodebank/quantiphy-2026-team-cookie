import av, numpy as np, csv, sys
from PIL import Image
# Crops of front & rear ends of black car at frame N, scaled x3, side by side, plus centreline luminance profile.
N=int(sys.argv[1]) if len(sys.argv)>1 else 65
tr={int(r['frame']):r for r in csv.DictReader(open('scene/tracks/black_car.csv'))}
r=tr[N]; cx=int(float(r['ref_x'])); cy=int(float(r['ref_y']))
c=av.open('simulation_0053.mp4')
for i,fr in enumerate(c.decode(video=0)):
    if i==0: bg=fr.to_ndarray(format='rgb24').astype(np.float32)
    if i==N: img=fr.to_ndarray(format='rgb24'); break
c.close()
print('cx,cy',cx,cy)
top=img[cy-320:cy-220,cx-130:cx+130]; bot=img[cy+220:cy+320,cx-130:cx+130]
pil=lambda a: Image.fromarray(a).resize((a.shape[1]*3,a.shape[0]*3),Image.NEAREST)
canvas=Image.new('RGB',(780,620),'white'); canvas.paste(pil(top),(0,0)); canvas.paste(pil(bot),(0,310))
canvas.save(f'frames/ends_{N}.png')
d=np.abs(img.astype(np.float32)-bg).sum(2)
for name,ys in [('top',range(cy-310,cy-250)),('bot',range(cy+250,cy+310))]:
    print(name)
    for y in ys:
        print(y, ' '.join(f'{int(np.median(d[y,cx+o-8:cx+o+8])):4d}' for o in (-90,-60,-30,0,30,60,90)))
