import csv, numpy as np
r=[x for x in csv.DictReader(open('scene/tracks/orange_car.csv')) if x['ref_reliable']=='1']
f=np.array([int(x['frame']) for x in r]); x=np.array([float(x_['ref_x']) for x_ in r]); y=np.array([float(x_['ref_y']) for x_ in r])
d=np.hypot(np.diff(x),np.diff(y)); ff=f[1:]
ok=np.diff(f)==1
for lo in [17,25,40]:
    m=ok&(ff>=lo)
    p=np.polyfit(ff[m],d[m],1); print(lo,'speed slope px/frame^2',p[0],'-> px/s^2',p[0]*900, 'resid',np.std(d[m]-np.polyval(p,ff[m])))
    p2=np.polyfit(ff[m],d[m],2); print('  quad',p2)
for lo,hi in [(20,50),(50,90),(20,90)]:
    m=(f>=lo)&(f<=hi)
    p=np.polyfit(f[m],y[m],2); print(lo,hi,'pos quad fit accel px/s^2',2*p[0]*900)
