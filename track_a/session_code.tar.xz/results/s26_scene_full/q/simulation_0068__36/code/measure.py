import numpy as np, csv, av
rows = list(csv.DictReader(open('scene/tracks/van.csv')))
f = np.array([int(r['frame']) for r in rows]); y = np.array([float(r['ccy']) for r in rows])
cw = np.array([float(r['cwidth']) for r in rows])
print('record cwidth median', np.median(cw))
t = f / 24.0
for a0 in [3, 5, 10, 20]:
    m = f >= a0
    p = np.polyfit(t[m], y[m], 2); res = y[m] - np.polyval(p, t[m])
    print('fit from', a0, 'acc px/s2', 2 * p[0], 'rms', res.std())
# own measurement: white-body mask per frame, rows/cols in van column band
tops, bots, wids = [], [], []
c = av.open('simulation_0068.mp4')
for i, fr in enumerate(c.decode(video=0)):
    img = fr.to_ndarray(format='rgb24').astype(int)
    band = img[:, 760:900]
    white = (band.min(axis=2) > 200) & (band.max(axis=2) - band.min(axis=2) < 25)
    rws = np.where(white.sum(1) > 20)[0]
    tops.append(rws.min()); bots.append(rws.max())
    # width: at the body midline rows, column extent of white
    mid = (rws.min() + rws.max()) // 2
    ws = []
    for r in range(mid - 40, mid + 40):
        cols = np.where(white[r])[0]
        if len(cols): ws.append(cols.max() - cols.min() + 1)
    wids.append(np.median(ws))
tops = np.array(tops, float); bots = np.array(bots, float); wids = np.array(wids)
cen = (tops + bots) / 2
print('own length median', np.median(bots - tops + 1), 'width median', np.median(wids))
for name, s in [('top', tops), ('bot', bots), ('cen', cen)]:
    for a0 in [5, 10, 20]:
        m = f >= a0
        p = np.polyfit(t[m], s[m], 2)
        print(name, a0, 'acc', 2 * p[0])
d = np.diff(y); sp = d * 24
print('per-frame step', np.round(-d, 1))
