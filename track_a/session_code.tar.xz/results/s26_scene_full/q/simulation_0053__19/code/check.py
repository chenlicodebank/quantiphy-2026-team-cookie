# Independent check: mask centroid (diff vs frame 0) per lane column band
import av, numpy as np
D = '/private/tmp/qp_blind/scene_full_a/simulation_0053/q_19/'
c = av.open(D + 'simulation_0053.mp4')
bg = None; res = {}
want = set(range(25, 91))
for i, fr in enumerate(c.decode(video=0)):
    g = fr.to_ndarray(format='rgb24').astype(np.int16)
    if i == 0: bg = g; continue
    if i not in want: continue
    diff = np.abs(g - bg).sum(2) > 60
    out = {}
    for name, (x0, x1) in {'o': (580, 1100), 'b': (1110, 1540)}.items():
        rows = diff[:, x0:x1].sum(1) > 40
        ys = np.nonzero(rows)[0]
        out[name] = (ys.min(), ys.max()) if len(ys) else None
    res[i] = out
c.close()
# trailing/leading edges
print('orange leading edge (bottom) per frame:')
lo = {i: res[i]['o'][1] for i in res if res[i]['o'] and res[i]['o'][1] < 2040}
fs = np.array(sorted(lo)); ye = np.array([lo[k] for k in fs], float)
p = np.polyfit(fs, ye, 2); print(' frames', fs.min(), fs.max(), 'acc px/f^2', 2 * p[0])
lt = {i: res[i]['o'][0] for i in res if res[i]['o'] and res[i]['o'][0] > 5}
fs2 = np.array(sorted(lt)); yt = np.array([lt[k] for k in fs2], float)
p = np.polyfit(fs2, yt, 2); print(' trailing edge frames', fs2.min(), fs2.max(), 'acc px/f^2', 2 * p[0])
bt = {i: res[i]['b'] for i in res if res[i]['b']}
for k in range(55, 66): print(k, bt.get(k))
ks = [k for k in range(47, 81) if bt.get(k) and bt[k][0] > 5]
yt = np.array([bt[k][0] for k in ks], float); pb = np.polyfit(ks, yt, 1); print('black trailing edge speed px/f', pb[0])
ks = [k for k in range(40, 80) if bt.get(k) and bt[k][1] < 2040]
yl = np.array([bt[k][1] for k in ks], float); pb = np.polyfit(ks, yl, 1); print('black leading edge speed px/f', pb[0])
