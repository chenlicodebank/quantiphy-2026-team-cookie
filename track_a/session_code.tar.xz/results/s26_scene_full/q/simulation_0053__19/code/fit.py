import csv, numpy as np
D = '/private/tmp/qp_blind/scene_full_a/simulation_0053/q_19/'
def arr(n):
    r = list(csv.DictReader(open(D + f'scene/tracks/{n}.csv')))
    f = np.array([int(x['frame']) for x in r]); X = np.array([float(x['ref_x']) for x in r]); Y = np.array([float(x['ref_y']) for x in r])
    return f, X, Y
f, x, y = arr('orange_car'); m = f >= 25
F, X, Y = f[m], x[m], y[m]
d = np.hypot(np.diff(X), np.diff(Y)); fm = F[1:]
p = np.polyfit(fm, d, 1); print('orange speed fit px/frame', p, 'resid std', np.std(d - np.polyval(p, fm)))
for lo, hi in [(25, 57), (57, 90)]:
    mm = (fm >= lo) & (fm <= hi); print(' window', lo, hi, np.polyfit(fm[mm], d[mm], 1)[0])
p2 = np.polyfit(F, Y, 2); print('quad y fit acc px/f^2', 2 * p2[0])
acc = -p[0] * 900; print('acc px/s^2', acc)
s = 2.86 / acc; print('m/px', s)
f, x, y = arr('black_car')
for i in range(len(f)):
    if 56 <= f[i] <= 64: print(f[i], x[i], y[i])
i = list(f).index(60)
v = np.hypot(x[i] - x[i-1], y[i] - y[i-1]); print('black disp f60', v)
m = (f >= 47) & (f <= 80); pb = np.polyfit(f[m], y[m], 2); vfit = 2 * pb[0] * 60 + pb[1]
print('black fit', pb, 'v at 60', vfit)
print('speed m/s', v * 30 * s, vfit * 30 * s)
