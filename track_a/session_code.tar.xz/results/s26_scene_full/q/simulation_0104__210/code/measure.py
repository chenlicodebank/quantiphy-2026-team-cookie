import av, numpy as np
c = av.open('/private/tmp/qp_blind/scene_full_a/simulation_0104/q_210/simulation_0104.mp4')
tops = {}
bg = None
for i, f in enumerate(c.decode(video=0)):
    a = f.to_ndarray(format='rgb24').astype(float)
    if bg is None:
        bg = np.median(a[:200, :200].reshape(-1, 3), 0)
    m = (np.abs(a[:, 700:790] - bg).sum(2) > 40).mean(1)
    rows = np.where(m > 0.5)[0]
    tops[i] = int(rows.min()) if len(rows) else None
print(tops)
print(np.diff([tops[i] for i in range(len(tops))]))
v = (tops[1] - tops[27]) / 26 * 24
s = 0.2 / v
print('px/s', v, 'm/px', s)
print('ext f12 vs f1', (tops[1] - tops[12]) * s, 'vs f0', (tops[0] - tops[12]) * s)
