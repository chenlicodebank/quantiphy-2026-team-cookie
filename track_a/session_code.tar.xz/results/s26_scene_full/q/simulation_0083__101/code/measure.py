import av, numpy as np
idx = [0, 16, 20, 22, 23, 24, 25, 26, 28, 32, 71]
c = av.open('/private/tmp/qp_blind/scene_full_a/simulation_0083/q_101/simulation_0083.mp4')
for i, f in enumerate(c.decode(video=0)):
    if i not in idx:
        continue
    f = f.to_ndarray(format='rgb24').astype(int)
    g = f.mean(2)
    ground = np.median(g)
    y = (f[360:470, :, 0] - f[360:470, :, 2] > 30) | (np.abs(g[360:470] - ground) > 40)
    b = np.abs(g[485:595] - ground) > 40
    def ext(m):
        cols = np.where(m.sum(0) >= 3)[0]
        return int(cols.min()), int(cols.max()), int(cols.max() - cols.min() + 1)
    print(i, 'yellow', ext(y), 'black', ext(b), 'ground', ground)
