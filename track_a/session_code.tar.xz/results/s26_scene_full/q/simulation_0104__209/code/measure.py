import av, numpy as np
c = av.open('/private/tmp/qp_blind/scene_full_a/simulation_0104/q_209/simulation_0104.mp4')
for i, fr in enumerate(c.decode(video=0)):
    if i in (15, 28, 30):
        a = fr.to_ndarray(format='rgb24').astype(float)
        bg = a[100:200, 100:300].reshape(-1, 3).mean(0)
        d = np.abs(a - bg).sum(2)
        y0 = 350 + int(round(23.96 * (27 - min(i, 27))))
        for y in range(y0, y0 + 45):
            prof = d[y, 700:1250]
            xs = np.nonzero(prof > 40)[0] + 700
            if len(xs) == 0:
                continue
            L, R = xs.min(), xs.max()
            # sub-pixel edges: fractional coverage of edge pixels, using interior level
            inner = np.median(d[y, L + 5:L + 15])
            innerR = np.median(d[y, R - 15:R - 5])
            fl = np.clip(d[y, L - 1] / inner, 0, 1) + np.clip(d[y, L] / inner, 0, 1)
            fr_ = np.clip(d[y, R] / innerR, 0, 1) + np.clip(d[y, R + 1] / innerR, 0, 1)
            w = (R - L - 1) + fl + fr_
            print(i, y, L, R, R - L + 1, round(w, 1), int(a[y, 960].mean()), int(a[y, L + 8].mean()))
