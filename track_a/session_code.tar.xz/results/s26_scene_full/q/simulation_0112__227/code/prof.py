import av, numpy as np
c = av.open('simulation_0112.mp4')
for i, f in enumerate(c.decode(video=0)):
    if i == 54:
        img = f.to_ndarray(format='rgb24').astype(float)
        break
for x0, x1 in [(50, 250), (400, 600), (800, 1000), (0, 1080)]:
    g = img[520:640, x0:x1].mean(axis=(1, 2))
    d = np.diff(g)
    print('cols', x0, x1)
    for k in range(len(d)):
        if abs(d[k]) > 5:
            print('  y', 520 + k, '->', 521 + k, round(g[k], 1), round(g[k + 1], 1))
