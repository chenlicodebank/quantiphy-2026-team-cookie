import av, numpy as np, cv2
# width profile along the whole car at frame 55 (saturation half-max edges per column)
def edges(p, thr):
    idx = np.where(p > thr)[0]
    a, b = idx.min(), idx.max()
    lo = a - 1 + (thr - p[a-1]) / (p[a] - p[a-1])
    hi = b + (p[b] - thr) / (p[b] - p[b+1])
    return lo, hi
c = av.open('simulation_0082.mp4')
for i, fr in enumerate(c.decode(video=0)):
    if i != 55: continue
    img = fr.to_ndarray(format='rgb24')
    S = cv2.cvtColor(img, cv2.COLOR_RGB2HSV)[..., 1].astype(float)
    for x in range(830, 1125, 6):
        lo, hi = edges(S[320:480, x], 60)
        print(x, round(lo+320, 1), round(hi+320, 1), round(hi-lo, 1))
