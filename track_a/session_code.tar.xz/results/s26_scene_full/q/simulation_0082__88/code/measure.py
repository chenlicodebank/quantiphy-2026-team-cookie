import av, numpy as np, cv2
frames_want = [10, 30, 45, 55, 65]
c = av.open('simulation_0082.mp4')
for i, fr in enumerate(c.decode(video=0)):
    if i not in frames_want: continue
    img = fr.to_ndarray(format='rgb24').astype(int)
    hsv = cv2.cvtColor(img.astype(np.uint8), cv2.COLOR_RGB2HSV)
    sat = hsv[..., 1] > 50
    band = img[300:470]
    s = sat[300:470]
    # columns: length along x within core rows 375-430 of yellow-saturated or dark pixels
    mn = img.min(2); mx = img.max(2)
    m = (sat | (mn < 100))
    m[:300] = 0; m[470:] = 0
    core = m[375:431]
    cols = np.where(core.sum(0) > 10)[0]
    x0, x1 = cols.min(), cols.max()
    # width: rows of saturated yellow within central x range (avoid mirrors: mirrors near front)
    xs_mid = slice(x0 + int(0.55*(x1-x0)), x0 + int(0.95*(x1-x0)))
    rows_s = np.where(sat[300:470, xs_mid].sum(1) > 0.5*(xs_mid.stop-xs_mid.start))[0] + 300
    rows_any = np.where(m[300:470, xs_mid].sum(1) > 0.3*(xs_mid.stop-xs_mid.start))[0] + 300
    # profile of saturation at column center of rear part
    xc = (xs_mid.start+xs_mid.stop)//2
    print(i, 'x0,x1', x0, x1, 'len', x1-x0+1, 'sat rows', rows_s.min(), rows_s.max(), rows_s.max()-rows_s.min()+1,
          'any rows', rows_any.min(), rows_any.max())
    # mirror extents (all columns)
    r = np.where(sat[300:490, x0:x1].sum(1) > 2)[0] + 300
    print('   sat rows all cols', r.min(), r.max())
    prof = hsv[335:470, xc, 1]
    print('   sat profile at x', xc, ' '.join(f'{335+k}:{v}' for k, v in enumerate(prof) if k % 1 == 0 and (335+k < 355 or 335+k > 445)))
