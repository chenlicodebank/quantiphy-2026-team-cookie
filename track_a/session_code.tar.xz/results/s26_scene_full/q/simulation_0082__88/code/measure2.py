import av, numpy as np, cv2
# Half-max edge extents using difference from the median background, frame 55 (car near image centre)
bg = cv2.imread('scene/scripts/bg.png')[..., ::-1].astype(float)
print('bg shape', bg.shape)
if bg.shape[:2] != (1080, 1920):
    bg = cv2.resize(bg, (1920, 1080))
def edges(p, thr):
    idx = np.where(p > thr)[0]
    a, b = idx.min(), idx.max()
    # sub-pixel interpolation
    lo = a - 1 + (thr - p[a-1]) / (p[a] - p[a-1])
    hi = b + (p[b] - thr) / (p[b] - p[b+1])
    return lo, hi
c = av.open('simulation_0082.mp4')
for i, fr in enumerate(c.decode(video=0)):
    if i not in (40, 50, 55, 60): continue
    img = fr.to_ndarray(format='rgb24').astype(float)
    hsv = cv2.cvtColor(img.astype(np.uint8), cv2.COLOR_RGB2HSV).astype(float)
    S = hsv[..., 1]
    d = np.abs(img - bg).max(2)
    # length: max over core rows of difference along x
    for y in (390, 401, 412):
        p = d[y, 600:1400]
        lo, hi = edges(p, 40)
        print(i, 'row', y, 'x edges', lo+600, hi+600, 'len', hi-lo)
    # width: saturation profile along columns in rear/middle body (avoid mirrors near front)
    x0 = int(np.where(d[401, :] > 40)[0].min())
    ws = []
    for x in range(x0 + 170, x0 + 285, 10):
        p = S[320:480, x]
        lo, hi = edges(p, 60)
        ws.append(hi - lo)
        if x == x0 + 220:
            print('   col', x, 'y edges', lo+320, hi+320)
    print('   widths (sat half-max)', np.round(ws, 1), 'median', np.median(ws))
