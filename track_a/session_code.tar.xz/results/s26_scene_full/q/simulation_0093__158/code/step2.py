import av, numpy as np, cv2
want = {2, 6, 11, 12, 18}
fr = {}
with av.open('simulation_0093.mp4') as c:
    for i, f in enumerate(c.decode(video=0)):
        if i in want: fr[i] = f.to_ndarray(format='rgb24').astype(np.float32)
        if i > 18: break
bg = np.array([80, 81, 88], np.float32)
P = lambda i: np.abs(fr[i][360:560] - bg).max(axis=2)
def sh(b, s): return cv2.warpAffine(b, np.float32([[1, 0, s], [0, 1, 0]]), (b.shape[1], b.shape[0]), flags=cv2.INTER_LINEAR)
def est(i, j):
    a, b = P(i), P(j); n = j - i
    ss = np.arange(-42 * n, -38 * n, 0.05)
    e = [np.mean((sh(a, s)[:, 40:1880] - b[:, 40:1880]) ** 2) for s in ss]
    k = int(np.argmin(e)); return round(ss[k], 2), round(ss[k] / n, 3)
for p in [(11, 12), (2, 18), (6, 18), (2, 11)]: print(p, est(*p))
