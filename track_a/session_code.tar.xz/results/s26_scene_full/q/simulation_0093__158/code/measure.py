import av, numpy as np
import cv2
def ndshift(b, sh, order=1):
    M=np.float32([[1,0,sh[1]],[0,1,sh[0]]]); return cv2.warpAffine(b,M,(b.shape[1],b.shape[0]),flags=cv2.INTER_LINEAR)

frames = {}
want = set(range(0, 20))
with av.open('simulation_0093.mp4') as c:
    for i, f in enumerate(c.decode(video=0)):
        if i in want:
            frames[i] = f.to_ndarray(format='rgb24').astype(np.float32)
        if i > max(want):
            break
bg = np.array([80, 81, 88], np.float32)

def car_extent(img, thr):
    sub = img[580:660, 700:1500]
    d = np.abs(sub - bg).max(axis=2)
    cols = np.where((d > thr).sum(axis=0) >= 2)[0]
    return cols.min() + 700, cols.max() + 700

for i in [0, 6, 11, 12, 13, 18]:
    out = []
    for thr in (12, 18, 30, 50):
        x0, x1 = car_extent(frames[i], thr)
        out.append((thr, x0, x1, x1 - x0 + 1))
    print('car', i, out)

# subpixel car length at frame 12: half-max crossings of row-max profile
def subpix_len(img):
    sub = img[595:645, 1000:1300]
    d = np.abs(sub - bg).max(axis=2)
    prof = d.max(axis=0)
    peak = np.median(prof[prof > 0.5 * prof.max()])
    h = peak / 2
    idx = np.where(prof > h)[0]
    a, b = idx.min(), idx.max()
    l = a - 1 + (h - prof[a - 1]) / (prof[a] - prof[a - 1])
    r = b + (prof[b] - h) / (prof[b] - prof[b + 1])
    return l + 1000, r + 1000, r - l
print('car halfmax f12', subpix_len(frames[12]))

# plane step by 1D cross-correlation of the tail region (x range in frame i) vs frame i-1
def plane_profile(img):
    sub = img[360:560, :]
    return np.abs(sub - bg).max(axis=2)

def step(i):
    a = plane_profile(frames[i - 1]); b = plane_profile(frames[i])
    best = None
    for s in np.arange(-44, -36, 0.25):
        bs = ndshift(b, (0, -s), order=1)  # move b back by s
        e = np.mean((a[:, 300:1400] - bs[:, 300:1400]) ** 2)
        if best is None or e < best[1]:
            best = (s, e)
    return best[0]
for i in [10, 11, 12, 13, 14]:
    print('plane step', i, step(i))
