import av, numpy as np
c = av.open('/private/tmp/qp_blind/scene_full_a/simulation_0092/q_154/simulation_0092.mp4')
want = (20, 22, 23, 24, 25, 26, 36, 60)
fr = {}
for i, f in enumerate(c.decode(video=0)):
    if i in want:
        fr[i] = f.to_ndarray(format='rgb24').astype(np.int16)
# background: median of frames where car is far apart
bg = np.median(np.stack([fr[20], fr[36], fr[60]]), axis=0)
res = {}
for i in (22, 23, 24, 25, 26):
    d = np.abs(fr[i] - bg).sum(2)[590:] > 12
    cols = np.where(d.sum(0) > 2)[0]
    rows = np.where(d.sum(1) > 2)[0]
    res[i] = (cols.min() + cols.max()) / 2
    print(i, cols.min(), cols.max(), cols.max() - cols.min() + 1, res[i], rows.min() + 590, rows.max() + 590)
for i in (23, 24, 25, 26):
    print('step', i, res[i - 1] - res[i])
