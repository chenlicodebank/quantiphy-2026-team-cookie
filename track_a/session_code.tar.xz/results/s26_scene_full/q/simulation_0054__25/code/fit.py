import csv,numpy as np
r=list(csv.DictReader(open('scene/tracks/orange_car.csv')))
f=np.array([int(x['frame']) for x in r])
for key in ['cy_bbox','y0','y1','cy_mask']:
    y=np.array([float(x[key]) for x in r])
    for a,b in [(16,90),(16,50),(50,90),(30,70),(40,90),(0,90)]:
        m=(f>=a)&(f<=b)
        if a==0 and key!='y1': continue
        p=np.polyfit(f[m],y[m],2); res=y[m]-np.polyval(p,f[m])
        print(key,a,b,'acc px/f2=%.4f v0=%.3f rms=%.2f'%(2*p[0],p[1],res.std()))
    m=(f>=16)
    p3=np.polyfit(f[m],y[m],3);print(key,'cubic',p3)
