import av, numpy as np, csv
# per frame: dark-shoe blobs of the walker (ground level) vs head blob
W = {int(r['frame']): r for r in csv.DictReader(open('scene/tracks/walker.csv'))}
c = av.open('simulation_0079.mp4')
out = []
for i, fr in enumerate(c.decode(video=0)):
    img = fr.to_ndarray(format='rgb24').astype(int)
    r = W[i]
    x0, x1 = int(r['bbox_x0']) - 10, int(r['bbox_x1']) + 10
    y0, y1 = int(r['bbox_y0']) - 10, int(r['bbox_y1']) + 10
    sub = img[max(y0, 0):y1, max(x0, 0):min(x1, 1920)]
    g = sub.mean(2)
    hx = float(r['head_x']) - max(x0, 0); hy = float(r['head_y']) - max(y0, 0)
    yy, xx = np.mgrid[0:sub.shape[0], 0:sub.shape[1]]
    m = (g < 45) & (np.hypot(xx - hx, yy - hy) > 35)
    if m.sum() < 20:
        continue
    import cv2
    n, lab, st, cen = cv2.connectedComponentsWithStats(m.astype(np.uint8))
    sizes = st[1:, 4]
    keep = np.argsort(sizes)[::-1][:2]
    pts = [(cen[k + 1][0] + max(x0, 0), cen[k + 1][1] + max(y0, 0)) for k in keep if sizes[k] > 30]
    out.append((i, float(r['head_x']), float(r['head_y']), pts))
    print(i, r['head_x'], r['head_y'], [(round(a, 1), round(b, 1)) for a, b in pts], [int(sizes[k]) for k in keep])
