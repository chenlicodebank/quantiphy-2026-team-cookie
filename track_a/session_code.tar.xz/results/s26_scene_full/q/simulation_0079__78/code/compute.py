import numpy as np
# frame 24 (t=1.0 s, 24 fps)
bike = np.array([647.0, 648.0])          # midpoint of front/back tips (443, 851), verified on frame
head = np.array([1574.4, 433.6])         # walker hair blob, verified on frame
c = np.array([960.0, 540.0])
H = 28.0                                  # camera height (m) from rider-vs-bike parallax slope 0.032 px/px
# pelvis (~1.0 m) below head (~1.65 m): undo radial perspective shift
pelvis = c + (head - c) * (H - 1.65) / (H - 1.0)
L_px = 412.0                              # bike tip-to-tip length (px), 1.7 m
d_px = np.linalg.norm(pelvis - bike)
print('pelvis px', pelvis.round(1), 'pixel dist', round(d_px, 1), '2D answer', round(d_px * 1.7 / L_px, 3))
k_bike = L_px / 1.7                       # px per m at bike-tip height (~0.35 m)
k = lambda h: k_bike * (H - 0.35) / (H - h)
P = (pelvis - c) / k(1.0); B = (bike - c) / k(0.35)
hd = np.linalg.norm(P - B)
print('horizontal world', round(hd, 3), '3D (bike origin at 0.35 m)', round(np.hypot(hd, 0.65), 3),
      '3D (bike origin at ground)', round(np.hypot(hd, 1.0), 3))
