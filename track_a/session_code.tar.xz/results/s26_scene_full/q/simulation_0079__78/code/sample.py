import av, numpy as np
c = av.open('/private/tmp/qp_blind/scene_full_b/simulation_0079/q_78/simulation_0079.mp4')
for i, fr in enumerate(c.decode(video=0)):
    if i == 24:
        img = fr.to_ndarray(format='rgb24').astype(int)
        break
for name, (x, y) in dict(shoe=(1412, 418), shoe2=(1425, 420), rearshoe=(1615, 455), hair=(1574, 433), jeans=(1490, 420),
                         jeans2=(1470, 425), floor=(1300, 300), shirt=(1560, 480), jacket=(680, 640), riderhair=(630, 655)).items():
    print(name, img[y - 2:y + 3, x - 2:x + 3].reshape(-1, 3).mean(0).round())
