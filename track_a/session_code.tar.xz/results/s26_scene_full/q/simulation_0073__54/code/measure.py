import av, numpy as np, cv2, csv
# Template-match the van and the cyclist (vertical motion only) across all frames, subpixel y.
frames = []
c = av.open('simulation_0073.mp4')
for f in c.decode(video=0):
    g = f.to_ndarray(format='gray')
    frames.append(g[:, 700:1000].astype(np.float32))  # narrow strip of the vertical road
c.close()
N = len(frames)

def rows(name):
    return list(csv.DictReader(open('scene/tracks/%s.csv' % name)))

def track(name, ref, pad):
    r = rows(name)
    a = r[ref]
    x0, y0, x1, y1 = [int(float(a[k])) for k in ('bbox_x0', 'bbox_y0', 'bbox_x1', 'bbox_y1')]
    x0 -= 700 + pad; x1 -= 700 - pad; y0 -= pad; y1 += pad
    tpl = frames[ref][y0:y1 + 1, x0:x1 + 1]
    out = []
    for i in range(N):
        cy = float(r[i]['cy_px']); cy0 = float(a['cy_px'])
        guess = int(round(y0 + cy - cy0))
        s0 = max(0, guess - 30); s1 = min(frames[i].shape[0], guess + tpl.shape[0] + 30)
        sx0 = max(0, x0 - 10); sx1 = x1 + 11
        res = cv2.matchTemplate(frames[i][s0:s1, sx0:sx1], tpl, cv2.TM_CCOEFF_NORMED)
        _, mv, _, ml = cv2.minMaxLoc(res)
        yy, xx = ml[1], ml[0]
        dy = 0.0
        if 0 < yy < res.shape[0] - 1:
            l, m, h = res[yy - 1, xx], res[yy, xx], res[yy + 1, xx]
            dy = 0.5 * (l - h) / (l - 2 * m + h)
        out.append((s0 + yy + dy) - y0)  # offset vs ref frame
    return np.array(out), mv

van, _ = track('van', 24, 6)
cyc, _ = track('cyclist', 36, 6)
np.save('tm.npy', np.vstack([van, cyc]))
print('van dy', np.round(np.diff(van), 2).tolist())
print('cyc dy', np.round(np.diff(cyc), 2).tolist())
