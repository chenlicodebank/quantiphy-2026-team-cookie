import numpy as np
xs=np.load('front.npy'); s=xs[:-1]-xs[1:]; f=np.arange(1,len(xs))
for lo,hi in [(3,56),(15,56),(25,47)]:
    m=(f>=lo)&(f<=hi); p=np.polyfit(f[m],s[m],1)
    v36=np.polyval(p,36); print(lo,hi,'a_px',p[0],'zero-speed frame',-p[1]/p[0],'step36',v36,'v=',v36/p[0]*4.03/24)
