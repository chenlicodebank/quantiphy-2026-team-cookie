import av, numpy as np
c=av.open('simulation_0086.mp4'); fr=[]
for f in c.decode(video=0):
    g=f.to_ndarray(format='gray').astype(np.float32); fr.append(g[545:760].copy())
bg=fr[71]
xs=[]
for i in range(0,57):
    d=np.abs(fr[i]-bg)
    m=d>30
    cols=np.where(m.sum(0)>20)[0]
    x0=cols.min()
    prof=d.sum(0)
    full=np.median(prof[x0+10:x0+40])
    seg=prof[max(x0-5,0):x0+15]
    off=max(x0-5,0)
    j=np.where(seg>=full/2)[0][0]
    a,b=seg[j-1],seg[j]
    xe=off+j-1+(full/2-a)/(b-a)
    xs.append(xe)
xs=np.array(xs); np.save('front.npy',xs)
for i,x in enumerate(xs): print(i,round(x,2), round(xs[i-1]-x,2) if i else '')
f=np.arange(len(xs))
for lo,hi in [(4,55),(10,50),(20,52),(26,46)]:
    p=np.polyfit(f[lo:hi+1],xs[lo:hi+1],2); print(lo,hi,p, 'a_px=',2*p[0],'t0=',-p[1]/(2*p[0]))
    a=-2*p[0]
    step36=np.polyval(p,35)-np.polyval(p,36)
    print('  step36 px',step36,' v=',step36/a*4.03/24)
