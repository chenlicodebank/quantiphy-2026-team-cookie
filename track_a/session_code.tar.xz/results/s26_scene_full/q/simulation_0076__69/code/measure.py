import csv, os, numpy as np
D = os.path.dirname(os.path.abspath(__file__))
def L(n):
    r = list(csv.DictReader(open(os.path.join(D, 'scene/tracks/%s.csv' % n))))
    return {k: np.array([float(x[k]) for x in r]) for k in r[0]}
b = L('man_black_shirt'); w = L('man_white_shirt')
print(list(b.keys()))
for k in [('head_x', 'head_y'), ('cx', 'cy'), ('pelvis_est_x', 'pelvis_est_y')]:
    pb = np.c_[b[k[0]], b[k[1]]]; pw = np.c_[w[k[0]], w[k[1]]]
    sb = np.linalg.norm(np.diff(pb, axis=0), axis=1)
    vb = np.linalg.norm(pb[71] - pb[2]) / 69
    vb2 = np.linalg.norm(pb[60] - pb[12]) / 48
    d = np.linalg.norm(pb - pw, axis=1)
    print(k, 'meanstep %.2f net %.2f %.2f' % (sb[1:].mean(), vb, vb2),
          'd48 %.1f' % d[48], np.round(d[44:53], 1),
          'ans net %.3f meanstep %.3f' % (d[48] / (vb * 24), d[48] / (sb[1:].mean() * 24)))
    print('  dx48', pb[48] - pw[48])
