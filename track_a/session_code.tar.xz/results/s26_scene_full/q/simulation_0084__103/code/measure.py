import av, numpy as np, cv2
c = av.open('simulation_0084.mp4')
frames = {}
for i, f in enumerate(c.decode(video=0)):
    if i in (24, 36, 48):
        frames[i] = f.to_ndarray(format='rgb24')
    if i > 48: break
for i, img in frames.items():
    hsv = cv2.cvtColor(img, cv2.COLOR_RGB2HSV)
    g = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY).astype(int)
    m = (g < 113) | (g > 176) | (hsv[..., 1] > 40)
    sub = m[420:620]
    ys, xs = np.nonzero(sub[:, 1200:1800]); xs += 1200; ys += 420
    print('frame', i, 'x', xs.min(), xs.max(), 'y', ys.min(), ys.max())
    # per-column y extent along car
    ext = []
    for x in range(xs.min() + 5, xs.max() - 5, 10):
        col = np.nonzero(m[420:620, x])[0] + 420
        ext.append((x, col.min(), col.max(), col.max() - col.min() + 1))
    for e in ext: print(e)
    # speed from front bumper
c.close()
