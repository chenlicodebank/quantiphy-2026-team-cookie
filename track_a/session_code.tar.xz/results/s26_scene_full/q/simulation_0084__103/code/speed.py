import numpy as np, csv
r = list(csv.DictReader(open('scene/tracks/yellow_car.csv')))
f = np.array([int(x['frame']) for x in r])
x0 = np.array([float(x['bbox_x0']) for x in r])
x1 = np.array([float(x['bbox_x1']) for x in r])
s = f >= 2
print('front slope px/frame', np.polyfit(f[s], x0[s], 1)[0])
s2 = f >= 12
print('rear slope px/frame', np.polyfit(f[s2], x1[s2], 1)[0])
print('lengths', np.unique(x1[s2] - x0[s2] + 1, return_counts=True))
