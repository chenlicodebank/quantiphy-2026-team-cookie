import csv, numpy as np, av

# 1) quadratic fits on the scene record (car bbox centre x)
r = list(csv.DictReader(open('scene/tracks/car.csv')))
f = np.array([int(x['frame']) for x in r]); x = np.array([float(x['ref_x']) for x in r])
for lo, hi in [(1, 40), (2, 40), (1, 25), (10, 40), (1, 15)]:
    m = (f >= lo) & (f <= hi); p = np.polyfit(f[m], x[m], 2); res = x[m] - np.polyval(p, f[m])
    print('record', lo, hi, 'a px/f^2=%.4f' % (2 * p[0]), 'vertex %.2f' % (-p[1] / (2 * p[0])), 'rms %.2f' % res.std())

# 2) own measurement: sub-pixel bumper edges and intensity-weighted centroid of |frame-bg| in car band
frames = []
with av.open('simulation_0096.mp4') as c:
    for fr in c.decode(video=0):
        frames.append(fr.to_ndarray(format='rgb24')[560:640].astype(np.float32))
bg = frames[40].copy(); bg[:, 800:1000] = frames[0][:, 800:1000]
cx = []; L = []; R = []
for i, F in enumerate(frames):
    d = np.abs(F - bg).max(axis=2)
    d[d < 18] = 0
    col = d.sum(axis=0)
    xs = np.arange(col.size)
    w = col > 0.5 * col.max() * 0.1
    idx = np.where(col > 200)[0]
    cx.append((col * xs).sum() / col.sum())
    L.append(idx.min()); R.append(idx.max())
cx = np.array(cx); L = np.array(L); R = np.array(R)
mid = (L + R) / 2
fr = np.arange(len(cx))
for name, y in [('centroid', cx), ('edgemid', mid), ('L', L), ('R', R)]:
    for lo, hi in [(1, 40), (2, 40), (10, 40)]:
        m = (fr >= lo) & (fr <= hi); p = np.polyfit(fr[m], y[m], 2); res = y[m] - np.polyval(p, fr[m])
        print(name, lo, hi, 'a=%.4f' % (2 * p[0]), 'vertex %.2f' % (-p[1] / (2 * p[0])), 'rms %.2f' % res.std())
print('length px', np.median((R - L + 1)[:15]))
