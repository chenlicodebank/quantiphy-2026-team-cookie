import numpy as np, av

frames_car = []; frames_pl = []
with av.open('simulation_0096.mp4') as c:
    for fr in c.decode(video=0):
        a = fr.to_ndarray(format='rgb24')
        frames_car.append(a[570:640].astype(np.float32))
        frames_pl.append(a[270:530].astype(np.float32))
# car background: frame 40 with its car region (x 530-680) patched from frame 0
bg = frames_car[40].copy(); bg[:, 520:690] = frames_car[0][:, 520:690]
L = []; R = []; C = []
for F in frames_car:
    d = np.abs(F - bg).max(axis=2)
    col = (d > 18).sum(axis=0).astype(float)
    idx = np.where(col >= 3)[0]
    l, r = idx.min(), idx.max()
    # sub-pixel edge: interpolate at half of plateau-ish level using fractional coverage of edge column
    L.append(l); R.append(r)
    w = d.copy(); w[w < 18] = 0
    cs = w.sum(axis=0); xs = np.arange(cs.size)
    C.append((cs * xs).sum() / cs.sum())
L = np.array(L, float); R = np.array(R, float); C = np.array(C); mid = (L + R) / 2
fr = np.arange(41)
print('length px (frames 0-15):', np.median(R[:16] - L[:16] + 1))
for name, y in [('edgemid', mid), ('L', L), ('R', R), ('centroid', C)]:
    for lo, hi in [(1, 40), (1, 20), (15, 40)]:
        m = (fr >= lo) & (fr <= hi); p = np.polyfit(fr[m], y[m], 2); res = y[m] - np.polyval(p, fr[m])
        print(name, lo, hi, 'a=%.4f px/f^2' % (2 * p[0]), 'vertex %.2f' % (-p[1] / (2 * p[0])), 'rms %.2f' % res.std())

# plane: tail edge x0 and (frames 0-10) nose edge x1
bgp = frames_pl[40]
X0 = []; X1 = []
for F in frames_pl[:26]:
    d = np.abs(F - bgp).max(axis=2)
    idx = np.where((d > 18).sum(axis=0) >= 3)[0]
    X0.append(idx.min()); X1.append(idx.max())
X0 = np.array(X0, float); X1 = np.array(X1, float)
print('plane x0', X0.astype(int).tolist())
print('plane x1', X1.astype(int).tolist())
m = np.arange(26) >= 1
p = np.polyfit(np.arange(1, 26), X0[1:], 1); print('plane tail-edge speed px/f %.3f' % p[0])
p = np.polyfit(np.arange(1, 11), X1[1:11], 1); print('plane nose-edge speed px/f %.3f' % p[0])
print('frame7 backward diff tail %.1f nose %.1f' % (X0[7] - X0[6], X1[7] - X1[6]))
