import csv,numpy as np
r=list(csv.DictReader(open('scene/tracks/car.csv')))
f=np.array([int(x['frame']) for x in r]);g=lambda k:np.array([float(x[k]) for x in r])
cx,cy=g('cx'),g('cy');fx,fy,rx,ry=g('front_x'),g('front_y'),g('rear_x'),g('rear_y')
bx0,bx1=g('bbox_x0'),g('bbox_x1')
print('bbox len frames 62-71',(bx1-bx0)[62:72], np.mean((bx1-bx0)[64:72]))
L=np.mean(g('length_px')[2:]);print('L',L)
for nm,(X,Y) in {'centroid':(cx,cy),'front':(fx,fy),'rear':(rx,ry),'mid':((fx+rx)/2,(fy+ry)/2)}.items():
  for a,b in [(52,68),(56,64),(55,71)]:
    s=slice(a,b+1);px=np.polyfit(f[s],X[s],2);py=np.polyfit(f[s],Y[s],2)
    vx=np.polyval(np.polyder(px),59.5);vy=np.polyval(np.polyder(py),59.5)
    v=np.hypot(vx,vy);print(nm,a,b,round(v,3),'px/f',round(v/L*5.44*24,3),'m/s')
st=np.hypot(np.diff(cx),np.diff(cy));print('mean step 3-71',st[2:].mean())
print('mean step 50-70',st[50:70].mean())
for a in range(2,72,10): print(a, st[a-1:a+9].mean())
