import av, numpy as np, cv2
# per-frame horizontal shift of the car by 1D/2D cross-correlation between consecutive frames
c = av.open('simulation_0087.mp4')
frames = []
for fr in c.decode(video=0):
    g = fr.to_ndarray(format='gray').astype(np.float32)
    frames.append(g[560:820].copy())   # car band only
c.close()
N = len(frames)
def shift(a, b, x0, x1, maxs=60):
    # find s such that b(x) ~ a(x+s) ; car moves left so s>0 means moved left by s
    A = a - 140; B = b - 140
    best = None; scores = []
    ss = np.arange(0, maxs + 1)
    for s in ss:
        lo = max(x0, 0); hi = min(x1, 1920 - s)
        sc = -np.mean((B[:, lo:hi] - A[:, lo + s:hi + s]) ** 2)
        scores.append(sc)
    scores = np.array(scores); k = int(np.argmax(scores))
    if 0 < k < len(ss) - 1:
        y0, y1, y2 = scores[k - 1], scores[k], scores[k + 1]
        off = 0.5 * (y0 - y2) / (y0 - 2 * y1 + y2)
    else:
        off = 0
    return ss[k] + off
import csv
r = list(csv.DictReader(open('scene/tracks/car.csv')))
x0s = [int(x['x0']) for x in r]; x1s = [int(x['x1']) for x in r]
out = []
for i in range(1, N):
    # region of car in frame i (destination), with margin
    lo = x0s[i] - 20; hi = min(x1s[i] + 20, 1920)
    s = shift(frames[i - 1], frames[i], lo, hi - 0)
    out.append((i, s))
    print(i, round(s, 3))
np.savetxt('shifts.txt', np.array(out), fmt='%.4f')
