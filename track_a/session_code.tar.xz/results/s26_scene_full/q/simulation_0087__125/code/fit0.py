import csv, numpy as np
r=list(csv.DictReader(open('scene/tracks/car.csv')))
f=np.array([int(x['frame']) for x in r]); x0=np.array([float(x['x0']) for x in r]); x1=np.array([float(x['x1']) for x in r])
for lo,hi in [(2,53),(5,53),(10,53),(20,53),(30,53),(2,25)]:
    m=(f>=lo)&(f<=hi); p=np.polyfit(f[m],x0[m],2); res=x0[m]-np.polyval(p,f[m])
    print(lo,hi,'a=',2*p[0],'f where v=0:',-p[1]/(2*p[0]),'rms',res.std())
m=f>=37; p=np.polyfit(f[m],x1[m],2); print('x1 a',2*p[0])
p=np.polyfit(f[m],x0[m],2); print('x0 37+ a',2*p[0])
