import numpy as np
d = np.loadtxt('shifts.txt'); i = d[:, 0]; s = d[:, 1]
for lo, hi in [(2, 48), (2, 30), (20, 48), (2, 53), (10, 45)]:
    m = (i >= lo) & (i <= hi); p = np.polyfit(i[m], s[m], 1)
    print(lo, hi, 'a px/f^2 =', p[0], 'v=0 at frame', -p[1] / p[0], 'rms', np.std(s[m] - np.polyval(p, i[m])))
a = np.polyfit(i[(i >= 2) & (i <= 48)], s[(i >= 2) & (i <= 48)], 1)[0]
apx = a * 24 * 24
mpp = 4.03 / apx
print('a px/s^2', apx, 'm/px', mpp)
for L in [583, 586, 588, 589, 577]:
    print(L, L * mpp)
