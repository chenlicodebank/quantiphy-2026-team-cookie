import av, numpy as np
c = av.open('simulation_0087.mp4')
want = {37, 41, 45, 49, 53}
for k, fr in enumerate(c.decode(video=0)):
    if k not in want: continue
    g = fr.to_ndarray(format='gray').astype(np.float32)
    band = g[600:780]
    dev = np.abs(band - 140)
    prof = np.percentile(dev, 99, axis=0)
    xs = np.where(prof > 30)[0]
    x0, x1 = xs[0], xs[-1]
    def sub(p, i, lvl, step):
        a, b = p[i - step], p[i]
        return i - step * (b - lvl) / (b - a)
    out = []
    for lvl in (15, 30, 60):
        l = np.where(prof > lvl)[0]
        L0 = sub(prof, l[0], lvl, 1); L1 = sub(prof, l[-1], lvl, -1)
        out.append((lvl, round(L0, 1), round(L1, 1), round(L1 - L0, 1)))
    print(k, out)
    print('  front', np.round(prof[x0 - 6:x0 + 10]).astype(int))
    print('  rear ', np.round(prof[x1 - 10:x1 + 6]).astype(int))
c.close()
