import csv, numpy as np, os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
def rd(n):
    return list(csv.DictReader(open(f'scene/tracks/{n}.csv')))
for n in ['eagle', 'crow']:
    r = rd(n)
    f = np.array([int(x['frame']) for x in r])
    te = np.array([float(x['tail_end_x']) for x in r])
    cx = np.array([float(x['cx_bbox']) for x in r])
    h = np.array([float(x['head_tip_x']) for x in r])
    for i in range(1, len(f)):
        print(n, f[i], te[i]-te[i-1], cx[i]-cx[i-1], h[i]-h[i-1])
