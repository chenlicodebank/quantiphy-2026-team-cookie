# Independent check: mask per frame, components, subpixel-ish motion via cross-correlation of column profiles.
import av, numpy as np, cv2, os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
bg = np.array([97, 149, 191], float)
prof = {}
c = av.open('simulation_0088.mp4')
for i, fr in enumerate(c.decode(video=0)):
    im = fr.to_ndarray(format='rgb24').astype(float)
    m = (np.abs(im - bg).sum(2) > 40).astype(np.uint8)
    n, lab, st, cen = cv2.connectedComponentsWithStats(m)
    comps = [(st[k, cv2.CC_STAT_WIDTH], st[k, cv2.CC_STAT_LEFT], k) for k in range(1, n) if st[k, cv2.CC_STAT_AREA] > 300]
    out = []
    for w, x0, k in sorted(comps, reverse=True):
        colsum = (lab == k).sum(0).astype(float)
        out.append((w, x0, x0 + w - 1, (colsum * np.arange(len(colsum))).sum() / colsum.sum()))
    prof[i] = out
    print(i, [(int(a), int(b), int(cc), round(d, 1)) for a, b, cc, d in out])
c.close()
# eagle = widest, crow = second, frames 2..14 both fully visible
e = [prof[i][0][2] for i in range(2, 15)]
cr = [prof[i][1][2] for i in range(2, 15)]
se = (e[-1] - e[0]) / 12; sc = (cr[-1] - cr[0]) / 12
print('tail-end steps f2-14: eagle', se, 'crow', sc)
print('crow speed =', 17.98 * sc / se)
