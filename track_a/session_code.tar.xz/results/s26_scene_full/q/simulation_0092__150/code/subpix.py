import av, numpy as np
# sub-pixel extents of the car near image centre. Background = median of every 4th frame (car moves, so it drops out).
# Each edge: per-line diff profile, crossing at half of that line's local plateau contrast (handles dark wheels vs white body).
want = set(range(28, 46))
stack, frames = [], {}
c = av.open('simulation_0092.mp4')
for i, f in enumerate(c.decode(video=0)):
    a = f.to_ndarray(format='rgb24')[600:720].astype(np.float32)
    if i % 4 == 0: stack.append(a)
    if i in want: frames[i] = a
c.close()
bg = np.median(np.stack(stack), axis=0)

def first_cross(p):
    # p: profile starting outside object; returns sub-pixel index of half-plateau crossing
    p = np.asarray(p, float)
    k = np.argmax(p > 12)
    plateau = p[k:k + 4].max()
    h = plateau / 2
    j = np.argmax(p > h)
    return j - 1 + (h - p[j - 1]) / (p[j] - p[j - 1])

res = []
for i in sorted(want):
    d = np.abs(frames[i] - bg).max(axis=2)
    m = d > 12
    ys, xs = np.where(m)
    x0, x1, y0, y1 = xs.min(), xs.max(), ys.min(), ys.max()
    # top: for each column take crossing from above, take min over columns
    tops = [first_cross(d[:, x]) for x in range(x0 + 2, x1 - 1) if m[:, x].any()]
    bots = [len(d) - 1 - first_cross(d[::-1, x]) for x in range(x0 + 2, x1 - 1) if m[:, x].any()]
    lefts = [first_cross(d[y, :]) for y in range(y0 + 2, y1 - 1) if m[y, :].any()]
    rights = [d.shape[1] - 1 - first_cross(d[y, ::-1]) for y in range(y0 + 2, y1 - 1) if m[y, :].any()]
    top, bot = min(tops), max(bots)
    left, right = min(lefts), max(rights)
    H = bot - top; L = right - left
    res.append((L, H))
    print(i, round(left, 2), round(right, 2), round(L, 2), round(top + 600, 2), round(bot + 600, 2), round(H, 2), round(H / L * 5.67, 3))
r = np.array(res)
print('median L %.2f median H %.2f height m %.3f' % (np.median(r[:, 0]), np.median(r[:, 1]), np.median(r[:, 1] / r[:, 0]) * 5.67))
