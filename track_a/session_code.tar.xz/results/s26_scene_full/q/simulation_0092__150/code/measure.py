import av, numpy as np
fr = []
c = av.open('simulation_0092.mp4')
for i, f in enumerate(c.decode(video=0)):
    if i % 4 == 0 or i in range(3, 66, 3):
        fr.append((i, f.to_ndarray(format='rgb24')[560:760].astype(np.int16)))
c.close()
bg = np.median(np.stack([a for i, a in fr if i % 4 == 0]), axis=0)
import cv2
for i, a in fr:
    if not (3 <= i <= 65): continue
    m = np.abs(a - bg).max(axis=2) > 12
    m = cv2.morphologyEx(m.astype(np.uint8), cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    n, lab, st, _ = cv2.connectedComponentsWithStats(m)
    if n < 2: continue
    k = 1 + np.argmax(st[1:, 4])
    ys, xs = np.where(lab == k)
    L = xs.max() - xs.min() + 1; H = ys.max() - ys.min() + 1
    print(i, xs.min(), xs.max(), ys.min() + 560, ys.max() + 560, L, H, round(H / L * 5.67, 3))
