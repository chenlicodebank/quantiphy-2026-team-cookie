import av, numpy as np, cv2
V = '/private/tmp/qp_blind/scene_full_b/simulation_0075/q_65/simulation_0075.mp4'
want = {0, 36, 60, 71}
fr = {}
with av.open(V) as c:
    for i, f in enumerate(c.decode(video=0)):
        if i in want:
            fr[i] = f.to_ndarray(format='rgb24').astype(int)
        if i > max(want):
            break
road = np.array([168, 168, 168])

def profile(img, x0, x1, y0, y1, axis, thr):
    sub = img[y0:y1, x0:x1]
    d = np.abs(sub - np.median(img[300:500, 640:760].reshape(-1, 3), axis=0)).max(axis=2)
    m = (d > thr)
    # sum along the other axis; extents where count > some fraction
    return m, d

# green car: column profile across rows (width = vertical extent since car is horizontal)
g = fr[0]
print('road colour', np.median(g[300:500, 640:760].reshape(-1, 3), axis=0))
for thr in (12, 18, 22, 25, 30):
    m, d = profile(g, 330, 540, 540, 660, 0, thr)
    m8 = cv2.morphologyEx(m.astype(np.uint8), cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    n, lab, st, _ = cv2.connectedComponentsWithStats(m8)
    k = 1 + np.argmax(st[1:, 4])
    mm = lab == k
    rows = np.where(mm.any(1))[0]; cols = np.where(mm.any(0))[0]
    # robust: width from columns in middle of car: per-column vertical extent
    ext = [np.ptp(np.where(mm[:, c])[0]) + 1 for c in range(cols[0] + 30, cols[-1] - 30) if mm[:, c].any()]
    print('green thr', thr, 'bbox x', cols[0] + 330, cols[-1] + 330, 'y', rows[0] + 540, rows[-1] + 540,
          'h', rows[-1] - rows[0] + 1, 'len', cols[-1] - cols[0] + 1, 'median col ext', np.median(ext), 'p90', np.percentile(ext, 90))
# green-hue mask only (body paint)
r, gg, b = g[..., 0], g[..., 1], g[..., 2]
gm = (gg - r > 25) & (gg - b > 5)
sub = gm[540:660, 320:560]
rows = np.where(sub.sum(1) > 5)[0]; cols = np.where(sub.sum(0) > 3)[0]
print('green paint rows', rows[0] + 540, rows[-1] + 540, 'h', rows[-1] - rows[0] + 1, 'cols', cols[0] + 320, cols[-1] + 320)
# per-column vertical extent profile of paint
for c in range(340, 530, 15):
    ys = np.where(gm[540:660, c])[0]
    if len(ys): print(' col', c, ys[0] + 540, ys[-1] + 540, ys[-1] - ys[0] + 1)

# van length (vertical) at frames 36,60,71
for i in (36, 60, 71):
    img = fr[i]
    for thr in (18, 25, 35):
        d = np.abs(img - np.median(img[300:500, 640:760].reshape(-1, 3), axis=0)).max(axis=2)
        sub = (d[0:1080, 770:900] > thr).astype(np.uint8)
        sub = cv2.morphologyEx(sub, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
        n, lab, st, _ = cv2.connectedComponentsWithStats(sub)
        k = 1 + np.argmax(st[1:, 4])
        mm = lab == k
        rows = np.where(mm.any(1))[0]; cols = np.where(mm.any(0))[0]
        ext = [np.ptp(np.where(mm[r_])[0]) + 1 for r_ in range(rows[0] + 30, rows[-1] - 30)]
        print('van f', i, 'thr', thr, 'y', rows[0], rows[-1], 'len', rows[-1] - rows[0] + 1, 'x', cols[0] + 770, cols[-1] + 770, 'median row width', np.median(ext))
