import av, numpy as np, cv2
c = av.open('/private/tmp/qp_blind/scene_full_b/simulation_0091/q_147/simulation_0091.mp4')
fr = []
for f in c.decode(video=0):
    fr.append(f.to_ndarray(format='rgb24').astype(np.int16))
bg = np.median(np.stack([fr[i] for i in (14, 18, 22, 26, 29)]), 0)
for i in range(0, 12):
    d = np.sqrt(((fr[i] - bg) ** 2).sum(2))
    m = cv2.morphologyEx((d > 15).astype(np.uint8), cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    n, lab = cv2.connectedComponents(m)
    out = []
    for k in range(1, n):
        ys, xs = np.nonzero(lab == k)
        if len(xs) < 50:
            continue
        band = np.abs(ys - 590) < 12
        out.append((int(xs.min()), int(xs.max()),
                    int(xs[band].min()) if band.any() else -1,
                    int(xs[band].max()) if band.any() else -1,
                    round(float(ys.mean()), 1), len(xs)))
    print(i, sorted(out))
