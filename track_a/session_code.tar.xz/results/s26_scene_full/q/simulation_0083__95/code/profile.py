import av, numpy as np
cont = av.open('simulation_0083.mp4')
for i, f in enumerate(cont.decode(video=0)):
    if i == 24:
        im = f.to_ndarray(format='rgb24').astype(int); break
for x in [520, 560, 575, 600, 650, 700, 715, 730, 750]:
    col = im[345:490, x]
    print('x', x)
    print('  ', ' '.join('%d:%d,%d,%d' % (345 + k, *col[k]) for k in range(0, len(col), 1) if k % 2 == 0))
