import av, numpy as np
cont = av.open('simulation_0083.mp4')
frames = {}
want = {0, 6, 12, 18, 24, 30, 36, 42, 48, 54, 60, 66, 71}
for i, f in enumerate(cont.decode(video=0)):
    if i in want:
        frames[i] = f.to_ndarray(format='rgb24').astype(int)
bg = np.median(np.stack([frames[k] for k in sorted(frames)]), axis=0)  # cars move far; median ok-ish
import csv
rows = list(csv.DictReader(open('scene/tracks/yellow_car.csv')))
for fi in [24, 30, 36, 42]:
    im = frames[fi]
    r = rows[fi]
    x0, x1 = int(r['bbox_x0']), int(r['bbox_x1'])
    sub = im[340:490, x0-5:x1+6]
    b = bg[340:490, x0-5:x1+6]
    d = np.abs(sub - b).sum(2)
    yel = (sub[..., 0] - sub[..., 2]) > 30
    m = (d > 45) | yel
    # per-column extent
    ext = []
    for c in range(m.shape[1]):
        ys = np.nonzero(m[:, c])[0]
        ext.append((ys.max() - ys.min() + 1, ys.min() + 340, ys.max() + 340) if len(ys) else (0, 0, 0))
    ext = np.array(ext)
    L = x1 - x0 + 1
    print('frame', fi, 'x', x0, x1, 'L', L)
    for c in range(0, m.shape[1], 6):
        print('  x=%d  w=%d  y=%d..%d' % (x0 - 5 + c, *ext[c]))
    # yellow-only extent per column
    ey = [ (np.nonzero(yel[:, c])[0]) for c in range(m.shape[1])]
    wy = [ (e.max()-e.min()+1) if len(e) else 0 for e in ey]
    print('  yellow-only widths median', np.median([w for w in wy if w > 0]), 'max', max(wy))
