import av, numpy as np, csv
rows = list(csv.DictReader(open('scene/tracks/yellow_car.csv')))
cont = av.open('simulation_0083.mp4')
want = [18, 20, 24, 28, 30, 34]
res = {}
for i, f in enumerate(cont.decode(video=0)):
    if i not in want:
        continue
    im = f.to_ndarray(format='rgb24').astype(int)
    r = rows[i]; x0, x1 = int(r['bbox_x0']), int(r['bbox_x1'])
    sub = im[340:495, x0:x1 + 1]
    g = sub.mean(2)
    car = ((sub[..., 0] - sub[..., 2]) > 40) | (g < 118)
    tops, bots = [], []
    for c in range(sub.shape[1]):
        ys = np.nonzero(car[:, c])[0]
        if len(ys) == 0:
            tops.append(np.nan); bots.append(np.nan); continue
        tops.append(ys.min() + 340); bots.append(ys.max() + 340)
    tops = np.array(tops); bots = np.array(bots); w = bots - tops + 1
    L = x1 - x0 + 1
    # sub-pixel edges at mid-body columns via half-threshold on chroma/gray contrast
    rel = np.arange(len(w)) / L
    mid = (rel > 0.35) & (rel < 0.95)
    print(i, 'L', L, 'max w (mirrors)', np.nanmax(w),
          'mid-body w median', np.nanmedian(w[mid]), 'p10-p90', np.nanpercentile(w[mid], [10, 90]),
          'top med', np.nanmedian(tops[mid]), 'bot med', np.nanmedian(bots[mid]))
    # columns where wheels: bottom extends
    print('   bottom profile (every 10 col):', [int(b) if b == b else -1 for b in bots[::10]])
    print('   top profile    (every 10 col):', [int(b) if b == b else -1 for b in tops[::10]])
