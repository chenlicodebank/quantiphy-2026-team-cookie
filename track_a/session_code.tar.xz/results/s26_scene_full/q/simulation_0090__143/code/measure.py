import av, numpy as np, cv2
frames = []
with av.open('simulation_0090.mp4') as c:
    for f in c.decode(video=0):
        frames.append(cv2.resize(f.to_ndarray(format='bgr24'), (960, 540)).astype(np.int16))
bg = np.median(np.stack(frames[24:30]), axis=0)
def boxes(i):
    m = (np.abs(frames[i] - bg).sum(2) > 20).astype(np.uint8)
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((3, 3), np.uint8))
    n, lab, st, cen = cv2.connectedComponentsWithStats(m)
    out = [(st[k], cen[k]) for k in range(1, n) if st[k][4] > 100]
    return sorted(out, key=lambda s: s[0][0])
res = {}
for i in range(2, 19):
    b = boxes(i)
    res[i] = [(2*(s[0] + s[2]/2), 2*s[0], 2*(s[0]+s[2])) for s, _ in b]
    print(i, [(round(2*(s[0]+s[2]/2), 1), 2*s[0], 2*(s[1]+s[3]/2)) for s, _ in b])
# crow = rightmost component; speed from x0 and x-centre frames 3..12
cr = {i: res[i][-1] for i in range(3, 19)}
v_x0 = (cr[3][1] - cr[12][1]) / 9
v_c = (cr[3][0] - cr[12][0]) / 9
print('crow px/frame x0', v_x0, 'centre', v_c)
