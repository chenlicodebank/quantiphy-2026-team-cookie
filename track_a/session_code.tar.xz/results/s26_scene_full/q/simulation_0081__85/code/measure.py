import av, numpy as np, cv2, os
os.makedirs('frames', exist_ok=True)
frames = []
c = av.open('simulation_0081.mp4')
for i, f in enumerate(c.decode(video=0)):
    img = f.to_ndarray(format='bgr24')
    frames.append(img[540:760].copy())  # bike band only
c.close()
H = []
for i, img in enumerate(frames):
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    m = (hsv[..., 0] >= 80) & (hsv[..., 0] <= 105) & (hsv[..., 1] > 60)
    m = m.astype(np.uint8)
    n, lab, st, cen = cv2.connectedComponentsWithStats(m)
    keep = np.zeros_like(m)
    for k in range(1, n):
        if st[k, 4] > 30: keep[lab == k] = 1
    ys, xs = np.nonzero(keep)
    x0, x1 = xs.min(), xs.max()
    H.append((i, x0, x1, x1 - x0 + 1, (x0 + x1) / 2, xs.mean()))
    if i == 12:
        ov = img.copy(); ov[keep > 0] = (0, 0, 255)
        cv2.line(ov, (x0, 0), (x0, 219), (0, 255, 0), 1); cv2.line(ov, (x1, 0), (x1, 219), (0, 255, 0), 1)
        cv2.imwrite('frames/ov12.png', ov[:, max(0, x0 - 60):x1 + 60])
for h in H: print(h)
# phase correlation of grey band, frame-to-frame shifts
g = [cv2.cvtColor(f, cv2.COLOR_BGR2GRAY).astype(np.float32) for f in frames]
for i in range(9, 16):
    a, b = g[i - 1], g[i]
    # search shift by SSD over bike region
    cx = int(H[i - 1][4]); half = 230
    pa = a[:, cx - half:cx + half]
    best = None
    for s in range(-55, -38):
        pb = b[:, cx - half + s:cx + half + s]
        e = np.mean((pa - pb) ** 2)
        if best is None or e < best[1]: best = (s, e)
    print('frame', i, 'SSD shift', best)
