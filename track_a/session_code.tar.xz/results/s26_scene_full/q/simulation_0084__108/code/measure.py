import av, numpy as np, cv2
c = av.open('/private/tmp/qp_blind/scene_full_b/simulation_0084/q_108/simulation_0084.mp4')
for i, f in enumerate(c.decode(video=0)):
    if i not in (12, 20, 22, 23, 24, 25, 36, 48, 60, 71):
        continue
    im = f.to_ndarray(format='rgb24')
    g = cv2.cvtColor(im, cv2.COLOR_RGB2GRAY)
    s = cv2.cvtColor(im, cv2.COLOR_RGB2HSV)[..., 1]
    m = (g < 113) | (g > 176) | (s > 40)
    out = []
    for (y0, y1) in [(480, 570), (600, 685)]:
        cols = np.where(m[y0:y1].sum(0) > 3)[0]
        out.append((int(cols.min()), int(cols.max()), int(cols.max() - cols.min() + 1), (cols.min() + cols.max()) / 2))
    print(i, 'yellow', out[0], 'dark', out[1])
