import av, numpy as np, cv2
def frame(i):
    c = av.open('simulation_0082.mp4')
    for k, f in enumerate(c.decode(video=0)):
        if k == i:
            a = f.to_ndarray(format='rgb24'); c.close(); return a
for i in [0, 24, 40, 55]:
    a = frame(i).astype(int)
    mn, mx = a.min(2), a.max(2)
    hsv = cv2.cvtColor(a.astype(np.uint8), cv2.COLOR_RGB2HSV)
    m = (mn < 100) | (mx > 172) | (hsv[..., 1] > 50)
    out = {}
    for name, (r0, r1) in {'yellow': (375, 430), 'white': (515, 580)}.items():
        cols = np.where(m[r0:r1].sum(0) > 3)[0]
        # largest contiguous run
        runs = np.split(cols, np.where(np.diff(cols) > 5)[0] + 1)
        r = max(runs, key=len)
        x0, x1 = r[0], r[-1]
        out[name] = (x0, x1, (x0 + x1) / 2, x1 - x0 + 1)
    y, w = out['yellow'], out['white']
    dx = y[2] - w[2]; dy = 401.5 - 539.5
    print(i, out, 'dx', dx, 'dist_px', np.hypot(dx, dy))
