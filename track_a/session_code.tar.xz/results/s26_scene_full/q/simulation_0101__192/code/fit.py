import csv, numpy as np
def load(n):
    r=list(csv.DictReader(open(f'scene/tracks/{n}.csv')))
    return {k:np.array([float(x[k]) if x[k] not in ('',None) else np.nan for x in r]) for k in r[0]}
s=load('shark'); b=load('boat')
print(list(s.keys())); print(list(b.keys()))
f=s['frame']; t=f/24
for key in ['centroid_x','bbox_cx','nose_x','tail_x']:
    if key not in s: continue
    m=f>=2
    for lo,hi in [(2,72),(2,36),(36,72),(1,72)]:
        m=(f>=lo)&(f<=hi)
        p=np.polyfit(t[m],s[key][m],2)
        res=s[key][m]-np.polyval(p,t[m])
        print(key,lo,hi,'acc px/s2',2*p[0],'v0',p[1],'rms',res.std())
dx=np.diff(s['centroid_x'])
print('shark dx',np.round(dx,1))
bx=b['bow_x']; db=np.diff(bx)
print('boat dx',db)
for lo,hi in [(2,72),(10,40),(20,30)]:
    m=(f>=lo)&(f<=hi)
    print('boat lin',lo,hi,np.polyfit(t[m],bx[m],1), np.polyfit(t[m],bx[m],2))
print('boat step at 24:',bx[24]-bx[23])
