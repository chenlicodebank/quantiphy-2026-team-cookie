import av, numpy as np, cv2
c = av.open('simulation_0068.mp4')
frames = []
for i, fr in enumerate(c.decode(video=0)):
    g = cv2.cvtColor(fr.to_ndarray(format='rgb24'), cv2.COLOR_RGB2GRAY).astype(np.float32)
    frames.append(g[:, 760:905].copy())
T = frames[0][795:1060]  # van in frame 0 (with margin), rows 795-1059
ys = []
for g in frames:
    r = cv2.matchTemplate(g, T, cv2.TM_CCOEFF_NORMED)[:, 0]
    k = int(np.argmax(r))
    d = 0.0
    if 0 < k < len(r)-1:
        d = 0.5*(r[k-1]-r[k+1])/(r[k-1]-2*r[k]+r[k+1])
    ys.append(k + d)
ys = np.array(ys); f = np.arange(len(ys)); t = f/24
for lo, hi in [(4,71),(10,71),(4,40),(40,71),(20,60)]:
    m = (f>=lo)&(f<=hi); p = np.polyfit(t[m], ys[m], 2)
    print(lo, hi, 'a=%.2f rms=%.2f' % (2*p[0], (ys[m]-np.polyval(p,t[m])).std()))
print('steps', np.round(np.diff(ys), 2))
# full length profile at frame 0: column-avg of |gray - road| along x 800-862
g = frames[0]
road = np.median(g[600:700, 40:100])
prof = np.abs(g[:, 45:100] - road).mean(axis=1)
idx = np.where(prof > 0.5*prof[850:1000].max())[0]
print('road', road, 'body rows >50%:', idx.min(), idx.max(), idx.max()-idx.min()+1)
for y in range(795, 815): print(y, round(prof[y],1))
for y in range(1035, 1055): print(y, round(prof[y],1))
