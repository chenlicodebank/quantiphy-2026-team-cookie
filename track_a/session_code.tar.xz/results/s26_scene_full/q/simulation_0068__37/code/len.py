import av, numpy as np, cv2
# full-length (bumper to rear) of van on several frames, centre columns, gradient extrema
c = av.open('simulation_0068.mp4')
for i, fr in enumerate(c.decode(video=0)):
    if i not in (0, 1, 5, 10): continue
    g = cv2.cvtColor(fr.to_ndarray(format='rgb24'), cv2.COLOR_RGB2GRAY).astype(float)
    p = g[:, 815:848].mean(axis=1)
    d = np.diff(p)
    yc = int(np.argmax(p[700:1100])) + 700
    # front: search a 40 px window above the white body start for strongest |gradient| (bumper outer edge)
    wb = np.where(p[:yc] < 215)[0][-1]  # last non-white row above body
    seg = slice(wb-30, wb+1)
    print(i, 'white body start', wb+1, 'profile above:', np.round(p[wb-20:wb+2]).astype(int))
    rear = np.where(p[yc:] < (p[yc]+171)/2)[0][0] + yc
    print('   rear half-level row', rear)
