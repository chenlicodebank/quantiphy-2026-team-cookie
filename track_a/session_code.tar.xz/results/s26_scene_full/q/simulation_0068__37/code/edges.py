import av, numpy as np
# independent route: white-body mask in a strip around the van (x 795-867), per-frame top/bottom edges (subpixel via row fill fraction)
c = av.open('simulation_0068.mp4')
tops, bots, fs = [], [], []
for i, fr in enumerate(c.decode(video=0)):
    img = fr.to_ndarray(format='rgb24').astype(float)
    strip = img[:, 800:862]
    bright = strip.min(axis=2)  # white => all channels high
    sat = strip.max(axis=2) - strip.min(axis=2)
    m = (bright > 215) & (sat < 25)
    frac = m.mean(axis=1)
    rows = np.where(frac > 0.5)[0]
    # largest contiguous run
    runs = np.split(rows, np.where(np.diff(rows) > 15)[0] + 1)
    r = max(runs, key=len)
    y0, y1 = r[0], r[-1]
    # subpixel: add partial fractions of neighbouring rows
    top = y0 - frac[y0-1] if y0 > 0 else y0
    bot = y1 + 1 + frac[y1+1]
    tops.append(top); bots.append(bot); fs.append(i)
f = np.array(fs); t = f/24; tops = np.array(tops); bots = np.array(bots)
print('lengths (white run) frames 0,20,40,60,71:', [(round(bots[k]-tops[k],1)) for k in [0,20,40,60,71]])
mid = (tops+bots)/2
for name, y in [('top', tops), ('bot', bots), ('mid', mid)]:
    for lo, hi in [(4,71),(10,71),(4,40),(40,71)]:
        m = (f>=lo)&(f<=hi); p = np.polyfit(t[m], y[m], 2)
        print(name, lo, hi, 'a=%.2f rms=%.2f' % (2*p[0], (y[m]-np.polyval(p,t[m])).std()))
