import numpy as np, csv
rows = list(csv.DictReader(open('scene/tracks/van.csv')))
f = np.array([int(r['frame']) for r in rows]); t = f/24.0
for key in ['ccy', 'cy', 'my', 'cbbox_y0', 'cbbox_y1', 'bbox_y0']:
    y = np.array([float(r[key]) for r in rows])
    for lo, hi in [(4, 71), (10, 71), (20, 71), (4, 40), (40, 71)]:
        m = (f >= lo) & (f <= hi)
        p = np.polyfit(t[m], y[m], 2)
        res = y[m] - np.polyval(p, t[m])
        print(key, lo, hi, 'a_px=%.2f' % (2*p[0]), 'rms=%.2f' % res.std())
    # also cubic check
    m = f >= 4
    p3 = np.polyfit(t[m], y[m], 3); print(key, 'cubic coeffs', p3)
for key in ['clength', 'length']:
    v = np.array([float(r[key]) for r in rows]); print(key, np.median(v), v.min(), v.max())
