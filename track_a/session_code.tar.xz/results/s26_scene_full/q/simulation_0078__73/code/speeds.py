import csv, numpy as np
def load(n):
    rows = list(csv.DictReader(open(f'scene/tracks/{n}.csv')))
    return rows
for n in ['person_A_dark_shirt', 'person_B_white_shirt']:
    r = load(n)
    print(n, list(r[0].keys()))
    f = np.array([int(float(x['frame'])) for x in r])
    for key in ['pelvis_est_x', 'head_x', 'shirt_cx', 'mask_cx']:
        v = np.array([float(x[key]) if x[key] not in ('', 'nan') else np.nan for x in r])
        ok = ~np.isnan(v)
        ff, vv = f[ok], v[ok]
        # fit linear over valid full-body frames
        sel = ff >= (6 if 'A' in n else 17)
        p = np.polyfit(ff[sel], vv[sel], 1)
        print(f'  {key}: slope {p[0]:.3f} px/frame  range {ff[sel].min()}-{ff[sel].max()}')
    # pelvis y
    y = np.array([float(x['pelvis_est_y']) if x['pelvis_est_y'] not in ('', 'nan') else np.nan for x in r])
    x = np.array([float(x['pelvis_est_x']) if x['pelvis_est_x'] not in ('', 'nan') else np.nan for x in r])
    d = np.hypot(np.diff(x), np.diff(y))
    print('  per-frame pelvis speed', np.round(d, 1))
    print('  frames', f)
