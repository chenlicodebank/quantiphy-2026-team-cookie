import csv,numpy as np
r=list(csv.DictReader(open('scene/tracks/cyclist.csv')))
for x in r[4:33]:
    print(x['frame'],x['bike_center_x'],x['bike_len_px'])
w=list(csv.DictReader(open('scene/tracks/walker.csv')))
h=np.array([float(x['head_x']) for x in w]); s=np.array([float(x['shirt_x']) for x in w])
dh=-np.diff(h); ds=-np.diff(s)   # dh[i-1] = speed at frame i
for i in range(21,28): print(i,dh[i-1],ds[i-1])
print('3-frame mean at 24: head',dh[22:25].mean(),'shirt',ds[22:25].mean())
# same gait phase one cycle (34 frames) later: frame 58
print('frame 58 head/shirt',dh[57],ds[57], 'frame 41',dh[40],ds[40])
