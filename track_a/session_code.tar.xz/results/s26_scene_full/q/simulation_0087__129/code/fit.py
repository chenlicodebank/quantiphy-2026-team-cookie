import csv, numpy as np
r=list(csv.DictReader(open('scene/tracks/car.csv')))
f=np.array([int(x['frame']) for x in r]); x0=np.array([float(x['x0']) for x in r]); x1=np.array([float(x['x1']) for x in r])
for lo,hi in [(2,53),(5,53),(2,36),(10,40),(14,34)]:
    m=(f>=lo)&(f<=hi); p=np.polyfit(f[m],x0[m],2)
    a=2*p[0]; v24=np.polyval(np.polyder(p),24)  # px/frame instantaneous
    vb=np.polyval(p,24)-np.polyval(p,23)
    t0=-p[1]/(2*p[0])
    print(lo,hi,'a px/f2',a,'v24 inst',v24,'backdiff',vb,'t0 frame',t0,'res',np.std(x0[m]-np.polyval(p,f[m])))
    print('  speed m/s inst', 4.03*abs(v24)/(abs(a)*24), 'backdiff', 4.03*abs(vb)/(abs(a)*24))
m=f>=37; p=np.polyfit(f[m],x1[m],2); print('x1 fit a',2*p[0])
