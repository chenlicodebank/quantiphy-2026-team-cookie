import numpy as np
pos=np.load('pos_tm.npy'); n=np.arange(len(pos))
for lo,hi in [(17,53),(17,40),(20,50),(30,53)]:
    m=(n>=lo)&(n<=hi); p=np.polyfit(n[m],pos[m],2); a=2*p[0]
    vb=np.polyval(p,23)-np.polyval(p,24); vi=-np.polyval(np.polyder(p),24)
    print(lo,hi,'a',round(a,4),'t0 frame',round(-p[1]/(2*p[0]),3),'res',round(np.std(pos[m]-np.polyval(p,n[m])),3),
          'vback px/f',round(vb,3),'m/s',round(4.03*vb/(-a*24),4),'inst m/s',round(4.03*vi/(-a*24),4))
# steps vs frame: linear fit of step -> where step = 0
st=pos[:-1]-pos[1:]; k=np.arange(1,len(pos))
m=(k>=18)&(k<=53); q=np.polyfit(k[m],st[m],1); print('step fit slope',q[0],'zero at frame',-q[1]/q[0]+0.5,'step24',np.polyval(q,24))
