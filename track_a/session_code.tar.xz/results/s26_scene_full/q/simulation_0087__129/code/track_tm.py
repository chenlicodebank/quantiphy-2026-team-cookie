import av, numpy as np, cv2
# Template-match the car's front part (from frame 53) along x in every frame; subpixel by parabola.
fr=[]
c=av.open('simulation_0087.mp4')
for i,f in enumerate(c.decode(video=0)):
    g=f.to_ndarray(format='gray').astype(np.float32)
    fr.append(g[560:820].copy())
c.close()
ref=fr[53]
# front of car at f53: x0=813 ; take template x 800..1000 (front 190 px incl. some ground)
tx0,tx1=800,1000
tpl=ref[:,tx0:tx1]
pos=[]
for i,g in enumerate(fr):
    r=cv2.matchTemplate(g,tpl,cv2.TM_CCOEFF_NORMED)[0]
    k=int(np.argmax(r))
    if 0<k<len(r)-1:
        d=(r[k-1]-r[k+1])/(2*(r[k-1]-2*r[k]+r[k+1]))
    else: d=0
    pos.append(k+d)
    print(i, round(k+d,2), round(float(r[k]),3))
pos=np.array(pos)
np.save('pos_tm.npy',pos)
n=np.arange(len(pos))
for lo,hi in [(2,53),(2,40),(5,53),(10,53),(2,30)]:
    m=(n>=lo)&(n<=hi)
    p=np.polyfit(n[m],pos[m],2)
    print(lo,hi,'a',2*p[0],'t0',-p[1]/(2*p[0]),'res',np.std(pos[m]-np.polyval(p,n[m])))
st=np.diff(pos)
print('steps',np.round(st,2))
a=np.polyfit(n[2:],pos[2:],2)[0]*2
print('backdiff v24 from raw', (pos[23]-pos[24]), 'm/s', 4.03*(pos[23]-pos[24])/(abs(a)*24))
