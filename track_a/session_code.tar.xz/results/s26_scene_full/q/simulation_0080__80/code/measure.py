import av, numpy as np, cv2
c = av.open('simulation_0080.mp4')
frames = {}
for i, f in enumerate(c.decode(video=0)):
    if i in (0, 2, 5, 8, 10, 11, 12, 13, 14):
        frames[i] = f.to_ndarray(format='rgb24').astype(int)
bg = 151
for i in (0, 5, 10):
    im = frames[i]
    # cyan bike: B and G high relative to R
    r, g, b = im[..., 0], im[..., 1], im[..., 2]
    cyan = (b - r > 30) & (g - r > 25)
    cyan[:500] = False
    ys, xs = np.nonzero(cyan)
    # include dark rider? bike extent only along x
    lo, hi = np.percentile(xs, [0.1, 99.9])
    print('frame', i, 'cyan x', xs.min(), xs.max(), 'p', lo, hi, 'len', xs.max() - xs.min() + 1)
    # all non-floor in lower lane
    d = np.abs(im - bg).max(-1) > 28
    d[:520] = False; d[780:] = False
    ys, xs = np.nonzero(d)
    print('   nonfloor x', xs.min(), xs.max(), 'len', xs.max() - xs.min() + 1)
# walker torso: pale shirt brighter than floor
for i in (10, 11, 12, 13, 14):
    im = frames[i]
    lum = im.mean(-1)
    sat = im.max(-1) - im.min(-1)
    sh = (lum > 175) & (sat < 40)
    sh[:330] = False; sh[560:] = False
    n, lab, st, cen = cv2.connectedComponentsWithStats(sh.astype(np.uint8))
    k = 1 + np.argmax(st[1:, 4])
    x0, y0, w, h = st[k, :4]
    print('frame', i, 'shirt bbox', x0, x0 + w - 1, y0, y0 + h - 1, 'cx', x0 + (w - 1) / 2, 'centroid', cen[k])
