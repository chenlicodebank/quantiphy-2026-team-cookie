import av, numpy as np, cv2
c = av.open('simulation_0080.mp4')
xs_bb, xs_c = [], []
for i, f in enumerate(c.decode(video=0)):
    im = f.to_ndarray(format='rgb24').astype(int)
    if i == 12:
        print('px', im[460, 1060], im[420, 1080], im[380, 1050], im[350, 1000])
    lum = im.mean(-1); sat = im.max(-1) - im.min(-1)
    sh = (lum > 162) & (sat < 30); sh[:330] = False; sh[560:] = False
    sh = cv2.morphologyEx(sh.astype(np.uint8), cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    n, lab, st, cen = cv2.connectedComponentsWithStats(sh)
    if n < 2:
        print(i, 'none'); continue
    k = 1 + np.argmax(st[1:, 4]); x0, y0, w, h, a = st[k]
    xs_bb.append(x0 + (w - 1) / 2); xs_c.append(cen[k][0])
    print(i, x0, x0 + w - 1, y0, y0 + h - 1, a, 'bbcx', x0 + (w - 1) / 2, 'cen', cen[k].round(1))
print('bb steps', np.diff(xs_bb)); print('cen steps', np.diff(xs_c).round(2))
