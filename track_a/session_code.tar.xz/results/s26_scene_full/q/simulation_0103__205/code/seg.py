import av, numpy as np, cv2
# Own shark segmentation: difference from a per-row median background of the underwater area
cont = av.open('simulation_0103.mp4')
res = []
for i, fr in enumerate(cont.decode(video=0)):
    img = fr.to_ndarray(format='rgb24').astype(np.float32)
    roi = img[760:1060]                       # underwater band around shark
    bg = np.median(roi, axis=1, keepdims=True)  # per-row background colour
    d = np.linalg.norm(roi - bg, axis=2)
    for th in (12, 25):
        m = (d > th).astype(np.uint8)
        m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
        n, lab, st, cen = cv2.connectedComponentsWithStats(m)
        k = 1 + np.argmax(st[1:, cv2.CC_STAT_AREA])
        x0, y0, w, h, a = st[k]
        if th == 12:
            r = [i, x0, x0 + w - 1, w, y0 + 760, h, cen[k][0]]
            if i in (5, 24, 45):
                vis = img[760:1060].astype(np.uint8).copy()
                vis[lab == k] = (vis[lab == k] * 0.5 + np.array([255, 0, 0]) * 0.5).astype(np.uint8)
                cv2.imwrite('frames/mask_%02d.png' % i, cv2.cvtColor(vis, cv2.COLOR_RGB2BGR))
        else:
            r += [x0, x0 + w - 1, w, cen[k][0]]
    res.append(r)
res = np.array(res, float)
np.savetxt('shark_own.csv', res, fmt='%.2f', delimiter=',',
           header='frame,x0_12,x1_12,w_12,y0,h,cx_12,x0_25,x1_25,w_25,cx_25')
print('w12 median', np.median(res[:, 3]), 'w25 median', np.median(res[:, 9]))
t = res[:, 0] / 24
m = res[:, 0] >= 1
for col, name in [(6, 'cx12'), (10, 'cx25'), (1, 'x0_12'), (2, 'x1_12')]:
    c = np.polyfit(t[m], res[m, col], 2)
    print(name, 'acc %.2f' % (2 * c[0]), 'rms %.2f' % (res[m, col] - np.polyval(c, t[m])).std())
for i in (5, 24, 45): print(res[i])
