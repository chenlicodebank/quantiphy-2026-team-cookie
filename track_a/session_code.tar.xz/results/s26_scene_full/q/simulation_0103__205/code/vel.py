import numpy as np, csv
own = np.loadtxt('shark_own.csv', delimiter=',')
r = list(csv.DictReader(open('scene/tracks/shark.csv')))
series = {'rec_cx': np.array([float(x['cx']) for x in r]), 'own_cx25': own[:, 10], 'own_x1': own[:, 2]}
f = np.arange(54); t = f / 24
for n, x in series.items():
    v = np.diff(x) * 24          # speed at frame i (backward diff), i = 1..53
    fi = f[1:]
    for a, b in [(2, 53), (2, 20), (20, 37), (37, 53)]:
        m = (fi >= a) & (fi <= b)
        c = np.polyfit(fi[m] / 24, v[m], 1)
        print(n, a, b, 'acc %.1f' % c[0])
    # cubic fit check for non-constant acceleration
    m = f >= 1
    c3 = np.polyfit(t[m], x[m], 3)
    print(n, 'cubic jerk term', c3[0] * 6, 'acc at mid', 2 * c3[1] + 6 * c3[0] * t[m].mean())
