import csv, numpy as np
r = list(csv.DictReader(open('scene/tracks/shark.csv')))
f = np.array([int(x['frame']) for x in r]); t = f / 24.0
for key in ['cx', 'x0', 'x1', 'bbox_cx']:
    v = np.array([float(x[key]) for x in r])
    for a, b in [(1, 53), (2, 53), (1, 27), (27, 53)]:
        m = (f >= a) & (f <= b)
        c = np.polyfit(t[m], v[m], 2)
        res = v[m] - np.polyval(c, t[m])
        print(key, a, b, 'acc px/s2 = %.2f' % (2 * c[0]), 'v0=%.1f' % c[1], 'rms=%.2f' % res.std())
    # piecewise check: speed per frame
w = np.array([float(x['bbox_w']) for x in r])
print('bbox_w median', np.median(w), 'mean', w.mean())
