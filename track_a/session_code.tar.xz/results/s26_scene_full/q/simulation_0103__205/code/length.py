import av, numpy as np
# Snout tip: leftmost column where the snout rows (y 895-935) differ from background; tail tip: rightmost column in rows 860-960
cont = av.open('simulation_0103.mp4')
out = []
for i, fr in enumerate(cont.decode(video=0)):
    img = fr.to_ndarray(format='rgb24').astype(np.float32)
    roi = img[840:1000]
    bg = np.median(roi, axis=1, keepdims=True)
    d = np.linalg.norm(roi - bg, axis=2)
    snout = d[895 - 840:940 - 840]
    col = (snout > 15).sum(0)          # count of differing pixels per column
    cols = np.where(col >= 3)[0]
    # pick contiguous run containing the body (largest run)
    runs = np.split(cols, np.where(np.diff(cols) > 3)[0] + 1)
    run = max(runs, key=len)
    x0 = run[0]
    colall = (d > 15).sum(0)
    c2 = np.where(colall >= 2)[0]
    runs2 = np.split(c2, np.where(np.diff(c2) > 3)[0] + 1)
    run2 = max(runs2, key=len)
    x1 = run2[-1]
    out.append((i, x0, x1, x1 - x0 + 1))
out = np.array(out)
print(out[::4])
print('length median', np.median(out[:, 3]), 'p25/p75', np.percentile(out[:, 3], [25, 75]))
t = out[:, 0] / 24; m = out[:, 0] >= 1
for k, n in [(1, 'nose'), (2, 'tail')]:
    c = np.polyfit(t[m], out[m, k], 2); print(n, 'acc %.2f' % (2 * c[0]))
