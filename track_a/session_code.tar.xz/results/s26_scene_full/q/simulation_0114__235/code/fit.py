import csv, numpy as np
r = list(csv.DictReader(open('scene/tracks/plane.csv')))
f = np.array([int(float(x['frame'])) for x in r if x['ref_y']])
y = np.array([float(x['ref_y']) for x in r if x['ref_y']])
fps = 24.002401
for lo, hi in [(0, 75), (2, 40), (20, 60), (30, 42), (40, 75)]:
    m = (f >= lo) & (f <= hi); c = np.polyfit(f[m], y[m], 2)
    print(lo, hi, 'a px/fr2', 2*c[0], 'v0 frame', -c[1]/(2*c[0]), 'rms', np.std(y[m]-np.polyval(c, f[m])))
d = np.diff(y); print(list(zip(f[1:], d))[28:44])
m = (f >= 0) & (f <= 75); c = np.polyfit(f[m], y[m], 2); a = 2*c[0]
scale = 18/(a*fps**2); print('m/px', scale)
i = round(1.5*fps); print('i', i)
p = np.polyval(c, [i-1, i])
print('fit backward speed', (p[1]-p[0])*fps*scale, 'inst', np.polyval(np.polyder(c), i)*fps*scale)
print('raw diff', (y[f == i][0]-y[f == i-1][0])*fps*scale)
print('ideal from rest', 18*(i-0.5)/fps, 18*i/fps)
