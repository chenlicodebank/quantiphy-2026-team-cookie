import av, numpy as np, cv2
c = av.open('/private/tmp/qp_blind/scene_full_b/simulation_0079/q_77/simulation_0079.mp4')
res = {}
for i, f in enumerate(c.decode(video=0)):
    if i < 8 or i > 31:
        continue
    img = f.to_ndarray(format='bgr24')
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    band = hsv[540:760]
    m = (band[..., 1] > 60) & (band[..., 0] > 75) & (band[..., 0] < 105)
    m = cv2.morphologyEx(m.astype(np.uint8), cv2.MORPH_OPEN, np.ones((2, 2), np.uint8))
    cols = np.where(m.sum(0) >= 2)[0]
    x0, x1 = cols.min(), cols.max()
    res[i] = (x0, x1)
    print(i, x0, x1, x1 - x0 + 1, (x0 + x1) / 2)
ks = sorted(res)
cc = np.array([(res[k][0] + res[k][1]) / 2 for k in ks])
L = np.array([res[k][1] - res[k][0] + 1 for k in ks])
p = np.polyfit(ks, cc, 1)
print('fit px/frame', p[0])
j = ks.index(24)
print('diff at 24', cc[j] - cc[j - 1])
print('local fit 20-28', np.polyfit(ks[j-4:j+5], cc[j-4:j+5], 1)[0])
print('len 20-28 mean', L[j-4:j+5].mean(), 'all mean', L.mean())
