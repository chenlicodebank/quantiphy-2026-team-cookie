import csv
r = list(csv.DictReader(open('scene/tracks/car.csv')))
for a in r[::4] + [r[-1]]:
    print(a['frame'], a['ref_x'], a['len_px'], a['height_px'])
