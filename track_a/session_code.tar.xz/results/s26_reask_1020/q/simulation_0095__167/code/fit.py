import csv, numpy as np
r = list(csv.DictReader(open('scene/tracks/car.csv')))
print(list(r[0].keys()))
f = np.array([float(x['frame']) for x in r])
for key in ['mask_cx', 'ref_x']:
    x = np.array([float(a[key]) for a in r])
    for lo, hi in [(2, 71), (10, 71), (2, 40), (40, 71)]:
        m = (f >= lo) & (f <= hi)
        p = np.polyfit(f[m], x[m], 2)
        print(key, lo, hi, 'a px/fr2 %.4f px/s2 %.2f res %.3f' % (2*p[0], 2*p[0]*576, np.std(x[m]-np.polyval(p, f[m]))))
x = np.array([float(a['mask_cx']) for a in r]); v = np.diff(x)
print(np.round(v, 2))
L = np.array([float(a['len_px']) for a in r]); print('car len', L[:3], L.mean())
