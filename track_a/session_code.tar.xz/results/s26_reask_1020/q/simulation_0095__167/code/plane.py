import av, numpy as np, cv2
bg = np.array([132, 126, 135])
c = av.open('simulation_0095.mp4')
for i, fr in enumerate(c.decode(video=0)):
    if i > 16: break
    if i < 6: continue
    a = fr.to_ndarray(format='rgb24').astype(int)[:545]
    d = np.abs(a - bg).max(2)
    for th in (6, 15, 30):
        m = (d > th).astype(np.uint8)
        m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
        cols = np.where(m.sum(0) > 0)[0]; rows = np.where(m.sum(1) > 0)[0]
        print(i, th, cols.min(), cols.max(), cols.max()-cols.min()+1, rows.min(), rows.max())
    if i == 10:
        # fuselage axis row profile: columns per row near center
        m = (d > 6)
        r = 400
        cs = np.where(m[r])[0]; print('row400', cs.min(), cs.max())
