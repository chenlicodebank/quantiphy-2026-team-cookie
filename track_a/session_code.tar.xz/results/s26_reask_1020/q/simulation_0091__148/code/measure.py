import av, numpy as np, csv
# crow speed (px/frame) via mask x-profile shift + eagle length from frame 0 mask
fr = []
with av.open('simulation_0091.mp4') as c:
    for i, f in enumerate(c.decode(video=0)):
        if i > 26: break
        fr.append(f.to_ndarray(format='rgb24')[400:700].astype(np.int16))
bg = np.median(np.stack([fr[k] for k in (14, 18, 22, 26)]), axis=0)
masks = [np.sqrt(((x - bg) ** 2).sum(-1)) > 15 for x in fr]

def xs(m, lo, hi):
    cols = np.where(m[:, lo:hi].any(0))[0] + lo
    return cols
# eagle frame 0
m0 = masks[0]
e = xs(m0, 600, 900); print('eagle f0 x', e.min(), e.max(), e.max() - e.min() + 1)
cw = xs(m0, 1050, 1300); print('crow f0 x', cw.min(), cw.max(), cw.max() - cw.min() + 1)
# crow: front (beak tip, rightmost) and tail (leftmost) per frame, region x>950
prev = None
for i in range(0, 11):
    cols = xs(masks[i], 950, 1920)
    print(i, cols.min(), cols.max(), cols.max() - cols.min() + 1)
# crow shift via column profile cross-correlation frame i vs i-1 (frames 2..10)
sh = []
for i in range(3, 11):
    a = masks[i - 1][:, 950:].sum(0).astype(float); b = masks[i][:, 950:].sum(0).astype(float)
    cc = np.correlate(b, a, 'full'); k = np.argmax(cc) - (len(a) - 1)
    sh.append(k)
print('crow xcorr shifts 2->10', sh, np.mean(sh))
print('crow beak x per frame (rightmost)')
