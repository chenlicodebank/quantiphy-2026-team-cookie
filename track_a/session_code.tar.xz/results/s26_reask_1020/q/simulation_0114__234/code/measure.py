import av, numpy as np, cv2, csv, os
os.makedirs('frames', exist_ok=True)
# Own tracking: yellow mask (HSV), wing row (rows with >=100 px yellow), and frame-0 bbox.
cont = av.open('simulation_0114.mp4')
wing = {}; f0box = None
for i, fr in enumerate(cont.decode(video=0)):
    img = fr.to_ndarray(format='bgr24')
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    m = (hsv[..., 0] > 15) & (hsv[..., 0] < 40) & (hsv[..., 1] > 100) & (hsv[..., 2] > 120)
    m[:, :450] = False; m[:, 900:] = False
    if i == 0:
        ys, xs = np.nonzero(m)
        f0box = (xs.min(), ys.min(), xs.max(), ys.max())
        vis = img.copy(); vis[m] = (0, 0, 255)
        cv2.imwrite('frames/mask0.png', vis[50:300, 500:850])
    rows = np.nonzero(m.sum(1) >= 100)[0]
    if len(rows) and i <= 75:
        wing[i] = rows.mean()
print('frame0 bbox', f0box, 'w', f0box[2]-f0box[0]+1, 'h', f0box[3]-f0box[1]+1)
fr_ = np.array(sorted(wing)); y = np.array([wing[k] for k in fr_])
for lo, hi in [(0, 75), (2, 40), (30, 75), (10, 60)]:
    s = (fr_ >= lo) & (fr_ <= hi)
    c = np.polyfit(fr_[s], y[s], 2)
    print(lo, hi, 'a px/f2 =', 2*c[0], 'v0 zero at', -c[1]/(2*c[0]))
# scene ref_y
r = list(csv.DictReader(open('scene/tracks/plane.csv')))
F = np.array([int(x['frame']) for x in r if x['ref_y'] not in ('', 'nan')])
Y = np.array([float(x['ref_y']) for x in r if x['ref_y'] not in ('', 'nan')])
s = F <= 75
c = np.polyfit(F[s], Y[s], 2); print('scene ref_y a =', 2*c[0])
d = np.diff(Y[s]); dd = np.diff(d); print('mean 2nd diff', dd.mean(), 'speed slope', np.polyfit(F[s][1:], d, 1)[0])
