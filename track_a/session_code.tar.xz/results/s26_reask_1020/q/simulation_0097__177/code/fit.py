import numpy as np, csv
from scipy.optimize import curve_fit
r = list(csv.DictReader(open('scene/tracks/car.csv')))
f = np.array([float(x['frame']) for x in r]); x = np.array([float(x['cx_centroid']) for x in r])
for lo in [0, 1, 2, 5]:
    m = f >= lo; p = np.polyfit(f[m], x[m], 2); print(lo, p, 2*p[0], np.std(x[m]-np.polyval(p, f[m])))
v = np.diff(x); print(np.round(v, 2))
def g(f, x0, a, t0): return x0 - 0.5*a*np.clip(f-t0, 0, None)**2
p, _ = curve_fit(g, f, x, p0=[1474, 0.37, 1]); print('piecewise', p)
a = p[1]*24**2; s = 10/a; print('m/px', s, 'plane', 800*s, 'car', 121*s)
pa = list(csv.DictReader(open('scene/tracks/airplane.csv')))
L = [float(q['length_px']) for q in pa if q['cut_by_left_edge'] in ('0','False') and q['cut_by_right_edge'] in ('0','False')]
print('plane len px', np.median(L), min(L), max(L))
