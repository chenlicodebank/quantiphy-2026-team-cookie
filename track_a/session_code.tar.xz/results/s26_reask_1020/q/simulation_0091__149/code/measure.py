import av, numpy as np
from scipy import ndimage as ndi
fr = []
with av.open('simulation_0091.mp4') as c:
    for i, f in enumerate(c.decode(video=0)):
        if i <= 12 or i in (14, 18, 22, 26, 29):
            fr.append((i, f.to_ndarray(format='rgb24').astype(np.int16)))
d = dict(fr)
bg = np.median(np.stack([d[k] for k in (14, 18, 22, 26, 29)]), axis=0)
res = {}
for i in range(0, 12):
    diff = np.sqrt(((d[i] - bg) ** 2).sum(-1))
    for thr in (15, 30):
        m = diff > thr
        m[:, :1000] = False  # crow is right of x=1000 (eagle moves left)
        lab, n = ndi.label(m)
        if n == 0: continue
        sizes = ndi.sum(m, lab, range(1, n + 1))
        keep = np.isin(lab, 1 + np.where(sizes > 30)[0])
        ys, xs = np.nonzero(keep)
        # weighted centroid using darkness
        w = diff[ys, xs]
        print(i, thr, 'x', xs.min(), xs.max(), 'len', xs.max() - xs.min() + 1,
              'y', ys.min(), ys.max(), 'cx_w %.1f' % ((xs * w).sum() / w.sum()))
        if thr == 15: res[i] = (xs.min(), xs.max())
# per-frame motion of extent midpoint & edges
for i in range(2, 11):
    a, b = res[i - 1], res[i]
    print(i, 'dx left', b[0] - a[0], 'dx right', b[1] - a[1])
