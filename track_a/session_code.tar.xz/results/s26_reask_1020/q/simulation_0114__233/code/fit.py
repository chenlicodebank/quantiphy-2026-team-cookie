import csv, numpy as np, cv2
rows = list(csv.DictReader(open('scene/tracks/plane.csv')))
f = np.array([float(r['frame']) for r in rows if r['ref_y'] not in ('', 'nan')])
y = np.array([float(r['ref_y']) for r in rows if r['ref_y'] not in ('', 'nan')])
fps = 24.0
for lo, hi in [(0, 40), (0, 75), (20, 75), (2, 60)]:
    m = (f >= lo) & (f <= hi)
    c = np.polyfit(f[m], y[m], 2)
    a_px = 2 * c[0] * fps**2
    print(lo, hi, 'a px/s^2', a_px, 'v0 frame zero', -c[1] / (2 * c[0]))
# per-frame speed differences (convention)
d = np.diff(y)
acc = np.diff(d)
print('mean second diff (frames 2..74)', acc[2:73].mean(), acc[2:73].mean() * fps**2)
# wingspan at frame 0 from own mask
cap = cv2.VideoCapture('simulation_0114.mp4')
ok, fr = cap.read()
hsv = cv2.cvtColor(fr, cv2.COLOR_BGR2HSV)
mask = cv2.inRange(hsv, (15, 80, 120), (40, 255, 255))
n, lab, st, cen = cv2.connectedComponentsWithStats(mask)
i = 1 + np.argmax(st[1:, 4])
print('bbox', st[i])
sub = (lab == i)
cols = np.where(sub.any(0))[0]
rws = np.where(sub.any(1))[0]
print('x extent', cols.min(), cols.max(), cols.max() - cols.min() + 1, 'y extent', rws.max() - rws.min() + 1)
