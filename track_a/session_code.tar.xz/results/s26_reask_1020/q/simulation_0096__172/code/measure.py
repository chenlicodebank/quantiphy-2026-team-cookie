import numpy as np, cv2, av, csv
# Car: sub-pixel left/right edges of the car, rows 588-620, per frame.
# Plane: length from frames 0-10.
V = 'simulation_0096.mp4'
frames = []
c = av.open(V)
for fr in c.decode(video=0):
    frames.append(fr.to_ndarray(format='rgb24').astype(np.int16))
c.close()
bg = frames[40].copy()
bg[560:640, 530:680] = frames[0][560:640, 530:680]

def mask(i, y0, y1):
    d = np.abs(frames[i][y0:y1] - bg[y0:y1]).max(axis=2)
    return d

car = []
for i in range(41):
    d = mask(i, 580, 630)
    m = d > 18
    m = cv2.morphologyEx(m.astype(np.uint8), cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    cols = np.where(m.any(axis=0))[0]
    # keep largest run near the car
    area = m.sum()
    ys, xs = np.nonzero(m)
    w = d[ys, xs].astype(float)
    cx_w = (xs * w).sum() / w.sum()
    car.append((i, cols.min(), cols.max(), xs.mean(), cx_w, area))
car = np.array(car, float)
f = car[:, 0]
print('car per-frame:')
for r in car:
    print(' %2d x0=%d x1=%d cx=%.2f cxw=%.2f area=%d' % tuple(r))
for k, name in [(1, 'x0'), (2, 'x1'), (3, 'cx'), (4, 'cxw')]:
    x = car[:, k]; mid = (car[:, 1] + car[:, 2]) / 2
    for lo in [1, 2, 4]:
        m = f >= lo
        p = np.polyfit(f[m], x[m], 2)
        res = x[m] - np.polyval(p, f[m])
        print(name, lo, 'a=%.4f px/fr2 rms=%.2f vertex=%.2f' % (2 * p[0], res.std(), -p[1] / (2 * p[0])))
mid = (car[:, 1] + car[:, 2]) / 2
for lo in [1, 2, 4]:
    m = f >= lo
    p = np.polyfit(f[m], mid[m], 2)
    print('mid', lo, 'a=%.4f vertex=%.2f' % (2 * p[0], -p[1] / (2 * p[0])))
# fit with fixed start at rest at frame t0: x = x_start - a/2 (f-t0)^2 for f>=t0
from scipy.optimize import least_squares
for k in [3, 4]:
    x = car[:, k]
    def r(q):
        xs, a, t0 = q
        return x - (xs - 0.5 * a * np.clip(f - t0, 0, None) ** 2)
    s = least_squares(r, [x[0], 0.5, 1])
    print('rest-start fit col', k, s.x, 'rms', np.std(s.fun))
print('car length px (frames 0-12):', np.median(car[:13, 2] - car[:13, 1] + 1))

# plane length
L = []
for i in range(0, 11):
    d = mask(i, 250, 540)
    m = (d > 18).astype(np.uint8)
    m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    n, lab, st, _ = cv2.connectedComponentsWithStats(m)
    j = 1 + np.argmax(st[1:, 4])
    x0, y0, w, h, a = st[j]
    L.append((i, x0, x0 + w - 1, w, h))
    print('plane', i, x0, x0 + w - 1, w, h)
L = np.array(L)
print('plane length median px', np.median(L[:, 3]), 'height', np.median(L[:, 4]))
