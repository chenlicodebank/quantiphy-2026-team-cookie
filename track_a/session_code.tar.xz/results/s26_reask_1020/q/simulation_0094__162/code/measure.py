import csv, numpy as np, cv2, os
D = os.path.dirname(os.path.abspath(__file__))
def load(n):
    return list(csv.DictReader(open(f'{D}/scene/tracks/{n}.csv')))
c = load('car'); a = load('airplane')
f = np.array([int(r['frame']) for r in c])
def col(rows, k):
    return np.array([float(r[k]) if r[k] else np.nan for r in rows])
for k in ['origin_proxy_x', 'lead_edge_x', 'trail_edge_x']:
    x = col(c, k); m = ~np.isnan(x) & (f >= 11 if k == 'origin_proxy_x' else True)
    print('car', k, 'slope px/frame', np.polyfit(f[m], x[m], 1)[0])
fa = np.array([int(r['frame']) for r in a]); L = col(a, 'length_px'); cl = col(a, 'clipped_by_frame_edge')
print('plane lengths', list(zip(fa[cl == 0], L[cl == 0])))

# independent re-measure from video: masks by bg difference
cap = cv2.VideoCapture(f'{D}/simulation_0094.mp4')
bg = np.array([86, 79, 78], float)  # BGR
i = 0; car = {}; pl = {}
while True:
    ok, im = cap.read()
    if not ok: break
    d = np.abs(im.astype(float) - bg).max(2) > 20
    for name, sl, store in [('plane', slice(0, 590), pl), ('car', slice(590, 1080), car)]:
        sub = d[sl]
        cols = np.where(sub.sum(0) > 0)[0]
        if len(cols): store[i] = (cols.min(), cols.max())
    i += 1
fr = sorted(k for k in car if car[k][0] > 0 and car[k][1] < 1919)
x0 = np.array([car[k][0] for k in fr]); x1 = np.array([car[k][1] for k in fr])
print('car (re) rear slope', np.polyfit(fr, x0, 1)[0], 'front slope', np.polyfit(fr, x1, 1)[0])
print('car lengths', [(k, car[k][1] - car[k][0] + 1) for k in fr])
fp = sorted(k for k in pl if pl[k][0] > 0 and pl[k][1] < 1919)
print('plane lengths (re)', [(k, pl[k][1] - pl[k][0] + 1) for k in fp])
nose = sorted(k for k in pl if pl[k][0] > 0)
print('plane nose slope', np.polyfit(nose, [pl[k][0] for k in nose], 1)[0])
