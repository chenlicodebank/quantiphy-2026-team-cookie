import av, numpy as np
c = av.open('simulation_0090.mp4')
fr = [f.to_ndarray(format='rgb24').astype(np.int16)[450:760] for f in c.decode(video=0)]
bg = np.median(np.stack(fr[24:30]), axis=0)
res = {}
for i in range(2, 19):
    d = np.abs(fr[i] - bg).sum(2)
    for th in (20, 40):
        m = d > th
        cols = np.where(m.any(0))[0]
        # crow: rightmost blob region; eagle gone/left by then; restrict x to crow region from track
        res.setdefault(th, []).append((i, cols))
import csv
tr = {int(r['frame']): r for r in csv.DictReader(open('scene/tracks/crow.csv'))}
out = {}
for th in (20, 40):
    x0s, x1s, ws = [], [], []
    for i, cols in res[th]:
        a, b = int(tr[i]['x0']) - 15, int(tr[i]['x1']) + 15
        cc = cols[(cols >= a) & (cols <= b)]
        x0s.append(cc.min()); x1s.append(cc.max()); ws.append(cc.max() - cc.min() + 1)
    fr_ = np.arange(2, 19)
    v0 = np.polyfit(fr_, x0s, 1)[0]; v1 = np.polyfit(fr_, x1s, 1)[0]
    print(th, 'widths', ws, 'median', np.median(ws), 'vx0', v0, 'vx1', v1)
    v = abs((v0 + v1) / 2) * 24
    L = np.median(ws) * 11 / v
    print('  px/s', v, 'm/px', 11 / v, 'length m', L)
