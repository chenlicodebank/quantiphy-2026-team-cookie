import numpy as np, cv2, csv
V = '/private/tmp/qp_blind/s27_plaus_reask/simulation_0105/q_212/simulation_0105.mp4'
cap = cv2.VideoCapture(V)
frames = {}
i = 0
while True:
    ok, fr = cap.read()
    if not ok: break
    if i in (0, 5, 12, 20):
        frames[i] = cv2.cvtColor(fr, cv2.COLOR_BGR2GRAY).astype(float)
    i += 1
for k, g in frames.items():
    bg = np.median(g[600:900, 50:300])
    d = np.abs(g - bg)
    m = d > 12
    m[:900] = False
    ys, xs = np.nonzero(m)
    print('frame', k, 'bg', bg, 'cup+saucer bbox y', ys.min(), ys.max(), 'x', xs.min(), xs.max(), 'h', ys.max() - ys.min() + 1)
    # per-column profile in central column
    for thr in (6, 12, 25):
        mm = d > thr; mm[:900] = False
        rows = np.nonzero(mm.any(1))[0]
        print('  thr', thr, 'rows', rows.min(), rows.max())
    col = d[940:1080, 520:560].mean(1)
    print('  centre col diff by row:', ' '.join(f'{940+j}:{v:.0f}' for j, v in enumerate(col) if 965 <= 940 + j <= 980 or 1065 <= 940 + j <= 1079))

# gravity fit
r = list(csv.DictReader(open('/private/tmp/qp_blind/s27_plaus_reask/simulation_0105/q_212/scene/tracks/cube.csv')))
f = np.array([int(x['frame']) for x in r]); y = np.array([float(x['cy']) for x in r])
mk = f >= 22
t = f[mk] / 24.0
p = np.polyfit(t, y[mk], 2)
a = 2 * p[0]
print('a px/s2', a, 'rms', (y[mk] - np.polyval(p, t)).std())
for lo, hi in ((22, 33), (34, 45)):
    s = (f >= lo) & (f <= hi)
    pp = np.polyfit(f[s] / 24.0, y[s], 2); print('half', lo, hi, 2 * pp[0])
print('m/px', 9.8 / a)
