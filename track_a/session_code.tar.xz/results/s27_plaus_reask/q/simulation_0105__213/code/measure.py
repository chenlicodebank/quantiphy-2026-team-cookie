import numpy as np, csv, av
# gravity fit
rows = list(csv.DictReader(open('scene/tracks/cube.csv')))
f = np.array([int(r['frame']) for r in rows if r['occluded'] == '0'], float)
y = np.array([float(r['cy']) for r in rows if r['occluded'] == '0'])
y0 = np.array([float(r['bbox_y0']) for r in rows if r['occluded'] == '0'])
y1 = np.array([float(r['bbox_y1']) for r in rows if r['occluded'] == '0'])
t = f / 24.0
for name, yy in [('cy', y), ('y0', y0), ('y1', y1), ('mid', (y0 + y1) / 2)]:
    c = np.polyfit(t, yy, 2)
    res = yy - np.polyval(c, t)
    print(name, 'a_px=%.2f' % (2 * c[0]), 'rms=%.3f' % res.std())
for sl in [slice(0, 12), slice(12, 24)]:
    c = np.polyfit(t[sl], y[sl], 2); print('half a=%.2f' % (2 * c[0]))
a = 2 * np.polyfit(t, y, 2)[0]
mpp = 9.8 / a
print('m/px', mpp)

# saucer/cup extents
cont = av.open('simulation_0105.mp4')
for i, fr in enumerate(cont.decode(video=0)):
    if i in (0, 5, 12):
        g = fr.to_ndarray(format='gray').astype(float)
        bg = np.median(g[850:900, :])
        for yy in range(960, 1080, 4):
            row = g[yy]
            m = np.abs(row - bg) > 12
            xs = np.where(m)[0]
            if len(xs):
                print(i, yy, xs.min(), xs.max(), xs.max() - xs.min() + 1)
        # column extents over whole cup region
        m = np.abs(g[940:1080] - bg) > 12
        cols = np.where(m.any(0))[0]
        print('frame', i, 'overall x', cols.min(), cols.max(), cols.max() - cols.min() + 1)
