import numpy as np, av
cont = av.open('simulation_0105.mp4')
for i, fr in enumerate(cont.decode(video=0)):
    if i == 5:
        g = fr.to_ndarray(format='gray').astype(float); break
bg = np.median(g[850:900, :])
for yy in range(1052, 1062):
    row = g[yy]; d = np.abs(row - bg)
    L = d[440:470]; R = d[620:650]
    pk = max(L.max(), R.max()); half = pk / 2
    i0 = np.where(L > half)[0][0]
    xl_f = 440 + i0 - 1 + (half - L[i0 - 1]) / (L[i0] - L[i0 - 1])
    j0 = np.where(R > half)[0][-1]
    xr_f = 620 + j0 + (R[j0] - half) / (R[j0] - R[j0 + 1])
    print(yy, round(pk, 1), round(xl_f, 2), round(xr_f, 2), round(xr_f - xl_f, 2))
