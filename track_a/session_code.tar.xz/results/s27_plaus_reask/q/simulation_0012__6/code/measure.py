import csv, numpy as np
r = list(csv.DictReader(open('/private/tmp/qp_blind/s27_plaus_reask/simulation_0012/q_6/scene/tracks/bird.csv')))
f = np.array([int(d['frame']) for d in r])
bx = np.array([float(d['beak_x']) for d in r]); by = np.array([float(d['beak_y']) for d in r])
tx = np.array([float(d['tail_x']) for d in r])
L = np.array([float(d['length_px']) for d in r]); c = np.array([int(d['tail_shadow_contaminated']) for d in r])
# source-frame index: one dropped source frame before file frames 19 and 43 (double steps)
src = f + (f >= 19) + (f >= 43)
QF = 24.0
for a, b in [(20, 42), (28, 42), (20, 30), (31, 42)]:
    m = (f >= a) & (f <= b)
    pb = np.polyfit(src[m], bx[m], 1)[0]; pt = np.polyfit(src[m], tx[m], 1)[0]
    print(f'cruise {a}-{b}: beak {pb:.2f} px/frame  tail {pt:.2f}')
m = (f >= 20) & (f <= 42)
v = np.polyfit(src[m], bx[m], 1)[0] * QF
# also include 44-45 (before deceleration) with skip accounted
m2 = (f >= 19) & (f <= 45)
v2 = np.polyfit(src[m2], bx[m2], 1)[0] * QF
clean = (c == 0) & (L < 136) & (f < 46)
Lm = np.median(L[clean]); print('length median clean', Lm, 'mean', L[clean].mean(), 'n', clean.sum())
print('cruise speed px/s', v, v2)
print('body length (cruise prior) m', 6 * Lm / v, 6 * Lm / v2)
tot = np.sum(np.hypot(np.diff(bx), np.diff(by)))
net = bx[-1] - bx[0]
vm = net / src[-1] * QF
print('mean speed px/s (net/63 frames)', vm, ' path-based', tot / src[-1] * QF, ' body length (mean prior)', 6 * Lm / vm)
