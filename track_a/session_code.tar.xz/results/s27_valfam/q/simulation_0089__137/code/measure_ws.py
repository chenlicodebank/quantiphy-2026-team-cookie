import av, numpy as np, cv2
p = '/private/tmp/qp_blind/s27_ids/simulation_0089/q_137/simulation_0089.mp4'
frames = {}
with av.open(p) as c:
    for i, f in enumerate(c.decode(video=0)):
        if i in (0, 1, 2, 3, 4, 5, 6, 7, 8, 20):
            frames[i] = f.to_ndarray(format='bgr24').astype(np.int16)
        if i > 20:
            break
bg = frames[20]
for i in range(9):
    d = np.abs(frames[i] - bg).max(axis=2)
    for thr in (10, 18, 30, 50):
        m = (d > thr).astype(np.uint8)
        m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
        n, lab, st, cen = cv2.connectedComponentsWithStats(m)
        out = []
        for k in range(1, n):
            x, y, w, h, a = st[k]
            if a > 500:
                out.append((int(cen[k][0]), w, h, a))
        print(i, thr, sorted(out))
