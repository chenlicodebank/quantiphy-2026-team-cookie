import av, numpy as np, cv2
frames = {}
c = av.open('simulation_0089.mp4')
for i, f in enumerate(c.decode(video=0)):
    if i in (0, 2, 6, 7, 8, 15, 20, 25):
        frames[i] = f.to_ndarray(format='bgr24').astype(np.float32)
bg = np.median(np.stack([frames[k] for k in (15, 20, 25)]), axis=0)
roi = (slice(400, 720),)
def mask(i, thr):
    d = np.abs(frames[i] - bg).max(axis=2)
    m = (d > thr).astype(np.uint8)
    n, lab, st, _ = cv2.connectedComponentsWithStats(m)
    # component in right half (bird B)
    best = max([k for k in range(1, n) if st[k, 0] > 1000 or st[k,0]+st[k,2] > 1100], key=lambda k: st[k, 4])
    return lab == best, st[best]
for thr in (10, 18, 30, 60):
    for i in (0, 7):
        m, s = mask(i, thr)
        print('thr', thr, 'frame', i, 'x0', s[0], 'x1', s[0]+s[2]-1, 'len', s[2], 'wy', s[3])
# subpixel x extent along body row using profile
for i in (0, 7):
    d = np.abs(frames[i] - bg).max(axis=2)
    _, s = mask(i, 18)
    rows = d[550:562, s[0]-5:s[0]+s[2]+5]
    col = rows.max(axis=0)
    full = np.percentile(col, 90)
    w = np.clip(col / full, 0, 1).sum()
    print('frame', i, 'body-row coverage width (subpixel)', w)
# template shift between frame 6->7 and 7->8 using body region
def shift(a, b, x0):
    ga = cv2.cvtColor(frames[a], cv2.COLOR_BGR2GRAY)
    gb = cv2.cvtColor(frames[b], cv2.COLOR_BGR2GRAY)
    tpl = ga[540:572, x0:x0 + 110]
    res = cv2.matchTemplate(gb[530:582, :], tpl, cv2.TM_CCOEFF_NORMED)
    _, _, _, loc = cv2.minMaxLoc(res)
    x = loc[0]
    if 0 < x < res.shape[1] - 1:
        r = res[loc[1], x-1:x+2]; x += 0.5 * (r[0] - r[2]) / (r[0] - 2*r[1] + r[2])
    return x - x0
print('shift 6->7', shift(6, 7, 1586), 'shift 7->8', shift(7, 8, 1677))
print('shift 2->7 per frame', shift(2, 7, 1217) / 5, ' 0->? n/a')
