import av, numpy as np
frames = {}
c = av.open('simulation_0089.mp4')
for i, f in enumerate(c.decode(video=0)):
    if i in range(0, 9) or i == 20:
        frames[i] = f.to_ndarray(format='rgb24').astype(float)
    if i > 20: break
bg = frames[20]
for i in range(9):
    d = np.abs(frames[i] - bg).max(axis=2)
    # bird B region: x > 1000
    sub = d[:, 1000:]
    for thr in (18, 40):
        m = sub > thr
        ys, xs = np.nonzero(m)
        # largest blob approx: restrict to rows 400-720
        k = (ys > 380) & (ys < 720)
        ys, xs = ys[k], xs[k]
        L = xs.max() - xs.min() + 1; W = ys.max() - ys.min() + 1
        print(i, thr, 'L', L, 'W', W, 'W/L*0.94=%.3f' % (W / L * 0.94), 'W*0.94/107=%.3f' % (W * 0.94 / 107))
