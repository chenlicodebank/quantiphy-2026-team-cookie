import av, numpy as np
frames = []
c = av.open('simulation_0089.mp4')
for i, fr in enumerate(c.decode(video=0)):
    if i < 10 or i >= 15:
        frames.append((i, fr.to_ndarray(format='rgb24').astype(np.int16)))
bg = np.median(np.stack([f for i, f in frames if i >= 15]), axis=0)
for i, f in frames:
    if i > 9: break
    d = np.abs(f - bg).max(axis=2)
    for thr in (18, 40):
        m = d > thr
        # A: x<~950 region at start, B to right; split by tracking column between birds
        xs = np.where(m.any(axis=0))[0]
        if len(xs) == 0: continue
        cols = m.any(axis=0)
        # find connected column segments
        segs = []; s = None
        for x in range(len(cols)):
            if cols[x] and s is None: s = x
            if not cols[x] and s is not None: segs.append((s, x - 1)); s = None
        if s is not None: segs.append((s, len(cols) - 1))
        segs = [g for g in segs if g[1] - g[0] > 5]
        print(i, thr, [(a, b, b - a + 1, (a + b) / 2) for a, b in segs])
