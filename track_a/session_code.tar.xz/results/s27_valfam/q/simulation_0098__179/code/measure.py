import av, numpy as np, cv2
# Independent velocity check: template-match each object between frames (x-shift), boat in rows 300-640, fish rows 820-990
path = '/private/tmp/qp_blind/s27_ids/simulation_0098/q_179/simulation_0098.mp4'
frames = {}
c = av.open(path)
for i, fr in enumerate(c.decode(video=0)):
    frames[i] = cv2.cvtColor(fr.to_ndarray(format='bgr24'), cv2.COLOR_BGR2GRAY).astype(np.float32)
c.close()

def shift(a, b, rows, xr):
    # template from frame a (cols xr), search in frame b
    t = a[rows[0]:rows[1], xr[0]:xr[1]]
    s = b[rows[0]-5:rows[1]+5, :]
    r = cv2.matchTemplate(s, t, cv2.TM_CCOEFF_NORMED)
    _, mv, _, ml = cv2.minMaxLoc(r)
    x = ml[0]
    if 0 < x < r.shape[1]-1:
        y0, y1, y2 = r[ml[1], x-1], r[ml[1], x], r[ml[1], x+1]
        x = x + 0.5*(y0-y2)/(y0-2*y1+y2)
    return x - xr[0], mv

# boat at t=1.0: bow near 1084; use bow part 1080-1700 ; fish around 1282-1550
for (a, b) in [(23, 24), (24, 25), (2, 24), (24, 46), (14, 34)]:
    bx = 1084 + (24 - a) * 17.87
    fx = 1282 + (24 - a) * 10.76
    sb, mb = shift(frames[a], frames[b], (300, 640), (int(bx), int(bx) + 600))
    sf, mf = shift(frames[a], frames[b], (845, 965), (int(fx) - 5, int(fx) + 280))
    n = b - a
    print(a, b, 'boat px/s %.2f (%.3f)' % (sb / n * 24, mb), 'fish px/s %.2f (%.3f)' % (sf / n * 24, mf),
          'ratio %.4f' % (sb / sf), 'boat m/s %.4f' % (3 * sb / sf))
