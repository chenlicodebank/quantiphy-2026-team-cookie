import av, numpy as np
c = av.open('/private/tmp/qp_blind/s27_ids/simulation_0089/q_141/simulation_0089.mp4')
fr = []
for i, f in enumerate(c.decode(video=0)):
    fr.append(f.to_ndarray(format='rgb24').astype(np.float32)[::1])
bg = np.median(np.stack(fr[12:30:3]), 0)
for i in [0, 3, 5, 7, 8]:
    d = np.abs(fr[i] - bg).max(2)
    for name, (a, b) in [('B', (1000, 1920)), ('A', (0, 1000))]:
        sub = d[:, a:b]
        cols = sub.max(0)
        xs = np.where(cols > 18)[0] + a
        xs2 = np.where(cols > 6)[0] + a
        if len(xs) == 0:
            print(i, name, 'none'); continue
        full = np.percentile(sub[sub > 18], 90)
        cov = np.clip(cols / full, 0, 1).sum()
        print(i, name, xs.min(), xs.max(), xs.max() - xs.min() + 1, xs2.min(), xs2.max(), round(float(cov), 1))
