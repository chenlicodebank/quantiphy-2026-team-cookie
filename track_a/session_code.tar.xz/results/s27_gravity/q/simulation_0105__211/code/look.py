import av, numpy as np
c = av.open('simulation_0105.mp4')
for i, fr in enumerate(c.decode(video=0)):
    if i in (25, 38):
        g = fr.to_ndarray(format='gray').astype(int)
        cy = {25: 109, 38: 599}[i]
        print(i)
        for r in range(cy - 16, cy + 17):
            print(r, ' '.join('%3d' % v for v in g[r, 524:556]))
