import av, numpy as np, cv2
c = av.open('simulation_0105.mp4')
rows = []
crops = {}
for i, fr in enumerate(c.decode(video=0)):
    g = fr.to_ndarray(format='gray').astype(float)
    if i == 0:
        bg = np.median(g[:900, :300])
    if i < 22 or i > 45:
        continue
    sub = g[:965]
    m = np.abs(sub - bg) > 25
    n, lab, st, cen = cv2.connectedComponentsWithStats(m.astype(np.uint8))
    k = 1 + np.argmax(st[1:, 4])
    x0, y0, w, h, a = st[k]
    # subpixel extents via edge profiles: fraction-weighted sums
    col = g[y0-3:y0+h+3, x0+5:x0+w-5].mean(1)   # vertical profile through centre columns
    row = g[y0+5:y0+h-5, x0-3:x0+w+3].mean(0)   # horizontal profile
    inner_v = np.median(g[y0+3:y0+h-3, x0+3:x0+w-3])
    # edge-only intensity: use top/bottom rows of the profile vs core level; core level = median of central profile
    cv_ = np.median(col[6:-6]); ch = np.median(row[6:-6])
    hv = np.clip((col - bg) / (cv_ - bg), 0, 1.2).sum()
    wh = np.clip((row - bg) / (ch - bg), 0, 1.2).sum()
    rows.append((i, cen[k][0], cen[k][1], w, h, a, hv, wh))
    if i in (30, 38):
        crops[i] = g[y0-4:y0+h+4, x0-4:x0+w+4]
R = np.array(rows)
for r in R: print('%2d cx=%.2f cy=%.2f bb=%dx%d area=%d  h_sub=%.2f w_sub=%.2f' % tuple(r))
f, y = R[:, 0], R[:, 2]
t = f / 24.0
p = np.polyfit(t, y, 2); res = y - np.polyval(p, t)
a_px = 2 * p[0]
print('quad fit a_px=%.2f px/s^2 rms=%.3f' % (a_px, res.std()))
# second differences
d2 = np.diff(y, 2) * 24**2
print('2nd diff mean %.1f median %.1f std %.1f' % (d2.mean(), np.median(d2), d2.std()))
# split halves
for sl in (slice(0, 12), slice(12, None)):
    pp = np.polyfit(t[sl], y[sl], 2); print('half a_px=%.1f' % (2 * pp[0]))
s = 9.8 / a_px
print('m/px = %.6f' % s)
print('h_sub mean %.2f, w_sub mean %.2f' % (R[:, 6].mean(), R[:, 7].mean()))
for lbl, px in (('w_sub', R[:, 7].mean()), ('h_sub', R[:, 6].mean()), ('bbox w', 26), ('sqrt area', np.sqrt(R[:, 5].mean()))):
    print(lbl, px, 'm=%.4f' % (px * s))
np.set_printoptions(linewidth=250, precision=0, suppress=True)
print(crops[38])
