import numpy as np, csv, os, av
os.chdir(os.path.dirname(os.path.abspath(__file__)))
rows = {int(r['frame']): r for r in csv.DictReader(open('scene/tracks/football.csv'))}
c = av.open('simulation_0116.mp4')
for i, fr in enumerate(c.decode(video=0)):
    if i != 6: continue
    img = fr.to_ndarray(format='rgb24').astype(int)
    r = rows[i]; cx, cy = float(r['cx']), float(r['cy'])
    print('cx,cy', cx, cy, r['bbox_x0'], r['bbox_x1'])
    yy = int(round(cy))
    for x in range(int(cx) - 30, int(cx) + 30):
        print(x, img[yy, x], img[yy, x, 2] - img[yy, x, 0])
    break
