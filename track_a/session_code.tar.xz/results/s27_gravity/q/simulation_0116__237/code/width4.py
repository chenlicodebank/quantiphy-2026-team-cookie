"""Ball width from blue chromaticity b = B/(R+G+B): ball ~0.30-0.37, wall/shadow ~0.45-0.55.
Sub-pixel crossing of threshold on each row; width = max over rows (median of top 3)."""
import numpy as np, csv, os, av
os.chdir(os.path.dirname(os.path.abspath(__file__)))
rows = {int(r['frame']): r for r in csv.DictReader(open('scene/tracks/football.csv'))}
c = av.open('simulation_0116.mp4')
allw = {}
for thr in [0.40, 0.42, 0.44]:
    allw[thr] = []
for i, fr in enumerate(c.decode(video=0)):
    if i == 17: continue
    img = fr.to_ndarray(format='rgb24').astype(float)
    r = rows[i]; cx, cy = int(float(r['cx'])), int(float(r['cy']))
    sub = img[cy - 45:cy + 45, cx - 35:cx + 35]
    b = sub[..., 2] / (sub.sum(2) + 1)
    for thr in allw:
        ws = []
        for yy in range(30, 60):
            p = b[yy]
            c0 = 35
            if p[c0] > thr: continue
            a = c0
            while a > 0 and p[a - 1] <= thr: a -= 1
            e = c0
            while e < 69 and p[e + 1] <= thr: e += 1
            if a == 0 or e == 69: continue
            le = a - (thr - p[a]) / (p[a - 1] - p[a])
            re = e + (thr - p[e]) / (p[e + 1] - p[e])
            ws.append(re - le)
        ws = np.sort(ws)
        allw[thr].append(np.median(ws[-3:]))
for thr, v in allw.items():
    v = np.array(v)
    print(thr, np.round(v, 1), 'median', np.median(v), 'mean', v.mean())
