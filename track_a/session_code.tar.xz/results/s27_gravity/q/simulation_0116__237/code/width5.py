"""Ball width by linear colour unmixing at each edge (area-conserving under the chroma blur):
width = sum over row window of alpha, alpha = projection of pixel colour on the segment
(outside colour 4 px beyond edge -> ball colour 4 px inside edge)."""
import numpy as np, csv, os, av
os.chdir(os.path.dirname(os.path.abspath(__file__)))
rows = {int(r['frame']): r for r in csv.DictReader(open('scene/tracks/football.csv'))}
c = av.open('simulation_0116.mp4')
out = []
for i, fr in enumerate(c.decode(video=0)):
    if i == 17: continue
    img = fr.to_ndarray(format='rgb24').astype(float)
    r = rows[i]; cx, cy = int(float(r['cx'])), int(float(r['cy']))
    sub = img[cy - 45:cy + 45, cx - 35:cx + 35]
    b = sub[..., 2] / (sub.sum(2) + 1)
    ws = []
    for yy in range(30, 60):
        p = b[yy]; c0 = 35; thr = 0.42
        if p[c0] > thr: continue
        a = c0
        while a > 0 and p[a - 1] <= thr: a -= 1
        e = c0
        while e < 69 and p[e + 1] <= thr: e += 1
        if a < 6 or e > 63: continue
        row = sub[yy]
        total = 0.0
        # interior fully counted between a+4 and e-4
        total += (e - 4) - (a + 4) - 1
        for (edge, sgn) in [(a, -1), (e, +1)]:
            inside = row[edge - sgn * 4]; outside = row[edge + sgn * 4]
            d = inside - outside
            for k in range(-3, 4):
                px = row[edge + sgn * k]
                al = np.clip(np.dot(px - outside, d) / np.dot(d, d), 0, 1)
                total += al
        ws.append(total)
    ws = np.sort(ws)
    out.append(np.median(ws[-3:]))
out = np.array(out)
print(np.round(out, 1)); print('median', np.median(out), 'mean', out.mean(), 'std', out.std())
