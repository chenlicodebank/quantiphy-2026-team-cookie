import numpy as np, csv, os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
rows = list(csv.DictReader(open('scene/tracks/football.csv')))
print(rows[0].keys())
f = np.array([int(r['frame']) for r in rows])
for k in ['cy', 'bbox_cy']:
    y = np.array([float(r[k]) for r in rows])
    m = f != 17 if k == 'cy' else np.ones(len(f), bool)
    for lo in [0, 3]:
        mm = m & (f >= lo)
        p = np.polyfit(f[mm] / 24.0, y[mm], 2)
        res = y[mm] - np.polyval(p, f[mm] / 24.0)
        print(k, lo, 'a_px=', 2 * p[0], 'rms', res.std(), 'm/px', 9.8 / (2 * p[0]))
w = np.array([float(r['mask_wid']) for r in rows])
L = np.array([float(r['mask_len']) for r in rows])
bw = np.array([float(r['bbox_w']) for r in rows])
print(np.round(w, 1)); print(np.round(L, 1)); print(bw)
