import numpy as np, csv, os, av
from scipy import ndimage
os.chdir(os.path.dirname(os.path.abspath(__file__)))
rows = {int(r['frame']): r for r in csv.DictReader(open('scene/tracks/football.csv'))}
want = list(range(0, 32, 2))
c = av.open('simulation_0116.mp4')
res = {}
for i, fr in enumerate(c.decode(video=0)):
    if i not in want: continue
    img = fr.to_ndarray(format='rgb24').astype(float)
    r = rows[i]; cx, cy = int(float(r['cx'])), int(float(r['cy']))
    sub = img[cy - 50:cy + 50, cx - 40:cx + 40]
    R, G, B = sub[..., 0], sub[..., 1], sub[..., 2]
    out = []
    for t in [15, 25, 35]:
        white = (R > 150) & (B - R < 40) & (np.abs(G - R) < 40)
        m = ((B - R) < t) | white
        lab, n = ndimage.label(m)
        l = lab[50, 40]
        if l == 0:
            l = np.bincount(lab.ravel())[1:].argmax() + 1
        mm = ndimage.binary_fill_holes(lab == l)
        ys, xs = np.nonzero(mm)
        rowsw = mm.sum(1)
        out.append((t, xs.max() - xs.min() + 1, ys.max() - ys.min() + 1, int(np.sort(rowsw)[-3:].mean())))
    res[i] = out
    print(i, out)
