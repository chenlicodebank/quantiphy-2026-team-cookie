import numpy as np, csv, os, av
os.chdir(os.path.dirname(os.path.abspath(__file__)))
rows = {int(r['frame']): r for r in csv.DictReader(open('scene/tracks/football.csv'))}
want = [0, 2, 4, 6, 8, 10, 12]
bg = None
frames = {}
c = av.open('simulation_0116.mp4')
for i, fr in enumerate(c.decode(video=0)):
    if i in want or i == 31:
        frames[i] = fr.to_ndarray(format='rgb24').astype(float)
bg = frames[31]
for i in want:
    r = rows[i]
    cx, cy = float(r['cx']), float(r['cy'])
    img = frames[i]
    ws = []
    for dy in range(-6, 7, 2):
        yy = int(round(cy)) + dy
        x0 = int(cx) - 45; x1 = int(cx) + 45
        d = np.abs(img[yy, x0:x1] - bg[yy, x0:x1]).sum(1)
        thr = d.max() / 2
        idx = np.where(d > thr)[0]
        # sub-pixel edges
        a, b = idx[0], idx[-1]
        le = a - 1 + (thr - d[a - 1]) / (d[a] - d[a - 1])
        re = b + (d[b] - thr) / (d[b] - d[b + 1])
        ws.append(re - le)
    print(i, np.round(ws, 1), 'max', round(max(ws), 1))
