import numpy as np, csv, os, av
os.chdir(os.path.dirname(os.path.abspath(__file__)))
rows = {int(r['frame']): r for r in csv.DictReader(open('scene/tracks/football.csv'))}
want = [0, 3, 6, 9, 12, 20, 25, 28]
c = av.open('simulation_0116.mp4')
for i, fr in enumerate(c.decode(video=0)):
    if i not in want: continue
    img = fr.to_ndarray(format='rgb24').astype(float)
    r = rows[i]; cx, cy = float(r['cx']), float(r['cy'])
    x0 = int(cx) - 40
    best = []
    for yy in range(int(cy) - 12, int(cy) + 13):
        seg = img[yy, x0:x0 + 80]
        s = seg[:, 2] - seg[:, 0]  # B-R: ball low, wall/shadow high
        bgv = np.median(np.r_[s[:5], s[-5:]])
        ball = np.median(s[35:45])
        thr = (bgv + ball) / 2
        idx = np.where(s < thr)[0]
        # contiguous run containing centre
        c0 = 40
        a = c0
        while a > 0 and s[a - 1] < thr: a -= 1
        b = c0
        while b < 79 and s[b + 1] < thr: b += 1
        le = a - 1 + (s[a - 1] - thr) / (s[a - 1] - s[a])
        re = b + (s[b + 1] - thr) / (s[b + 1] - s[b]) if False else b + (thr - s[b]) / (s[b + 1] - s[b])
        best.append(re - le)
    best = np.array(best)
    print(i, 'max', round(best.max(), 1), 'top3 mean', round(np.sort(best)[-3:].mean(), 1), 'median', round(np.median(best), 1))
