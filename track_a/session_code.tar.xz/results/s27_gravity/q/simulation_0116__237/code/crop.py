import numpy as np, os, av, sys
from PIL import Image
os.chdir(os.path.dirname(os.path.abspath(__file__)))
fi = int(sys.argv[1]); x0, y0, x1, y1 = map(int, sys.argv[2:6])
c = av.open('simulation_0116.mp4')
for i, fr in enumerate(c.decode(video=0)):
    if i == fi:
        img = fr.to_ndarray(format='rgb24')[y0:y1, x0:x1]
        bg = None
        break
c.close()
c = av.open('simulation_0116.mp4')
for i, fr in enumerate(c.decode(video=0)):
    if i == (31 if y0 < 1000 else 0):
        bg = fr.to_ndarray(format='rgb24')[y0:y1, x0:x1]
s = 10
a = np.kron(img, np.ones((s, s, 1), np.uint8))
b = np.kron(bg, np.ones((s, s, 1), np.uint8))
for k in range(0, a.shape[1], 10 * s): a[:, k] = [255, 0, 0]; b[:, k] = [255, 0, 0]
for k in range(0, a.shape[0], 10 * s): a[k, :] = [255, 0, 0]; b[k, :] = [255, 0, 0]
Image.fromarray(np.concatenate([a, b], 1)).save(f'frames/crop_{fi}.png')
