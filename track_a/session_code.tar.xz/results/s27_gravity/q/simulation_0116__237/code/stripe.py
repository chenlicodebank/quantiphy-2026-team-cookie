import numpy as np, csv, os, av
os.chdir(os.path.dirname(os.path.abspath(__file__)))
rows = {int(r['frame']): r for r in csv.DictReader(open('scene/tracks/football.csv'))}
want = list(range(0, 31, 2))
c = av.open('simulation_0116.mp4')
for i, fr in enumerate(c.decode(video=0)):
    if i not in want: continue
    img = fr.to_ndarray(format='rgb24').astype(float)
    r = rows[i]; cx, cy = int(float(r['cx'])), int(float(r['cy']))
    sub = img[cy - 45:cy + 45, cx - 35:cx + 35]
    R, G, B = sub[..., 0], sub[..., 1], sub[..., 2]
    Y = 0.299 * R + 0.587 * G + 0.114 * B
    white = (R > 140) & (G > 140) & (B - R < 50)
    ys, xs = np.nonzero(white)
    sc = (xs.min() + xs.max()) / 2 if len(xs) else np.nan
    # right edge: per row, last column where ball-ish (B-R<45) then luma-based subpixel
    s = B - R
    redges = []; ledges = []
    for yy in range(25, 65):
        row = s[yy]
        ball = np.where(row < 25)[0]
        if len(ball) < 10: continue
        redges.append(ball.max() + 0.5); ledges.append(ball.min() - 0.5)
    redges = np.array(redges); ledges = np.array(ledges)
    re = np.sort(redges)[-3:].mean(); le = np.sort(ledges)[:3].mean()
    print(i, 'stripe x', xs.min() if len(xs) else None, xs.max() if len(xs) else None, 'centre', sc,
          'R edge', re, 'L edge', le, 'w(L-R)', re - le, 'w 2*(R-c)', 2 * (re - sc - 0.0))
