import numpy as np, csv, os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
r = list(csv.DictReader(open('scene/tracks/football.csv')))
print(r[0].keys())
f = np.array([int(float(x['frame'])) for x in r])
cy = np.array([float(x['cy']) for x in r]); by = np.array([float(x['bbox_cy']) for x in r])
fps = 24.0
for name, y in [('cy', cy), ('bbox_cy', by)]:
    m = f != 17
    for lo in [0, 3]:
        mm = m & (f >= lo)
        p = np.polyfit(f[mm], y[mm], 2)
        a = 2 * p[0]  # px/frame^2
        s = 9.8 / (a * fps ** 2)
        v12 = (np.polyval(p, 12) - np.polyval(p, 11)) * fps * s
        t0 = -p[1] / (2 * p[0])
        res = y[mm] - np.polyval(p, f[mm])
        print(name, lo, 'a px/fr2 %.4f m/px %.6f v12 %.4f rest frame %.3f rms %.3f' % (a, s, v12, t0, res.std()))
    d = np.diff(y)
    print(' raw dy 11->12 speed', d[11] * fps * s)
print(np.round(np.diff(cy), 2))
