import numpy as np, av
from PIL import Image
c = av.open('/private/tmp/qp_blind/s27_gravity/simulation_0020/q_8/simulation_0020.mp4')
fr = {}
for i, f in enumerate(c.decode(video=0)):
    if i in (10, 33, 105, 0):
        fr[i] = f.to_ndarray(format='rgb24')
    if i > 105: break
# side-by-side upscaled crop of feet region at frames 105 and 33
crops = [Image.fromarray(fr[i][740:830, 770:860]).resize((540, 540), Image.NEAREST) for i in (105, 33, 10)]
W = Image.new('RGB', (1620, 540))
for k, im in enumerate(crops): W.paste(im, (540 * k, 0))
W.save('/private/tmp/qp_blind/s27_gravity/simulation_0020/q_8/feet_cmp.png')
a = fr[105].astype(int)
for x in (800, 805, 810, 815, 820, 825, 830):
    col = a[770:820, x]
    print(x, ' '.join(str(v) for v in col.mean(axis=1).astype(int)))
