import numpy as np, av
c = av.open('/private/tmp/qp_blind/s27_gravity/simulation_0020/q_8/simulation_0020.mp4')
for i, f in enumerate(c.decode(video=0)):
    if i == 105:
        a = f.to_ndarray(format='rgb24').astype(int); break
# rows near feet: print mean brightness of white shoe pixels per row
for y in range(780, 820):
    row = a[y, 780:845]
    white = (row.min(axis=1) > 170).sum()
    print(y, white, row.mean(axis=0).astype(int))
print('head')
for y in range(575, 600):
    row = a[y, 795:825]
    print(y, row.mean(axis=0).astype(int), a[y, 760:775].mean(axis=0).astype(int))
