import numpy as np, csv
d = np.load('/private/tmp/qp_blind/s27_gravity/simulation_0020/q_8/scene/scripts/player_masks_all.npz')
print({k: d[k].shape for k in d.files})
r = list(csv.DictReader(open('/private/tmp/qp_blind/s27_gravity/simulation_0020/q_8/scene/tracks/player.csv')))
print(list(r[0].keys()))
hs = [float(x['height_px']) for x in r[49:131]]
print('standing height px median', np.median(hs), np.percentile(hs, [10, 90]))
for x in r[100:106]:
    print({k: x[k] for k in ('frame', 'bbox_y0', 'bbox_y1', 'height_px')} if 'bbox_y0' in x else x)
b = list(csv.DictReader(open('/private/tmp/qp_blind/s27_gravity/simulation_0020/q_8/scene/tracks/ball.csv')))
dm = [float(x['diam_fit']) for x in b[21:35]]
print('ball diam near player (21-34)', np.median(dm), np.mean(dm))
dm2 = [float(x['diam_fit']) for x in b[25:78]]
print('ball diam flight', np.median(dm2))
