import av, numpy as np
cont = av.open('simulation_0105.mp4')
rows = []
bg = None
for i, fr in enumerate(cont.decode(video=0)):
    g = fr.to_ndarray(format='gray').astype(float)
    if i == 0:
        bg = np.median(g[:900, :], axis=0)  # column median of background (cube absent in f0)
        bgv = np.median(g[:900, 400:700])
    if i < 21 or i > 45:
        continue
    sub = g[:960, 500:580]
    w = np.clip((sub - bgv) / (sub.max() - bgv), 0, 1)  # soft mask (cube brighter)
    w[w < 0.15] = 0
    ys = np.arange(sub.shape[0])[:, None]
    xs = np.arange(sub.shape[1])[None, :] + 500
    cy = (w * ys).sum() / w.sum(); cx = (w * xs).sum() / w.sum()
    # subpixel top/bottom edges from row profile (half-max crossings)
    prof = w.max(axis=1)
    idx = np.where(prof > 0.5)[0]
    def cross(a, b):
        pa, pb = prof[a], prof[b]
        return a + (0.5 - pa) / (pb - pa)
    top = cross(idx[0] - 1, idx[0]) if idx[0] > 0 else np.nan
    bot = cross(idx[-1], idx[-1] + 1)
    rows.append((i, cx, cy, top, bot, (top + bot) / 2))
rows = np.array(rows)
np.set_printoptions(suppress=True, precision=2, linewidth=150)
print(rows)
fps = 24.0
for col, name in [(2, 'centroid'), (5, 'edge-mid')]:
    m = rows[:, 0] >= 22
    t = rows[m, 0] / fps; y = rows[m, col]
    c = np.polyfit(t, y, 2)
    a = 2 * c[0]
    res = y - np.polyval(c, t)
    print(name, 'a_px/s2 =', a, 'rms res', res.std())
    scale = 9.8 / a
    # one-frame backward diff at frame 24
    y24 = rows[rows[:, 0] == 24, col][0]; y23 = rows[rows[:, 0] == 23, col][0]
    v_bd = (y24 - y23) * fps * scale
    # fitted backward diff
    yf = lambda f: np.polyval(c, f / fps)
    v_fit_bd = (yf(24) - yf(23)) * fps * scale
    v_inst = np.polyval(np.polyder(c), 1.0) * scale
    print(' scale m/px', scale, 'cube size m', 25.5 * scale)
    print(' v backward diff raw', v_bd, 'fit backward', v_fit_bd, 'instant', v_inst)
    # release time
    print(' t at v=0', -c[1] / (2 * c[0]))
