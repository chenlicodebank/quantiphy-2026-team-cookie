import numpy as np, cv2, av
c=av.open('simulation_0116.mp4')
for i,fr in enumerate(c.decode(video=0)):
    img=fr.to_ndarray(format='bgr24'); break
hsv=cv2.cvtColor(img,cv2.COLOR_BGR2HSV)
yel=(hsv[...,0]>15)&(hsv[...,0]<40)&(hsv[...,1]>80)&(hsv[...,2]>100)
# middle door rows 830-1030 (above railing), bottom door 1380-1700, top door 340-390
for name,rows in [('mid',range(840,1030,10)),('bot',range(1440,1700,20)),('top',range(330,390,10))]:
    for y in rows:
        row=yel[y,560:900]
        xs=np.where(row)[0]+560
        # find longest contiguous run
        runs=[];s=None
        for x in range(560,900):
            if yel[y,x] and s is None: s=x
            if not yel[y,x] and s is not None: runs.append((s,x-1)); s=None
        if s is not None: runs.append((s,899))
        runs=[r for r in runs if r[1]-r[0]>5]
        print(name,y,runs)
# column profile for horizontal edges of middle door
for x in [700,730,760]:
    col=yel[780:1060,x]; ys=np.where(col)[0]+780
    print('col',x,ys.min() if len(ys) else None, ys.max() if len(ys) else None)
