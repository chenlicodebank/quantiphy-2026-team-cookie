import numpy as np, csv
r=list(csv.DictReader(open('scene/tracks/football.csv')))
f=np.array([float(x['frame']) for x in r]); cy=np.array([float(x['cy']) for x in r]); by=np.array([float(x['bbox_cy']) for x in r])
fps=24.0
for name,y in [('cy',cy),('bbox_cy',by)]:
  for lo in [0,3,6]:
    m=(f>=lo)&(f!=17)
    p=np.polyfit(f[m],y[m],2); res=y[m]-np.polyval(p,f[m])
    a=2*p[0]
    print(name,lo,'a_px/frame2 %.4f'%a,'rms %.2f'%res.std(),'m/px %.6f'%(9.8/(a*fps**2)))
d=np.diff(cy); print(np.round(d,1)); print(np.round(np.diff(d),2))
