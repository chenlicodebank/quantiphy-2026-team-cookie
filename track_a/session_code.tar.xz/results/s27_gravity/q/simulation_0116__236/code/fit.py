import csv,numpy as np
r=list(csv.DictReader(open('scene/tracks/football.csv')))
f=np.array([int(x['frame']) for x in r]);y=np.array([float(x['bbox_cy']) for x in r]);yc=np.array([float(x['cy']) for x in r])
fps=24.0
for lo in [0,1,2,5]:
  for yy,n in [(y,'bbox'),(yc,'cent')]:
    m=(f>=lo)&(f!=17)
    t=f[m]/fps;p=np.polyfit(t,yy[m],2);res=yy[m]-np.polyval(p,t)
    print(lo,n,'a px/s2',2*p[0],'v0',p[1],'rms',res.std())
d=np.diff(y);print(np.diff(d))
