import av, numpy as np, cv2
X0, X1 = 960, 1120
want = set(range(0, 32))
fr = {}
c = av.open('simulation_0116.mp4')
for i, f in enumerate(c.decode(video=0)):
    fr[i] = f.to_ndarray(format='rgb24')[:, X0:X1].copy()
bg = fr[0].astype(np.float32).copy(); bg[:1000] = fr[31][:1000].astype(np.float32)
for i in range(32):
    a = fr[i].astype(np.float32)
    d = np.abs(a - bg).sum(2)
    R, B = a[..., 0], a[..., 2]
    ballcol = (B - R < 45) | ((a.min(2) > 150) & (B - R < 60))
    core = ((d > 50) & ballcol).astype(np.uint8)
    n, lab, st, cen = cv2.connectedComponentsWithStats(core)
    b = 1 + int(np.argmax(st[1:, 4]))
    ys, xs = np.nonzero(lab == b)
    (cx, cy), (w, h), ang = cv2.minAreaRect(np.stack([xs, ys], 1).astype(np.float32))
    # PCA axis of core
    P = np.stack([xs, ys], 1).astype(float); mu = P.mean(0)
    ev, evec = np.linalg.eigh(np.cov((P - mu).T)); ax = evec[:, 1]; px = evec[:, 0]
    # profiles along axis and across, sampling soft "ball-ness": B-R deficit relative to bg
    def prof(dirv, L=60):
        s = np.arange(-L, L + 0.01, 0.25)
        out = []
        for off in np.arange(-3, 3.01, 1.0):
            pts = mu[None] + s[:, None] * dirv[None] + off * (np.array([-dirv[1], dirv[0]]))[None]
            mx = pts[:, 0].astype(np.float32).reshape(1, -1); my = pts[:, 1].astype(np.float32).reshape(1, -1)
            v = cv2.remap(np.ascontiguousarray(d), mx, my, cv2.INTER_LINEAR)[0]
            out.append(v)
        v = np.median(out, 0)
        # level: half of median value inside central region
        inside = np.median(v[np.abs(s) < 10])
        thr = 0.5 * inside
        above = np.nonzero(v > thr)[0]
        # contiguous run containing centre
        c0 = np.argmin(np.abs(s)); lo = c0; hi = c0
        while lo > 0 and v[lo - 1] > thr: lo -= 1
        while hi < len(s) - 1 and v[hi + 1] > thr: hi += 1
        return s[hi] - s[lo] + 0.25
    print(i, 'minrect', round(max(w, h), 1), round(min(w, h), 1), 'pca-angle', round(np.degrees(np.arctan2(ax[0], ax[1])), 1),
          'halfmax len', prof(ax), 'wid', prof(px))
