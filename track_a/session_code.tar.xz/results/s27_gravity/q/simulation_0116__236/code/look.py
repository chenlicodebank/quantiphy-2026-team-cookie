import av, numpy as np, cv2, sys
idx = [int(x) for x in sys.argv[1:]] or [0]
c = av.open('simulation_0116.mp4')
tiles = []
for i, f in enumerate(c.decode(video=0)):
    if i in idx:
        a = f.to_ndarray(format='rgb24')
        import csv
        r = list(csv.DictReader(open('scene/tracks/football.csv')))[i]
        cx, cy = int(float(r['cx'])), int(float(r['cy']))
        crop = a[cy - 45:cy + 45, cx - 35:cx + 35]
        if i == idx[0]:
            print('frame', i, 'origin', cx - 35, cy - 45)
            # column profile through centre
            col = crop[:, 35].astype(int)
            for k, v in enumerate(col): print(cy - 45 + k, v, end=' | ')
            print()
            row = crop[45].astype(int)
            for k, v in enumerate(row): print(cx - 35 + k, v, end=' | ')
            print()
        big = cv2.resize(crop, (crop.shape[1] * 6, crop.shape[0] * 6), interpolation=cv2.INTER_NEAREST)
        for k in range(0, 90, 10): cv2.line(big, (0, k * 6), (big.shape[1], k * 6), (255, 255, 0), 1)
        for k in range(0, 70, 10): cv2.line(big, (k * 6, 0), (k * 6, big.shape[0]), (255, 255, 0), 1)
        tiles.append(big)
cv2.imwrite('frames/look.png', cv2.cvtColor(np.hstack(tiles), cv2.COLOR_RGB2BGR))
