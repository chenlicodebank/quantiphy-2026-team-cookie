import numpy as np, csv
rows = list(csv.DictReader(open('scene/tracks/football.csv')))
f = np.array([int(r['frame']) for r in rows]); y = np.array([float(r['cy']) for r in rows]); yb = np.array([float(r['bbox_cy']) for r in rows])
fps = 24.0
for name, yy in [('cy', y), ('bbox_cy', yb)]:
    for lo in [0, 2, 5]:
        m = (f >= lo) & (f != 17)
        p = np.polyfit(f[m], yy[m], 2)
        a = 2 * p[0] * fps**2
        print(name, lo, 'a px/s2', a, 'm/px', 9.8 / a, 'resid', np.std(yy[m] - np.polyval(p, f[m])))
d2 = np.diff(y, 2)
print('second diffs', np.round(d2, 2), 'median', np.median(d2))
