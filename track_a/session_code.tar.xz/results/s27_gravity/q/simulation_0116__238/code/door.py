import av, numpy as np
c = av.open('/private/tmp/qp_blind/s27_gravity/simulation_0116/q_238/simulation_0116.mp4')
fr = next(c.decode(video=0)).to_ndarray(format='rgb24').astype(int)
R, G, B = fr[..., 0], fr[..., 1], fr[..., 2]
yel = (R > 150) & (G > 130) & (B < 110)
# vertical profiles along door frame stiles and centre
for x in [652, 656, 660, 720, 800, 803]:
    col = yel[:, x]
    print('x', x)
    for y0, y1 in [(780, 1260), (1330, 1780)]:
        ys = np.where(col[y0:y1])[0] + y0
        # print runs
        runs = []; s = ys[0]; p = ys[0]
        for y in ys[1:]:
            if y != p + 1:
                runs.append((s, p)); s = y
            p = y
        runs.append((s, p))
        print('  ', [r for r in runs if r[1] - r[0] >= 2])
# horizontal: door width rows
for y in [950, 1500]:
    xs = np.where(yel[y, 600:860])[0] + 600
    print('row', y, xs.min(), xs.max())
