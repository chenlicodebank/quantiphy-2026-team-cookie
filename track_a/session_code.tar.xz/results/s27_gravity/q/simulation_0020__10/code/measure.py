import av, numpy as np, cv2
V = 'simulation_0020.mp4'
want = {25, 30, 40, 50, 60, 78, 105, 110, 128, 129}
frames = {}
c = av.open(V)
for i, f in enumerate(c.decode(video=0)):
    if i in want:
        frames[i] = f.to_ndarray(format='rgb24')
    if i > max(want):
        break
for i in sorted(frames):
    im = frames[i]
    hsv = cv2.cvtColor(im, cv2.COLOR_RGB2HSV)
    m = ((hsv[..., 0] < 18) | (hsv[..., 0] > 170)) & (hsv[..., 1] > 110) & (hsv[..., 2] > 60)
    m = m.astype(np.uint8)
    # remove rim: restrict to a window around the scene track
    n, lab, st, cen = cv2.connectedComponentsWithStats(m)
    best = None
    for k in range(1, n):
        x, y, w, h, a = st[k]
        if a < 150: continue
        fill = a / (w * h)
        if best is None or abs(w - h) + (1 - fill) * 40 < best[0]:
            best = (abs(w - h) + (1 - fill) * 40, k, x, y, w, h, a)
    _, k, x, y, w, h, a = best
    eq = 2 * np.sqrt(a / np.pi)
    cs, _ = cv2.findContours((lab == k).astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    (cx, cy), r = cv2.minEnclosingCircle(cs[0])
    print(i, 'bbox', x, y, w, h, 'area', a, 'eqdiam %.1f' % eq, 'encl %.1f' % (2 * r), 'c %.1f %.1f' % (cx, cy))
