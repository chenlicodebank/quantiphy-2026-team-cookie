import av, cv2, numpy as np
# ball diameter at rest (frame 129) and in the drop, from difference to a ball-free frame
c = av.open('simulation_0020.mp4')
want = {40, 60, 105, 108, 110, 112, 127, 129}
F = {}
for i, f in enumerate(c.decode(video=0)):
    if i in want: F[i] = f.to_ndarray(format='rgb24').astype(float)
    if i > 129: break
bg = F[60]  # ball is up near the hoop then; region x 250-340, y 560-800 is ball-free
for i in (105, 108, 110, 112, 127, 129):
    d = np.abs(F[i] - bg).sum(2)[560:800, 250:340]
    for th in (30, 60, 90):
        m = (d > th).astype(np.uint8)
        if i >= 127:
            m[778 - 560:, :] = 0  # cut wet-floor reflection below contact
        n, lab, st, cen = cv2.connectedComponentsWithStats(m)
        k = 1 + np.argmax(st[1:, 4])
        mk = (lab == k).astype(np.uint8)
        cs, _ = cv2.findContours(mk, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
        p = cs[0][:, 0, :].astype(float)
        # algebraic circle fit
        A = np.c_[2 * p, np.ones(len(p))]; bb = (p ** 2).sum(1)
        cx, cy, cc = np.linalg.lstsq(A, bb, rcond=None)[0]
        r = np.sqrt(cc + cx ** 2 + cy ** 2)
        x, y, w, h, a = st[k]
        print(i, th, 'bbox w,h', w, h, 'top,bottom', y + 560, y + h - 1 + 560, 'eq %.1f' % (2 * np.sqrt(a / np.pi)),
              'fit d %.1f c (%.1f, %.1f)' % (2 * r + 1, cx + 250, cy + 560))
