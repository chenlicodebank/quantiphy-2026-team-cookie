import av, numpy as np
# half-max edge widths of the ball along horizontal/vertical lines through its centre
V = 'simulation_0020.mp4'
cent = {25: (745, 530.6), 30: (697.5, 503.5), 40: (588, 463.6), 50: (475.2, 447.5), 60: (380.4, 446.3),
        105: (293.9, 601), 110: (293.2, 661), 129: (293.6, 761.3)}
c = av.open(V)
def edges(p):
    p = np.asarray(p, float)
    bg = np.median(np.r_[p[:6], p[-6:]]); pk = np.max(p[len(p)//2-4:len(p)//2+5])
    half = (bg + pk) / 2
    n = len(p); mid = n // 2
    i = mid
    while i > 0 and p[i] > half: i -= 1
    l = i + (half - p[i]) / (p[i+1] - p[i])
    j = mid
    while j < n-1 and p[j] > half: j += 1
    r = j - 1 + (p[j-1] - half) / (p[j-1] - p[j])
    return r - l
for i, f in enumerate(c.decode(video=0)):
    if i in cent:
        im = f.to_ndarray(format='rgb24').astype(float)
        red = im[..., 0] - 0.5 * (im[..., 1] + im[..., 2])
        x, y = cent[i]; xi, yi = int(round(x)), int(round(y))
        hs = [edges(red[yi+d, xi-28:xi+29]) for d in (-1, 0, 1)]
        vs = [edges(red[yi-28:yi+29, xi+d]) for d in (-1, 0, 1)]
        print(i, 'horiz %.2f' % np.mean(hs), 'vert %.2f' % np.mean(vs))
    if i > 130: break
