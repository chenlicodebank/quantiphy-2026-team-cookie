import av, cv2, numpy as np, csv
# ball diameter through the clip with the same difference-mask method (thresholds 60 / 90)
rows = {int(r['frame']): r for r in csv.DictReader(open('scene/tracks/ball.csv'))}
want = list(range(22, 78, 3)) + [99, 102, 105, 108, 111, 114, 127]
c = av.open('simulation_0020.mp4')
F = {}
for i, f in enumerate(c.decode(video=0)):
    if i in want or i in (5, 129):
        F[i] = f.to_ndarray(format='rgb24').astype(float)
    if i > 129: break
for i in want:
    x, y = float(rows[i]['x']), float(rows[i]['y'])
    bg = F[129] if i < 99 else F[5]
    x0, y0 = int(x) - 30, int(y) - 30
    d = np.abs(F[i] - bg).sum(2)[y0:y0 + 61, x0:x0 + 61]
    out = []
    for th in (60, 90):
        m = (d > th).astype(np.uint8)
        if i == 127: m[778 - y0:, :] = 0
        n, lab, st, cen = cv2.connectedComponentsWithStats(m)
        k = 1 + np.argmax(st[1:, 4])
        out.append(2 * np.sqrt(st[k, 4] / np.pi))
    print(i, 'x %.0f y %.0f' % (x, y), 'eq60 %.1f eq90 %.1f' % tuple(out))
