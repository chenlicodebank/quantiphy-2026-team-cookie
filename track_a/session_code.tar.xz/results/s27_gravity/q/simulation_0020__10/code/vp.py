import av, cv2, numpy as np
# vanishing point of the sidewalk tile seams (lines running toward the wall)
c = av.open('simulation_0020.mp4')
for i, f in enumerate(c.decode(video=0)):
    if i == 129:
        im = f.to_ndarray(format='bgr24'); break
g = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY)
y0, y1 = 762, 842
roi = cv2.GaussianBlur(g[y0:y1], (3, 3), 0)
e = cv2.Canny(roi, 20, 60)
ls = cv2.HoughLinesP(e, 1, np.pi / 360, 25, minLineLength=25, maxLineGap=4)
segs = []
for l in ls.reshape(-1, 4):
    x1, yy1, x2, yy2 = l.astype(float)
    yy1 += y0; yy2 += y0
    if abs(yy2 - yy1) < 12: continue  # skip near-horizontal
    if 740 < (x1 + x2) / 2 < 860: continue  # skip player legs/reflection
    if abs(x2 - x1) < 1 and 250 < x1 < 340: continue
    segs.append((x1, yy1, x2, yy2))
segs = np.array(segs)
print(len(segs))
for s in segs: print(np.round(s, 1), 'slope dx/dy %.3f' % ((s[2] - s[0]) / (s[3] - s[1])))
# least squares intersection
A = []; b = []
for x1, yy1, x2, yy2 in segs:
    n = np.array([yy2 - yy1, -(x2 - x1)]); n /= np.linalg.norm(n)
    A.append(n); b.append(n @ [x1, yy1])
A = np.array(A); b = np.array(b)
sol = np.linalg.lstsq(A, b, rcond=None)[0]
print('VP', sol, 'resid', np.round(A @ sol - b, 1))
vis = im.copy()
for x1, yy1, x2, yy2 in segs.astype(int): cv2.line(vis, (x1, yy1), (x2, yy2), (0, 0, 255), 2)
cv2.imwrite('frames/vp.png', vis[700:900])
