import av, cv2, numpy as np
# refine hand-picked sidewalk seam guesses (dark lines) and intersect them
c = av.open('simulation_0020.mp4')
for i, f in enumerate(c.decode(video=0)):
    if i == 129:
        im = f.to_ndarray(format='bgr24'); break
g = cv2.GaussianBlur(cv2.cvtColor(im, cv2.COLOR_BGR2GRAY).astype(float), (3, 3), 0)
guess = [((15, 819), (47, 800)), ((60, 842), (80, 822)), ((140, 842), (155, 827)), ((260, 819), (280, 800)),
         ((185, 799), (197, 785)), ((575, 820), (580, 842)), ((900, 820), (920, 842)), ((955, 800), (980, 820)),
         ((830, 785), (845, 799))]
A = []; b = []; fits = []
for (xa, ya), (xb, yb) in guess:
    lo, hi = sorted((ya, yb))
    pts = []
    for y in range(lo + 1, hi):
        xg = xa + (xb - xa) * (y - ya) / (yb - ya)
        xs = np.arange(int(xg) - 6, int(xg) + 7)
        prof = g[y, xs]
        k = np.argmin(prof)
        if 0 < k < len(xs) - 1 and prof[k] < np.median(prof) - 6:
            pts.append((xs[k], y))
    pts = np.array(pts, float)
    if len(pts) < 6: print('skip', xa, ya); continue
    p = np.polyfit(pts[:, 1], pts[:, 0], 1)  # x = p0*y + p1
    res = pts[:, 0] - np.polyval(p, pts[:, 1])
    print((xa, ya), 'n', len(pts), 'dx/dy %.3f' % p[0], 'rms %.2f' % res.std(), 'x at y=540: %.0f' % np.polyval(p, 540))
    fits.append(p)
    n = np.array([1.0, -p[0]]); n /= np.linalg.norm(n)  # x - p0 y = p1
    A.append(n); b.append(p[1] / np.sqrt(1 + p[0] ** 2))
A = np.array(A); b = np.array(b)
sol = np.linalg.lstsq(A, b, rcond=None)[0]
print('VP (x,y)', np.round(sol, 1), 'resid px', np.round(A @ sol - b, 1))
