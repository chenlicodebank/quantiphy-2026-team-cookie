import av, numpy as np, cv2, sys
# usage: crop.py frame x0 y0 x1 y1 scale out
fi, x0, y0, x1, y1, s = map(int, sys.argv[1:7]); out = sys.argv[7]
c = av.open('simulation_0020.mp4')
for i, f in enumerate(c.decode(video=0)):
    if i == fi:
        im = f.to_ndarray(format='bgr24')[y0:y1, x0:x1]
        break
im = cv2.resize(im, None, fx=s, fy=s, interpolation=cv2.INTER_NEAREST)
for y in range(y0, y1):
    if y % 10 == 0:
        cv2.line(im, (0, (y - y0) * s), (im.shape[1], (y - y0) * s), (0, 255, 255), 1)
        cv2.putText(im, str(y), (2, (y - y0) * s - 2), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 255, 255), 1)
for x in range(x0, x1):
    if x % 10 == 0:
        cv2.line(im, ((x - x0) * s, 0), ((x - x0) * s, im.shape[0]), (0, 255, 255), 1)
cv2.imwrite(out, im)
