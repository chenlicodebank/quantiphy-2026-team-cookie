import av, numpy as np, cv2
# track the ball over frames 0-12 with template matching (template = frame 0 ball patch)
c = av.open('/private/tmp/qp_blind/s27_gravity/simulation_0020/q_9/simulation_0020.mp4')
fr = []
for i, f in enumerate(c.decode(video=0)):
    fr.append(f.to_ndarray(format='bgr24')[560:760, 650:850].copy())
    if i >= 12: break
OX, OY = 650, 560
def orange(img):
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    h, s, v = hsv[..., 0].astype(int), hsv[..., 1].astype(int), hsv[..., 2].astype(int)
    return ((h <= 15) | (h >= 170)) & (s > 90) & (v > 90)
for i, im in enumerate(fr):
    m = orange(im)
    ys, xs = np.nonzero(m)
    # largest connected component
    n, lab, st, cen = cv2.connectedComponentsWithStats(m.astype(np.uint8))
    k = 1 + np.argmax(st[1:, cv2.CC_STAT_AREA])
    x0, y0, w, h, a = st[k]
    print(i, 'cc centroid', np.round(cen[k] + [OX, OY], 2), 'bbox', x0 + OX, y0 + OY, x0 + w + OX, y0 + h + OY, 'area', a)
# template matching using frame 0 ball patch (left part, less occluded)
t0 = fr[0][697 - 560 - 14:697 - 560 + 14, 745 - 650 - 14:745 - 650 + 6]
prev = None
for i, im in enumerate(fr):
    r = cv2.matchTemplate(im, t0, cv2.TM_CCOEFF_NORMED)
    _, mx, _, loc = cv2.minMaxLoc(r)
    # subpixel via parabola
    x, y = loc
    def sp(a, b, c_): d = a - 2 * b + c_; return 0 if d == 0 else 0.5 * (a - c_) / d
    dx = sp(r[y, x - 1], r[y, x], r[y, x + 1]); dy = sp(r[y - 1, x], r[y, x], r[y + 1, x])
    p = np.array([x + dx + OX, y + dy + OY])
    s = '' if prev is None else f'step {np.linalg.norm(p - prev):.2f}'
    print(i, 'tm', np.round(p, 2), round(mx, 3), s); prev = p
