import av, numpy as np
c = av.open('/private/tmp/qp_blind/s27_gravity/simulation_0020/q_9/simulation_0020.mp4'); fr = []
for i, f in enumerate(c.decode(video=0)):
    fr.append(f.to_ndarray(format='gray').astype(int))
    if i >= 4: break
for i in range(4):
    d = np.abs(fr[i+1] - fr[i]); print(i, i+1, d.mean(), (d > 20).sum())
    ys, xs = np.nonzero(d > 20)
    if len(xs): print('  bbox', xs.min(), ys.min(), xs.max(), ys.max())
